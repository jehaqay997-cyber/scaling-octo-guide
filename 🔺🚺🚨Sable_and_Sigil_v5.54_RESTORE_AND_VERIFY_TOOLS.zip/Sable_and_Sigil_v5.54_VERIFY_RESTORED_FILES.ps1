param(
    [Parameter(Mandatory = $true)]
    [string] $ProjectPath
)
$ErrorActionPreference = 'Stop'
$manifestPath = Join-Path $ProjectPath 'SOURCE_PRESERVATION_MANIFEST_v5.54.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw 'Source preservation manifest not found.'
}
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$missing = New-Object System.Collections.Generic.List[string]
$mismatched = New-Object System.Collections.Generic.List[string]
$total = 0
foreach ($entry in $manifest.files.PSObject.Properties) {
    $total++
    $relative = $entry.Name -replace '/', [IO.Path]::DirectorySeparatorChar
    $filePath = Join-Path $ProjectPath $relative
    if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) {
        $missing.Add($entry.Name)
        continue
    }
    $actual = (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne [string]$entry.Value) {
        $mismatched.Add($entry.Name)
    }
}
Write-Host ('Original file count: ' + $total)
Write-Host ('Missing files: ' + $missing.Count)
Write-Host ('Content mismatches: ' + $mismatched.Count)
if ($missing.Count -gt 0) {
    $missing | Select-Object -First 20 | ForEach-Object { Write-Error ('MISSING: ' + $_) }
}
if ($mismatched.Count -gt 0) {
    $mismatched | Select-Object -First 20 | ForEach-Object { Write-Error ('MISMATCH: ' + $_) }
}
if ($missing.Count -gt 0 -or $mismatched.Count -gt 0) {
    exit 2
}
foreach ($directory in @('Assets','Packages','ProjectSettings')) {
    if (-not (Test-Path -LiteralPath (Join-Path $ProjectPath $directory) -PathType Container)) {
        throw ('Required Unity directory is missing: ' + $directory)
    }
}
Write-Host 'PASS: All original source files have identical SHA-256 hashes.' -ForegroundColor Green
exit 0
