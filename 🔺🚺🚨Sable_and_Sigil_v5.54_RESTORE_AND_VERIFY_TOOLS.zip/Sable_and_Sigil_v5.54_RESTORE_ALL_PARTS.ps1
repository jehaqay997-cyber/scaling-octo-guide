param(
    [string] $DestinationPath = (Join-Path $PSScriptRoot 'Sable_and_Sigil_v5.54_RESTORED')
)
$ErrorActionPreference = 'Stop'
$archives = @(
    'Sable_and_Sigil_v5.54_PART_1_UNITY_CORE_UNDER_25MB.zip',
    'Sable_and_Sigil_v5.54_PART_2_ART_MASTERS_AND_VERIFICATION_UNDER_25MB.zip',
    'Sable_and_Sigil_v5.54_PART_3_DESIGN_AND_HISTORY_UNDER_25MB.zip'
)
foreach ($archive in $archives) {
    $fullPath = Join-Path $PSScriptRoot $archive
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        throw ('Missing archive: ' + $archive)
    }
}
if (-not (Test-Path -LiteralPath $DestinationPath)) {
    New-Item -ItemType Directory -Path $DestinationPath | Out-Null
}
foreach ($archive in $archives) {
    Write-Host ('Extracting: ' + $archive)
    Expand-Archive -LiteralPath (Join-Path $PSScriptRoot $archive) -DestinationPath $DestinationPath -Force
}
Write-Host 'Verifying restored source files...'
& (Join-Path $PSScriptRoot 'Sable_and_Sigil_v5.54_VERIFY_RESTORED_FILES.ps1') -ProjectPath $DestinationPath
if ($LASTEXITCODE -ne 0) {
    throw ('Verification failed with exit code ' + $LASTEXITCODE)
}
Write-Host ('Unity project: ' + $DestinationPath)
