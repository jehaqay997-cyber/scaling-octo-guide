@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Sable_and_Sigil_v5.54_RESTORE_ALL_PARTS.ps1"
if errorlevel 1 (
  echo RESTORE FAILED. See error messages above.
  pause
  exit /b 1
)
echo RESTORE AND SHA256 VERIFICATION COMPLETED.
pause
exit /b 0
