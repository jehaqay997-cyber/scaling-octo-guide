# Sable & Sigil v5.18 — Chapter Two Navigation Completion Candidate

**Source baseline:** v5.17. **Editor target:** Unity 2022.3.62f3.
**Scope:** Chapter Two locations 03–06; Chapter One, dossier answers, imported art and serialized assets unchanged.

## Implementation

- Added chapter-scoped Back/Escape behavior to `ChapterWorldExplorer` for both the active Unity Input System (`Keyboard.current.escapeKey.wasPressedThisFrame`) and the legacy Input Manager (`Input.GetKeyDown(KeyCode.Escape)`) via compile-time backend selection.
- A Back request consumes exactly one navigation layer. Priority: Chapter Two mechanism modal, original-art viewer, clue comparison, scene camera focus/rotation/zoom, then return to the atlas through the existing `Finish(false)` callback.
- Closing a modal preserves both inspected evidence flags, mechanism verification, attempt count, hint stage and the authored dossier solution. Closing camera focus restores the 8.7-world-unit overview and clears the corresponding transient interaction state.
- Navigation never uses `Finish(true)`, `TryInspectEvidence`, mechanism selection or a persistent save write. It is ignored outside Chapter Two.
- The explicit on-screen `RETURN TO ATLAS`, modal `CLOSE`, and `RETURN TO OVERVIEW` controls remain available; no global input or Android app-exit settings were modified.
- Added two Unity PlayMode source fixtures for the four-site back stack, one-shot callback delivery and Chapter One isolation. They are not executed in this environment.

## Independent, offline verification

- Python regression tests: 692 of 692 successful.
- Offline static gates: 72 of 72 successful. They ran in three separately recorded batches (24/24/24).
- Source inventory retained existing NUnit fixture classes; the intentionally modified PlayMode source fingerprint was updated.
- All prior Unity `.meta` GUIDs, images, scenes and protected assets retained byte-for-byte.
- No Unity compiler, editor PlayMode or EditMode runner, Android emulator or physical device was available. No mobile Back-key dispatch behavior is certified without device evidence.

**Status:** PRE_UNITY_SOURCE_CANDIDATE, NOT RELEASE VERIFIED. Numeric 99% completion cannot be substantiated until Unity acceptance is executed and recorded.

## Primary API references

- Unity Android Back input: https://docs.unity.cn/Documentation/ScriptReference/Input-backButtonLeavesApp.html
- Unity Input System keyboard: https://docs.unity3d.com/ja/Packages/com.unity.inputsystem%401.4/api/UnityEngine.InputSystem.Keyboard.html
