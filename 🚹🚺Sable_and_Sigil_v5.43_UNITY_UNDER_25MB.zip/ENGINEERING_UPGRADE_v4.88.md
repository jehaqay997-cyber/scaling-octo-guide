# Sable & Sigil v4.88 — Procedural 3D Chapter Case Engineering Review

**Source baseline:** v4.87 / **Editor target:** Unity 2022.3.62f3
**Evidence state:** STATIC_SOURCE_ACCEPTED; UNITY_COMPILE_NOT_EXECUTED.

## Implemented playable prototype source

- Added `ChapterWorldSceneCatalog`: ten immutable 3D location specifications across four chapters (2 / 4 / 3 / 1). Each maps to the existing story graph, the original location image and two already-authored dossier evidence fragments. The catalog does not award completion.
- Added `ChapterWorldExplorer`: an on-demand, bounded procedural 3D set for each location, including backdrop with the original art texture, scene-specific silhouettes and clue geometry, isolated camera, layered evidence colliders, orbit and zoom buttons, accessibility shortcuts, safe-area HUD, and per-open cleanup of native materials and objects.
- Added visual evidence labels connected to the actual mathematical or logical case constraints (crest ray count, periodic balusters, lunar cycle, additive petals, spout ordering, compass directions, stained glass, historical dates, epitaph, meridian rules). These are low-poly authored prototypes, not photorealistic final architecture.
- Integrated `EXPLORE 3D` into the existing chapter gallery: only unlocked cases can launch world exploration. The underlying Chapter One camera stays suspended and the world is isolated from unrelated game layers.
- Passing both ephemeral world inspections opens the existing `StoryDossierView` with both fragments read, preserving the original revision-bound `StoryDossierSession.TrySubmit` as the **sole durable completion owner**. World exploration never writes `PlayerPrefs` and never changes save schema.
- Added Unity Editor content/material validation and EditMode plus PlayMode source tests for all ten 3D scene sets, input gates, camera isolation, evidence transfer, texture ownership, and cleanup. Those C# tests are authored but **NOT executed**.
- Enhanced static governance to verify art SHA-256, exact 1280x720 images, chapter/location consistency, anti-bypass controls, resource cleanup and non-promotion of unexecuted runtime evidence. Fixed legacy gallery contract checks to account honestly for interactive 3D **prototypes**, not completed chapter scenes.
- Avoided editing any pre-existing image, Unity GUID, `.meta`, package manifest, project setting or save key.

## Static evidence executed in this environment

- Python regression suite: **286/286 passed** (all in local Python, not Unity).
- Maintained static gates: **43/43 passed**, or **44/44 sequential stages** when the final Python suite is included.
- New independent 3D design gate: **10 source scene specs; 10 art SHA-256 digests matched**, with 2/4/3/1 scene distribution.
- Full immutable v4.87 ZIP preservation and per-file SHA-256 release manifest generated; CRC and ZIP re-read performed independently.
- A test-log creation issue was identified when writing stdout directly to a zero-byte log path inside the source tree. Evidence logs were instead captured outside the candidate and copied back after completion.

## Scope boundaries and risk decisions

1. All 10 3D environments are generated **at runtime**, not serialized as prebuilt `.unity` scenes. The only chapter with an existing authored narrative runtime is Chapter One. Chapter II–IV are now accessible as 3D case prototypes when their evidence gates unlock, but complete 3D chapters, cinematics, final meshes and photorealistic sets are not yet developed.
2. Existing 1280x720 location images are integrated as textured reference panels. No claim is made that their geometry has been reconstructed as high-fidelity 3D. Original art files remain byte-for-byte unchanged.
3. `ChapterStoryGraph.HasPlayableScene` stays false, and full-chapter entry remains disabled for Chapters II–IV. This is intentional: prototype availability is not proof of completion.
4. Shaders, camera rendering, lighting, 3D text, raycast hit regions and UI safe-area performance are **unverified at runtime** until Unity and device tests execute. Shader fallback is guarded but import/build compatibility has not been exercised.
5. No Unity Console log, C# compiler result, EditMode/PlayMode XML, Android APK/AAB or phone profiler recording was produced here. `DESIGN_VERIFIED` is partial; `COMPILE_VERIFIED`, `TEST_VERIFIED` and `DEVICE_VERIFIED` remain **not verified**.

## Acceptance gate in Unity

- Import the candidate independently into Unity **2022.3.62f3**, retaining Safe Mode if compilation errors appear. Capture all Console errors with file and line.
- Execute **Sable & Sigil > Validate 3D Case Prototypes** and retain its Console output.
- Run EditMode tests including `ChapterWorldSceneCatalogTests`; then PlayMode tests including `ChapterWorldExplorerPlayModeTests`, `StoryDossierPlayModeTests`, Chapter One tests and all existing save-fault tests. Preserve Test Runner XML and `Editor.log`.
- Start Chapter One, open the chapter gallery, select an unlocked case, use `EXPLORE 3D`, inspect relics A/B, rotate/zoom, open deduction, verify the original save ledger after the correct answer and ensure the case does not get credited twice. Repeat at each chapter transition.
- On Android, inspect memory and FPS across 10 scene openings, save/reload, pause/resume and interrupted writes. Confirm touchscreen UI safe-area behavior and native material/camera cleanup.

## References

- Unity 2022.3 physics raycasts: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Physics.Raycast.html
- Unity 2022.3 assembly definitions: https://docs.unity3d.com/2022.3/Documentation/Manual/AssemblyDefinitionFileFormat.html
- Unity Test Framework 1.1: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/index.html
- NIST SSDF SP 800-218: https://csrc.nist.gov/pubs/sp/800/218/final
