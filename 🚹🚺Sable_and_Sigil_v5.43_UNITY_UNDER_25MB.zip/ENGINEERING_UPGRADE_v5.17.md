# Sable & Sigil v5.17 — Chapter Two Pre-Unity Completion Candidate

Editor target: **Unity 2022.3.62f3**. Base version: **v5.16**. The scope is limited to Chapter Two authored locations **03–06**.

## Delivered source work

- Chapter Two mechanism camera close-up: a visual-only, chapter-gated `FOCUS MECHANISM` command for all four authored locations. The centered target is `(0, 2.23, 0.10)` and initial camera distance is **6.2**, with separate continuous **4.3–8.8** zoom limits. This prevents the jump to room minimum distance **6.6** that would otherwise occur during close-up manipulation.
- Close-up focus is mutually exclusive with evidence-focus and overview state, and blocked while an artwork, comparison, crest, spiral or Chapter Two modal viewer is active. Close/reopen resets the focus, pointer gesture and pinch state. The command does not inspect evidence, select any answer, reveal hints or commit progress.
- Site-specific relief geometry preserves existing mesh ownership and the 512 triangle cap. Rose and lunar geometry generation now preallocates **768** items per vertices/normals/triangles list, avoiding capacity growth for the largest authored 231-triangle relief. Correct-answer rebuild still reuses the same Unity Mesh.
- Added PlayMode regression for close-up/zoom/modal guards across locations 03–06 and one full four-location investigation-to-dossier callback regression; both are **unexecuted NUnit source fixtures** pending Unity testing.
- Added a standalone static source contract and 15 adversarial mutation checks for lens bounds, state isolation, no invented success, mesh budget and UI wiring. Bumped the acceptance runner source baseline to **v5.17**, retaining all previous fixture identities and updating the reviewed PlayMode source hash.

## Offline evidence and scope boundary

- **673/673** Python tests passed.
- **71/71** offline gates passed (first 50 in a bounded run, remaining 21 executed separately).
- The earlier Chapter One source, story dossier answers, serialized scenes, original images, Unity `.meta` GUIDs and package definitions were not changed.
- There is **no Unity Editor, C# compilation, actual PlayMode/EditMode run, screenshot review or Android/device measurement** in this execution environment.

**Approval status:** PRE_UNITY_SOURCE_CANDIDATE, NOT RELEASE VERIFIED. The requested 99% is a *target*, not a defensible measured completion percentage until the acceptance checklist runs in Unity.
