# Launch and inspect Sable & Sigil v4.54

1. Extract the complete archive into a local Windows folder.
2. Use Unity 2022.3.62f3 and open `OPEN_GAME.cmd`.
3. Once the existing Chapter One initializes successfully, press `CHAPTERS`, then `SCENE ATLAS`.
4. Use `PREVIOUS SCENE` and `NEXT SCENE` to inspect all ten user-provided visual references.
5. The location artwork is not itself a complete interactive puzzle. Future locations remain non-playable until implemented and verified.
6. Read `ENGINEERING_ACCEPTANCE_v4.54.md` for evidence boundaries.
