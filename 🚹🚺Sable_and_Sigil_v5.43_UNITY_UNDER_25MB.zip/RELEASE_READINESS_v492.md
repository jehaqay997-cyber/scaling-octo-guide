# Sable & Sigil v4.92 — Launch Acceptance Candidate

## Baseline and scope

The validated source baseline is **v4.91**. v4.92 adds a guarded Unity import/scene/asset preflight, Windows launch-acceptance wrappers, a standalone static source validator, source mutation tests, and static gate integration. It does **not** rewrite puzzle gameplay, PlayerPrefs keys, artwork, Android application identifiers, assemblies, or other authored assets.

**Unity Editor target: 2022.3.62f3 (exact).** The source is accepted for controlled Editor evaluation. **Commercial release is NOT approved.** Unity Editor, Test Runner and Android SDK were not available in the packaging environment.

## Operational acceptance contract

- `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` runs an exact-version Unity batch preflight that creates and validates both chapter and integrated scenes, checks 3D reference art and build order, and then invokes the existing Unity verification runner.
- EditMode and PlayMode must each emit complete, passed NUnit XML with required fixtures; a successful Unity process exit code is insufficient.
- Editor validation and NUnit results must preserve source and generated-scene fingerprints.
- `RUN_SABLE_ANDROID_BUILD_GATE.cmd` adds a verified development APK build, structural APK inspection, and checksum verification.
- The physical device must still be tested. No script changes `device_verification` from `NOT_VERIFIED`.
- Any failure produces `BLOCKED` and nonzero exit status. Missing generated scenes and a missing package lock before first import are expected and explicitly listed as pending Unity work.

## Validation performed outside Unity

- 319 of 319 Python tests passed.
- 47 of 47 static gates passed: 46 executed sequentially and the final gate run separately after the overall aggregate timeout.
- 7 assembly definition files were parsed; required domain/test references were checked and there were no duplicate asset GUIDs.
- The four chapter images and ten location images passed the 1280×720 JPEG contract.
- ZIP CRC and per-entry SHA-256 are checked again after packaging.

## Unverified requirements

- `COMPILE_VERIFIED`: NO — actual Unity compilation never executed here.
- `EDITMODE_VERIFIED`: NO — NUnit tests are authored but not run in Unity here.
- `PLAYMODE_VERIFIED`: NO — graphics, scene flow and 3D interaction need Unity execution.
- `ANDROID_BUILD_VERIFIED`: NO — no APK/AAB was created here.
- `DEVICE_VERIFIED`: NO — physical Android input, save lifecycle and frame pacing need hardware evidence.

The status from `Verification/release_source_preflight_v492.py` is deliberately `STATIC_SOURCE_ACCEPTED_UNITY_PENDING` and cannot be promoted to release approval by static checks.

## Primary source documents

- Unity 2022.3 Editor command line: https://docs.unity.cn/2022.3/Documentation/Manual/EditorCommandLineArguments.html
- Unity Test Framework 1.1.33: https://docs.unity.cn/Packages/com.unity.test-framework%401.1/manual/index.html
- Unity Test Framework command-line runs: https://docs.unity.cn/Packages/com.unity.test-framework%401.1/manual/reference-command-line.html
