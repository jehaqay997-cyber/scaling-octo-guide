# Sable & Sigil v5.22 — Chapter Three Final Pre-Unity Source Closure

**Source baseline:** v5.21  
**Unity target:** 2022.3.62f3  
**Scope:** Chapter Three locations 07–09, with one inherited Chapter Two compile-type fix.  
**Status:** Source candidate; Unity compilation and actual runtime acceptance NOT EXECUTED.

## P0 C# type corrections

The 3D world caption variables `chapterTwoWorldMark` and `chapterThreeWorldMark` had the `UnityEngine.UI.Text` field type even though `GetComponent<TextMesh>()` assigned a `UnityEngine.TextMesh`. The two class hierarchies are incompatible, so these assignments are compile blockers. Both field declarations now use `TextMesh`, preserving their original 3D GameObjects and authored behavior. The new static regression audit independently inspects declared field types and `GetComponent<T>` assignments and includes mutation tests that restore the erroneous declarations.

This review demonstrates removal of those **source-level type mismatches**, not a full compilation of the Unity project.

## Chapter Three staged 3D disclosure

The pre-existing v5.21 protection applied to `TextMesh.text` but not to the adjacent carved 3D mesh. The unsolved authored geometry was previously drawn before both independent fragments were inspected. The relief now has explicit `Locked`, `Investigating`, and `Restored` states. Location-specific locked decorations conceal glyph ordering, timeline markings and the missing letter position. After both clues, the existing mesh reveals the incomplete problem; after successful verification, the same owned mesh shows the restored answer. The stage is cached, so unrelated HUD updates do not rebuild the mesh.

`ChapterThreeReliefMesh.Create/Rebuild(int, bool)` remain as backwards-compatible APIs, while the 3D world uses the typed stage overload. Invalid stages are rejected before any mesh mutation. Source media, authored answers, puzzle progress and dossier persistence have not been changed.

## Test and verification scope

- Existing EditMode/PlayMode fixtures were extended to assert three visually distinct geometric stages, consistent one-clue locking, mesh identity, bounded triangle count and non-destructive invalid-state handling. These tests are authored but **not executed in Unity**.
- Added `verify_chapter_three_closeout_v522.py` and mutation regression suite, and appended a new offline audit gate.
- Updated the current acceptance version and SHA-256 inventory for the two changed NUnit fixture sources.
- Original Unity `.meta` GUIDs, authored images, scenes and imported assets are preserved byte-for-byte.

## Remaining validation

Unity 2022.3.62f3 must open and compile the project, resolve package dependencies and generate the authored scenes, then pass EditMode, PlayMode, art/lighting inspection, navigation, and Android device profiling. No `.unity` scene files or resolved `packages-lock.json` have been invented. The release remains unapproved until editor evidence exists.
