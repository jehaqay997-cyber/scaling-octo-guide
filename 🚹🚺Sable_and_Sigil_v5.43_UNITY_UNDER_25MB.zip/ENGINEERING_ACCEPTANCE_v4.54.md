# Sable & Sigil v4.54 — User-Approved Location Reference Integration

## Scope

- Integrated all ten user-supplied reference images as a traceable, separate visual atlas.
- Original JPEGs preserved exactly in `Design/LocationSourceReferences/`.
- Created full-subject 1280x720 display renditions with aspect-ratio-safe containment, a subtle dimmed extension for unused areas, and no nonuniform scaling.
- Integrated the atlas into the existing `ChapterGalleryView` through the `SCENE ATLAS`, `PREVIOUS SCENE`, and `NEXT SCENE` controls.
- Loaded location textures on demand and released the previous location texture to limit memory residency.
- Linked each scene to a proposed story beat and puzzle concept in `Design/LOCATION_ART_AND_PUZZLE_MAP_v4.54.json`.
- Only the original Chapter One implementation remains a playable candidate. All ten atlas scenes explicitly remain visual references and do not unlock content.
- Added a PlayMode test that must run in a real Unity Editor to verify display integrity and lock state.
- Added an offline image checksum, source-preservation, size, and contracts gate; integrated it into the complete offline audit.

## Visual asset handling

Source images are portrait or landscape, with varying dimensions. To prevent stretching in landscape:
1. Preserve the complete source frame using uniform (isotropic) scaling.
2. Center it within a 1280x720 frame.
3. Fill only the unused strips with a dim, blurred continuation of the image.
4. Use the scene atlas `RawImage` and `FitArtwork()` for intrinsic aspect-ratio enforcement.

These images are concept references used in Unity UI. They are **not** 3D meshes, photogrammetry, PBR material sets, or automatically generated playable environments.

## Evidence classification

- ZIP, source preservation, checksum, JPEG geometry and Python tests: independently verifiable offline.
- Unity C# compilation: NOT EXECUTED.
- PlayMode and EditMode: NOT EXECUTED.
- Interactive 3D puzzle completion for new locations: NOT IMPLEMENTED.
- Android performance and device testing: NOT EXECUTED.

## Unity compatibility

The project preserves its registered editor version `2022.3.62f3`. Run `OPEN_GAME.cmd` on Windows and use `CHAPTERS` then `SCENE ATLAS` inside the first chapter. A migrated Unity 6.3 build has not been verified.
