# TheOrderRoom v4.43 — Source Inspection and Verification

This archive is a complete Unity source candidate, not an already-compiled game.

Unity version pinned in ProjectSettings/ProjectVersion.txt: 2022.3.62f3.

1. Extract the ZIP to a dedicated local Windows directory outside cloud sync.
2. Open the directory containing Assets, Packages and ProjectSettings in Unity Hub
   with the exact pinned Unity editor version.
3. To run an offline source audit with Python 3.9+, execute:
   `python Verification/run_full_static_audit_v443.py`
4. To compile, generate/validate the scene and execute EditMode/PlayMode tests
   using Windows PowerShell, execute:
   `powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1`
5. To perform those stages and then build a development APK, install Unity
   Android Build Support, SDK, NDK and OpenJDK and execute:
   `powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1 -BuildAndroid`
6. Review Verification/LocalResults/verification.json, Unity logs and NUnit XML.
   A failing or missing stage always blocks release acceptance.

The editor bootstrap generates Assets/_Project/Scenes/Main.unity on the first
successful import. A pre-generated scene is intentionally not shipped.

Do not switch to Unity 6.x or another editor without a separate controlled
migration and compilation test. No APK or Android device test is included.
