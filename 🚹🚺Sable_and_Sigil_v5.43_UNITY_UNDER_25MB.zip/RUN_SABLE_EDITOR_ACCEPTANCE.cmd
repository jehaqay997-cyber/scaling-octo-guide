@echo off
setlocal
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0Verification\Run-SableAcceptance.ps1" -ProjectPath "%~dp0."
if errorlevel 1 (
    echo Acceptance blocked. Inspect the generated verification logs.
    exit /b 1
)
echo Unity Editor and NUnit acceptance passed. Android and device validation remain separate.
exit /b 0
