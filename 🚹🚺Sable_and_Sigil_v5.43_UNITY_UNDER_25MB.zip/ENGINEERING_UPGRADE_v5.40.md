# Sable & Sigil — v5.40 Source Engineering and Playability Audit

**Unity Editor compatibility target:** `2022.3.62f3` only.  
**Release classification:** editor-test candidate, not a verified game build.  
**Reference direction:** original, photorealistic gothic environmental puzzle adventure; classic hidden-object adventure pacing as a design benchmark, never copied third-party artwork or assets.

## Actual defects corrected

1. **Unreachable scene interactions.** A previous zoom control occupied the screen position of the seventh investigation's mechanism. The panoramic zoom tools are now in a reserved lower-left gutter; the scenic/3D mode control uses a lower-center position in scenic mode and its original position in 3D mode. New pure-domain `CinematicHudClearance` evaluates four HUD rectangles versus all thirty authored interaction rectangles across ten investigation locations at the canonical 1600x900 viewport, and is required by `CinematicSceneMap.Validate()`. Domain EditMode, PlayMode and adversarial Python regressions were added. The proof applies at the authored default viewport and is not a substitute for a full touchscreen matrix under dynamic layout/zoom changes.
2. **Chapter-one modal navigation.** Android Back/Escape now dismisses the current evidence, mechanical focus, and gallery overlays in the intended order; stale callbacks cannot navigate away while a chapter-one modal remains open.
3. **Interactive gesture ownership.** Right-click cannot initiate panorama dragging; an unrelated touch pointer cannot end or steal the active drag, and focus loss resets the pinch state.
4. **Asset ownership and memory lifecycle.** The world explorer now releases only the featured `Resources.Load` panorama texture it owns and detaches the active `RawImage` first. It does not unload the gallery's separately owned reference texture. This is a lifecycle fix, not an empirically measured Android memory reduction.
5. **Noncritical audio failure containment.** On procedural atmosphere creation failure, the audio source is detached from the failed clip, the native clip is released, and the state is reset; the investigation itself continues.
6. **Obsolete PlayMode hint assertions.** `ChapterStoryIntegrationTests` previously asserted hint disclosure on initial view and infinite wraparound, contrary to the actual v5.33+ game rules. It now creates a valid three-completed-case checkpoint for location four, asserts zero hints before user request, exactly three explicit hint tiers, no fourth-tier wraparound, locked-case hint suppression, and restoration of both saved PlayerPrefs slots after the test.
7. **Verification inventory.** Updated NUnit source hashes and registered additional static geometry/lifecycle/input checks and Unity tests. Acceptance revision is now v5.40. The original Unity version and previous source assets are preserved.

## Chapter/story/puzzle/art assessment

- **Authored structure:** four chapters, ten sequential evidence investigations, mathematically checked clues and a four-part finale requiring all ten verified cases.
- **Current imagery:** ten original source photographs are preserved. Six locations (1, 2, 4, 5, 7, 10) have additional cinematic 16:9 plates; four (3, 6, 8, 9) remain on older portrait-oriented photographic references with embedded soft margins. All chapter and location images remain unmodified in this release.
- **3D status:** interactive 3D puzzle inspection and actual torus-based meridian rings exist; most environments are hybrid photographic 2.5D and procedural 3D objects. Neither complete photorealistic explorable 3D architecture nor full visual equivalence to a commercial benchmark has been proved.
- **World-state contract:** clue thumbnails and ornamental symbols must not authorize puzzle completion; dossier revision and prerequisites remain authoritative. Current v5.40 changes do not migrate or rewrite the story save schema.
- **Remaining art risks:** interactive hit placement must be observed in the final imported sprites and all relevant Android aspect ratios, especially locations with inherited portrait art; seasonal light/material continuity requires an in-editor art pass. The new images are not proof of camera-safe or physically accurate 3D geometry.

## Independent validation delivered

- Existing and new Python unit and mutation suite: **1,017 passing tests**, re-run from the extracted archive.
- Source verification commands: **94/94 passing gates**, re-run from the extracted archive.
- Archive: CRC validation, manifest SHA-256 for every shipped source entry, previous archive preservation, nonzero source file sizes, Unity GUID uniqueness, original `.meta` identity preservation, and Pillow decoding for all packaged photographs.
- NUnit EditMode and PlayMode fixtures are **authored but not executed**.

## Explicitly unverified release blockers (P0)

1. Unity 2022.3.62f3 Editor source import, actual C# compile and package/asmdef resolution.
2. Test Runner EditMode/PlayMode NUnit XML results from actual Unity execution.
3. From-clean-save game completion, all ten puzzles, four chapters, coda/finale unlock, scene switching and crash-free back navigation on a real touchscreen.
4. Device-specific touch accuracy, portrait/landscape safe-area, texture residency, frame timing, thermal stability, sound playback, and Android device install.
5. Android publish compliance, signing/security review, supported Android API settings and package-lock resolution. Local PlayerPrefs are not encrypted, and no sensitive secrets should be stored there.

**No Unity Editor, C# compiler, Android SDK, GPU measurement, or physical device was available to the offline verification environment.** It would be incorrect to claim zero remaining bugs or production readiness.

## Exact test procedure for the recipient

1. Extract the entire ZIP into a local non-synced folder on the computer; retain `.meta` files, `Packages` and `ProjectSettings`. Do not open from ZIP or cloud placeholder folders.
2. Unity Hub: open the extracted root specifically with **Unity 2022.3.62f3**. Avoid concurrent Editor sessions.
3. Inspect `Console`, Unity Package Manager and assembly compilation; if Safe Mode appears, save the **complete** compiler log, not merely a screenshot of the first error.
4. From the extracted project root, run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` on Windows and preserve the resulting JSON, XML and Editor logs. The included PowerShell acceptance gate checks Editor version, source import, chapter scenes, EditMode and PlayMode results; optional Android acceptance requires its own build evidence.
5. Test chapters I–IV in order, case clues 1–10, first-view hint concealment, third-hint lockout, pan/touch and Back during each modal, chapter-four meridian rings, save recovery and final record access after exactly ten completed cases.
6. Only after source import, NUnit success and a complete manual playthrough should the game be considered **playable on the tested configuration**. Android release needs separate device testing and publishing approval.

## Scope discipline

No new fifth chapter, original cinematic photography, new character models, premium PBR world, licensed commercial soundtrack, or market-ready APK was fabricated in this pass. These are distinct production workstreams, not defects hidden by static source success.
