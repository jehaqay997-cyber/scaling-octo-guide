# TheOrderRoom v4.39 — UI Event Delivery and Release Readiness Audit

## Verified source baseline
- Based on the actual v4.38 final-audit-corrected source archive.
- Editor version remains `2022.3.62f3` as specified by `ProjectSettings/ProjectVersion.txt`.
- No runtime game code, save schema, assembly definition, GUID, or scene bootstrap logic changed.
- Excluded generated Python bytecode caches from the deliverable (not authored project files).

## Confirmed verification blind spot
`OrderSceneValidator.ValidateScene` checked that an EventSystem, UI input module, Canvas, and Button callbacks existed but did not require the active module, the canvas GraphicRaycaster, and button raycast targets to be active. A malformed scene could therefore pass static/editor scene validation even though UI pointer clicks cannot reach buttons.

## Implemented root-cause remediation
In `Assets/_Project/Editor/OrderSceneValidator.cs`:
1. Require the expected input backend module to be present and `isActiveAndEnabled`.
2. Reject multiple simultaneously active `BaseInputModule` components.
3. Require each active Canvas to have an enabled `GraphicRaycaster`.
4. Require every interactive button to have an active `targetGraphic` that accepts raycasts.
5. Require every button to belong to an active raycast-capable Canvas.
6. Preserve exact persistent callback matching for all 13 existing buttons.

## Verification evidence
- Python unit tests: **61 passed**, including 6 new static-gate mutation checks.
- The independent architecture gate returned `STATIC_PASS_ONLY` with zero reported issues and six assemblies.
- The governance gate completed successfully; the restricted adventure oracle reported 20 reachable states, 34 transitions, 3 winning states, and zero softlocks within its model.
- ZIP CRC and SHA-256 manifest checked after packaging.

## Explicit verification limitations
- Unity Editor, a C# compiler, and Android hardware were not available in this execution environment.
- The added checks execute when the Unity Editor scene validator is run, but they have **not** themselves been compiled or executed inside Unity here.
- The distributed archive does not contain a generated `Assets/_Project/Scenes/Main.unity`; `OrderProjectBootstrap.BuildAndValidateBatch()` must generate and validate it on first import.
- The scripted source may still contain runtime, PlayMode, Android, persistence, energy, and game integration defects that static tests cannot find.

## Acceptance sequence (mandatory, in order)
1. Import a clean local clone using the exact Editor shown in ProjectVersion.txt; verify packages resolve without Safe Mode.
2. Execute `Verification/Run-UnityVerification.ps1` from Windows and require a zero exit code, an emitted bootstrap marker, `verification.json` status `PASS`, and passing NUnit XML.
3. Add and run PlayMode acceptance scenarios: buttons from uGUI input module; touch drag, cancellation, UI interception; undo/redo/reset; inspection and artifact claim; save/resume including corrupted and future-version saves.
4. Build and launch Android on the target device and capture logs, frame times, GC allocation, RAM, temperature, and lifecycle recovery behavior.
5. Keep shipping blocked until all four stages are evidenced and unresolved P0 issues are zero.

## Technical reference
Unity 2022.3 Runtime UI Event System manual: https://docs.unity3d.com/2022.3/Documentation/Manual/UIE-Runtime-Event-System.html
Unity Input System UI module: https://docs.unity3d.com/Packages/com.unity.inputsystem@1.4/api/UnityEngine.InputSystem.UI.InputSystemUIInputModule.html
Unity GraphicRaycaster documentation: https://docs.unity3d.com/2018.3/Documentation/Manual/script-GraphicRaycaster.html
