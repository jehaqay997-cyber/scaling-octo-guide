# Sable & Sigil v4.90 — Three-Dimensional Scene and Visual Reliability Upgrade

**Unity compatibility target:** `2022.3.62f3`  
**Baseline:** v4.89 source archive, preserved except declared changes  
**Classification:** SOURCE-VALIDATED CANDIDATE; UNITY COMPILATION AND PLAYMODE UNVERIFIED

## P0 — Confirmed visual defect

The location reference panel was a Unity `PrimitiveType.Quad` rotated 180 degrees on the Y axis. Unity's default quad front faces local negative Z; the isolated scene camera is at negative Z. The rotation made the photo panel face away from the player, potentially causing backface culling. The panel now uses `Quaternion.identity`, and a PlayMode assertion verifies positive camera-facing alignment for every location.

Primary reference: https://docs.unity.cn/2022.1/Documentation/Manual/Example-CreatingaBillboardPlane.html

## P1 — Actual scene construction upgrades

1. Added a double-sided, curved pointed barrel-vault mesh (`ChapterWorldVaultGeometry`). The underside is visible from the camera and uses independent vertices/normals from the upper face. Geometry uses bounded deterministic dimensions, tiled UVs and explicit triangle winding.
2. Added repeatable chapter-specific masonry albedo (`ChapterWorldStoneSurface`) with mortar joints, fine deterministic grain and 128x128 RGBA32 mipmapped texture. CPU pixel storage is discarded after uploading texture data. No image assets are overwritten.
3. Bound the new stone albedo to existing wall/slate materials with consistent UV tiling. The ten authored location reference JPEGs and their `.meta` files remain unchanged.
4. Registered the vault as a fourth owned procedural mesh and stone albedo as an owned texture in the explorer. Both are destroyed on close, disable or destroy; no persistent puzzle state is modified.
5. Added Unity EditMode tests for finite geometry, vertex/triangle/index bounds, normals, UVs, invalid inputs, texture determinism and CPU-copy disposal. Extended all-ten-world PlayMode tests for visual-facing orientation, resource cleanup and scene budget.

### Geometric and resource budgets (source-derived, not device measurements)

- Vault at 20 transverse and 8 longitudinal segments: **378 vertices / 640 triangles** (two independent faces).
- Three existing arches at 16 segments: **408 vertices / 792 triangles** combined.
- Total newly and previously owned procedural architecture per open world: **786 vertices / 1,432 triangles**, excluding built-in primitive meshes.
- Stone texture: 128x128 RGBA32, 16,384 pixels, **87,380 bytes of uncompressed mip levels** before API/driver overhead. Exactly one per open world, not shared globally.
- No new camera, save key, archive-scene file, material package, external dependency or original image replacement was introduced.

## Verification evidence

- All **303 Python regression tests** passed. These are static/source mathematical tests, not Unity tests.
- All **45 maintained standalone static gates** passed when executed in three separately recorded batches. The legacy full-audit wrapper exceeded its external execution time budget before completing. This does not invalidate independently completed gate results but is not a claim that the wrapper completed.
- Unity EditMode and PlayMode tests were authored but could not be run here; no Unity Editor executable was available.
- No rendered screenshot, measured FPS, Android build, live memory profile, compiled assembly or Unity test-runner XML has been produced.

## Release blockers and priorities

**P0:** Open in Unity 2022.3.62f3; inspect Console and Test Runner; verify `asmdef` references and installed package versions; generate/validate the entry scene and `packages-lock.json` through Unity; run EditMode and PlayMode.  
**P1:** Render all ten 3D locations on target GPU, capture camera-facing panel and vault screenshots, inspect normals/material shader compatibility, prove save-key preservation and repeated open/close resource release.  
**P2:** Replace procedural set-dressing with scene-authored high-fidelity geometry, optimized textured assets, lighting probes/baking and LOD where beneficial; profile draw calls, memory, frame time and thermal behavior on Android hardware before asserting quality targets.

**Not claimed:** photorealistic reconstructions of the ten JPEG scenes, fully playable authored 3D chapters II–IV, Android compatibility or release readiness.
