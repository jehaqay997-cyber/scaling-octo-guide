# Sable & Sigil v5.00 — Imported Scene Binding Integrity

Unity target: `2022.3.62f3`. Source baseline: `v4.99`.

## Actual source changes

- Audits all imported `Assets/` scene dependencies, rejecting links outside `Assets/_Project` rather than silently skipping them.
- Inspects both generated scenes with additive, read-only editor loading; restores the preceding active scene and closes scenes opened by the validator.
- Detects missing MonoBehaviour scripts on all scene GameObjects, including inactive children.
- Checks every compiled project MonoBehaviour against its originating `MonoScript`, class name, source path, and asset GUID round trip.
- Checks serialized `ObjectReference` properties for unresolved nonzero reference instance IDs.
- Rejects unsaved scenes during binding validation.
- Adds 15 Python contract and negative mutation tests, and exports a new per-source file linkage map.
- Updates the acceptance-runner baseline to `v5.00` without changing the required Unity Editor version.

## Preservation

No existing game graphics, puzzles, chapter data, runtime scene building behavior, persistence schema, `.asmdef`, or existing `.meta` file is intentionally changed. The previous source remains the recovery baseline.

## Verification boundary

Python and static source audits cannot establish Unity C# compilation, imported asset binding at runtime, successful NUnit execution, Android builds, or device readiness. Only the Unity 2022.3.62f3 acceptance runner can generate their primary evidence. Generated `Main.unity` and `ChapterOne.unity` scenes are not present in source archive prior to running the Editor.

## Primary references

- Unity 2022.3 Manual: Assembly definitions: https://docs.unity3d.com/2022.3/Documentation/Manual/ScriptCompilationAssemblyDefinitionFiles.html
- Unity 2022.3 Scripting API: MonoScript: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/MonoScript.html
- Unity 2022.3 Scripting API: AssetDatabase: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/AssetDatabase.html
- Unity 2022.3 Scripting API: SerializedObject: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/SerializedObject.html
