# Sable & Sigil v4.96 — Case Inlay Geometry and Original Artwork Examination

## Source
- Baseline: v4.95 (exact source ZIP, all original members retained).
- Unity compatibility target: **2022.3.62f3**.
- Delivery: **source candidate, not a certified Unity or Android build**.

## Implemented improvements

### Authored 3D floor inlays across ten locations
- `Assets/_Project/Runtime/ChapterWorldFloorSigilGeometry.cs`: builds a finite, UV-mapped, upward-facing radial inlay for every case. Two disjoint sets of spokes correspond to the *counts* of the two authored evidence motifs, not to puzzle answers.
- Mesh consists of two tessellated rings (48 and 32 segments), plus the A and B spoke groups. Per-case budget: maximum **384 vertices** and **192 triangles**. All geometry is owned by the current chapter world, uses the existing brass material, belongs to scenery layer 26, and has no collider.
- `ChapterWorldExplorer` disposes the fifth owned mesh with the original three pointed arches and vault on world closure. The inlay is noninteractive and is not a solver or save-state authority.

### Inspectable original reference artwork
- `ChapterWorldExplorer`: a **VIEW ORIGINAL ART** control opens a dedicated focused `RawImage` presentation that uses the *same imported texture* as the 3D rear exhibit. The image is aspect-fitted without modifying the source texture.
- Artwork zoom is clamped to **1.0–3.0**, with centered UV cropping only at zoom values over 1.0. Closing and reopening resets the image zoom to 1.0.
- The dark overlay blocks taps on the 3D world; pending drag/pinch state is cancelled when opening/closing. Artwork review does not count as case evidence and cannot grant game progression.

## Verification implemented
- Existing `ChapterWorldVaultGeometryTests` EditMode fixture extended with all ten mesh geometry, determinism, UV, normal orientation, invalid-location and budget assertions.
- Existing `ChapterWorldExplorerPlayModeTests` extended with owned sigil lifecycle, collider isolation, original imported artwork identity, zoom bounds, reopen/close behavior and unchanged investigation state.
- The reviewed NUnit source hash inventory reflects both modified fixtures; no unrelated fixture was dropped.
- Added an independent mathematical oracle in `Verification/verify_world_artwork_and_sigil_v496.py` and 12 mutation tests in `Verification/test_world_artwork_and_sigil_v496.py`.
- The historical v4.89 and v4.90 gates were updated only for the deliberately increased owned mesh count (4 -> 5).
- The Unity acceptance baseline identifier is now v4.96 (its binary execution remains unverified).

## Limits / nonclaims
- This version does not replace the authored location photography or produce photorealistic room meshes. The photo is shown in an enlarged reference viewer; the room is still procedural.
- These radial inlays represent evidence-group counts **visually**; they do not introduce new puzzle mechanics, alter answer truth, advance dossiers, or write save files.
- The environment **does not have Unity Editor, a Unity C# compiler, GPU frame output, or Android hardware**; those execution stages remain pending even if every offline gate passes.
- Material appearance, camera occlusion and mobile frame timings must be checked in Unity 2022.3.62f3 on actual target devices.

## Unity acceptance instructions
1. Extract the complete v4.96 ZIP to a local non-synced folder.
2. Open using **Unity 2022.3.62f3** and run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` with the editor closed before batch startup.
3. Retain the Unity editor log, generated scenes and NUnit XML. Do not mark compile/test success if the acceptance command fails.
4. Inspect all ten locations: verify **VIEW ORIGINAL ART**, overlay zoom and return to 3D, as well as the two distinct relics and non-colliding inlay.
5. Confirm the two-evidence deduction gate, original image appearance, no texture destruction on close, and stable Android GPU frame time after repeated location changes.

## Documentation references
- Unity 2022.3 Graphics Performance Fundamentals: https://docs.unity3d.com/2022.3/Documentation/Manual/OptimizingGraphicsPerformance.html
- Unity 2022.3 Optimizing Draw Calls: https://docs.unity3d.com/2022.3/Documentation/Manual/optimizing-draw-calls.html
- Unity 2022.3 Mesh API: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.html
- Unity 2022.3 UI RawImage: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/UI.RawImage.html
