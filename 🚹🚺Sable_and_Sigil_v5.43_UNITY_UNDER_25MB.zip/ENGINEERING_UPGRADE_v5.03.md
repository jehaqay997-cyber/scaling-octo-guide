# Sable & Sigil v5.03 — Artwork Navigation and Authored 3D Evidence Reliefs

**Target editor:** Unity 2022.3.62f3. **Release status:** source integrity and static tests only; Editor compilation, NUnit execution in Unity and Android device checks remain pending.

## Scope completed

- Added `Assets/_Project/Domain/ChapterArtworkViewport.cs`, a pure C# transient UV-window policy with non-finite-input rejection, exact zoom bounds of 1×–3×, clipped two-axis panning, and deterministic reset. It has no Unity or save-system dependency.
- Connected original chapter/location artwork to four pan buttons and mouse/touch dragging in the 3D investigation overlay, using `RawImage.uvRect`, `EventTrigger` and local-space pointer conversion. The imported texture is reused and never re-encoded or destroyed by this viewer.
- Added `ChapterWorldPedestalInlayGeometry.cs`, building one single-mesh, upward-facing carved motif ring for each of the two evidence pedestals at each of ten authored locations, using exactly the evidence motif counts in `ChapterEvidenceVisualCatalog`. Maximum 32 vertices/16 triangles per relic mesh. Inlays use the non-interactive scenery layer and have no collider.
- The 3D world now owns and destroys all seven generated meshes (three arches, one vault, one floor sigil, two pedestal inlays); it preserves image ownership, transient inspection, dossier and save behavior.
- Added EditMode mathematical assertions and PlayMode interaction/asset-identity checks to existing fixtures, preserving the reviewed NUnit fixture inventory and updating the three touched source hashes.
- Added `verify_artwork_pan_and_pedestal_v503.py` with a numerical oracle and `test_artwork_pan_and_pedestal_v503.py` containing sixteen negative/mutation checks plus one clean-baseline contract test. Maintained all prior static gates, updated legacy assertions from five to seven owned meshes, and aligned the acceptance source version to v5.03.

## Known limitations and acceptance blockers

1. Unity Editor was not available in the authoring environment. **COMPILE_VERIFIED=false, EDITMODE_VERIFIED=false, PLAYMODE_VERIFIED=false**. C# test source inclusion does not prove NUnit execution or production runtime behavior.
2. The new relief meshes are lightweight procedural geometry, not photogrammetry, high-poly sculpted assets, or a final realistic environment. Camera/UI interaction must be examined on target aspect ratios and actual Android hardware.
3. Input event routing for the transparent drag capture requires actual Unity PlayMode and touchscreen evaluation. GPU draw-call and frame-time impact of two extra pedestal renderers must be profiled rather than assumed negligible.
4. The original 1280×720 chapter/location art remains unmodified; this change makes off-center detail examinable but does not increase its physical resolution.
5. Generated Unity scenes `Main.unity` and `ChapterOne.unity` require editor bootstrap and imported-reference acceptance before any release claim.

## Windows acceptance

Extract the complete ZIP outside synchronizing folders, close Unity Editor, then run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` using the installed **2022.3.62f3** Editor. Preserve `SableSigilVerification` logs, test XML, `verification.json`, and `sable-acceptance.json` next to the project. Fix actual errors before Android build or release.

## Authoritative API references

- [Unity 2022.3 Mesh.SetVertices](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.SetVertices.html).
- [Unity RawImage texture UV coordinates](https://docs.unity3d.com/2022.3/Documentation/Manual/script-RawImage.html).
- [Unity Event System Drag interface](https://docs.unity3d.com/2022.3/Documentation/Manual/SupportedEvents.html).

All implementation/source code, identifiers, logs, and new technical artifacts use English.
