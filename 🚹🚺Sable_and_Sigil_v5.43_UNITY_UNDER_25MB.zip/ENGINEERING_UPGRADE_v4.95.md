# Sable & Sigil v4.95 — Authored 3D Evidence Relics

## Target and evidence
- Unity Editor target: **2022.3.62f3**.
- Source baseline: **v4.94** (all baseline files retained).
- Source static verification: **50/50** individual static gates plus one Python regression stage.
- Python unittest regression: **356/356 passed**.
- **Unity compilation, EditMode, PlayMode, GPU rendering, and Android device validation have NOT been performed.**

## 3D production improvement
- `Assets/_Project/Domain/ChapterEvidenceVisualCatalog.cs`: twenty authored visual specifications from the ten story dossiers. Contains 17 silhouette variants, stable labels, bounded motif counts, cross-checked against the existing world and dossier catalogs. No reference to Unity, saves or gameplay progress.
- `Assets/_Project/Runtime/ChapterWorldRelicFactory.cs`: creates a physical visual relic for each case fragment, using bounded compound primitive geometry, existing owned chapter materials, inactive decorative colliders and a single selectable root collider. It owns no imported images, save keys, external textures, or global scene objects.
- `Assets/_Project/Runtime/ChapterWorldExplorer.cs`: uses the catalog and factory instead of the previous generic sphere/cube artifacts. Retains current 3D orbit/touch controls, evidence inspection, original reference artwork, two-fragment deduction gate and transient progress.
- EditMode/PlayMode coverage extended to verify label association, counts, invalid input, interactive collider isolation and shape-specific motifs. The existing 77-class NUnit fixture inventory was updated with exact SHA-256 hashes for the two changed classes.

## Quality scope
This improves distinctive 3D investigative objects and authored evidence-to-visual linkage. It does **not** add photogrammetry, production meshes, complete serialized 3D scenes for all locations, AI-generated clues, new puzzle answers or a certified Android build.

## Engineering and safety constraints
- Domain contract remains pure C#; neither `UnityEngine` nor `PlayerPrefs` appears in the new catalog.
- Puzzle truth stays in `StoryDossierCatalog`; physical relics cannot solve or persist a case.
- The 10 original reference images and four chapter images remain byte-identical to v4.94.
- Existing `.meta`, assembly definitions, packages, settings, and all unchanged source files remain byte-identical.
- Unity `Object.Destroy` is deferred until the end of the update loop; runtime-owned ornaments are children of the pre-existing disabled/destroyed explorer scene root.
- Source validation alone is not sufficient for any `COMPILE_VERIFIED`, `TEST_VERIFIED` or `DEVICE_VERIFIED` claim.

## Next acceptance
1. Import v4.95 into Unity 2022.3.62f3 on a local path, not cloud placeholder folders.
2. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`; retain the logs and NUnit XML reports.
3. In PlayMode, open locations 1–10 and verify two distinct visible relics, accurate labels and successful click/touch inspection, no UI-camera interference and no console exceptions.
4. Verify a dossier requires both evidence inspections and correct deduction before persistent advancement.
5. Profile draw calls, frame times and peak memory on an actual Android device before adding high-resolution meshes or lighting.

## Documentation used
- Unity 2022.3 `Object.Destroy` (destruction deferred within the frame)
- Unity 2022.3 `GameObject.CreatePrimitive` (primitive mesh with collider)
- Unity 2022.3 `Renderer.sharedMaterial` (shared material references and mutation caveats)
