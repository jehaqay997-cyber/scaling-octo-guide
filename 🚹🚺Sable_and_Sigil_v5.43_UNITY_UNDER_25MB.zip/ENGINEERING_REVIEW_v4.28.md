# TheOrderRoom v4.28 — Integrated Systems Engineering Review

**Baseline:** exact recovered v4.27 candidate archive. **Compatibility target:** project-declared Unity 2022.3.62f3. **Release status:** source candidate, not verified player build.

## Confirmed source findings and root-cause remediation

1. **OrderSaveStore.TryRead, bounded memory:** the previous reader allocated a full 1,048,577-byte buffer for each journal candidate, even when the entry contained a few kilobytes. It now allocates only `observedFileLength + 1` bytes, after validating the 1 MiB limit. The extra byte and an exact-length assertion reject append/truncation during the read. A single FileStream handle and strict UTF-8 decode remain in place. This reduces allocation overhead but is not an on-device GC benchmark.
2. **OrderPerformanceGovernor, ownership:** the application-wide frame-rate and VSync settings previously had no inter-instance owner; two governors could race to restore unrelated prior settings. A single owner is now enforced: duplicates disable themselves, and only the owner restores settings. This guards duplicate components across different GameObjects, beyond DisallowMultipleComponent's same-GameObject constraint.
3. **Integrated input and scene review:** inspected the two input backends, focus/pause cancellation, UI raycast interception, gesture revision validation, scene construction and scene validator. No additional source mutation made without a confirmed defect. Tests below inspect explicit contracts but cannot prove gameplay behavior.

## Automated verification executed in this environment

- `python Verification/governance_v423.py`: source/meta/GUID checks PASS (static only).
- `python Verification/architecture_gate_v426.py`: assembly graph and editor scene callback contracts PASS (static only).
- `python Verification/camera_contract_gate_v427.py`: seven camera source contracts PASS (static only).
- `python Verification/integration_gate_v428.py`: 15 source-contract checks PASS (static only).
- `python Verification/test_integration_gate_v428.py`: 4 Python tests PASS, including three negative mutation checks.
- `python Verification/independent_adventure_oracle.py`: 20 reachable states, 34 edges, 3 victory states, zero deadlocks within the limited reference model; not a full-world proof.

## Unverified release gates (block release)

- **P0 / COMPILE_VERIFIED:** Unity Editor executable not available in this execution environment, so no C# compile has run.
- **P0 / TEST_VERIFIED:** Unity Test Runner / NUnit not run. New Python checks do not imply the C# code compiles.
- **P0 / SCENE_VERIFIED:** generated `Main.unity` not opened or executed. Scene references must be validated via `Verification/Run-UnityVerification.ps1`.
- **P0 / SAVE_VERIFIED:** crash-injection recovery and cross-process concurrency must be proven with real filesystem and Unity lifecycle tests. SHA-256 is corruption detection, not cryptographic origin authentication.
- **P1 / DEVICE_VERIFIED:** Android touch and drag, aspect ratios, graphics, frame pacing, battery drain and thermal behavior must be measured on physical devices.
- **P1 / ARCHITECTURE:** Runtime still calls Domain directly; AppCore and Infrastructure adventure systems are not fully wired into the gameplay scene.
- **P1 / PERFORMANCE:** independent per-save journal entry inspection remains non-trivial at high history counts; bound and profile cumulative IO.

## Traceability and governance

Production code changed: `Assets/_Project/Runtime/OrderSaveStore.cs` and `Assets/_Project/Runtime/OrderPerformanceGovernor.cs`.
New non-Unity verification: `Verification/integration_gate_v428.py`, `Verification/test_integration_gate_v428.py`, `Verification/INTEGRATION_REPORT_v4.28.json`, and this review.
No earlier file was removed. No editor version migration was attempted. Source verification must not be reported as operational verification.

## Official references

- Unity `Application.targetFrameRate` (2022.3): https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Application-targetFrameRate.html
- Unity `QualitySettings.vSyncCount` (2022.3): https://docs.unity3d.com/2022.3/Documentation/ScriptReference/QualitySettings-vSyncCount.html
- Unity Profiler / device profiling: https://docs.unity3d.com/2022.3/Documentation/Manual/profiler-profiling-applications.html
- Unity Memory Profiler: https://docs.unity3d.com/2022.3/Documentation/Manual/com.unity.memoryprofiler.html
