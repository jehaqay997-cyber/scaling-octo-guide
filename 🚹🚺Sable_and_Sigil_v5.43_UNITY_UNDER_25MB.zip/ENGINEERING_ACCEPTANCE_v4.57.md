# Sable & Sigil v4.57 — Chapter Checkpoint Recovery Audit

## Change scope

- Introduced `Assets/_Project/Domain/ChapterCheckpointCodec.cs`, a versioned, Unity-independent checkpoint codec with canonical serialization, corruption detection, explicit domain validation and strict rejection of malformed records.
- Replaced three separately-written chapter-progress integer values with two alternating, versioned snapshot strings (`CheckpointA` / `CheckpointB`). The highest valid revision is restored. If one slot is damaged, the other may recover progress. Neither valid slot is overwritten before the next snapshot is written.
- Retained read-only migration from the v1 `Flags` / `Dial` / `Check` keys to avoid intentionally invalidating pre-existing saves. A corrupted new-format save is **not** allowed to revive obsolete legacy progress.
- Added C# EditMode tests for codec round trips, corruption, bounds and impossible state. These tests are present but **not executed in Unity**.
- Added a required offline static checkpoint gate, including mutation-oriented Python regression tests.

## Governance and risk

- This is error detection, **not cryptographic tamper protection**. The checksum does not provide authentication.
- `PlayerPrefs.Save()` is not an atomic multi-file transaction. Two slots reduce risk from a partially corrupt checkpoint but cannot guarantee recovery from device-wide storage corruption, complete data loss or failed operating-system writes.
- Gameplay uses the existing camera, chapter presentation, asset ratios, save key prefix, art and assembly references. No chapter visuals or puzzle answers were rewritten in this release.
- C# compile, Unity EditMode/PlayMode, Windows `.cmd` launch and Android runtime tests could not be executed in this environment.

## Executed evidence

- 162/162 Python regression cases passed.
- 30/30 required static gates passed, plus regression suite (31/31 stages).
- Unity assembly and GUID integrity passes the maintained static gate.
- Entire previous archive content preserved; existing files modified only as documented.

## Mandatory acceptance in the Unity editor

1. Open the project with Unity 2022.3.62f3. Import and compile with zero Console errors.
2. Run EditMode and PlayMode tests; confirm `ChapterCheckpointCodecTests` execute.
3. Check old v1 chapter-save migration without clearing the player’s data.
4. After two completed chapter checkpoints, corrupt only the latest slot in a test environment; verify fallback to the last valid snapshot.
5. Test resume/quit and simulated crash on a real Android device; ensure chapter unlocks and object interactions remain consistent.
6. Inspect chapter artwork on landscape aspect ratios and device safe areas; confirm scene-generation/first-run startup successfully produces ChapterOne.unity.

## Reference

Unity Scripting API — PlayerPrefs, version 2022.3: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PlayerPrefs.html
NIST SSDF SP 800-218: https://csrc.nist.gov/pubs/sp/800/218/final
