# Sable & Sigil — Cinematic Environment Production Guide v5.37

## Non-negotiable visual direction

Create distinct, naturalistic, full-width Gothic environments with credible architecture, physically coherent daylight, real weathering, natural perspective, human-scale objects, restrained color and authentic materials. Avoid anime, cartoon shading, plastic bloom, excessive blue/orange grading, stock placeholders, lifted assets, inaccurate clue symbols, and baked blurred sidebars. Never imply that an AI-generated image is a usable volumetric 3D level; each plate is a 2.5D exploration background until separately modeled.

## Scene-by-scene production contracts

| Location | Authored subject | Art direction | Status |
| --- | --- | --- | --- |
| 01 | Sealed threshold | Fully integrated Gothic masonry doorway, old carved wooden doors, moist steps, worn plaques and surrounding architecture; overcast cool daylight with warm material details; readable central entry with evidence sightlines | New full-bleed candidate included |
| 02 | Ceremonial staircase | Actual full-width stone and carved brass staircase continuing into a believable interior; room geometry and perspective must agree with Chapter One architecture | Original padded image retained |
| 03 | Garden lantern | Moonlit or late-blue-hour garden path, single believable iron lantern, distant Gothic estate and vegetation at correct depth; no magical glow unless driven by the story | Original padded image retained |
| 04 | Conservatory inscription | Weathered greenhouse with varied, fresh but imperfect roses and an engraved basin; realistic glass reflections, organic plants and diffuse daylight | Original padded image retained |
| 05 | Fountain and four spouts | Four spatially legible carved stone spouts and a drained basin, easy to count without overlays; natural stone staining, believable courtyard | Original padded image retained |
| 06 | The crossing and three statues | Traversable ruined passage with exactly three distinguishable historic figures, consistent shadow geometry and path scale | Original padded image retained |
| 07 | Broken testament window | Tall leaded-glass window whose divisions support the authored puzzle, masonry beams, deep chapel interior and physically consistent caustics | Original padded image retained |
| 08 | Family portrait hall | Ornate but restrained historical portrait gallery with distinct frames and accurate architectural vanishing lines; no imitation of existing game art | Original padded image retained |
| 09 | Weathered witness | Grand weathered sculpture or funerary monument with readable epitaph placement and patina that does not hide critical clue geometry | Original padded image retained |
| 10 | Meridian rotunda | Coherent domed chamber with legible ring geometry, brass fittings, sandstone/limestone, skylight and a convincing central focal mechanism | Original padded image retained |

## Technical acceptance for each new environment

1. Widescreen 16:9, at least 1600 x 900 imported pixels. No deliberate blurred side borders, black pillars or watermark. No anime/cartoon features.
2. Retain the existing `Scene_XX.jpg` reference, art hash and Unity GUID; place the replacement at `Resources/CinematicLocations/Location_XX.png` with its own GUID and a recorded checksum.
3. Position evidence A, evidence B and the mechanism with reference screenshots from Unity at 100%, 120% and 140% zoom. Both touch and mouse click geometry must remain attached to the same image transform.
4. Puzzle-specific clues must be spatially discoverable yet not revealed by the environment plate itself. Aesthetic changes cannot alter correctness, hint order, case revisions or finale prerequisites.
5. On Android, measure imported texture dimensions/compression, frame timing, live texture memory, thermal response and UI safe area. Run the Unity acceptance suite and manual inspection on real devices.
6. Only mark an image approved after the full rendered scene has passed viewpoint, content, contrast, tappability and frame-cost review. A source-art hash is not a visual acceptance certificate.

## 3D conversion pipeline (not yet implemented)

For physical inspection rooms, create true modular stone, wood, metal and glass meshes; bake normal/roughness/ambient occlusion maps; use UV-consistent PBR shading and authored lighting; then anchor the original puzzle interactors in world space. Validate collider-to-renderer correspondence and camera orbits before replacing the present lightweight procedural inspection rooms. This work cannot be substantiated by panorama generation alone.
