# Sable & Sigil v5.31 — Unity / Android Official Compatibility Review

Review date: 2026-11-22. Parent source: v5.30. Pinned editor: Unity 2022.3.62f3.

**Evidence boundary:** This release is an offline source candidate. The Unity Editor, Unity C# compiler, Test Runner, Android build, Android package analyzer, Play Console and hardware profiler have not been executed in this environment. Passing Python tests or source checks does not establish build compatibility or release readiness.

## Implemented source changes

1. Added `Assets/_Project/Editor/SableAndroidPublicationGate.cs` with a Unity 2022-compatible `IPreprocessBuildWithReport` guard. It blocks non-development Android builds unless the target API is explicitly selected at 36 or higher, the Android backend is IL2CPP, ARM64 is enabled, AAB is selected, a positive version code is present and build scenes exist. Development APK testing is deliberately unaffected. The gate is side-effect-free and never changes ProjectSettings or application identity. There is a manual/batch validation entry point; passing it proves configuration only, not successful Android publication.
2. Added `Verification/Portable/android_publication_audit_v531.py` to inspect package manifest/version/player settings, identify untrusted Brotli APIs and scoped registries, and optionally read actual APK/AAB archives. It checks ARM64 ELF `PT_LOAD` alignments and uncompressed `.so` zip-entry offsets for APKs. It does not make unsupported claims about ELF RELRO segments, generated AAB splits, final target SDK, bundle signing or Play Console acceptance.
3. Added 15 adversarial Python tests, including synthetic broken native ELF, an unaligned AAB library, unaligned APK zip packaging, corrupted/duplicate package manifests, target SDK 35, an untrusted compression call and a release gate with no external evidence.
4. Registered the publication implementation gate into the maintained offline audit registry. Preserve all pre-existing .meta GUIDs, art, scenes policy, archive history, NUnit fixture hashes, save keys and puzzle solutions. No dependency upgrade or Unity version change was applied without a compatibility proof.

## Actual source findings

| Priority | Finding | Established status | Project consequence |
| --- | --- | --- | --- |
| P0 | Unity ProjectVersion is `2022.3.62f3`; Play submission after August 31, 2026 requires target API 36 | Requirement confirmed; current build target not evidenced | No commercial release until generated Android manifest and Play Console acceptance prove API 36 |
| P0 | Existing `OrderAndroidBuildBatch` creates a Development APK | Source-confirmed | Development builds are for diagnostics, not Google Play AAB release |
| P0 | 16 KB memory-page compatibility has not been measured on a generated Android artifact | Unverified on product | ELF and installed split APK compatibility must be measured; Unity engine minimum support is not a device test |
| P0 | October 2026 eMudhra CA issue, CVE-2026-111943, affects Editor/package trust and some platform configurations | Official advisory; game exposure platform-dependent | Use a patched supported Editor for future production or follow official trust-store guidance; avoid nonstandard registries |
| P0 | October 2026 Brotli decoder issue, CVE-2026-111497, is exploitable only when untrusted data reaches affected decompressors | Official conditional risk; no matching C# calls in scanned project code | Avoid untrusted scoped registries and audit any future DLL/SDK changes |
| P1 | `Packages/packages-lock.json` is absent | Source-confirmed | Unity Package Manager must generate a genuine dependency lock after first successful resolution; do not fabricate it |
| P1 | `com.unity.inputsystem` 1.7.0 and `com.unity.test-framework` 1.1.33 are explicitly pinned | Source-confirmed | Do not upgrade until the 2022.3.62f3 dependency and NUnit compatibility is tested |
| P1 | `com.theorderroom.game` is still the Android application ID | Source-confirmed | Brand/package change requires explicit Play Console and save-namespace decision; preserve original identity meanwhile |
| P1 | Android 16 can ignore orientation and aspect-ratio restrictions on qualifying large-screen devices and enforces edge-to-edge | Official behavior; game UI not measured | Verify large display, system bars, cutouts, focus, HUD and input safe-area behavior on API 36 |
| P1 | Built-in 2022.3 Gradle 7.2 / AGP 7.1.2 / JDK 11 / NDK r23b constraints differ from current Android recommendations | Official Unity toolchain guidance; local toolchain not inspected | Do not inject AGP 8.5.1 or NDK r28 into this Unity version without a tested migration |

## Review of official security advisories

- **CVE-2025-59489:** Unity identifies 2022.3.62f2 as an affected-stream patched editor; this source is pinned to the later 2022.3.62f3. This only addresses the 2025 advisory, not future advisories or build authenticity.
- **CVE-2026-111943:** Unity reports Google Play Services certificate changes protect Android runtime devices receiving its October 2026 update; Editor and bundled build JDK exposure are separate. Do not label the entire project "exploited" or "fixed" merely from the editor version.
- **CVE-2026-111497:** Source scan found no explicit `BrotliStream`, `BrotliDecoder`, `AutomaticDecompression` or `HttpClient` references in project C# files. This does not audit compiled Unity Package Manager binaries or future plugins. Unity has not declared a patched Unity 2022.3 editor in its November 7, 2026 advisory.

## Release proof still required

1. Extract this source to a local writable directory. Open using exactly Unity 2022.3.62f3. Keep `Packages/manifest.json` versions fixed; resolve packages and record the genuine generated `packages-lock.json` and Console errors.
2. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`, then verify all five scenes, full NUnit EditMode and PlayMode XML output, chapter progression, persistence and UI/input/audio. Capture all logs.
3. For Google Play distribution, run `Sable & Sigil > Android > Validate Google Play Configuration`. A blocking result is expected until the correct Android 16 SDK/platform build options are configured and proven; the gate does not auto-repair unsupported Editor APIs.
4. Produce a **non-development, signed AAB** using a validated Android toolchain and examine `base/manifest/AndroidManifest.xml` using the official Android SDK/bundletool. Confirm target SDK >= 36, ARM64 IL2CPP and a unique valid version code. Run `bundletool dump config --bundle=<AAB>` to inspect `PAGE_ALIGNMENT_16K` and generate device-specific APKs to verify zip alignment, ELF `PT_LOAD`, RELRO and installability.
5. Use `python Verification/Portable/android_publication_audit_v531.py --artifact <APK_OR_AAB> --json <OUT_JSON>` to obtain supplemental structural evidence. This checker intentionally does not certify signing or Play acceptance. Use `--enforce-publication` to produce a nonzero blocking status until external evidence exists.
6. Run Android 15/16 device profiling with 4 KB and 16 KB page sizes, including at least 10 chapter transitions/reloads, audio playback, UI cutouts, 60/30 FPS behavior, GC allocation trend, native memory growth and temperature/battery measurements.
7. Update to a newer **supported patched Unity release line** in a separate isolated migration branch if API 36 or October 2026 Editor-security requirements cannot be met in 2022.3.62f3. Never edit ProjectVersion.txt merely to simulate an Editor upgrade.

## Official sources

- Unity 2025 security advisory: https://unity.com/security/sept-2025-01
- Unity October 2026 eMudhra: https://unity.com/security/unity-emudhra-compromise
- Unity October 2026 Brotli: https://unity.com/security/unity-brotli-decoder-vulnerability
- Unity official 16 KB announcement: https://discussions.unity.com/t/android-unity-engine-support-for-16-kb-memory-page-sizes-android-15/1589588
- Unity 2022.3 Gradle / AGP compatibility: https://docs.unity3d.com/2022.3/Documentation/Manual/android-gradle-overview.html
- Unity 2022.3 Android environment: https://docs.unity3d.com/2022.3/Documentation/Manual/android-sdksetup.html
- Google Play target API policy: https://support.google.com/googleplay/android-developer/answer/11926878
- Google Play Android App Bundle: https://developer.android.com/guide/app-bundle
- Google Android 16 KB guidance: https://developer.android.com/guide/practices/page-sizes
- Google Android 16 behavior: https://developer.android.com/about/versions/16/behavior-changes-16
- Google 64-bit Android: https://developer.android.com/google/play/requirements/64-bit
- NIST SSDF SP 800-218: https://csrc.nist.gov/pubs/sp/800/218/final

### Verification labels

`SOURCE_STATIC_TESTS`: externally recorded test results only.

`COMPILE_VERIFIED`: NOT EXECUTED.

`TEST_VERIFIED`: Unity EditMode/PlayMode NOT EXECUTED.

`ANDROID_BUILD_VERIFIED`: NOT EXECUTED.

`DEVICE_VERIFIED`: NOT EXECUTED.

`GOOGLE_PLAY_COMPLIANT`: NOT VERIFIED.
