# Sable & Sigil v5.21 — Chapter Three Controlled Evidence Disclosure

**Baseline:** v5.20  
**Editor target:** Unity 2022.3.62f3  
**Scope:** Chapter Three, locations 07–09, plus scoped source contract regressions.  
**Status:** Source candidate; Unity runtime unverified.

## Implemented corrections

1. `ChapterThreeVisualSpec` now supplies a **LockedMark** for every Chapter Three location and a pure, Unity-independent `GetVisibleMark(inspectedA, inspectedB, verified)` decision method. The missing-fragment condition takes precedence even if a corrupted verification flag were supplied.
2. On first opening the 3D investigation, the world label shows only the locked mark. Inspecting **either one** of the two evidence fragments does not expose the puzzle statement. Inspecting **both** reveals the unsolved visual mark; successfully verifying the mechanism reveals the solved mark. Every transition updates the existing `TextMesh`, without allocating a new mesh or changing the source artwork.
3. Removed the Chapter Three glass inscription's premature solution instruction, keeping the authored case fragments, four options, correct-answer indices and three-stage hints unchanged.
4. Added Unity EditMode and PlayMode assertions covering all three locations, all evidence-visibility combinations and the reveal sequence. These assertions are **authored, not executed in Unity**.
5. Added a dedicated static contract and mutation suite to detect premature disclosure, missing evidence gates, missing state refresh, and lost Unity test coverage.
6. Improved two older Chapter One source mutation verifiers so their tests inspect the **Chapter One selection method**, not an identically worded expression introduced by Chapter Three. Legacy source checks remain fail-closed.
7. Updated Unity acceptance source baseline, existing NUnit source fingerprints, and a new Chapter Three acceptance checklist.

## Preservation and constraints

- Chapters One and Two gameplay, authored dossier solutions and image assets were not intentionally changed.
- Do not regenerate existing Unity `.meta` GUIDs or fabricate resolved package lock state.
- Existing project builds editor-generated scenes. The project lacks pre-saved `.unity` files and a `packages-lock.json` in its source archive. Both require actual Unity validation.
- Python assertions and static gates cannot prove Unity compilation, Editor behavior, graphical quality, or device performance.

## Sign-off

Source-only checks and ZIP integrity should be reviewed in `Verification/STATIC_EVIDENCE_v521.json` and the external independent verification report. Unity compilation and all EditMode/PlayMode/Android gates remain **NOT EXECUTED** until supported by actual logs and screenshots.
