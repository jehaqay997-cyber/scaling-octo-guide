# Sable & Sigil v4.51 — Source acceptance

## Source provenance

- Input: TheOrderRoom v4.50 official candidate archive.
- Removed original files: **0**.
- Original C# namespaces and seven asmdef names: **unchanged**.
- Original `.meta` files and GUIDs: **unchanged**.
- All files: **nonempty**.
- All assets/directories under Assets have matching `.meta` entries; no orphan `.meta` files.
- GUID uniqueness and local asmdef reference resolution: passed.
- Browser preview JavaScript parsed with Node.js (`node --check`).
- Combined maintained static audit: **24/24 gates passed**, 138/138 Python tests passed.
- Brand migration details: see `BRAND_MIGRATION_v4.51.md`.

## Verified changes

- Unity Product Name changed to Sable & Sigil.
- Generated gameplay HUD title changed to SABLE & SIGIL.
- Browser playable preview changed to SABLE & SIGIL.
- New fail-closed branding and Unity asset linkage gate with four regression tests; included in the consolidated audit.
- Refreshed source package SHA-256 manifest.

## Outstanding release blockers

- Unity Editor 2022.3.62f3 compilation not run in this environment.
- Scene generation and EditMode/PlayMode tests not executed in Unity.
- Android APK not built; device performance/interaction unverified.
- The primary Main.unity scene is generated at first import; it is not serialized in this archive.
- Brand is a working title; official trademark clearance has not been performed.
- Android package identifier remains com.theorderroom.game for update/save compatibility; publisher name remains unchanged pending ownership confirmation.

**Status: STATIC SOURCE ACCEPTED — UNITY AND DEVICE RELEASE NOT VERIFIED.**
