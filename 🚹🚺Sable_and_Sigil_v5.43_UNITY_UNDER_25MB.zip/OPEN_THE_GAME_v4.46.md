# TheOrderRoom v4.46 — Open and Play

## Immediate playable view

Open `PLAY_GAME_NOW.html` in Safari, Chrome or Edge. This is an **offline browser companion**, not a Unity build. The preview displays the game board immediately, supports twelve chambers, artifact placement, mouse drag, tap-to-select, Undo, Redo, Hint, Reset and browser-local progress.

## Integrated Unity project

1. Extract the archive to a local, nonsynced directory.
2. Open the folder containing `Assets`, `Packages`, and `ProjectSettings` in **Unity 2022.3.62f3**.
3. On successful import/compilation, the editor's first-session hook creates `Assets/_Project/Scenes/Main.unity` if absent, opens it, selects Game view, and enters Play Mode automatically.
4. If a modified unsaved scene is already open, Unity may request permission to save it. The hook will not discard that scene without consent.
5. To launch again, use the menu **TheOrderRoom → Play Integrated Game**.

The auto-launch does not run in batch mode and does not override the opt-out marker `Assets/_Project/Scenes/.skip-auto-bootstrap`.

## Acceptance caveat

This environment has no Unity Editor. Unity compilation, real EditMode/PlayMode execution, and Android device compatibility remain **unverified**. The browser companion is a separate gameplay demonstration; its state and assets are not exported to Unity.
