# TheOrderRoom v4.48 — Integrated First-Run Gate

## Scope

This release is a focused, non-destructive integration and regression hardening update based on the complete v4.47 source archive.

## Changes

- Registered `unity_first_run_gate_v447.py` exactly once in the full static audit pipeline.
- Updated the full-audit regression test to require the first-run gate.
- Strengthened the first-run gate to detect removal of exact Unity version comparison or the failed version-query guard.
- Added three regression tests for release-gate inclusion, exact-version comparison, and failed version-query rejection.
- Preserved the Unity runtime, Domain, AppCore, persistence, scene bootstrap and launch entry points without speculative rewrites.

## Evidence

- Python unittest discovery: 123/123 passed.
- Consolidated static audit: 22 standalone gates plus the Python regression suite passed (23 stages total).
- ZIP and full-file SHA-256 integrity: see `Verification/SHA256_MANIFEST_v4.48.json`.
- Exact Unity version in ProjectSettings: 2022.3.62f3.

## Verification limitations

- No Unity Editor executable was available in this execution environment.
- No Unity C# compilation, EditMode execution, PlayMode execution, Android build or physical-device run was performed.
- The generated Main scene is created on first Unity import; a generated `Main.unity` is not included in the source archive. This remains a runtime acceptance gate.
- `SOURCE_STATIC_VERIFIED` does not imply `COMPILE_VERIFIED`, `TEST_VERIFIED`, `DEVICE_VERIFIED`, or release readiness.

## Windows execution

1. Extract the entire archive to a local path without sync-based placeholders.
2. Install Unity Editor version 2022.3.62f3.
3. Run `OPEN_GAME.cmd` to verify the Editor version and open the project.
4. On successful import, the Editor attempts to generate and open the Main scene and enter Play Mode. If blocked, inspect Console and Editor.log; use `TheOrderRoom > Play Integrated Game` after resolution.
5. Run `Verification/Run-UnityVerification.ps1` to execute Unity bootstrap and EditMode/PlayMode. Use `-BuildAndroid` only with Android build support installed.

## Release decision

STATIC SOURCE CANDIDATE — NOT UNITY VERIFIED. No 10/10 production claim is warranted without executed Unity and device evidence.
