# TheOrderRoom — Product and Architecture Blueprint

Date: 2026-11-16
Status: Approved product direction, NOT implemented or validated as a complete HOPA game.

## Product identity

A landscape, fixed-camera 3D investigation adventure blending organization puzzles, hidden-object observation, artifact inspection, and evidence-based deductions. All narrative, visual assets, characters and names must remain original.

## Differentiators and acceptance criteria

1. **Knowledge graph:** Every authored deduction has explicit prerequisites, evidence provenance, and an immutable event history. Test that required knowledge transitions are reachable.
2. **Anti-guessing:** Multi-answer deduction batches must not leak correctness of individual guesses.
3. **Softlock resistance:** For every reachable modeled nonterminal state, at least one intended completion must remain reachable. Explicitly distinguish mutually exclusive narrative endings from real softlocks. Independent model and deterministic exhaustive checks required at bounded scope.
4. **Hidden-object scenes as data:** Seeded deterministic item placement; every required object must be observable from at least one permitted camera node, including UI and occlusion constraints.
5. **Landscape fixed-camera interaction:** Support pointer and touch, click/tap to inspect, controlled zoom, accessible target sizes; verify on-device.
6. **Accessible interface:** Scalable text, non-color-dependent signals, focus and contrast checks; human accessibility review.

## MVP vertical slice (proposal, not existing content)

- 3 connected locations, 5 main puzzles, 1 solvable mystery, 3-tier hints.
- Target playtime: 15–25 minutes, to be tested with players, not asserted.
- Free first chapter; premium one-time paid later chapters; no energy wait timer required for premium.

## Architecture and ownership

- Domain: Pure C# rules for puzzle, world, inventory, knowledge and completion.
- AppCore: Command orchestration, save contracts and consistency boundaries; no Unity dependency.
- Infrastructure: Durable adapters, migrations and telemetry implementation.
- Presentation: Unity UI, input mapping and camera nodes; no authority over Domain state.
- PuzzleBoard/OrderBoard must remain sole owner of its existing board rules. Do not conflate it with the whole adventure aggregate.
- Existing assets, package manifest, GUID metadata and save compatibility must be preserved until changes are justified and tested.

## Gates

- M0: Compile original recovered candidate, run all relevant tests, verify catalog parity. Do not infer test success from stored historic XML.
- M1: Model world graph, inventory, knowledge, transactional transitions, and independent softlock verifier.
- M2: Integrate a minimal fixed-camera 3D touch interaction prototype early to de-risk user experience.
- M3: Transactional save/recovery, Undo/Redo, staged hints, invariant checks.
- M4: Playable vertical slice, observation testing, accessibility checks and full UX validation.
- M5: Original art/audio, frame time/memory benchmarks, Android field tests and release gates.

## Commercial and measurement policy

Proposed episodic premium monetization, first episode free. Instrument aggregate puzzle completion, hint use, and stall points without personal data. Review feasibility using actual player data. Do not treat legacy industry retention metrics as live product forecasts.

## Verification caveat

The v4.15 source includes an AdventureChapter and AppCore AdventureSession, but no completed Unity integration or adventure persistence adapter. This blueprint does not misrepresent those planned components as implemented.
