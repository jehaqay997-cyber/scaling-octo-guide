# Sable & Sigil — Chapter Visual Art Direction v4.53

## Visual identity
Cinematic gothic fantasy, grounded architectural scale, plausible antique materials, cold moonlight against warm practical light, readable object silhouettes, and restrained ornament. Images are authored as visual direction, not evidence of real-time Unity rendering. The photographs and art were generated as original concept material.

## Chapter order and player state
1. **The House of the Last Star** — first playable mystery, lens inspection, cabinet, hidden passage and observatory reveal. Image: `Chapter_01.jpg`.
2. **The Veiled Conservatory** — humid glass gardens, moonlit water, violet flowers and botanical celestial instruments. Image: `Chapter_02.jpg`. Concept preview only.
3. **The Ashen Gallery** — worn limestone, ancestral portraits, falling ash and missing faces. Image: `Chapter_03.jpg`. Concept preview only.
4. **The Hollow Meridian** — cloud-top observatory, antique celestial machinery and broken bridges. Image: `Chapter_04.jpg`. Concept preview only.

## Implementation
The four 1280x720 JPEG assets live in `Assets/_Project/Resources/ChapterArt`. Unity loads them by `Resources.Load<Texture2D>` in `ChapterGalleryView`, which is opened through the CHAPTERS action in `ChapterOneExperience`. The gallery uses native Unity UI widgets. Chapters II-IV cannot be entered. There are no invented chapter scenes, chapter completion rewards, or unimplemented navigation paths.

## Engineering acceptance
The static chapter-art gate validates image signatures, dimensions, SHA-256, import GUIDs, loader paths, access restrictions and PlayMode-test wiring. All tests run offline. Actual texture import, UI layout, game interaction, Unity compile, rendering on Windows and Android must be verified with the project editor. Do not interpret concept art as Unity gameplay footage or production PBR materials.

## Project compatibility
Unity target from `ProjectSettings/ProjectVersion.txt`: `2022.3.62f3`. Existing namespaces, save keys, assembly names, and legacy chapter state are preserved.

## Primary technical references
- Unity Resources.Load<T>: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Resources.Load.html
- Unity UI RawImage: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/UI.RawImage.html
- Unity Texture Importer: https://docs.unity3d.com/2022.3/Documentation/Manual/class-TextureImporter.html
- NIST SP 800-218 SSDF: https://csrc.nist.gov/pubs/sp/800/218/final
