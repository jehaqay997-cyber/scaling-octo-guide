# Sable & Sigil — Chapter One: The House of the Last Star

## Creative premise

At the estate of Lady Elara Vey, the night sky has been erased from every astronomical portrait. The missing astronomer left a final warning: "Do not trust the sky." The player arrives during a storm to discover why the family sealed its observatory, and why one constellation was deliberately removed from the chart.

The mystery is carried by objects and the environment rather than by lengthy exposition. The archive contains one short opening hook, a sequence of three evidence discoveries, a close-up inspection, and a tactile cipher. Opening the sealed threshold reveals a moonlit stair and the erased star chart — the lead-in to the next location.

## Visual direction

- Genre: realistic gothic-fantasy mystery, period-inspired architecture with restrained supernatural detail.
- Mood: rain-dark limestone, aged walnut, blackened iron, midnight velvet, tarnished brass, cool blue moonlight and local amber lantern light.
- Composition: readable central exploration space, evidence journal to the left, contextual actions to the right, uninterrupted 3D background.
- Contrast: neutral materials and low-saturation lighting; never luminous toy colors or soft, plastic-looking surfaces.
- Architecture: stone piers and capitals, Gothic tracery, pointed arch ribs, cross-vault ribs and a hidden moonlit threshold.
- Motion: lantern intensity changes very subtly; camera transitions are damped; the hidden door slides open after solving the cipher.
- Reveal: a missing constellation, not a reward pop-up; the final secret should raise a new question.

## Implemented gameplay slice

1. Explore the cabinet and recover the blackened key.
2. Unlock the writing desk and read Lady Vey's final note.
3. Investigate the portrait and recover an engraved celestial lens.
4. Rotate and focus the lens in a dedicated live 3D inspection viewport.
5. Decode the three-number clue and operate the mechanical seal.
6. Open the false wall and reveal the forbidden star chart.
7. Enter the observatory to persist the chapter-unlocked state.

The contextual hint button provides a progressive, spoiler-limited prompt at every stage.

## Production-quality asset requirements (NOT YET PROVIDED)

Procedural Unity primitives demonstrate layout and interactions; they are **not** photorealistic finished art. A commercial scene requires professionally authored modular Gothic meshes with correct UVs, baked or authored normal/roughness/metallic maps, weighted normals, LODs, and art-directed reflection probes. All assets must be original or properly licensed. Do not imply these assets are included in the candidate.

Target architectural materials: stone with chipped edges and readable pores, anisotropic aged brass, worn walnut, velvet with believable fabric response, distressed parchment and optical glass. Avoid uniform gloss, flat textures, excessively saturated surfaces and heavy bloom. Keep UI legible in both bright and dark viewing conditions.

## Acceptance criteria

- Unity Editor opens the chapter scene as the active scene after bootstrap, with zero C# compile errors.
- PlayMode confirms exactly one active main camera, one inactive inspection camera before inspection, and active event system.
- All five clue stages can be completed in order without bypass; invalid saves cannot skip progression.
- The live inspection texture shows the rotating object, not merely the text/UI controls.
- The door opens visually when the cipher is solved; the observatory unlock persists across restart.
- Android device tests must verify touch input, frame time, memory, thermal behavior and save restoration.
- Visual quality cannot be declared photorealistic before in-editor screenshots and device capture are reviewed.

## Reference standards

Unity 2022.3 Scripting API for camera, lighting and UI. NIST SSDF SP 800-218 for secure software development governance. ISO/IEC 25010:2023 for software product quality characteristics. These references guide the process; they do not imply formal certification.
