# Enhanced art candidates

Fourteen conservative photographic-tonality derivatives, original source images preserved. Review each against its original before replacing runtime assets. No scene geometry or gameplay logic modified.
