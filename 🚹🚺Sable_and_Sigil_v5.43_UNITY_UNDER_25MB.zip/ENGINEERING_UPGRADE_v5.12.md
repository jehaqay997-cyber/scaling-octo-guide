# Sable & Sigil v5.12 — Chapter One, Both Locations

## Baseline and target
- Source baseline: v5.11, verified local ZIP copy.
- Target: Unity Editor **2022.3.62f3**, not Unity 6.
- Scope: The Threshold of Vey (location 1) and The Spiral of Testimony (location 2).
- This is a **source candidate**, not a release-certified Unity build.

## Verified source changes
1. Added `SpiralBalusterPuzzle` in the pure C# Domain assembly. Its six-slot pattern is circle, diamond, star, circle, diamond, missing; slot six must repeat star. Circle, diamond, crescent and star are accepted input choices; only star verifies. The mechanism requires both inspected fragments and rejects invalid choices without mutating progress. Attempts are saturating, and Reset clears all transient state.
2. Updated `ChapterWorldExplorer` to gate location-2 deduction on both evidence fragments **and** verified stair pattern, using the same `CanDeduce` authority as `Finish(true)`. Added a four-option visual puzzle with gated modal access. State resets on open and close.
3. Added `ChapterWorldSpiralGlyphGeometry`: a single collider-free owned 3D mesh that draws the five original markers plus the sixth empty location, reading the Domain sequence. Numerical source oracle: **71 vertices, 174 indices, 58 triangles** and camera-facing winding. Added six low-cost baluster posts with disabled colliders. `Close()` destroys the owned mesh.
4. Added a source-photo UV crop for location 2's stage only (1280x720 source: horizontal crop from x=400 of width=480). The original `Scene_02.jpg` remains unchanged and the original-art viewer still uses its full texture. Aspect ratio remains 480:720 without stretching.
5. Extended existing NUnit EditMode/PlayMode test fixtures for gate invariants, four choices, collider-free geometry, mesh ownership, input-modal isolation, camera-facing normals, screen composition and reset. Recalculated reviewed fixture source hashes; did not claim to run NUnit.
6. Appended a dedicated static/mutation gate with 17 additional Python tests. All original 578 Python tests remain passing.
7. Preserved original Unity scenes, all prior `.meta` GUIDs and image files. New scripts include new `.meta` files.

## Executed verification (offline)
- Python unittest discovery: **595/595 PASS**.
- Independent static gates: **66/66 PASS**.
- Numerically independent scene-2 puzzle/mesh oracle: PASS.
- Source fixture SHA-256 inventory: PASS (static check only).
- Parent-source differential and unchanged protected asset hashing: see v5.12 Independent Verification JSON and SourceLinkMap CSV.
- ZIP CRC, exact per-file SHA-256, and extraction replay: see v5.12 Independent Verification JSON.

## Explicit unverified release gates
- `DESIGN_VERIFIED`: static source-contract checks passed. Full visual execution remains pending.
- `COMPILE_VERIFIED`: NO.
- `EDITMODE_VERIFIED`: NO.
- `PLAYMODE_VERIFIED`: NO.
- `DEVICE_VERIFIED`: NO.
- `RELEASE_APPROVED`: NO.

## Required acceptance sequence
1. Extract ZIP to a local, non-synced drive and use Unity **2022.3.62f3**.
2. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`, collect Console errors and NUnit EditMode and PlayMode results.
3. In location 1, inspect both fragments, select the inserted sixth ray, and complete the original dossier. Verify occlusion, camera focus and safe-area input.
4. From the atlas open location 2, verify that the stair-pattern button is locked before both fragments. Then inspect both clues, open the stair viewer; test all wrong choices, confirm only STAR unlocks deduction. Confirm overlay input cannot inspect/rotate evidence. Close and reopen and confirm fresh mechanism state.
5. Check the six 3D stair markers are visible and face the camera, that the sixth marker is empty, no object unexpectedly blocks evidence, and the stage crop leaves the original art image untouched.
6. Verify scene transitions and save/restore on Windows and a physical Android device; inspect mobile frame time, memory and UI clipping before release approval.

## Official API references
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.SetTriangles.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.RecalculateNormals.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Object.Destroy.html
- https://docs.unity3d.com/2022.3/Documentation/Manual/AssetMetadata.html
