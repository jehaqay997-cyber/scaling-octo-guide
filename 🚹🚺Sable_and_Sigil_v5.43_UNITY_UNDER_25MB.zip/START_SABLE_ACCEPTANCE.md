# Sable & Sigil: executable acceptance workflow

Compatibility target: Unity 2022.3.62f3. The v4.91 source is the retained baseline; these new verification files do not replace existing game code or saves.

## Windows editor acceptance

1. Extract the entire ZIP into a local folder with enough free disk space. Do not launch from inside the ZIP or an online-only sync folder.
2. Close any open Unity Editor instance that has this project loaded. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` in the extracted project root.
3. If Unity is installed outside `C:\Program Files\Unity\Hub\Editor\2022.3.62f3`, invoke `Verification\Run-SableAcceptance.ps1` with `-UnityEditorPath` set to the actual Editor executable.
4. Inspect the uniquely timestamped `SableSigilVerification` folder next to the project. `sable-acceptance.json` records the final gate status; `chapter-and-3d-preflight.log`, `bootstrap.log`, `editmode-results.xml`, `playmode-results.xml`, and `verification.json` provide executable evidence.
5. If the gate passes, open the same project in Unity 2022.3.62f3. Use `Sable & Sigil > Prepare and Validate Playable Chapter`, then enter Play Mode. A successful automation run does not replace visual and input testing.

## Android build acceptance

Run `RUN_SABLE_ANDROID_BUILD_GATE.cmd` only after Android Build Support, SDK, NDK, and JDK for the exact Unity Editor installation are available. It runs the same preflight and Unity tests and creates a development APK only on complete success. APK publication is blocked on failure. Install the APK on a real device and validate touch, save/recovery, chapter progression, performance, and background/resume before any commercial release claim.

## Failure policy

Missing Unity executable, wrong Editor version, compiler diagnostics, missing imported art, missing generated scene, incomplete NUnit XML, failing tests, source fingerprint drift, and bad Android output all yield a nonzero exit code and a `BLOCKED` report. Existing player saves and project source are not deliberately rewritten by these verification scripts. Unity automatically creates scenes, their `.meta` files and a package lock on import.

### Verification status at packaging

- Static source checks: performed with standalone tools and separately recorded.
- Unity compilation, scene execution, NUnit EditMode/PlayMode, Android build, and physical-device tests: **not performed by this package build environment**.
- The source is an acceptance candidate, not a certified release binary.
