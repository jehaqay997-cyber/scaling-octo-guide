"""Static regression checks for the optional, fail-closed Android delivery stage."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'Verification' / 'Run-UnityVerification.ps1'
BUILDER = ROOT / 'Assets' / '_Project' / 'Editor' / 'OrderAndroidBuildBatch.cs'


class AndroidAutomationGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.script = SCRIPT.read_text(encoding='utf-8')
        cls.builder = BUILDER.read_text(encoding='utf-8')

    def test_android_is_opt_in_after_playmode(self):
        self.assertIn('[switch]$BuildAndroid', self.script)
        self.assertLess(self.script.index('$report.playmode = "PASS"'), self.script.index('if ($BuildAndroid)'))

    def test_result_requires_actual_apk(self):
        for clause in ('Assert-File $apkPath', '$apkInfo.Length -le 0',
                       'THEORDERROOM_ANDROID_APK_BUILT', 'Get-FileHash',
                       '$report.android = "PASS"'):
            self.assertIn(clause, self.script)

    def test_build_output_outside_project(self):
        self.assertIn('TheOrderRoom_BuildArtifacts', self.script)
        self.assertIn('outputPath.StartsWith(normalizedProject', self.builder)
        self.assertIn('Refusing to overwrite an existing APK', self.builder)

    def test_build_requires_supported_target_and_scene_validation(self):
        for clause in ('BuildPipeline.IsBuildTargetSupported', 'EditorUserBuildSettings.activeBuildTarget',
                       'SableChapterBuildRoute.Validate()', 'enabledScenes.Length != 4'):
            self.assertIn(clause, self.builder)

    def test_buildreport_requires_success_and_no_errors(self):
        for clause in ('BuildPipeline.BuildPlayer(options)', 'BuildResult.Succeeded',
                       'report.summary.totalErrors != 0', 'new FileInfo(outputPath).Length <= 0'):
            self.assertIn(clause, self.builder)

    def test_test_skips_cannot_be_reported_as_success(self):
        self.assertIn('$report.skipped -ne 0', self.script)
        self.assertIn('$report.playmode_skipped -ne 0', self.script)

    def test_batch_build_targets_android_explicitly(self):
        self.assertIn('"-buildTarget", "Android"', self.script)
        self.assertIn('BuildOptions.Development', self.builder)


if __name__ == '__main__':
    unittest.main()
