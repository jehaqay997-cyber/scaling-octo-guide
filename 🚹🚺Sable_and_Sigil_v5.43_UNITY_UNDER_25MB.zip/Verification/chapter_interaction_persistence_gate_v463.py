#!/usr/bin/env python3
"""Chapter hotspot state/write contract. Static checks only; no Unity execution."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = Path('Assets/_Project/Runtime/ChapterOneExperience.cs')
TESTS = Path('Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs')


def extract_method(source: str, signature: str) -> str:
    start = source.find(signature)
    if start < 0:
        return ''
    brace = source.find('{', start + len(signature))
    if brace < 0:
        return ''
    depth = 0
    for position in range(brace, len(source)):
        if source[position] == '{':
            depth += 1
        elif source[position] == '}':
            depth -= 1
            if depth == 0:
                return source[brace:position + 1]
    return ''


def evaluate(runtime: str, tests: str) -> list[str]:
    problems = []
    body = extract_method(runtime, 'public void Interact(string id)')
    if not body:
        return ['Chapter hotspot interaction method missing']
    expected = (
        'int previousFlags = progress.Flags;',
        'int previousDial = progress.DialValue;',
        'if (progress.Flags != previousFlags || progress.DialValue != previousDial)',
    )
    if any(item not in body for item in expected):
        problems.append('Interaction checkpoint requires pre-action state and mutation comparison')
    if body.count('SaveProgress();') != 1:
        problems.append('Interaction must have exactly one guarded checkpoint call')
    else:
        guard = body.find('if (progress.Flags != previousFlags || progress.DialValue != previousDial)')
        write = body.find('SaveProgress();')
        if guard < 0 or write < guard or 'UpdatePresentation();' not in body[write:]:
            problems.append('Checkpoint call must be under mutation guard and before view refresh')
    if 'HotspotInteractionsPersistOnlyDurablePuzzleChanges' not in tests:
        problems.append('Missing Unity PlayMode test of no-op and successful hotspot writes')
    if 'ReadCheckpointRevision' not in tests:
        problems.append('Missing checkpoint revision assertion helper')
    return problems


def check(root: Path = ROOT) -> list[str]:
    if not (root / RUNTIME).is_file() or not (root / TESTS).is_file():
        return ['Required runtime source or Unity test missing']
    return evaluate((root / RUNTIME).read_text(encoding='utf-8'),
                    (root / TESTS).read_text(encoding='utf-8'))


if __name__ == '__main__':
    problems = check()
    for problem in problems:
        print('FAIL:', problem)
    if not problems:
        print('STATIC_PASS_ONLY: chapter hotspot persistence mutation boundary')
    raise SystemExit(bool(problems))
