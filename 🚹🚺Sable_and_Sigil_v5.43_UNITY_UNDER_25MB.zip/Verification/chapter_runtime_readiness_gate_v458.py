#!/usr/bin/env python3
"""Static acceptance guard for the chapter readiness contract (not a Unity test)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EDITOR = ROOT / 'Assets/_Project/Editor/OrderFirstImportSetup.cs'
RUNTIME = ROOT / 'Assets/_Project/Runtime/ChapterOneExperience.cs'
PLAYMODE = ROOT / 'Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs'


def validate(editor: str, runtime: str, playmode: str) -> list[str]:
    failures: list[str] = []
    event = 'state == PlayModeStateChange.EnteredPlayMode'
    approval = 'SessionState.SetBool(SessionLaunchKey, true);'
    ready = 'chapter != null && chapter.isActiveAndEnabled && chapter.IsChapterReady'
    if event not in editor or approval not in editor or ready not in editor:
        failures.append('Editor launch does not require an initialized, enabled chapter')
    elif not (editor.index(event) < editor.index(ready) < editor.index(approval)):
        failures.append('Readiness must be checked before success is recorded')
    if 'public bool IsChapterReady => initialized && viewCamera != null && narrative != null && worldRoot != null;' not in runtime:
        failures.append('Chapter runtime readiness does not cover initialization and core presentation')
    if 'initialized = true;' not in runtime or 'enabled = false;' not in runtime:
        failures.append('Chapter runtime initialization/failure state is not explicit')
    if 'Assert.That(chapters[0].isActiveAndEnabled, Is.True' not in playmode:
        failures.append('PlayMode does not verify the chapter remains enabled')
    if 'Assert.That(chapters[0].IsChapterReady, Is.True' not in playmode:
        failures.append('PlayMode does not verify the constructed gameplay')
    return failures


def check(root: Path = ROOT) -> list[str]:
    paths = [root / 'Assets/_Project/Editor/OrderFirstImportSetup.cs',
             root / 'Assets/_Project/Runtime/ChapterOneExperience.cs',
             root / 'Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs']
    for path in paths:
        if not path.is_file() or path.stat().st_size == 0:
            return ['Missing or empty: ' + str(path.relative_to(root))]
    return validate(*(path.read_text(encoding='utf-8') for path in paths))


if __name__ == '__main__':
    issues = check()
    for issue in issues:
        print('FAIL:', issue)
    if not issues:
        print('STATIC_PASS_ONLY: chapter PlayMode readiness and fail-closed launch contract')
    raise SystemExit(bool(issues))
