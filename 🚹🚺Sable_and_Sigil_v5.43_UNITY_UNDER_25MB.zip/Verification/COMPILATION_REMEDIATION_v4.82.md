# Sable & Sigil v4.82 — P0 Compilation Repair Candidate

Baseline: `Sable_and_Sigil_v4.81_UNITY_CS1061_CS0117_FIXED_CANDIDATE.zip`.
Editor target: **Unity 2022.3.62f3** (unchanged).
Unity Test Framework: **1.1.33** (unchanged; its documented NUnit integration is based on NUnit 3.5).

## Root causes and exact changes

1. `Assets/_Project/Tests/EditMode/SaveFaultInjectionTests.cs`: replace the fixture-level `[NonParallelizable]` attribute with `[Parallelizable(ParallelScope.None)]`. The NUnit documentation defines these as equivalent; the latter is compatible with older NUnit versions. Leave test methods, filesystem isolation, fault injection, save keys, and test assembly references unchanged. Resolves the two observed `CS0246` diagnostics at source line 11 if the locally installed test package matches the project manifest.
2. `Assets/_Project/Tests/PlayMode/TheOrderRoom.Tests.PlayMode.asmdef`: add the direct assembly reference `TheOrderRoom.Domain` to `references`. The PlayMode tests call `ChapterOneExperience.Progress`, whose `ChapterOneProgress` type is declared in `TheOrderRoom.Domain`, which was not referenced by the tests. Resolves the three observed `CS0012` diagnostics at `ChapterOneSceneTests.cs` lines 42, 48, and 83, subject to actual Unity compilation.

## Scope preservation

- No original paths are removed or renamed; all original source and assets are retained.
- Only the two files listed above are modified relative to the supplied v4.81 archive.
- Original Unity `.meta` files and GUIDs, runtime and Domain code, package manifest, save system, and Unity Editor target remain byte-identical.
- Historical `MANIFEST*.sha256` and older verification reports are retained as version-specific evidence; they are **not** the integrity manifest for this revised archive. `SHA256_MANIFEST_v4.82.json` is the current archive manifest.
- `verify_p0_compiler_patch_v482.py` validates the limited patch against the original v4.81 archive, asmdef dependencies, file hashes, and metadata preservation.

## Evidence / release gates

- `STATIC_SOURCE`: verified by a reproducible offline Python patch audit.
- `UNITY_COMPILE_VERIFIED`: **NO** — Unity compilation was not executed.
- `EDITMODE_VERIFIED`: **NO** — NUnit tests were not executed.
- `PLAYMODE_VERIFIED`: **NO** — scene tests were not executed.
- `ANDROID_BUILD_VERIFIED`: **NO** — no build/device test was executed.

## Verification on Windows

1. Back up the currently open project. Close the Unity Editor and Unity Hub project window before replacing project files.
2. Import/extract the complete v4.82 archive as a **separate** project directory; do not overwrite an unknown, locally modified v4.81 copy.
3. Open with Unity 2022.3.62f3. Stay in Safe Mode until the Console shows zero compile errors. Do not interpret Safe Mode exit by itself as a passing test.
4. If compilation completes, generate the chapter scene using the project's existing bootstrap (the archive does not contain a saved `.unity` scene).
5. Execute EditMode and PlayMode tests and inspect NUnit result XML / `Editor.log`. Test mode is not validated by static checks.
6. To recheck integrity from the extracted project's parent directory, run:
   `python Verification/verify_p0_compiler_patch_v482.py ../Sable_and_Sigil_v4.81_UNITY_CS1061_CS0117_FIXED_CANDIDATE.zip ../Sable_and_Sigil_v4.82_P0_COMPILATION_REPAIR_CANDIDATE.zip`

## Sources

- Unity Test Framework 1.1.33: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/index.html
- Unity 2022.3 assembly definition format: https://docs.unity3d.com/2022.3/Documentation/Manual/AssemblyDefinitionFileFormat.html
- NUnit equivalent non-parallel fixture syntax: https://docs.nunit.org/articles/nunit/technical-notes/usage/Framework-Parallel-Test-Execution.html
