#!/usr/bin/env python3
"""Static regression gate for chapter-owned cameras and PlayMode save isolation.

This gate checks source contracts only. Unity PlayMode execution is required to
verify actual destruction and persistence behavior.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = Path('Assets/_Project/Runtime/ChapterOneExperience.cs')
PLAYMODE = Path('Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs')


def method_body(source: str, signature: str) -> str:
    start = source.find(signature)
    if start < 0:
        return ''
    brace = source.find('{', start + len(signature))
    if brace < 0:
        return ''
    depth = 0
    for i in range(brace, len(source)):
        if source[i] == '{':
            depth += 1
        elif source[i] == '}':
            depth -= 1
            if depth == 0:
                return source[brace:i + 1]
    return ''


def validate(runtime: str, tests: str) -> list[str]:
    issues: list[str] = []
    room = method_body(runtime, 'private void CreateRoom()')
    camera = room.find('var cameraGo = new GameObject("Chapter One Main Camera");')
    parent = room.find('cameraGo.transform.SetParent(transform, false);', camera)
    add_camera = room.find('viewCamera = cameraGo.AddComponent<Camera>();', camera)
    if camera < 0 or not (camera < parent < add_camera):
        issues.append('Fallback camera must be a child of chapter before adding Camera')

    lens = method_body(tests, 'public IEnumerator LensInspection_ReleasesAndReacquiresGpuSurface()')
    required = ('bool hadA = PlayerPrefs.HasKey(slotA);',
                'bool hadB = PlayerPrefs.HasKey(slotB);',
                'string oldA = PlayerPrefs.GetString(slotA, "");',
                'string oldB = PlayerPrefs.GetString(slotB, "");',
                'finally',
                'if (hadA) PlayerPrefs.SetString(slotA, oldA);',
                'else PlayerPrefs.DeleteKey(slotA);',
                'if (hadB) PlayerPrefs.SetString(slotB, oldB);',
                'else PlayerPrefs.DeleteKey(slotB);',
                'PlayerPrefs.Save();')
    if not lens or any(value not in lens for value in required):
        issues.append('Lens PlayMode test must restore both checkpoint slots in finally')
    elif lens.find('finally') < lens.find('chapter.Interact("shelf");'):
        issues.append('Checkpoint recovery must occur after test interactions')

    owner = method_body(tests, 'public IEnumerator ChapterOwnedFallbackCamera_IsRemovedWhenChapterIsDestroyed()')
    if not owner or 'main.transform.IsChildOf(chapter.transform)' not in owner or \
            'Object.Destroy(chapter.gameObject);' not in owner or \
            'Assert.That(main == null, Is.True' not in owner:
        issues.append('PlayMode must check fallback camera ownership and destruction')
    return issues


def check(root: Path = ROOT) -> list[str]:
    paths = [root / RUNTIME, root / PLAYMODE]
    if any(not p.is_file() or p.stat().st_size == 0 for p in paths):
        return ['Missing chapter runtime or PlayMode test source']
    return validate(*(p.read_text(encoding='utf-8') for p in paths))


if __name__ == '__main__':
    problems = check()
    for problem in problems:
        print('FAIL:', problem)
    if not problems:
        print('STATIC_PASS_ONLY: chapter fallback camera ownership and PlayMode save isolation')
    raise SystemExit(bool(problems))
