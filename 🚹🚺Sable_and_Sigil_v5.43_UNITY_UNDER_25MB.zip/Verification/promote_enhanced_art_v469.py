#!/usr/bin/env python3
"""Validate and optionally promote enhanced artwork without altering Unity metadata."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
COUNT = {"ChapterArt": 4, "LocationArt": 10}


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def plan(root):
    enhanced = root / "Design" / "EnhancedArt"
    resources = root / "Assets" / "_Project" / "Resources"
    changes = []
    for category, count in COUNT.items():
        for number in range(1, count + 1):
            name = ("Chapter_" if category == "ChapterArt" else "Scene_") + f"{number:02d}.jpg"
            source = enhanced / category / name
            target = resources / category / name
            if not source.is_file() or not target.is_file():
                raise ValueError(f"Missing source or target: {category}/{name}")
            source_bytes = source.read_bytes()
            target_bytes = target.read_bytes()
            if not source_bytes.startswith(b"\xff\xd8\xff") or not source_bytes.endswith(b"\xff\xd9"):
                raise ValueError(f"Invalid enhanced JPEG: {name}")
            if not target_bytes.startswith(b"\xff\xd8\xff") or not target_bytes.endswith(b"\xff\xd9"):
                raise ValueError(f"Invalid original JPEG: {name}")
            changes.append((source, target, sha256(source), sha256(target)))
    return changes


def promote(root, apply=False):
    changes = plan(root)
    if not apply:
        return {"mode": "DRY_RUN", "files": len(changes), "changed": sum(a != b for _, _, a, b in changes)}
    backup = root / "Verification" / "ArtPromotionBackup"
    if backup.exists():
        raise ValueError("Backup directory already exists; refusing to overwrite recovery evidence")
    backup.mkdir(parents=True)
    completed = []
    try:
        for source, target, source_hash, original_hash in changes:
            relative = target.relative_to(root / "Assets" / "_Project" / "Resources")
            destination = backup / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, destination)
            if sha256(destination) != original_hash:
                raise IOError(f"Backup integrity failure: {relative}")
            temporary = target.with_name(target.name + ".promotion.tmp")
            try:
                shutil.copy2(source, temporary)
                if sha256(temporary) != source_hash:
                    raise IOError(f"Copy integrity failure: {relative}")
                temporary.replace(target)
                completed.append((target, destination))
            finally:
                temporary.unlink(missing_ok=True)
    except Exception:
        for target, destination in reversed(completed):
            shutil.copy2(destination, target)
        raise
    report = {"mode": "APPLIED", "files": len(changes), "backup": str(backup.relative_to(root)),
              "assets": [{"path": str(target.relative_to(root)), "before": before, "after": after}
                         for _, target, after, before in changes]}
    (root / "Verification" / "V469_ART_PROMOTION_RESULT.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true", help="Promote art; default is read-only dry run")
    args = parser.parse_args()
    try:
        print(json.dumps(promote(ROOT, args.apply), indent=2))
    except (OSError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
