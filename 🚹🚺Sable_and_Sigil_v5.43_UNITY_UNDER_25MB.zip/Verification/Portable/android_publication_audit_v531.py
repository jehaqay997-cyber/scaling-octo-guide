#!/usr/bin/env python3
"""Audit Android release preconditions without claiming an unexecuted build passed.

Only the source project and explicitly supplied APK/AAB artifacts are inspected.
No Unity Editor APIs, Android build processes, or device tests are simulated.
"""

from __future__ import annotations

import argparse
import json
import re
import struct
import sys
import zipfile
from pathlib import Path
from typing import Any

EDITOR_TARGET = "2022.3.62f3"
REQUIRED_PLAY_API = 36
REQUIRED_PAGE_ALIGNMENT = 16_384
OFFICIAL_SOURCES = {
    "google_play_target_api": "https://support.google.com/googleplay/android-developer/answer/11926878",
    "android_page_sizes": "https://developer.android.com/guide/practices/page-sizes",
    "android_app_bundles": "https://developer.android.com/guide/app-bundle",
    "android_16_behaviour": "https://developer.android.com/about/versions/16/behavior-changes-16",
    "unity_16kb_support": "https://discussions.unity.com/t/android-unity-engine-support-for-16-kb-memory-page-sizes-android-15/1589588",
    "unity_security_2025": "https://unity.com/security/sept-2025-01",
    "unity_emudhra_2026": "https://unity.com/security/unity-emudhra-compromise",
    "unity_brotli_2026": "https://unity.com/security/unity-brotli-decoder-vulnerability",
    "unity_2022_gradle": "https://docs.unity3d.com/2022.3/Documentation/Manual/android-gradle-overview.html",
}


def parse_json_unique(path: Path) -> Any:
    def no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate JSON key: {key}")
            result[key] = value
        return result

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=no_duplicates)


def add(rows: list[dict[str, Any]], code: str, severity: str, state: str, detail: str) -> None:
    rows.append({"code": code, "priority": severity, "status": state, "detail": detail})


def scan_source(root: Path) -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    manifest_path = root / "Packages" / "manifest.json"
    version_path = root / "ProjectSettings" / "ProjectVersion.txt"
    player_settings = root / "ProjectSettings" / "ProjectSettings.asset"
    required = [manifest_path, version_path, player_settings]
    for file in required:
        if not file.is_file() or file.stat().st_size == 0:
            add(results, "REQUIRED_SOURCE_MISSING", "P0", "CONFIRMED", file.relative_to(root).as_posix())
    if any(not f.is_file() or f.stat().st_size == 0 for f in required):
        return {"editor": None, "packages": {}, "issues": results, "csharp_scanned": 0, "native_plugins": []}

    version = version_path.read_text(encoding="utf-8")
    match = re.search(r"(?m)^m_EditorVersion:\s*([^\s]+)\s*$", version)
    editor = match.group(1) if match else None
    if editor != EDITOR_TARGET:
        add(results, "EDITOR_BASELINE", "P0", "CONFIRMED", f"Expected {EDITOR_TARGET}; found {editor!r}.")

    try:
        manifest = parse_json_unique(manifest_path)
        if not isinstance(manifest, dict) or not isinstance(manifest.get("dependencies"), dict):
            raise ValueError("A project dependencies object is required")
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        add(results, "PACKAGE_MANIFEST_INVALID", "P0", "CONFIRMED", str(exc))
        manifest = {}
    packages = manifest.get("dependencies", {})
    for name, version in packages.items():
        if not isinstance(version, str) or not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
            add(results, "UNPINNED_PACKAGE", "P1", "CONFIRMED", f"{name}: {version!r}")
    if manifest.get("scopedRegistries"):
        add(results, "SCOPED_REGISTRY", "P0", "POTENTIAL", "Review remote registry trust under the October 2026 UPM security advisories.")
    if not (root / "Packages" / "packages-lock.json").is_file():
        add(results, "PACKAGE_LOCK_ABSENT", "P1", "CONFIRMED", "Allow Unity Package Manager to resolve packages, then retain its generated lock file; never synthesize transitive hashes.")

    player = player_settings.read_text(encoding="utf-8")
    if "scriptingBackend:" not in player or not re.search(r"(?m)^\s+Android:\s*1\s*$", player):
        add(results, "ANDROID_IL2CPP_NOT_PROVEN", "P0", "POTENTIAL", "The serialized Android IL2CPP setting is not established; Editor release validation is mandatory.")
    sdk_match = re.search(r"(?m)^\s*androidTargetSdkVersion:\s*(\d+)\s*$", player)
    if not sdk_match:
        add(results, "TARGET_API_UNVERIFIED", "P0", "CONFIRMED", "Target API is not explicitly serialized in the supplied source. Verify generated AndroidManifest/Play Console for API >= 36.")
    elif int(sdk_match.group(1)) < REQUIRED_PLAY_API:
        add(results, "TARGET_API_TOO_LOW", "P0", "CONFIRMED", f"Serialized API {sdk_match.group(1)} is below API {REQUIRED_PLAY_API}.")

    identifier = re.search(r"(?m)^\s+Android:\s*([^\s]+)\s*$", player.split("applicationIdentifier:")[-1])
    if identifier and identifier.group(1) == "com.theorderroom.game":
        add(results, "APPLICATION_ID_REVIEW", "P1", "CONFIRMED", "Android application ID belongs to the prior game identity; changing it requires explicit release and save-compatibility decisions.")

    native = sorted(
        path.relative_to(root).as_posix()
        for path in (root / "Assets").rglob("*")
        if path.is_file() and path.suffix.lower() in {".so", ".aar", ".jar", ".dll"}
    ) if (root / "Assets").exists() else []
    if native:
        add(results, "NATIVE_PLUGIN_AUDIT_REQUIRED", "P1", "POTENTIAL", "Embedded binary dependencies require individual 16 KB and security analysis.")

    source_files = sorted((root / "Assets").rglob("*.cs")) if (root / "Assets").exists() else []
    risky_names = ["BrotliStream", "BrotliDecoder", "AutomaticDecompression", "HttpClient"]
    usage: dict[str, list[str]] = {name: [] for name in risky_names}
    for path in source_files:
        try:
            data = path.read_text(encoding="utf-8")
        except (UnicodeError, OSError) as exc:
            add(results, "CS_READ_ERROR", "P0", "CONFIRMED", f"{path.relative_to(root)}: {type(exc).__name__}")
            continue
        for name in risky_names:
            if re.search(r"\b" + name + r"\b", data):
                usage[name].append(path.relative_to(root).as_posix())
    for name, paths in usage.items():
        if paths:
            add(results, "BROTLI_SURFACE_REVIEW", "P0", "POTENTIAL", f"{name} referenced in {', '.join(paths)}. Review attacker-controlled input.")

    return {
        "editor": editor,
        "packages": packages,
        "package_lock_present": (root / "Packages" / "packages-lock.json").is_file(),
        "issues": results,
        "csharp_scanned": len(source_files),
        "native_plugins": native,
        "compression_api_matches": usage,
    }


def inspect_elf(binary: bytes, name: str) -> list[dict[str, Any]]:
    problems: list[dict[str, Any]] = []
    if len(binary) < 64 or binary[:4] != b"\x7fELF":
        add(problems, "INVALID_ELF", "P0", "CONFIRMED", f"{name}: ELF header is missing/truncated")
        return problems
    if binary[4] != 2 or binary[5] != 1:
        add(problems, "ELF_FORMAT_UNSUPPORTED", "P0", "POTENTIAL", f"{name}: expected 64-bit little-endian ELF for ARM64.")
        return problems
    machine = struct.unpack_from("<H", binary, 18)[0]
    if machine != 183:
        add(problems, "ABI_MISMATCH", "P0", "CONFIRMED", f"{name}: ARM64 ELF expected, found e_machine={machine}.")
    program_offset = struct.unpack_from("<Q", binary, 32)[0]
    entry_size, entry_count = struct.unpack_from("<HH", binary, 54)
    if entry_size < 56 or entry_count == 0 or program_offset > len(binary) or (entry_size * entry_count) > len(binary) - program_offset:
        add(problems, "INVALID_ELF_PROGRAM_TABLE", "P0", "CONFIRMED", f"{name}: no valid program header table.")
        return problems
    load_count = 0
    for index in range(entry_count):
        offset = program_offset + index * entry_size
        p_type, _, p_offset, p_vaddr, _, _, _, p_align = struct.unpack_from("<IIQQQQQQ", binary, offset)
        if p_type != 1:
            continue
        load_count += 1
        if p_align < REQUIRED_PAGE_ALIGNMENT or (p_offset - p_vaddr) % REQUIRED_PAGE_ALIGNMENT:
            add(problems, "ELF_LOAD_NOT_16K", "P0", "CONFIRMED", f"{name}: PT_LOAD[{index}] p_align={p_align}, offset={p_offset}, vaddr={p_vaddr}.")
    if load_count == 0:
        add(problems, "NO_LOAD_SEGMENTS", "P0", "CONFIRMED", f"{name}: ELF has no PT_LOAD segment.")
    return problems


def inspect_archive(path: Path) -> dict[str, Any]:
    problems: list[dict[str, Any]] = []
    artifacts: list[dict[str, Any]] = []
    suffix = path.suffix.lower()
    if suffix not in {".apk", ".aab"}:
        raise ValueError("Expected a .apk or .aab artifact")
    with zipfile.ZipFile(path, "r") as archive:
        damaged = archive.testzip()
        if damaged:
            add(problems, "BAD_ZIP_CRC", "P0", "CONFIRMED", f"First damaged archive entry: {damaged}")
        for entry in archive.infolist():
            normalized = entry.filename.replace("\\", "/")
            if not normalized.endswith(".so"):
                continue
            if "/arm64-v8a/" not in "/" + normalized:
                continue
            data = archive.read(entry)
            artifacts.append({"name": normalized, "bytes": len(data)})
            problems.extend(inspect_elf(data, normalized))
            if suffix == ".apk" and entry.compress_type == zipfile.ZIP_STORED:
                with path.open("rb") as stream:
                    stream.seek(entry.header_offset)
                    header = stream.read(30)
                if len(header) < 30 or header[:4] != b"PK\x03\x04":
                    add(problems, "ZIP_ENTRY_HEADER_INVALID", "P0", "CONFIRMED", normalized)
                else:
                    file_name_bytes, extra_bytes = struct.unpack_from("<HH", header, 26)
                    payload_offset = entry.header_offset + 30 + file_name_bytes + extra_bytes
                    if payload_offset % REQUIRED_PAGE_ALIGNMENT:
                        add(problems, "APK_LIBRARY_ZIP_NOT_16K", "P0", "CONFIRMED", f"{normalized}: data offset {payload_offset} is not 16 KB aligned.")
    if not artifacts:
        add(problems, "NO_ARM64_ELF_FOUND", "P0", "POTENTIAL", "No arm64-v8a shared libraries were present; inspect the final Android build.")
    return {
        "path": str(path),
        "format": suffix[1:].upper(),
        "arm64_elf_entries": artifacts,
        "checks": problems,
        "scope": "ELF PT_LOAD alignment and APK uncompressed library offsets only. Not a full 16 KB, RELRO, AAB-generated APK, signing, or target-SDK certification.",
    }


def audit(root: Path, archive: Path | None = None) -> dict[str, Any]:
    if not root.is_dir():
        raise ValueError(f"Project directory not found: {root}")
    project = scan_source(root)
    artifact = inspect_archive(archive) if archive is not None else None
    issues = list(project["issues"]) + (artifact["checks"] if artifact else [])
    return {
        "release": "v5.31",
        "project": "Sable & Sigil",
        "unity_target": EDITOR_TARGET,
        "google_play_target_api_required": REQUIRED_PLAY_API,
        "source_audit": project,
        "artifact_audit": artifact,
        "issues": issues,
        "publication_status": "NOT_VERIFIED",
        "unity_compile": "NOT_EXECUTED",
        "unity_editor_tests": "NOT_EXECUTED",
        "android_build": "INSPECTED_ONLY" if archive is not None else "NOT_EXECUTED",
        "device_test": "NOT_EXECUTED",
        "references": OFFICIAL_SOURCES,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--artifact", type=Path, help="Optional actual built APK or AAB to inspect")
    parser.add_argument("--json", type=Path, help="Optional path for JSON results")
    parser.add_argument("--enforce-publication", action="store_true", help="Refuse to approve publication without full external release evidence")
    args = parser.parse_args(argv)
    try:
        result = audit(args.project.resolve(), args.artifact.resolve() if args.artifact else None)
    except (OSError, ValueError, zipfile.BadZipFile, struct.error) as exc:
        print(f"ANDROID_PUBLICATION_AUDIT_ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    payload = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.json is not None:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(payload, encoding="utf-8")
    print(payload)
    if args.enforce_publication:
        print("ANDROID_PUBLICATION_BLOCKED: A Unity AAB build, manifest/SDK evidence, 16 KB/RELRO checks, signing verification, and Play review are mandatory.", file=sys.stderr)
        return 3
    return 0 if not any(issue["code"] in {"REQUIRED_SOURCE_MISSING", "PACKAGE_MANIFEST_INVALID", "EDITOR_BASELINE", "INVALID_ELF", "INVALID_ELF_PROGRAM_TABLE", "ELF_LOAD_NOT_16K", "APK_LIBRARY_ZIP_NOT_16K"} for issue in result["issues"]) else 1


if __name__ == "__main__":
    sys.exit(main())
