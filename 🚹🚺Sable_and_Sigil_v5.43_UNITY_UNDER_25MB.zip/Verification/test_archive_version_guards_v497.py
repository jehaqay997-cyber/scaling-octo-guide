"""The two historical ZIP checkers must reject an incompatible Unity version."""
import sys
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_project_integrity import validate
from verify_source_integrity_v481 import check_archive


class ArchiveUnityVersionGuards(unittest.TestCase):
    def make_zip(self, path, version):
        with ZipFile(path, 'w', ZIP_DEFLATED) as file:
            file.writestr('ProjectSettings/ProjectVersion.txt', 'm_EditorVersion: ' + version + '\n')
            file.writestr('Assets/_Project/Runtime/AuthoredPuzzleHintController.cs',
                          'namespace TheOrderRoom.Runtime { public class AuthoredPuzzleHintController {} }\n')
            file.writestr('Assets/_Project/Runtime/AuthoredPuzzleHintController.cs.meta',
                          'fileFormatVersion: 2\nguid: 217d5ad5185c4485bc334d75248bf1b9\n')

    def test_correct_unity_version_passes_both_checkers(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'right.zip'
            self.make_zip(path, '2022.3.62f3')
            for report in (validate(path), check_archive(path)):
                self.assertFalse([i for i in report['errors'] if 'UNITY_EDITOR_VERSION_MISMATCH' in i], report)
                self.assertFalse(any('Unity 6.3.28f1' in line for line in report['warnings']))

    def test_wrong_unity_version_fails_both_checkers(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'wrong.zip'
            self.make_zip(path, '6000.3.28f1')
            for report in (validate(path), check_archive(path)):
                self.assertTrue(any(i.startswith('UNITY_EDITOR_VERSION_MISMATCH:') for i in report['errors']), report)

    def test_version_like_prose_does_not_pass(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'misleading.zip'
            self.make_zip(path, '2022.3.62f3-other')
            for report in (validate(path), check_archive(path)):
                self.assertTrue(any(i.startswith('UNITY_EDITOR_VERSION_MISMATCH:') for i in report['errors']), report)


if __name__ == '__main__':
    unittest.main()
