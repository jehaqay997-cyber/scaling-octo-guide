# Sable & Sigil v4.65 — Content Contract Audit

## Changes actually made
- Added a machine-readable design contract for 10 locations across 4 chapters.
- Added explicit evidence IDs, prerequisite ordering, three hint tiers, and artwork SHA-256 binding.
- Added a standalone Python validator; the original Unity source and images are preserved byte-for-byte.
- Puzzle mechanics remain proposals. No new runtime gameplay, 3D scenes, or Unity tests are claimed.

## Visual review
- The four chapter artworks are cinematic widescreen illustrations.
- The ten location images are portrait-source compositions placed inside 1280x720 canvases with side fills. These are gallery/reference assets, not navigable 3D levels.
- Avoid stretching the subject. The artwork is already 16:9 as a whole image; the meaningful portrait content occupies a narrower center region.
- The location visual assets must not be represented as implemented interactive scenes.

## Remaining release blockers
- ProjectVersion.txt declares Unity 2022.3.62f3, not target 6000.3.28f1.
- Unity compilation, scene bootstrap, EditMode, PlayMode, Android build and device tests are unverified in this environment.
- The content contract is intentionally not wired into runtime progression. Its hint text is design guidance, not validated puzzle solutions.
