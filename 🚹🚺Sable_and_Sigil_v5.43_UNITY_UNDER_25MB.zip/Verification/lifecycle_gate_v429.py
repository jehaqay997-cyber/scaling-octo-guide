#!/usr/bin/env python3
"""Fail-closed source contracts for input, camera layout and UI gesture ownership.

These checks operate on source text only; they do not assert Unity compilation.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / "Assets" / "_Project" / "Runtime"

CONTRACTS = {
    "unowned_touch_blocked_on_pause": ("OrderPointerInput.cs", r"OnApplicationPause\(bool paused\)\s*\{\s*if\s*\(paused\)\s*SuspendInput\(\);"),
    "unowned_touch_blocked_on_focus_loss": ("OrderPointerInput.cs", r"OnApplicationFocus\(bool focused\)\s*\{\s*if\s*\(!focused\)\s*SuspendInput\(\);"),
    "touch_block_set_before_resume": ("OrderPointerInput.cs", r"private void SuspendInput\(\)\s*\{[^{}]*blockUntilTouchesEnd\s*=\s*true;"),
    "touch_cancel_on_suspension": ("OrderPointerInput.cs", r"private void SuspendInput\(\)\s*\{\s*CancelGesture\(\);"),
    "empty_world_drag_prevented": ("OrderGame.cs", r"if\s*\(gestureItem\s*==\s*null\)\s*return;\s*gestureDragging\s*=\s*true;"),
    "drag_board_revision_checked": ("OrderGame.cs", r"ReferenceEquals\(gestureBoard,\s*board\)\s*&&\s*board\.Revision\s*==\s*gestureRevision"),
    "drag_cancel_restores_visual": ("OrderGame.cs", r"gestureItem\.transform\.position\s*=\s*gestureOriginalPosition;"),
    "layout_restores_canvas_anchors": ("OrderScreenLayout.cs", r"content\.anchorMin\s*=\s*originalAnchorMin;[\s\S]*?content\.anchorMax\s*=\s*originalAnchorMax;"),
    "layout_restores_canvas_offsets": ("OrderScreenLayout.cs", r"content\.offsetMin\s*=\s*originalOffsetMin;[\s\S]*?content\.offsetMax\s*=\s*originalOffsetMax;"),
    "layout_restores_scaler": ("OrderScreenLayout.cs", r"scaler\.referenceResolution\s*=\s*originalReferenceResolution;[\s\S]*?scaler\.screenMatchMode\s*=\s*originalScreenMatchMode;"),
    "layout_restores_camera": ("OrderScreenLayout.cs", r"boardCamera\.transform\.SetPositionAndRotation\(originalPosition,\s*cameraRotation\);"),
}

def audit(base=RUNTIME):
    failures = []
    for name, (source, pattern) in CONTRACTS.items():
        if not re.search(pattern, (base/source).read_text(encoding="utf-8-sig")):
            failures.append(name)
    return {"result": "STATIC_PASS_ONLY" if not failures else "FAIL",
            "contracts": len(CONTRACTS), "failures": failures,
            "unity_compile_verified": False, "unity_tests_executed": False,
            "device_verified": False}

if __name__ == "__main__":
    report = audit()
    path = ROOT / "Verification" / "INTEGRITY_REPORT_v4.29.json"
    path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    sys.exit(bool(report["failures"]))
