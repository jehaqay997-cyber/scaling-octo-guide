#!/usr/bin/env python3
"""Offline contract check for bounded chapter image residency.

This is static source validation, not a Unity memory measurement.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GALLERY = Path('Assets/_Project/Runtime/ChapterGalleryView.cs')
PLAYMODE = Path('Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs')
CHAPTER = Path('Assets/_Project/Runtime/ChapterOneExperience.cs')


def method(source: str, signature: str) -> str:
    start = source.find(signature)
    if start < 0:
        return ''
    opening = source.find('{', start + len(signature))
    if opening < 0:
        return ''
    depth = 0
    for index in range(opening, len(source)):
        if source[index] == '{':
            depth += 1
        elif source[index] == '}':
            depth -= 1
            if depth == 0:
                return source[opening:index + 1]
    return ''


def validate(gallery: str, tests: str, chapter: str) -> list[str]:
    failures = []
    build = method(gallery, 'private void Build()')
    acquire = method(gallery, 'private Texture2D GetChapterTexture(int index)')
    release = method(gallery, 'private void ReleaseChapterTexture()')
    close = method(gallery, 'public void Close()')
    disable = method(gallery, 'private void OnDisable()')
    destroy = method(gallery, 'private void OnDestroy()')
    refresh = method(gallery, 'private void Refresh()')
    if 'Resources.Load<Texture2D>' in build:
        failures.append('Gallery preload still acquires images while constructing the UI')
    if 'Resources.Load<Texture2D>' not in acquire or 'ReleaseChapterTexture();' not in acquire:
        failures.append('Chapter changes do not load on demand and release the old image')
    if 'activeChapterTextureIndex == index' not in acquire:
        failures.append('Repeated same-chapter rendering can reload the same texture')
    if 'artwork.texture = null' not in release or 'Resources.UnloadAsset(previous)' not in release:
        failures.append('Chapter texture not detached before native memory unload')
    for name, block in [('Close', close), ('OnDisable', disable), ('OnDestroy', destroy)]:
        if 'ReleaseChapterTexture();' not in block:
            failures.append(f'{name} does not release chapter textures')
    if 'GetChapterTexture(selectedIndex)' not in refresh or 'FitArtwork(selectedChapterTexture)' not in refresh:
        failures.append('Refresh does not preserve aspect ratio with the selected chapter image')
    if 'ChapterArtworkLoadsOnDemandAndReleasesWhenClosed' not in tests or \
            'Assert.That(image.texture, Is.Null' not in tests or \
            'gallery.Show();' not in tests:
        failures.append('PlayMode regression test does not cover release and reopen')
    if 'if (!initialized || (chapterGallery != null && chapterGallery.IsOpen)) return;' not in chapter:
        failures.append('Chapter continues world updates behind a fully opaque gallery')
    if 'private ChapterGalleryView chapterGallery;' not in chapter or \
            'if (chapterGallery == null) chapterGallery = GetComponent<ChapterGalleryView>();' not in chapter:
        failures.append('Chapter has no stable gallery component reference')
    if 'gallery.ResidentChapterArtworkCount' not in tests or \
            'Assert.That(gallery.ResidentChapterArtworkCount, Is.Zero);' not in tests:
        failures.append('PlayMode does not enforce bounded owned chapter image residency')
    return failures


def check(root: Path = ROOT) -> list[str]:
    paths = (GALLERY, PLAYMODE, CHAPTER)
    for path in paths:
        if not (root / path).is_file() or (root / path).stat().st_size == 0:
            return ['Missing or empty contract source: ' + str(path)]
    return validate(*( (root / path).read_text(encoding='utf-8') for path in paths))


if __name__ == '__main__':
    issues = check()
    for item in issues:
        print('FAIL:', item)
    if not issues:
        print('STATIC_PASS_ONLY: chapter art on-demand ownership and lifecycle')
    raise SystemExit(bool(issues))
