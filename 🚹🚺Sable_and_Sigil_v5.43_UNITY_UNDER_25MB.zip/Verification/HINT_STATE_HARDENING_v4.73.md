# v4.73 Hint State Hardening

- Clear displayed hint when its authoritative prerequisite evidence is revoked.
- Reset revealed tier on catalog replacement, preventing cross-catalog hint leakage.
- Reject duplicate evidence identifiers, repeated prerequisites, and self-dependencies in runtime catalog.
- Add two Unity EditMode regression tests (authored, not executed).
- Unity compilation, PlayMode, Android, and scene wiring remain unverified.
- Existing Unity Editor version is unchanged; do not assume compatibility with Unity 6.3.28f1.
