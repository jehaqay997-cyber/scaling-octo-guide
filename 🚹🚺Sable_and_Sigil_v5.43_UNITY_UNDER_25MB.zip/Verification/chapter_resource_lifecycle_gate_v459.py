#!/usr/bin/env python3
"""Static guard for chapter power pacing, RenderTexture lifecycle and image ownership.

This is source validation only: it does not measure thermal, memory or GPU behavior.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHAPTER = Path('Assets/_Project/Runtime/ChapterOneExperience.cs')
GALLERY = Path('Assets/_Project/Runtime/ChapterGalleryView.cs')
GOVERNOR = Path('Assets/_Project/Runtime/OrderPerformanceGovernor.cs')
PLAYMODE = Path('Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs')


def validate(chapter: str, gallery: str, governor: str, playmode: str) -> list[str]:
    errors = []
    if 'gameObject.AddComponent<OrderPerformanceGovernor>()' not in chapter or \
            'GetComponent<OrderPerformanceGovernor>() == null' not in chapter:
        errors.append('Chapter is missing a single-owner frame-pacing governor')
    if 'if (inspectionTarget == null || (!inspectionTarget.IsCreated() && !inspectionTarget.Create()))' not in chapter:
        errors.append('Inspection rendering lacks a guarded GPU allocation')
    if 'if (inspectionTarget != null && inspectionTarget.IsCreated()) inspectionTarget.Release();' not in chapter:
        errors.append('Inspection GPU memory is not released after use')
    if 'private void OnApplicationPause(bool paused)' not in chapter or \
            'if (inspectionTarget.IsCreated() || inspectionTarget.Create())' not in chapter:
        errors.append('Pause/resume does not restore the inspection surface')
    if 'if (artwork != null && artwork.texture == previous) artwork.texture = null;' not in gallery or \
            'Resources.UnloadAsset(previous)' not in gallery:
        errors.append('Image unloading can leave a dangling RawImage native reference')
    if 'SuspendWorldCamera();' not in gallery or 'RestoreWorldCamera();' not in gallery or \
            'if (worldCameraWasEnabled) hiddenWorldCamera.enabled = true;' not in gallery:
        errors.append('Opaque gallery does not suspend and restore world rendering')
    if 'private void OnDisable()' not in governor or 'activeOwner = null;' not in governor:
        errors.append('Frame pacing ownership is not restored')
    if 'var governor = chapters[0].GetComponent<OrderPerformanceGovernor>();' not in playmode or \
            'Assert.That(governor.isActiveAndEnabled, Is.True);' not in playmode:
        errors.append('PlayMode lacks governor acceptance checks')
    return errors


def check(root: Path = ROOT) -> list[str]:
    paths = (CHAPTER, GALLERY, GOVERNOR, PLAYMODE)
    for path in paths:
        full = root / path
        if not full.is_file() or full.stat().st_size == 0:
            return ['Missing or empty source: ' + str(path)]
    return validate(*( (root / path).read_text(encoding='utf-8') for path in paths))


if __name__ == '__main__':
    failures = check()
    for error in failures:
        print('FAIL:', error)
    if not failures:
        print('STATIC_PASS_ONLY: chapter frame pacing, render surface and gallery image ownership')
    raise SystemExit(bool(failures))
