import importlib.util
import pathlib
import tempfile
import unittest

MODULE = pathlib.Path(__file__).with_name("promote_enhanced_art_v469.py")
spec = importlib.util.spec_from_file_location("art_promotion", MODULE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class ArtPromotionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = pathlib.Path(self.temp.name)
        for category, count in module.COUNT.items():
            for index in range(1, count + 1):
                name = ("Chapter_" if category == "ChapterArt" else "Scene_") + f"{index:02d}.jpg"
                for prefix, payload in (("Design/EnhancedArt", b"\xff\xd8\xffNEW\xff\xd9"),
                                        ("Assets/_Project/Resources", b"\xff\xd8\xffOLD\xff\xd9")):
                    path = self.root / prefix / category / name
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(payload)
        (self.root / "Verification").mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def test_dry_run_never_changes_assets(self):
        result = module.promote(self.root)
        self.assertEqual(result["files"], 14)
        self.assertEqual(result["changed"], 14)
        self.assertFalse((self.root / "Verification/ArtPromotionBackup").exists())

    def test_apply_keeps_original_backups(self):
        result = module.promote(self.root, True)
        self.assertEqual(result["mode"], "APPLIED")
        self.assertEqual(len(result["assets"]), 14)
        self.assertEqual((self.root / "Verification/ArtPromotionBackup/LocationArt/Scene_01.jpg").read_bytes(), b"\xff\xd8\xffOLD\xff\xd9")
        self.assertEqual((self.root / "Assets/_Project/Resources/LocationArt/Scene_01.jpg").read_bytes(), b"\xff\xd8\xffNEW\xff\xd9")

    def test_missing_source_blocks_all_changes(self):
        (self.root / "Design/EnhancedArt/LocationArt/Scene_10.jpg").unlink()
        with self.assertRaises(ValueError):
            module.promote(self.root, True)
        self.assertFalse((self.root / "Verification/ArtPromotionBackup").exists())

    def test_second_apply_refused(self):
        module.promote(self.root, True)
        with self.assertRaises(ValueError):
            module.promote(self.root, True)

    def test_corrupt_jpeg_rejected(self):
        (self.root / "Design/EnhancedArt/ChapterArt/Chapter_01.jpg").write_bytes(b"invalid")
        with self.assertRaises(ValueError):
            module.promote(self.root, True)


if __name__ == "__main__":
    unittest.main()
