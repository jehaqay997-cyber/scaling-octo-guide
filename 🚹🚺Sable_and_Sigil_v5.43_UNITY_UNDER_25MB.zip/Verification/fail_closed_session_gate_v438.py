#!/usr/bin/env python3
"""Source contract gate for board restore and failed-session recovery (not a C# runtime test)."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
BOARD = ROOT / "Assets/_Project/Domain/OrderBoard.cs"
GAME = ROOT / "Assets/_Project/Runtime/OrderGame.cs"
TEST = ROOT / "Assets/_Project/Tests/EditMode/BoardExternalDictionarySafetyTests.cs"


def check(board: str, game: str, test: str) -> list[str]:
    failures = []
    restore = board.split("private bool RestoreCore(", 1)[-1].split("private bool ValidateSnapshot(", 1)[0]
    for requirement in (
        "catch (ArgumentException) { return false; }",
        "catch (InvalidOperationException) { return false; }",
        "catch (NotSupportedException) { return false; }",
        "candidate.Add(pair.Key, pair.Value);",
        "locations = candidate; occupancy = counts; totalWeight = weights;",
    ):
        if requirement not in restore:
            failures.append("Board restore contract missing: " + requirement)
    start = game.split("private void Start()", 1)[-1].split("public void Select(", 1)[0]
    rejected = re.search(r"if \(valid\)\s*\{.*?\}\s*else\s*\{(.*?)\}\s*\}\s*else", start, flags=re.S)
    if rejected is None:
        failures.append("Runtime save staging rejection branch cannot be located")
    else:
        branch = rejected.group(1)
        for token in ("saveSessionBlocked = true;", "selected = null;", "board = null;", "SetStatus("):
            if token not in branch:
                failures.append("Runtime save staging rejection does not fail closed: " + token)
        if "LoadLevel(" in branch:
            failures.append("Runtime save staging rejection creates replacement level")
    if "UnsupportedExternalEnumerationIsRejectedWithoutChangingBoardOrTicket" not in test:
        failures.append("External dictionary regression test not found")
    return failures


def audit(root: Path = ROOT) -> dict:
    failures = check((root / BOARD.relative_to(ROOT)).read_text(encoding="utf-8"),
                     (root / GAME.relative_to(ROOT)).read_text(encoding="utf-8"),
                     (root / TEST.relative_to(ROOT)).read_text(encoding="utf-8"))
    return {"gate": "fail_closed_session_v438", "status": "STATIC_PASS_ONLY" if not failures else "FAIL",
            "unity_compiled": False, "nunit_executed": False, "issues": failures}


if __name__ == "__main__":
    result = audit()
    print(json.dumps(result, indent=2))
    sys.exit(bool(result["issues"]))
