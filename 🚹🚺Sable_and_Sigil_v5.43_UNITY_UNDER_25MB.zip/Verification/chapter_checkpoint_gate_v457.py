#!/usr/bin/env python3
"""Static acceptance contract for dual-slot, fail-closed Chapter One checkpoints."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTRACTS = {
    Path('Assets/_Project/Domain/ChapterCheckpointCodec.cs'): (
        'public static string Encode(long revision, int flags, int dial)',
        'public static bool TryDecode(string data, out long revision, out int flags, out int dial)',
        'ChapterOneProgress.IsValid(flags, dial)',
        'Checksum(canonical) != expectedChecksum',
    ),
    Path('Assets/_Project/Runtime/ChapterOneExperience.cs'): (
        'private const string CheckpointA = SavePrefix + "CheckpointA";',
        'private const string CheckpointB = SavePrefix + "CheckpointB";',
        'PlayerPrefs.SetString(destination, snapshot);',
        'PlayerPrefs.Save();',
        'nextCheckpointIsA = !nextCheckpointIsA;',
        'bool validA = ChapterCheckpointCodec.TryDecode(',
        'bool validB = ChapterCheckpointCodec.TryDecode(',
        'bool useA = validA && (!validB || revisionA >= revisionB);',
        'if (PlayerPrefs.HasKey(CheckpointA) || PlayerPrefs.HasKey(CheckpointB))',
        'int flags = PlayerPrefs.GetInt(SavePrefix + "Flags", 0);',
        'progress.Restart();',
    ),
    Path('Assets/_Project/Tests/EditMode/ChapterCheckpointCodecTests.cs'): (
        'RoundTripValidCheckpointPreservesState',
        'InvalidOrTruncatedSnapshotsAreRejected',
        'InvalidProgressCannotBeWritten',
    ),
}

def check(root=ROOT):
    failures = []
    for path, snippets in CONTRACTS.items():
        full = root / path
        if not full.is_file() or full.stat().st_size == 0:
            failures.append('Missing or empty: ' + str(path))
            continue
        contents = full.read_text(encoding='utf-8')
        for snippet in snippets:
            if snippet not in contents:
                failures.append(str(path) + ': missing ' + snippet)
    return failures

if __name__ == '__main__':
    problems = check()
    for problem in problems:
        print('FAIL:', problem)
    if not problems:
        print('STATIC_PASS_ONLY: checkpoint validation, redundancy and migration contracts')
    raise SystemExit(bool(problems))
