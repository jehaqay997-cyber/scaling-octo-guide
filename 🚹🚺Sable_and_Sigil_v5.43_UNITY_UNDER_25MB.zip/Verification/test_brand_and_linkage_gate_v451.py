"""Mutation-based regression tests for the rebrand and Unity link integrity."""
import tempfile
import unittest
from pathlib import Path
from brand_and_linkage_gate_v451 import inspect


class BrandAndLinkageGateTests(unittest.TestCase):
    def test_candidate_passes(self):
        self.assertEqual(inspect(), [])

    def test_missing_required_source_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            (Path(temp) / "Assets").mkdir()
            self.assertTrue(any("Missing required file" in e for e in inspect(Path(temp))))

    def test_unpaired_asset_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp) / "Assets"
            folder.mkdir()
            (folder / "orphan.cs").write_text("class Orphan {}")
            self.assertTrue(any("Asset missing .meta" in e for e in inspect(Path(temp))))

    def test_zero_byte_asset_fails(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp) / "Assets"
            folder.mkdir()
            (folder / "empty.cs").touch()
            self.assertTrue(any("Zero-byte file" in e for e in inspect(Path(temp))))


if __name__ == "__main__":
    unittest.main()
