# Sable & Sigil v4.83 — P0 compiler dependencies and regression hardening

## Source identity
- Full-project base: `Sable_and_Sigil_v4.82_P0_COMPILATION_REPAIR_CANDIDATE.zip`.
- Editor target: `2022.3.62f3` (unchanged).
- Test Framework package: `com.unity.test-framework` `1.1.33` (unchanged).
- Game runtime, story and art content, save schema, Android settings, C# assembly names, and all Unity `.meta` identifiers are **unchanged from v4.82**.
- Previously applied v4.82 compilation remedies **remain**: fixture `[Parallelizable(ParallelScope.None)]` and direct `TheOrderRoom.Domain` reference in the PlayMode asmdef.

## New changes in v4.83 (four existing files)
1. `Verification/release_source_gate_v435.py`: the approved PlayMode assembly contract now REQUIRES the direct `TheOrderRoom.Domain` reference. Previously this gate incorrectly rejected the compiler repair from v4.82.
2. `Verification/test_release_source_gate_v435.py`: added a regression test proving that deleting or duplicating the PlayMode-to-Domain reference fails the dependency audit. Production assemblies' rules stay fail-closed.
3. `Assets/_Project/Tests/EditMode/SaveFaultInjectionTests.cs`: Reset process-wide injected storage hooks before creating each temporary test store. Teardown always attempts test-hook reset, safely handles a partial setup, and clears its directory reference even if file removal throws. File deletion failures remain visible, not silently swallowed.
4. `Verification/test_content_graph_v466.py`: mutation tests now load the checked-out content/art when invoked by unittest discovery, while still accepting an explicit archive path. The previous test treated discovery's `-q` flag as an archive filename and broke the all-tests audit.

## Executed evidence (offline only)
- Before remediation, the 206-test `test_*gate*.py` suite had **2 failures**, both caused by the stale PlayMode asmdef dependency contract. The full static audit also failed in its release governance and final-integrity stages.
- After remediation: `python -m unittest discover -s Verification -p 'test_*.py' -q` passed **230 of 230 tests**.
- `python Verification/run_full_static_audit_v443.py` passed all **37 named gates** and the final `all_python_regressions` stage (**38/38 steps**).
- New archive's CRC, SHA-256 manifest, original asset preservation and assembly-reference contracts are checked independently by `verify_v483_candidate.py`.
- These static checks **do not** compile C#, execute NUnit in Unity, generate the missing scene, or build Android.

## Required runtime acceptance in Unity
1. Back up the locally edited project. Extract v4.83 into a new directory with `Assets`, `Packages`, `ProjectSettings`, and `Verification` at its root. Do not nest the project under another extra ZIP folder.
2. Launch the extracted project with Unity **2022.3.62f3**; stay in Safe Mode if errors appear. A screenshot showing v4.81 in the title bar does **not** show v4.83 compiled.
3. Check the Console for CS0246 / CS0012 and any newly surfaced diagnostics. Do not declare compilation passed unless there are zero compiler errors.
4. If compilation succeeds, run `Sable & Sigil/Create or Open Chapter One` if the chapter scene was not generated. Then run EditMode and PlayMode via Test Runner. Save the Editor.log and NUnit XML.
5. For automated validation, with the project **closed** in Unity Editor, use `Verification/Run-UnityVerification.ps1` with an explicit Unity Editor executable path; inspect all outputs before claiming a release pass.
6. Only after Unity tests pass, test pause/resume, lens RenderTexture reallocation, PlayerPrefs preservation and restart on a physical Android device.

## Release gates
- STATIC_SOURCE_VERIFIED: YES (for the packaged source contracts and executed offline Python checks)
- UNITY_COMPILE_VERIFIED: NO
- UNITY_EDITMODE_VERIFIED: NO
- UNITY_PLAYMODE_VERIFIED: NO
- ANDROID_BUILD_VERIFIED: NO
- DEVICE_VERIFIED: NO

## Official references
- Unity assembly definition format: https://docs.unity3d.com/2022.3/Documentation/Manual/AssemblyDefinitionFileFormat.html
- Unity Test Framework 1.1: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/index.html
- NUnit ParallelScope.None and NonParallelizable: https://docs.nunit.org/articles/nunit/technical-notes/usage/Framework-Parallel-Test-Execution.html
