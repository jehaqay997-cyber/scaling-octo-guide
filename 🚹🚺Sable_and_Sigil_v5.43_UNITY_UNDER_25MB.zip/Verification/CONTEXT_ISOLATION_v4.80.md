# v4.80 — Context Isolation and Chapter Dependency Audit

## Applied source fixes

- Rebinding the hint controller to a different catalog now clears the prior puzzle ID and evidence snapshot, as well as the disclosure cursor. This prevents cross-catalog state reuse.
- Authored hint prerequisites are rejected if they reference evidence from a later chapter.
- Added an EditMode regression test for catalog replacement and mandatory fresh evidence context.

## Verification scope

ZIP CRC, JSON syntax, entry uniqueness, metadata presence and static source assertions were checked in Python. Unity compilation, EditMode execution, PlayMode execution, Android build and device verification were **not** executed.

## Outstanding P0

- `SetContext` still accepts evidence from an arbitrary caller; it must be wired to a trusted progress service, not to untrusted UI or player input.
- `ProjectSettings/ProjectVersion.txt` remains on the previous editor version; Unity 6.3.28f1 migration is not verified.
- The saved ChapterOne scene and resolved `packages-lock.json` are not included; do not synthesize either without the Unity Editor.
