# Hint UI integration v4.72

## Scope
- UI controller can bind a Unity UI Button and Text to the authored hint catalog.
- Context is supplied explicitly via SetContext(puzzleId, authoritativeEvidenceSnapshot).
- Hint tiers are bounded to 1..3 and do not change gameplay or save data.
- Invalid evidence snapshots are rejected before context mutation.
- Runtime hint eligibility remains enforced by AuthoredPuzzleHintCatalog.

## Required scene integration
- Add AuthoredPuzzleHintCatalog and AuthoredPuzzleHintController to a scene object.
- Assign a Button and Text via inspector or Configure.
- On puzzle change and evidence change, call SetContext with a snapshot from the authoritative progression owner.
- Do not infer collected evidence from UI clicks.

## Verification boundaries
- NUnit EditMode test source included, but NOT executed in Unity.
- Unity Editor compilation, PlayMode, Android, and real scene wiring NOT verified.
- ProjectVersion still requires migration review against Unity 6.3.28f1.
