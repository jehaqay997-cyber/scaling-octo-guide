# v4.75 — Hint Security and Lifecycle Audit

## Changes
- Clear visible hint text when the controller is disabled; re-enable never redisplays it automatically.
- Prevent duplicate button listeners on repeated OnEnable callbacks.
- Reject oversized puzzle identifiers and evidence identifiers, bound evidence snapshots to 4096 IDs, and reject failing enumerators without partial context mutation.
- Reject hint catalogs referencing unknown evidence IDs.
- Add three Unity EditMode regression tests (not executed here).

## Security boundary
`SetContext` remains a public presentation adapter. It **does not authenticate** collected evidence. Callers must obtain evidence from the authoritative game progression system, not player-controlled UI or saved untrusted strings. A real gameplay integration is still required.

## Verification
- ZIP CRC, duplicate filenames, JSON syntax, source transformations: checked locally.
- Unity compilation, EditMode execution, PlayMode, Android: NOT VERIFIED.
- Existing ProjectVersion.txt targets Unity 2022.3.62f3; Unity 6.3.28f1 compatibility NOT VERIFIED.
