#!/usr/bin/env python3
"""Non-executable presentation and interaction boundary contract checks."""
from __future__ import annotations
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOOTSTRAP = ROOT / 'Assets/_Project/Editor/OrderProjectBootstrap.cs'
VALIDATOR = ROOT / 'Assets/_Project/Editor/OrderSceneValidator.cs'
PLAYMODE = ROOT / 'Assets/_Project/Tests/PlayMode/IntegratedSceneSmokeTests.cs'
RAILS = ('North Inlay', 'South Inlay', 'East Inlay', 'West Inlay')
PANELS = ('Upper Archive Header', 'Lower Control Deck')


def validate(bootstrap: str, validator: str, playmode: str) -> list[str]:
    errors = []
    for label in RAILS:
        if bootstrap.count('"' + label + '"') != 1:
            errors.append('Missing or duplicate visual inlay: ' + label)
        if '"' + label + '"' not in validator or '"' + label + '"' not in validator:
            errors.append('Inlay lacks independent validation: ' + label)
    for label in PANELS:
        if bootstrap.count('"' + label + '"') != 1:
            errors.append('Missing or duplicate decorative panel: ' + label)
        if '"' + label + '"' not in validator or '"' + label + '"' not in validator:
            errors.append('Panel lacks independent validation: ' + label)
    requirements = (
        ('collider suppression', r'UnityEngine\.Object\.DestroyImmediate\(collider\)'),
        ('non-interactive presentation', r'image\.raycastTarget\s*=\s*false'),
        ('decorations placed behind controls', r'rect\.SetAsFirstSibling\(\)'),
        ('persistent callbacks kept intact', r'UnityEventTools\.AddPersistentListener'),
        ('button tactile states', r'tint\.pressedColor\s*='),
    )
    for title, pattern in requirements:
        if not re.search(pattern, bootstrap):
            errors.append('Missing bootstrap contract: ' + title)
    if not re.search(r'matches\[0\]\.GetComponent<Collider>\(\)\s*!=\s*null', validator):
        errors.append('Editor does not reject raycast-obstructing decorative inlays')
    if 'matches[0].raycastTarget' not in validator:
        errors.append('Editor does not reject input-blocking decorative UI')
    if 'chapters[0].IsChapterReady, Is.True' not in playmode:
        errors.append('Narrative PlayMode does not verify chapter readiness')
    if 'GetComponentsInChildren<OrderGame>(true)).Any(), Is.False' not in playmode:
        errors.append('Narrative PlayMode does not reject legacy board entry')
    return errors


def main() -> int:
    errors = validate(BOOTSTRAP.read_text(encoding='utf-8'),
                      VALIDATOR.read_text(encoding='utf-8'),
                      PLAYMODE.read_text(encoding='utf-8'))
    for error in errors:
        print('FAIL:', error)
    if not errors:
        print('STATIC_PASS_ONLY: four inlays, two panels, callback and pointer safety contracts')
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
