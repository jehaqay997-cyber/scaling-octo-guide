#!/usr/bin/env python3
"""Strict offline validation of chapter art linkage and locked future content.

This gate does not execute Unity and must not be treated as a PlayMode pass.
"""
from __future__ import annotations
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "Design/CHAPTER_VISUAL_CATALOG_v4.53.json"
SCENE = ROOT / "Assets/_Project/Runtime/ChapterOneExperience.cs"
GALLERY = ROOT / "Assets/_Project/Runtime/ChapterGalleryView.cs"
PLAYMODE = ROOT / "Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs"


def jpeg_size(data: bytes) -> tuple[int, int]:
    if not data.startswith(b"\xff\xd8"):
        raise ValueError("Not a JPEG")
    pos = 2
    while pos + 4 <= len(data):
        if data[pos] != 255:
            raise ValueError("Invalid JPEG marker")
        while pos < len(data) and data[pos] == 255:
            pos += 1
        if pos >= len(data):
            break
        marker = data[pos]
        pos += 1
        if marker in (0xD8, 0xD9) or 0xD0 <= marker <= 0xD7:
            continue
        if marker == 0xDA:
            break
        if pos + 2 > len(data):
            raise ValueError("JPEG segment truncated")
        length = int.from_bytes(data[pos:pos+2], "big")
        if length < 2 or pos + length > len(data):
            raise ValueError("Invalid JPEG segment length")
        if marker in {0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF}:
            if length < 7:
                raise ValueError("Invalid JPEG SOF")
            height = int.from_bytes(data[pos+3:pos+5],"big")
            width = int.from_bytes(data[pos+5:pos+7],"big")
            return width,height
        pos += length
    raise ValueError("JPEG dimensions missing")


def verify(root: Path) -> list[str]:
    problems = []
    catalog = json.loads((root / "Design/CHAPTER_VISUAL_CATALOG_v4.53.json").read_text())
    assets = catalog.get("assets", [])
    if len(assets) != 4 or [a.get("index") for a in assets] != [1,2,3,4]:
        problems.append("Expected four ordered chapters")
    hashes = set()
    for asset in assets:
        idx = asset.get("index")
        path = root / str(asset.get("asset",""))
        expected = f"Assets/_Project/Resources/ChapterArt/Chapter_{idx:02d}.jpg" if isinstance(idx,int) else ""
        if path.as_posix() != (root/expected).as_posix():
            problems.append(f"Chapter {idx} uses an unexpected asset path")
        if not path.is_file() or path.stat().st_size < 30000:
            problems.append(f"Chapter {idx} artwork is missing or empty")
            continue
        metadata = path.with_name(path.name + ".meta")
        if not metadata.is_file() or not re.search(r"(?m)^guid: [0-9a-f]{32}$",metadata.read_text()):
            problems.append(f"Chapter {idx} Unity meta file missing or invalid")
        data = path.read_bytes()
        try:
            width,height = jpeg_size(data)
            if (width,height)!=(1280,720):
                problems.append(f"Chapter {idx} artwork dimensions mismatch")
        except ValueError as exc:
            problems.append(f"Chapter {idx} JPEG invalid: {exc}")
        digest = hashlib.sha256(data).hexdigest()
        if digest != asset.get("sha256"):
            problems.append(f"Chapter {idx} SHA256 mismatch")
        if digest in hashes:
            problems.append(f"Chapter {idx} artwork duplicate")
        hashes.add(digest)
        expected_state = "PLAYABLE_CHAPTER_ONE" if idx==1 else "CONCEPT_ONLY_LOCKED"
        if asset.get("state") != expected_state:
            problems.append(f"Chapter {idx} state is misleading")
    source = (root / "Assets/_Project/Runtime/ChapterGalleryView.cs").read_text()
    scene = (root / "Assets/_Project/Runtime/ChapterOneExperience.cs").read_text()
    test = (root / "Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs").read_text()
    for token in ('Resources.Load<Texture2D>', 'ChapterArt/Chapter_', 'chapterTextures',
                  'enterButton.interactable = chapterReady', 'selectedIndex == 0',
                  'public const int ChapterCount = 4', 'Unity acceptance pending.'):
        if token not in source:
            problems.append("Gallery interaction contract missing: " + token)
    for token in ('Action("chapters", "CHAPTERS"', 'ShowChapterGallery()', 'gallery.Show();'):
        if token not in scene:
            problems.append("Chapter One scene integration missing: " + token)
    for token in ('[UnityTest]', 'ChapterGalleryView.ChapterCount', 'enter.interactable', 'Resources.Load<Texture2D>'):
        if token not in test:
            problems.append("PlayMode test contract missing: " + token)
    return problems


if __name__ == "__main__":
    errors = verify(ROOT)
    print(json.dumps({"status":"STATIC_PASS_ONLY" if not errors else "FAIL",
                      "artwork_count":4,"problems":errors,"unity_executed":False}, indent=2))
    sys.exit(1 if errors else 0)
