#!/usr/bin/env python3
"""Fail-closed static guards for gallery safe areas, modal blocking and camera input."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GALLERY = Path('Assets/_Project/Runtime/ChapterGalleryView.cs')
EXPERIENCE = Path('Assets/_Project/Runtime/ChapterOneExperience.cs')
PLAYMODE = Path('Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs')

CONTRACTS = {
    GALLERY: (
        'new GameObject("Gallery Input Shield", typeof(RectTransform), typeof(Image))',
        'shieldImage.raycastTarget = true;',
        'scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;',
        'safeAreaRoot.anchorMin = new Vector2(safe.xMin / width, safe.yMin / height);',
        'safeAreaRoot.anchorMax = new Vector2(safe.xMax / width, safe.yMax / height);',
        'float fit = Mathf.Min(1f, safeLogicalWidth / 1600f, safeLogicalHeight / 900f);',
        'layoutRoot.localScale = Vector3.one * Mathf.Max(.01f, fit);',
        'float scale = Mathf.Min(viewportWidth / texture.width, viewportHeight / texture.height);',
        'ReleaseLocationTexture();',
    ),
    EXPERIENCE: ('!viewCamera.pixelRect.Contains(position)',),
    PLAYMODE: (
        'GallerySafeAreaAndModalShieldPreserveScreenBounds',
        'ImageAspectAndNavigationStayConsistent',
    ),
}


def check(root=ROOT):
    problems = []
    for path, fragments in CONTRACTS.items():
        actual = root / path
        if not actual.is_file() or actual.stat().st_size == 0:
            problems.append(f'Missing or empty: {path}')
            continue
        source = actual.read_text(encoding='utf-8')
        for fragment in fragments:
            if fragment not in source:
                problems.append(f'{path}: missing contract {fragment}')
    return problems


if __name__ == '__main__':
    failures = check()
    for problem in failures:
        print('FAIL:', problem)
    if not failures:
        print('STATIC_PASS_ONLY: viewport, safe area and camera contracts')
    raise SystemExit(bool(failures))
