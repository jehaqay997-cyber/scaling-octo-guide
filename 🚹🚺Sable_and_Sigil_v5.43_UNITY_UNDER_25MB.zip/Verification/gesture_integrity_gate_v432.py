#!/usr/bin/env python3
"""Fail-closed static guard for world gesture dispatch. This does not execute Unity code."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
GAME_PATH = ROOT / 'Assets/_Project/Runtime/OrderGame.cs'
TEST_PATH = ROOT / 'Assets/_Project/Tests/EditMode/WorldGestureTapSafetyTests.cs'


def inspect(source):
    issues = []
    checks = {
        'tap_anchored_to_press': r'HandleWorldTap\(tapPosition\)',
        'movement_latched': r'gestureExceededTapThreshold\s*=\s*true',
        'tap_must_not_be_drag': r'!dragged\s*&&\s*!gestureExceededTapThreshold',
        'finite_coordinates_required': r'float\.IsNaN\(start\.x\)',
        'ui_release_rejected': r'bool\s+overUi\s*=\s*IsScreenPointOverUi\(point\)\s*;',
        'ui_exit_before_dispatch': r'if\s*\(overUi\)\s*return\s*;',
        'drag_requires_item': r'if\s*\(gestureItem\s*==\s*null\)\s*return\s*;',
        'selection_failure_blocks_place': r'if\s*\(!TrySelectItem\(itemId\)\)\s*return\s*;\s*Place\(destination\.Destination\)',
        'selection_requires_board_identity': r'!board\.TryGetItem\(id,\s*out\s+Item\s+item\)',
        'generation_check': r'board\.Revision\s*==\s*gestureRevision',
        'end_cancels_state': r'CancelWorldGesture\(\);\s*\n\s*if\s*\(overUi\)',
    }
    for label, regex in checks.items():
        if not re.search(regex, source):
            issues.append(label)
    return issues


def main():
    issues = inspect(GAME_PATH.read_text(encoding='utf-8-sig'))
    if not TEST_PATH.is_file():
        issues.append('missing_unity_regression_tests')
    output = {
        'status': 'STATIC_PASS_ONLY' if not issues else 'FAIL',
        'checks': 12,
        'issues': issues,
        'compile_verified': False,
        'unity_tests_verified': False,
        'android_verified': False,
    }
    report = ROOT / 'Verification/GESTURE_REPORT_v4.32.json'
    report.write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(output, indent=2))
    return 1 if issues else 0


if __name__ == '__main__':
    sys.exit(main())
