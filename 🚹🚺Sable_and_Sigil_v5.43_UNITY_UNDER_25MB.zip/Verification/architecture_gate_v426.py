#!/usr/bin/env python3
"""Static Unity assembly graph and UI binding governance. Not a C# compiler."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "Assets" / "_Project"
ISSUES = []


def issue(message):
    ISSUES.append(message)


def analyze():
    asmdefs = sorted(PROJECT.rglob("*.asmdef"))
    definitions = {}
    paths = {}
    for path in asmdefs:
        try:
            definition = json.loads(path.read_text(encoding="utf-8-sig"))
            name = definition["name"]
            if name in definitions:
                issue("Duplicate assembly: " + name)
            definitions[name] = definition
            paths[name] = path
        except (OSError, ValueError, KeyError) as error:
            issue("Invalid assembly: " + str(path) + ": " + str(error))
    external = {"UnityEngine.UI", "Unity.InputSystem", "UnityEngine.TestRunner", "UnityEditor.TestRunner"}
    graph = {}
    for name, definition in definitions.items():
        refs = definition.get("references", [])
        if not isinstance(refs, list):
            issue("Invalid assembly references: " + name)
            continue
        graph[name] = []
        for ref in refs:
            if ref in definitions:
                graph[name].append(ref)
            elif ref not in external and not str(ref).startswith("GUID:"):
                issue("Unresolved assembly dependency: " + name + " -> " + str(ref))
        if name in ("TheOrderRoom.Domain", "TheOrderRoom.AppCore", "TheOrderRoom.Infrastructure") and not definition.get("noEngineReferences", False):
            issue("Pure assembly uses engine references: " + name)
    visiting, visited = set(), set()
    def visit(name, trail):
        if name in visiting:
            issue("Assembly dependency cycle: " + " -> ".join(trail + [name]))
            return
        if name in visited:
            return
        visiting.add(name)
        for dependency in graph.get(name, []):
            visit(dependency, trail + [name])
        visiting.remove(name)
        visited.add(name)
    for name in sorted(graph):
        visit(name, [])
    expected = {
        "TheOrderRoom.Domain": set(),
        "TheOrderRoom.AppCore": {"TheOrderRoom.Domain"},
        "TheOrderRoom.Infrastructure": {"TheOrderRoom.Domain", "TheOrderRoom.AppCore"},
    }
    for name, allowed in expected.items():
        if name not in graph:
            issue("Missing required assembly: " + name)
        elif not set(graph[name]).issubset(allowed):
            issue("Architecture boundary violation: " + name)
    sources = sorted(PROJECT.rglob("*.cs"))
    owned = {}
    for path in sources:
        parents = [asm for asm in paths if paths[asm].parent == path.parent or paths[asm].parent in path.parents]
        if not parents:
            issue("Source outside an assembly definition: " + str(path.relative_to(ROOT)))
            continue
        owner = max(parents, key=lambda name: len(paths[name].parts))
        owned[str(path.relative_to(ROOT))] = owner
        if not Path(str(path) + ".meta").is_file():
            issue("Missing C# meta file: " + str(path.relative_to(ROOT)))
        if owner in expected:
            data = path.read_text(encoding="utf-8-sig")
            if re.search(r"\b(?:using\s+Unity(?:Engine|Editor)\b|UnityEngine\.|UnityEditor\.)", data):
                issue("Unity dependency inside pure assembly: " + str(path.relative_to(ROOT)))
    editor = (PROJECT / "Editor" / "OrderProjectBootstrap.cs").read_text(encoding="utf-8")
    validator = (PROJECT / "Editor" / "OrderSceneValidator.cs").read_text(encoding="utf-8")
    creation = dict(re.findall(r'AddButton\("([^"]+)",[^;]*?game,\s*"([^"]+)"\)', editor))
    required = dict(re.findall(r'\{\s*"([^"]+)",\s*"([^"]+)"\s*\}', validator[validator.index("var requiredButtons"):]))
    if creation != required:
        issue("Scene button callbacks do not match validation contract: " + repr({"created": creation, "validated": required}))
    if 'default: throw new ArgumentException("Unknown UI callback:' not in editor:
        issue("Scene UI callback dispatcher is not fail-closed")
    if "GetPersistentListenerState" not in validator or "GetPersistentEventCount() != 1" not in validator:
        issue("Scene does not verify callback cardinality and activation")
    missing = []
    for path in sorted((ROOT / "Assets").rglob("*.asmdef")):
        if not Path(str(path) + ".meta").exists():
            missing.append(str(path.relative_to(ROOT)))
    if missing:
        issue("Missing asmdef meta: " + ", ".join(missing))
    return {
        "status": "STATIC_PASS_ONLY" if not ISSUES else "FAIL",
        "asmdef_count": len(definitions),
        "source_count": len(sources),
        "assemblies": {name: {"path": str(paths[name].relative_to(ROOT)), "dependencies": sorted(graph.get(name, []))} for name in sorted(definitions)},
        "source_ownership": owned,
        "scene_buttons": creation,
        "issues": ISSUES,
        "unity_compilation_verified": False,
        "unity_tests_verified": False,
        "device_verified": False,
    }


if __name__ == "__main__":
    report = analyze()
    (ROOT / "Verification" / "ARCHITECTURE_REPORT_v4.26.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "source_ownership"}, indent=2))
    sys.exit(1 if ISSUES else 0)
