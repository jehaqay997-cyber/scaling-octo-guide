import hashlib
import io
import json
import unittest
import zipfile
from PIL import Image
from verify_art_integrity_v467 import inspect

class FakeArchive:
    def __init__(self, payload, art):
        self.payload = payload
        self.art = art
    def read(self, path):
        if path == "Design/SCENE_PUZZLE_CONTRACT_v4.65.json":
            return json.dumps({"puzzles": self.payload}).encode()
        return self.art[path]

def fixture():
    buffer = io.BytesIO()
    Image.new("RGB", (1280, 720)).save(buffer, format="JPEG")
    data = buffer.getvalue()
    path = "Assets/_Project/Resources/LocationArt/Scene_01.jpg"
    record = {"id": "scene_01", "art": path, "art_sha256": hashlib.sha256(data).hexdigest()}
    return record, {path: data}

class ArtIntegrityTests(unittest.TestCase):
    def test_valid(self):
        record, art = fixture()
        self.assertEqual(len(inspect(FakeArchive([record], art))), 1)
    def test_digest_tampering(self):
        record, art = fixture()
        record["art_sha256"] = "0" * 64
        with self.assertRaises(ValueError): inspect(FakeArchive([record], art))
    def test_duplicate(self):
        record, art = fixture()
        with self.assertRaises(ValueError): inspect(FakeArchive([record, record], art))
    def test_path_traversal(self):
        record, art = fixture()
        record["art"] = "../Scene_01.jpg"
        art[record["art"]] = next(iter(art.values()))
        with self.assertRaises(ValueError): inspect(FakeArchive([record], art))
    def test_corrupt_image(self):
        record, art = fixture()
        art[record["art"]] = b"not an image"
        record["art_sha256"] = hashlib.sha256(art[record["art"]]).hexdigest()
        with self.assertRaises(ValueError): inspect(FakeArchive([record], art))
    def test_undersized(self):
        record, art = fixture()
        buf = io.BytesIO()
        Image.new("RGB", (640, 360)).save(buf, format="JPEG")
        art[record["art"]] = buf.getvalue()
        record["art_sha256"] = hashlib.sha256(buf.getvalue()).hexdigest()
        with self.assertRaises(ValueError): inspect(FakeArchive([record], art))

if __name__ == "__main__": unittest.main()
