# Optional .NET verification

Requires .NET 8 SDK and working NuGet access. Not executed in this environment.

```bash
cd Verification/Portable
dotnet run --project Portable.Tests.csproj -- --labels=All
```

The portable test project includes the new `AdventureJournalStoreTests` and existing `AdventureRecoveryTests`, as well as the earlier portable selection. Unity assembly tests must also be run with the matching editor. This command is a future test instruction, **not evidence of success**.
