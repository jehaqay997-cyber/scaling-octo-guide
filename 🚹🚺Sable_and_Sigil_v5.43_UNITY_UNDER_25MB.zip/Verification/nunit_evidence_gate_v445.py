#!/usr/bin/env python3
"""Static contract validation for NUnit evidence required by the Unity release runner.

This gate does not execute PowerShell, Unity or NUnit. It prevents accidental
removal of the evidence checks and keeps the supported test-fixture inventory
aligned with real C# source files.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / 'Verification' / 'Run-UnityVerification.ps1'
REQUIRED_EDITMODE = (
    'OrderBoardTests', 'BoardRestoreAtomicityTests', 'SaveFaultInjectionTests',
    'WorldGestureTapSafetyTests', 'FrameBudgetPolicyTests',
    'InspectionCameraContractTests', 'ChapterWorldVaultGeometryTests',
    'ChapterWorldStoneSurfaceTests', 'ChapterWorldGothicGeometryTests',
    'StoryDossierTests', 'ChapterInvestigationProgressionTests',
    'ChapterStoryGraphTests', 'AdventureSolvabilityVerifierTests',
    'SaveHardeningTests',
)
REQUIRED_PLAYMODE = (
    'IntegratedSceneSmokeTests', 'ChapterOneSceneTests',
    'ChapterWorldExplorerPlayModeTests', 'StoryDossierPlayModeTests',
    'ChapterStoryIntegrationTests', 'ChapterArtGalleryTests',
)


def validate(text: str, root: Path = ROOT) -> list[str]:
    errors: list[str] = []
    required_fragments = (
        'function Assert-NUnitEvidence',
        "@('total', 'passed', 'failed', 'skipped', 'inconclusive')",
        "$values['passed'] -ne $values['total']",
        "$values['inconclusive'] -ne 0",
        "SelectNodes(\"//*[local-name()='test-case']\")",
        "$cases.Count -ne $values['total']",
        "$testCase.GetAttribute('result') -ne 'Passed'",
        '$found = @($names | Where-Object',
        'throw "$Stage omitted required test fixture: $fixture"',
        "Assert-NUnitEvidence $xml 'EditMode'",
        "Assert-NUnitEvidence $playXml 'PlayMode'",
        '$report.status = "PASS"',
        'if ($report.status -ne "PASS")',
    )
    for fragment in required_fragments:
        if fragment not in text:
            errors.append('Missing release evidence invariant: ' + fragment)
    for name in REQUIRED_EDITMODE:
        if not re.search(r"^\s*'" + re.escape(name) + r"'\s*,?\s*$", text, re.MULTILINE):
            errors.append('EditMode fixture not required: ' + name)
        source = root / 'Assets' / '_Project' / 'Tests' / 'EditMode' / (name + '.cs')
        if not source.is_file() or not re.search(r'\bclass\s+' + re.escape(name) + r'\b', source.read_text(encoding='utf-8')):
            errors.append('Missing required EditMode fixture source: ' + name)
    for name in REQUIRED_PLAYMODE:
        if not re.search(r"^\s*'" + re.escape(name) + r"'\s*,?\s*$", text, re.MULTILINE):
            errors.append('PlayMode fixture not required: ' + name)
        source = root / 'Assets' / '_Project' / 'Tests' / 'PlayMode' / (name + '.cs')
        if not source.is_file() or not re.search(r'\bclass\s+' + re.escape(name) + r'\b', source.read_text(encoding='utf-8')):
            errors.append('Missing required PlayMode fixture source: ' + name)
    if text.find("Assert-NUnitEvidence $xml 'EditMode'") > text.find('$report.editmode = "PASS"'):
        errors.append('EditMode evidence must be checked before PASS')
    if text.find("Assert-NUnitEvidence $playXml 'PlayMode'") > text.find('$report.playmode = "PASS"'):
        errors.append('PlayMode evidence must be checked before PASS')
    return errors


def main() -> int:
    errors = validate(RUNNER.read_text(encoding='utf-8-sig'))
    for error in errors:
        print('FAIL:', error)
    if not errors:
        print('STATIC_PASS_ONLY: NUnit evidence and fixture guards exist in the runner')
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
