"""Adversarial tests for Android publication auditing and artifact inspection."""

from __future__ import annotations

import importlib.util
import json
import shutil
import struct
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "Verification" / "Portable" / "android_publication_audit_v531.py"
SPEC = importlib.util.spec_from_file_location("android_publication_audit_v531", MODULE_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("Cannot load Android publication audit module")
AUDIT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT)


def sample_project(root: Path) -> None:
    (root / "ProjectSettings").mkdir(parents=True)
    (root / "Packages").mkdir(parents=True)
    (root / "Assets").mkdir(parents=True)
    (root / "ProjectSettings" / "ProjectVersion.txt").write_text("m_EditorVersion: 2022.3.62f3\n", encoding="utf-8")
    (root / "ProjectSettings" / "ProjectSettings.asset").write_text(
        "PlayerSettings:\n  scriptingBackend:\n    Android: 1\n  applicationIdentifier:\n    Android: com.example.sable\n",
        encoding="utf-8",
    )
    (root / "Packages" / "manifest.json").write_text(
        json.dumps({"dependencies": {"com.unity.inputsystem": "1.7.0"}}), encoding="utf-8"
    )


def arm64_elf(alignment: int) -> bytes:
    output = bytearray(256)
    output[:4] = b"\x7fELF"
    output[4] = 2
    output[5] = 1
    struct.pack_into("<H", output, 18, 183)
    struct.pack_into("<Q", output, 32, 64)
    struct.pack_into("<HH", output, 54, 56, 1)
    struct.pack_into("<IIQQQQQQ", output, 64, 1, 5, 0, 0, 0, 0, 0, alignment)
    return bytes(output)


class AndroidPublicationAuditTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        sample_project(self.root)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def issues(self) -> set[str]:
        return {item["code"] for item in AUDIT.scan_source(self.root)["issues"]}

    def test_unresolved_target_api_blocks_release_evidence(self) -> None:
        self.assertIn("TARGET_API_UNVERIFIED", self.issues())

    def test_explicit_below_minimum_target_is_detected(self) -> None:
        path = self.root / "ProjectSettings" / "ProjectSettings.asset"
        path.write_text(path.read_text() + "  androidTargetSdkVersion: 35\n", encoding="utf-8")
        self.assertIn("TARGET_API_TOO_LOW", self.issues())

    def test_valid_target_removes_target_code_without_certifying_build(self) -> None:
        path = self.root / "ProjectSettings" / "ProjectSettings.asset"
        path.write_text(path.read_text() + "  androidTargetSdkVersion: 36\n", encoding="utf-8")
        output = AUDIT.audit(self.root)
        codes = {item["code"] for item in output["issues"]}
        self.assertNotIn("TARGET_API_UNVERIFIED", codes)
        self.assertNotIn("TARGET_API_TOO_LOW", codes)
        self.assertEqual("NOT_VERIFIED", output["publication_status"])

    def test_missing_manifest_detected(self) -> None:
        (self.root / "Packages" / "manifest.json").unlink()
        self.assertIn("REQUIRED_SOURCE_MISSING", self.issues())

    def test_duplicate_json_dependency_detected(self) -> None:
        (self.root / "Packages" / "manifest.json").write_text(
            '{"dependencies":{"com.unity.inputsystem":"1.7.0","com.unity.inputsystem":"1.7.0"}}',
            encoding="utf-8",
        )
        self.assertIn("PACKAGE_MANIFEST_INVALID", self.issues())

    def test_custom_scoped_registry_is_flagged(self) -> None:
        path = self.root / "Packages" / "manifest.json"
        path.write_text(json.dumps({"dependencies": {}, "scopedRegistries": [{"name": "custom"}]}), encoding="utf-8")
        self.assertIn("SCOPED_REGISTRY", self.issues())

    def test_untrusted_brotli_usage_requires_review(self) -> None:
        (self.root / "Assets" / "Untrusted.cs").write_text(
            "using System.IO.Compression; public class Untrusted { BrotliStream stream; }", encoding="utf-8"
        )
        self.assertIn("BROTLI_SURFACE_REVIEW", self.issues())

    def test_application_id_preserved_without_silent_migration(self) -> None:
        path = self.root / "ProjectSettings" / "ProjectSettings.asset"
        path.write_text(path.read_text().replace("com.example.sable", "com.theorderroom.game"), encoding="utf-8")
        self.assertIn("APPLICATION_ID_REVIEW", self.issues())
        self.assertIn("com.theorderroom.game", path.read_text())

    def test_aligned_64_bit_native_elf(self) -> None:
        self.assertEqual([], AUDIT.inspect_elf(arm64_elf(16384), "libok.so"))

    def test_unaligned_native_elf_rejected(self) -> None:
        results = AUDIT.inspect_elf(arm64_elf(4096), "libbad.so")
        self.assertIn("ELF_LOAD_NOT_16K", {entry["code"] for entry in results})

    def test_invalid_native_elf_rejected(self) -> None:
        results = AUDIT.inspect_elf(b"not ELF", "libbad.so")
        self.assertIn("INVALID_ELF", {entry["code"] for entry in results})

    def test_aab_native_library_is_analyzed(self) -> None:
        path = self.root / "test.aab"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("base/lib/arm64-v8a/libunity.so", arm64_elf(4096))
        result = AUDIT.inspect_archive(path)
        self.assertIn("ELF_LOAD_NOT_16K", {item["code"] for item in result["checks"]})

    def test_uncompressed_apk_alignment_is_checked(self) -> None:
        path = self.root / "test.apk"
        with zipfile.ZipFile(path, "w") as archive:
            archive.writestr("lib/arm64-v8a/libunity.so", arm64_elf(16384), compress_type=zipfile.ZIP_STORED)
        result = AUDIT.inspect_archive(path)
        self.assertIn("APK_LIBRARY_ZIP_NOT_16K", {item["code"] for item in result["checks"]})

    def test_release_mode_fails_closed_without_external_evidence(self) -> None:
        result = AUDIT.main(["--project", str(self.root), "--enforce-publication", "--json", str(self.root / "result.json")])
        self.assertEqual(3, result)
        payload = json.loads((self.root / "result.json").read_text(encoding="utf-8"))
        self.assertEqual("NOT_VERIFIED", payload["publication_status"])

    def test_project_version_mismatch_detected(self) -> None:
        (self.root / "ProjectSettings" / "ProjectVersion.txt").write_text("m_EditorVersion: 6000.3.0f1\n", encoding="utf-8")
        self.assertIn("EDITOR_BASELINE", self.issues())


if __name__ == "__main__":
    unittest.main()
