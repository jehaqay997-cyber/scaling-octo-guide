#!/usr/bin/env python3
"""Independent finite-state oracle for the v4.17 adventure chapter.
This deliberately does not execute or parse the production C# transition methods.
An equality assertion against an executable C# export is still required for full
cross-implementation equivalence. The oracle proves only its own transition rules.
"""
import collections
import json
from pathlib import Path

COURTYARD, ARCHIVE, OBSERVATORY = range(3)
KEY, OPEN, LENS, MOUNT, ASSEMBLED, INSTALLED = (1, 2, 4, 8, 16, 32)
START = (COURTYARD, 0)

def transitions(state):
    loc, facts = state
    if loc == COURTYARD:
        if not facts & KEY:
            yield ('TakeKey', (loc, facts | KEY))
        if facts & KEY and not facts & OPEN:
            yield ('OpenArchive', (loc, facts | OPEN))
    if facts & OPEN:
        if loc == COURTYARD:
            yield ('TravelArchive', (ARCHIVE, facts))
            yield ('TravelObservatory', (OBSERVATORY, facts))
        else:
            yield ('TravelCourtyard', (COURTYARD, facts))
    if loc == ARCHIVE:
        if not facts & LENS:
            yield ('TakeLens', (loc, facts | LENS))
        if not facts & MOUNT:
            yield ('TakeMount', (loc, facts | MOUNT))
    if facts & (LENS | MOUNT) == LENS | MOUNT and not facts & ASSEMBLED:
        yield ('AssembleLens', (loc, facts | ASSEMBLED))
    if loc == OBSERVATORY and facts & ASSEMBLED and not facts & INSTALLED:
        yield ('InstallLens', (loc, facts | INSTALLED))

def verify():
    queue = collections.deque([START])
    found = {START}
    reverse = collections.defaultdict(set)
    edges = 0
    while queue:
        state = queue.popleft()
        for name, dest in transitions(state):
            edges += 1
            reverse[dest].add(state)
            if dest not in found:
                found.add(dest)
                queue.append(dest)
    wins = {s for s in found if s[1] & INSTALLED}
    reachable_to_win = set(wins)
    queue = collections.deque(wins)
    while queue:
        for predecessor in reverse[queue.popleft()]:
            if predecessor not in reachable_to_win:
                reachable_to_win.add(predecessor)
                queue.append(predecessor)
    return {'reachable_states':len(found),'transitions':edges,'winning_states':len(wins),
            'states_with_path_to_victory':len(reachable_to_win),
            'softlocked_states':len(found-reachable_to_win)}

if __name__ == '__main__':
    result=verify()
    assert result['reachable_states'] > 0
    assert result['winning_states'] > 0
    assert result['softlocked_states'] == 0
    print(json.dumps(result, indent=2, sort_keys=True))
