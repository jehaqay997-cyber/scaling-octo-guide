# v4.76 Hint Consistency Audit

## Changes
- Corrected the evidence snapshot size boundary: exactly 4096 unique IDs are valid; 4097 are rejected atomically.
- Revalidated the previously revealed tier before showing a subsequent tier and before enabling the hint button.
- Added two EditMode regression tests for the 4096/4097 boundary.

## Known limitations / P0
- `SetContext` still trusts the caller to provide authoritative evidence. No authenticated progression adapter is wired.
- Unity Editor 6000.3.28f1 compilation, EditMode/PlayMode execution and Android tests were NOT run.
- The packaged `ProjectSettings/ProjectVersion.txt` still targets 2022.3.62f3; migration remains unverified.
- No complete gameplay scene or evidence acquisition integration has been verified.

## Verification
- ZIP CRC, duplicate names, empty entries and JSON parsing are checked by the build script.
- This is a source patch and static archive audit, not a Unity runtime verification.
