#!/usr/bin/env python3
"""Fail-closed static checks for the Sable & Sigil Unity 2022.3 launch baseline.

This program does not execute Unity, run NUnit, build Android, or approve a release.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

TARGET_EDITOR = "2022.3.62f3"
PACKAGE_VERSIONS = {
    "com.unity.test-framework": "1.1.33",
    "com.unity.inputsystem": "1.7.0",
    "com.unity.ugui": "1.0.0",
}
ASSEMBLIES = {
    "TheOrderRoom.Domain",
    "TheOrderRoom.AppCore",
    "TheOrderRoom.Infrastructure",
    "TheOrderRoom.Runtime",
    "TheOrderRoom.Editor",
    "TheOrderRoom.Tests.EditMode",
    "TheOrderRoom.Tests.PlayMode",
}
REQUIRED_TEST_REFERENCES = {
    "TheOrderRoom.Domain",
    "TheOrderRoom.Runtime",
    "UnityEngine.TestRunner",
}


def jpeg_size(path):
    """Read JPEG dimensions without third-party dependencies or decoding pixels."""
    with path.open("rb") as stream:
        if stream.read(2) != b"\xff\xd8":
            raise ValueError("Invalid JPEG signature")
        while True:
            marker_head = stream.read(1)
            if not marker_head:
                raise ValueError("JPEG frame dimensions are missing")
            if marker_head != b"\xff":
                continue
            marker = stream.read(1)
            while marker == b"\xff":
                marker = stream.read(1)
            if not marker:
                raise ValueError("Truncated JPEG marker")
            tag = marker[0]
            if tag == 0xD9 or tag == 0xDA:
                raise ValueError("JPEG frame dimensions are missing")
            if tag in (0x01,) or 0xD0 <= tag <= 0xD7:
                continue
            length = int.from_bytes(stream.read(2), "big")
            if length < 2:
                raise ValueError("Invalid JPEG section length")
            if tag in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                       0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                section = stream.read(length - 2)
                if len(section) < 5:
                    raise ValueError("Truncated JPEG frame header")
                return int.from_bytes(section[3:5], "big"), int.from_bytes(section[1:3], "big")
            stream.seek(length - 2, 1)


def cycle_exists(graph):
    visiting = set()
    visited = set()

    def walk(name):
        if name in visiting:
            return True
        if name in visited:
            return False
        visiting.add(name)
        for dependency in graph[name]:
            if dependency in graph and walk(dependency):
                return True
        visiting.remove(name)
        visited.add(name)
        return False

    return any(walk(node) for node in graph)


def check(root):
    root = Path(root).resolve()
    errors = []
    warnings = []
    evidence = {"unity_target": TARGET_EDITOR, "source_root": str(root)}

    def require(relative):
        file = root / relative
        if not file.is_file():
            errors.append("MISSING_FILE: " + relative)
            return None
        if file.stat().st_size == 0:
            errors.append("EMPTY_FILE: " + relative)
            return None
        return file

    version = require("ProjectSettings/ProjectVersion.txt")
    if version is not None:
        match = re.search(r"(?m)^m_EditorVersion:\s*(\S+)\s*$", version.read_text("utf-8"))
        if not match or match.group(1) != TARGET_EDITOR:
            errors.append("EDITOR_VERSION_MISMATCH: exact 2022.3.62f3 required")

    manifest = require("Packages/manifest.json")
    if manifest is not None:
        try:
            deps = json.loads(manifest.read_text("utf-8"))["dependencies"]
            for package, expected in PACKAGE_VERSIONS.items():
                if deps.get(package) != expected:
                    errors.append("PACKAGE_VERSION_MISMATCH: " + package)
        except (KeyError, TypeError, ValueError) as error:
            errors.append("INVALID_PACKAGE_MANIFEST: " + str(error))

    asm_paths = list((root / "Assets").rglob("*.asmdef"))
    names = {}
    for asm_path in asm_paths:
        try:
            assembly = json.loads(asm_path.read_text("utf-8"))
            name = assembly["name"]
            if not isinstance(name, str) or not name:
                raise ValueError("Empty assembly name")
            if name in names:
                errors.append("DUPLICATE_ASSEMBLY: " + name)
            names[name] = assembly
        except (KeyError, TypeError, ValueError) as error:
            errors.append("INVALID_ASMDEF: " + str(asm_path.relative_to(root)) + ": " + str(error))

    for missing in sorted(ASSEMBLIES - names.keys()):
        errors.append("MISSING_ASSEMBLY: " + missing)
    graph = {}
    for name, assembly in names.items():
        refs = assembly.get("references", [])
        if not isinstance(refs, list) or not all(isinstance(item, str) for item in refs):
            errors.append("INVALID_REFERENCES: " + name)
            continue
        graph[name] = [ref for ref in refs if ref in names]
    if cycle_exists(graph):
        errors.append("CYCLIC_ASSEMBLY_DEPENDENCY")
    for name in ("TheOrderRoom.Domain", "TheOrderRoom.AppCore", "TheOrderRoom.Infrastructure"):
        if name in names and names[name].get("noEngineReferences") is not True:
            errors.append("ENGINE_REFERENCE_LEAK: " + name)
    for name in ("TheOrderRoom.Tests.EditMode", "TheOrderRoom.Tests.PlayMode"):
        if name not in names:
            continue
        asm = names[name]
        refs = set(asm.get("references", []))
        for missing in sorted(REQUIRED_TEST_REFERENCES - refs):
            errors.append("TEST_ASSEMBLY_MISSING_REFERENCE: " + name + " -> " + missing)
        if asm.get("overrideReferences") is not True or "nunit.framework.dll" not in asm.get("precompiledReferences", []):
            errors.append("MISSING_NUNIT_REFERENCE: " + name)
        if "UNITY_INCLUDE_TESTS" not in asm.get("defineConstraints", []):
            errors.append("MISSING_TEST_DEFINE: " + name)

    assets = root / "Assets"
    files = [file for file in assets.rglob("*") if file.is_file()]
    for file in files:
        rel = file.relative_to(root).as_posix()
        if file.stat().st_size == 0:
            errors.append("EMPTY_ASSET: " + rel)
        if file.suffix != ".meta" and not Path(str(file) + ".meta").is_file():
            errors.append("MISSING_ASSET_META: " + rel)
    guid_owners = {}
    for file in files:
        if file.suffix != ".meta":
            continue
        match = re.search(r"(?m)^guid:\s*([0-9a-fA-F]{32})\s*$", file.read_text("utf-8", errors="replace"))
        if not match:
            errors.append("INVALID_META_GUID: " + file.relative_to(root).as_posix())
            continue
        guid = match.group(1).lower()
        if guid in guid_owners:
            errors.append("DUPLICATE_META_GUID: " + guid)
        guid_owners[guid] = file.relative_to(root).as_posix()

    for index in range(1, 11):
        rel = "Assets/_Project/Resources/LocationArt/Scene_%02d.jpg" % index
        image = require(rel)
        if image is not None:
            try:
                if jpeg_size(image) != (1280, 720):
                    errors.append("ARTWORK_DIMENSION_MISMATCH: " + rel)
            except (ValueError, OSError) as error:
                errors.append("INVALID_ARTWORK: " + rel + ": " + str(error))
    for index in range(1, 5):
        rel = "Assets/_Project/Resources/ChapterArt/Chapter_%02d.jpg" % index
        image = require(rel)
        if image is not None:
            try:
                if jpeg_size(image) != (1280, 720):
                    errors.append("CHAPTER_DIMENSION_MISMATCH: " + rel)
            except (ValueError, OSError) as error:
                errors.append("INVALID_CHAPTER_ARTWORK: " + rel + ": " + str(error))

    for rel in (
        "Assets/_Project/Editor/SableLaunchAcceptance.cs",
        "Assets/_Project/Editor/OrderProjectBootstrap.cs",
        "Assets/_Project/Editor/ChapterOneSceneBuilder.cs",
        "Assets/_Project/Tests/PlayMode/ChapterWorldExplorerPlayModeTests.cs",
        "Verification/Run-SableAcceptance.ps1",
        "Verification/Run-UnityVerification.ps1",
        "RUN_SABLE_EDITOR_ACCEPTANCE.cmd",
        "RUN_SABLE_ANDROID_BUILD_GATE.cmd",
    ):
        require(rel)
    new_gate = root / "Assets/_Project/Editor/SableLaunchAcceptance.cs"
    if new_gate.is_file():
        content = new_gate.read_text("utf-8")
        for marker in (
            "ChapterCaseSceneBuilder.EnsureCaseScenes();",
            "ChapterOneSceneBuilder.ScenePath",
            "ChapterWorldPrototypeValidator.ValidateAssets()",
            "SableChapterBuildRoute.Validate()",
            "SABLE_SIGIL_LAUNCH_PREFLIGHT_PASS",
        ):
            if marker not in content:
                errors.append("LAUNCH_GATE_CONTRACT_MISSING: " + marker)

    evidence["asset_file_count"] = len(files)
    evidence["assembly_count"] = len(names)
    evidence["unique_guid_count"] = len(guid_owners)
    evidence["generated_main_scene_present"] = (root / "Assets/_Project/Scenes/Main.unity").is_file()
    evidence["generated_chapter_scene_present"] = (root / "Assets/_Project/Scenes/ChapterOne.unity").is_file()
    evidence["unity_package_lock_present"] = (root / "Packages/packages-lock.json").is_file()
    evidence["generated_narrative_scenes_present"] = all(
        (root / ("Assets/_Project/Scenes/Chapter%s.unity" % label)).is_file()
        for label in ("One", "Two", "Three", "Four")
    )
    if not evidence["generated_narrative_scenes_present"]:
        warnings.append("UNITY_SCENE_GENERATION_REQUIRED: the four narrative scenes must be created and inspected by the Unity Editor")
    if not evidence["unity_package_lock_present"]:
        warnings.append("UNITY_PACKAGE_RESOLUTION_REQUIRED: package lock must be generated by the Unity Editor")

    result = {
        "status": "STATIC_SOURCE_ACCEPTED_UNITY_PENDING" if not errors else "STATIC_SOURCE_BLOCKED",
        "errors": errors,
        "warnings": warnings,
        "evidence": evidence,
        "unity_compile_verified": False,
        "unity_editmode_verified": False,
        "unity_playmode_verified": False,
        "android_build_verified": False,
        "device_verified": False,
        "commercial_release_approved": False,
    }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_root", nargs="?", default=str(Path(__file__).resolve().parent.parent))
    parser.add_argument("--output", help="Optional path for the JSON report")
    args = parser.parse_args()
    outcome = check(args.project_root)
    serialized = json.dumps(outcome, indent=2, sort_keys=True)
    if args.output:
        target = Path(args.output)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(serialized + "\n", "utf-8")
    print(serialized)
    return 0 if not outcome["errors"] else 2


if __name__ == "__main__":
    sys.exit(main())
