#!/usr/bin/env python3
"""Fail-closed static check of the first playable chapter's scene, narrative, and automation.

STATIC ONLY: does not claim Unity compilation or gameplay execution.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def inspect(root: Path = ROOT) -> list[str]:
    paths = {
        "runtime": "Assets/_Project/Runtime/ChapterOneExperience.cs",
        "domain": "Assets/_Project/Domain/ChapterOneProgress.cs",
        "editor": "Assets/_Project/Editor/ChapterOneSceneBuilder.cs",
        "bootstrap": "Assets/_Project/Editor/OrderProjectBootstrap.cs",
        "launch": "Assets/_Project/Editor/OrderFirstImportSetup.cs",
        "android": "Assets/_Project/Editor/OrderAndroidBuildBatch.cs",
        "tests": "Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs",
    }
    issues: list[str] = []
    source: dict[str, str] = {}
    for label, relative in paths.items():
        path = root / relative
        if not path.is_file() or path.stat().st_size == 0:
            issues.append(f"Missing or empty: {relative}")
        else:
            source[label] = path.read_text(encoding="utf-8")
            if label in ("runtime", "domain", "editor", "tests") and not Path(str(path) + ".meta").is_file():
                issues.append(f"Missing Unity meta: {relative}")
    clauses = {
        "runtime": ("GothicWindow(", "Pointed Arch Rib", "Ceiling Rib", "AnimateEnvironment()",
                    "FocusCamera(", "Hidden Passage Moonlight", "ShowContextHint", "RenderSettings.fog = true",
                    "IsPointerOverInterface", "cachedEventSystem", "PointerEventData",
                    "CreateInspectionCamera()", "Live Lens Examination", "inspectionCamera.targetTexture",
                    "inspectionTarget.Release()"),
        "domain": ("DecodeLens", "CipherSolution", "IsValid", "Restore"),
        "editor": ("ChapterOne.unity", "EnsureChapterOne", "EditorBuildSettings.scenes"),
        "bootstrap": ("ChapterOneSceneBuilder.EnsureChapterOne(false)" ,),
        "launch": ("ChapterOneSceneBuilder.EnsureChapterOne(true)",),
        "android": ("ChapterOneSceneBuilder.EnsureChapterOne(false)",),
        "tests": ("ChapterOne_OpensAnInteractiveArchiveWithCluesAndNarrative", "Pointed Arch Rib",
                  "Ceiling Rib", "STORY HINT", "Hidden Passage Moonlight", "Live Lens Examination"),
    }
    for label, tokens in clauses.items():
        for token in tokens:
            if label in source and token not in source[label]:
                issues.append(f"{label} does not enforce {token!r}")
    if "namespace TheOrderRoom.Runtime" not in source.get("runtime", ""):
        issues.append("Serialized runtime type namespace changed")
    if "namespace TheOrderRoom.Domain" not in source.get("domain", ""):
        issues.append("Domain assembly namespace changed")
    return issues


if __name__ == "__main__":
    errors = inspect()
    for error in errors:
        print("FAIL:", error)
    if not errors:
        print("PASS: chapter source, gothic dressing, narrative controls, build integration")
    raise SystemExit(bool(errors))
