"""Negative tests for the fail-closed v4.93 acceptance contract."""
import unittest

from verify_acceptance_coverage_v493 import ROOT, analyze


class AcceptanceCoverageContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runner = (ROOT / "Verification/Run-UnityVerification.ps1").read_text(encoding="utf-8")
        cls.acceptance = (ROOT / "Verification/Run-SableAcceptance.ps1").read_text(encoding="utf-8")

    def evaluate(self, runner=None, acceptance=None):
        return analyze(ROOT, runner or self.runner, acceptance or self.acceptance)

    def test_complete_static_contract_without_claiming_unity_execution(self):
        result = self.evaluate()
        self.assertEqual([], result["errors"])
        self.assertEqual(14, result["editmode_fixture_count"])
        self.assertEqual(6, result["playmode_fixture_count"])
        self.assertFalse(result["unity_compile_verified"])
        self.assertFalse(result["unity_playmode_verified"])

    def test_removing_3d_playmode_fixture_blocks_acceptance(self):
        runner = self.runner.replace("        'ChapterWorldExplorerPlayModeTests',\n", "")
        self.assertIn("MISSING_PLAYMODE_COVERAGE: ChapterWorldExplorerPlayModeTests", self.evaluate(runner)["errors"])

    def test_removing_chapter_one_playmode_fixture_blocks_acceptance(self):
        runner = self.runner.replace("        'ChapterOneSceneTests',\n", "")
        self.assertIn("MISSING_PLAYMODE_COVERAGE: ChapterOneSceneTests", self.evaluate(runner)["errors"])

    def test_removing_dossier_editmode_fixture_blocks_acceptance(self):
        runner = self.runner.replace("        'StoryDossierTests',\n", "")
        self.assertIn("MISSING_EDITMODE_COVERAGE: StoryDossierTests", self.evaluate(runner)["errors"])

    def test_removing_save_fault_test_blocks_acceptance(self):
        runner = self.runner.replace("        'SaveFaultInjectionTests',\n", "")
        self.assertIn("MISSING_EDITMODE_COVERAGE: SaveFaultInjectionTests", self.evaluate(runner)["errors"])

    def test_headless_playmode_is_rejected(self):
        runner = self.runner.replace('    $playArguments = @("-batchmode", "-projectPath",',
                                     '    $playArguments = @("-batchmode", "-nographics", "-projectPath",')
        self.assertIn("PLAYMODE_GRAPHICS_DEVICE_DISABLED", self.evaluate(runner)["errors"])

    def test_missing_nunit_evidence_call_is_rejected(self):
        runner = self.runner.replace("Assert-NUnitEvidence $playXml 'PlayMode' $requiredPlayModeFixtures", "Write-Host 'Skipped'")
        self.assertTrue(any(x.startswith("MISSING_VERIFICATION_ENFORCEMENT") for x in self.evaluate(runner)["errors"]))

    def test_missing_duplicate_guard_is_rejected(self):
        runner = self.runner.replace("-not $uniqueNames.Add($name)", "-not $true")
        self.assertTrue(any(x.startswith("MISSING_VERIFICATION_ENFORCEMENT") for x in self.evaluate(runner)["errors"]))

    def test_missing_baseline_update_is_rejected(self):
        acceptance = self.acceptance.replace('source_baseline = "v5.30"', 'source_baseline = "v4.91"')
        self.assertTrue(any(x.startswith("MISSING_ACCEPTANCE_ENFORCEMENT") for x in self.evaluate(acceptance=acceptance)["errors"]))

    def test_missing_graphics_acceptance_check_is_rejected(self):
        acceptance = self.acceptance.replace('$report.playmode_graphics -cne "ENABLED"', '$false')
        self.assertTrue(any(x.startswith("MISSING_ACCEPTANCE_ENFORCEMENT") for x in self.evaluate(acceptance=acceptance)["errors"]))


if __name__ == "__main__":
    unittest.main()
