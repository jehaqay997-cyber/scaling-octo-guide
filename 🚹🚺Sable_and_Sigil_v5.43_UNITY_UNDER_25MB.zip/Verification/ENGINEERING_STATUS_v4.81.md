# v4.81 Engineering verification

Changes: bounded UTF-8 hint catalog payload to 1 MiB before parsing; reject chapters outside 1..4; added read-only archive integrity validator.

Scope: static checks only. No Unity Editor, compiler, test runner, or Android device is available in this execution environment.

Open P0: authoritative evidence source not connected; target Unity 6000.3.28f1 migration and compilation unverified; no saved scene in archive. Do not create fabricated packages-lock.json or .unity scenes.
