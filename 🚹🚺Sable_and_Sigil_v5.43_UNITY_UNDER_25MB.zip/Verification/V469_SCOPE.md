# v4.69 Art Promotion Safety

Adds an opt-in, backup-first artwork promotion workflow. No image or Unity source is changed by default.

Run `python Verification/promote_enhanced_art_v469.py` for a read-only dry run.
Run `python Verification/promote_enhanced_art_v469.py --apply` only on a disposable project copy after reviewing the visual assets. Original JPEGs are copied to `Verification/ArtPromotionBackup` and `.meta` files remain unchanged.

Run `python -m unittest discover -s Verification -p test_art_promotion_v469.py`.

The promotion is not a Unity compilation, rendered visual quality approval, scene integration test, or Android verification. Editor version remains unchanged.
