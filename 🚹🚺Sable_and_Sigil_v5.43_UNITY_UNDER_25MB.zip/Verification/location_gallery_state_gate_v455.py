#!/usr/bin/env python3
"""Fail-closed static contract for distinct chapter and location gallery controls."""
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path('Assets/_Project/Runtime/ChapterGalleryView.cs')
PLAYMODE = Path('Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs')

REQUIRED_SOURCE = (
    'previousSceneButton = MakeButton(root, "PREVIOUS SCENE"',
    'nextSceneButton = MakeButton(root, "NEXT SCENE"',
    'previousSceneButton.gameObject.SetActive(locationMode)',
    'nextSceneButton.gameObject.SetActive(locationMode)',
    'caption.text = locationMode ? "CHAPTERS" : "SCENE ATLAS"',
    'enterButton.interactable = false;',
    'bool chapterReady = selectedIndex == 0;',
    'enterButton.interactable = chapterReady;',
)
REQUIRED_TESTS = (
    'sceneNavigation.gameObject.activeSelf, Is.False',
    'sceneNavigation.gameObject.activeSelf, Is.True',
    'gallery.SelectChapter(1);',
)


def check(root: Path) -> list[str]:
    problems = []
    for relative_path, fragments in ((SOURCE, REQUIRED_SOURCE), (PLAYMODE, REQUIRED_TESTS)):
        target = root / relative_path
        if not target.is_file():
            problems.append(f'Missing required source: {relative_path}')
            continue
        contents = target.read_text(encoding='utf-8')
        for fragment in fragments:
            if fragment not in contents:
                problems.append(f'{relative_path}: missing {fragment}')
    return problems


if __name__ == '__main__':
    issues = check(ROOT)
    for issue in issues:
        print('FAIL: ' + issue)
    if not issues:
        print('STATIC_PASS_ONLY: chapter/location navigation separation')
    raise SystemExit(bool(issues))
