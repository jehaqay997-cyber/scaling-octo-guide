#!/usr/bin/env python3
"""Fail-closed static brand, empty-file and Unity GUID linkage audit."""
from __future__ import annotations
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "Assets"
GUID_PATTERN = re.compile(r"(?m)^guid: ([0-9a-f]{32})\s*$")


def inspect(root: Path = ROOT) -> list[str]:
    errors: list[str] = []
    assets = root / "Assets"
    if not assets.is_dir():
        return ["Required Assets directory is missing"]
    required = [
        "ProjectSettings/ProjectVersion.txt",
        "ProjectSettings/ProjectSettings.asset",
        "Packages/manifest.json",
        "Assets/_Project/Editor/OrderProjectBootstrap.cs",
        "Assets/_Project/Runtime/OrderGame.cs",
        "Verification/Run-UnityVerification.ps1",
        "OPEN_GAME.ps1",
        "OPEN_GAME.cmd",
        "PLAY_GAME_NOW.html",
        "BRAND_MIGRATION_v4.51.md",
    ]
    for rel in required:
        p = root / rel
        if not p.is_file():
            errors.append(f"Missing required file: {rel}")
        elif p.stat().st_size == 0:
            errors.append(f"Empty required file: {rel}")
    for p in root.rglob("*"):
        if not p.is_file() or "LocalResults" in p.parts:
            continue
        if p.stat().st_size == 0:
            errors.append("Zero-byte file: " + p.relative_to(root).as_posix())
    registered = defaultdict(list)
    for p in assets.rglob("*"):
        if p.is_dir() and p != assets:
            if not Path(str(p) + ".meta").is_file():
                errors.append("Asset folder missing .meta: " + p.relative_to(root).as_posix())
        elif p.is_file() and p.suffix != ".meta":
            if not Path(str(p) + ".meta").is_file():
                errors.append("Asset missing .meta: " + p.relative_to(root).as_posix())
        elif p.is_file() and p.suffix == ".meta":
            actual = Path(str(p)[:-5])
            if not actual.exists():
                errors.append("Orphan .meta: " + p.relative_to(root).as_posix())
            found = GUID_PATTERN.findall(p.read_text(encoding="utf-8-sig", errors="replace"))
            if len(found) != 1:
                errors.append("Invalid .meta GUID: " + p.relative_to(root).as_posix())
            else:
                registered[found[0]].append(p.relative_to(root).as_posix())
    for guid, paths in registered.items():
        if len(paths) > 1:
            errors.append("Duplicate asset GUID " + guid + " in " + ", ".join(paths))
    try:
        asmdefs = list(assets.rglob("*.asmdef"))
        names = {json.loads(p.read_text(encoding="utf-8"))["name"] for p in asmdefs}
        if len(asmdefs) != 7 or len(names) != 7:
            errors.append("Expected seven uniquely named Unity assemblies")
        for path in asmdefs:
            data = json.loads(path.read_text(encoding="utf-8"))
            for ref in data.get("references", []):
                if ref.startswith("TheOrderRoom.") and ref not in names:
                    errors.append("Unresolved project assembly reference: " + ref)
    except (ValueError, KeyError, OSError) as exc:
        errors.append("Assembly parse failed: " + str(exc))
    try:
        settings = (root / "ProjectSettings/ProjectSettings.asset").read_text()
        bootstrap = (root / "Assets/_Project/Editor/OrderProjectBootstrap.cs").read_text()
        preview = (root / "PLAY_GAME_NOW.html").read_text()
        if "productName: Sable & Sigil" not in settings:
            errors.append("Unity product name is not Sable & Sigil")
        if '"SABLE & SIGIL"' not in bootstrap:
            errors.append("Generated game HUD is missing new branding")
        if "SABLE & SIGIL" not in preview or "Sable & Sigil — Playable Preview" not in preview:
            errors.append("Browser preview is missing new branding")
        if "applicationIdentifier:\n    Android: com.theorderroom.game" not in settings:
            errors.append("Android app identifier drift (requires explicit migration)")
        if "theorderroom.preview.v1" not in preview:
            errors.append("Browser save-key drift (requires explicit migration)")
        if "namespace TheOrderRoom.Editor" not in bootstrap:
            errors.append("Unity serialized C# contract namespace drift")
    except OSError as exc:
        errors.append("Brand inspection failed: " + str(exc))
    return sorted(set(errors))


def main() -> int:
    issues = inspect()
    if issues:
        for issue in issues:
            print("FAIL: " + issue)
        return 1
    print("PASS: brand, nonempty files, paired .meta, GUID uniqueness, and asmdef references")
    return 0


if __name__ == "__main__":
    sys.exit(main())
