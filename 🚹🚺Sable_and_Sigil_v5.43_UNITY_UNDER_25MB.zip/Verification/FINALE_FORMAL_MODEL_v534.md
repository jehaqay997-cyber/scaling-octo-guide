# Sable & Sigil — Formal Evidence and Finale Model, v5.34

## State and authority

Let the resolved evidence set at revision `r` be `E_r`. Initially `E_0 = {}`. A successful story deduction for `i` is admissible only if (a) `i` is a valid scene, (b) `i` is absent from `E_r`, (c) every predecessor of `i` is in `E_r`, (d) the UI has handed off its required world evidence, and (e) the chosen answer satisfies the logical deduction. The repository commits a complete `E_{r+1} = E_r union {i}` by revision-checked write. Failure leaves the prior confirmed in-memory revision unavailable for further writes until reconciled. The design does not use a client-supplied snapshot as authoritative recovery.

## Proof obligations

- `I1`: For any committed state, `r = |E_r|`.
- `I2`: `E_r` includes no ID outside `{1,...,10}` and no duplicate.
- `I3`: For every `i` in `E_r`, its prerequisites are also in `E_r`.
- `I4`: `E_{r+1}` strictly supersets `E_r` by one ID.
- `I5`: Story finale access is true exactly when `r = 10` and all ten IDs are present.
- `I6`: Finale UI reads progress and narrative but does not call a commit operation.
- `I7`: Every authored question has exactly one answer satisfying its independent logical model.

## Finite combinatorics

`|S_4| = 4! = 24`. For the fountain model: `p[0]=1`, `p[1]=3`, `p[3]=4`, `position(2)<position(4)`. Exhaustive enumeration leaves a single state, `(1,3,2,4)`. For the meridian model: `position(B)=position(A)+1`, `position(A)<position(C)`, `p[3]=D`. Again one state, `(A,B,C,D)`. Every alternative among the four authored choices fails at least one condition.

## Save compatibility

The original v1 checkpoint schema stores revision and sorted evidence IDs. The original production commit function always added exactly one evidence ID and incremented the revision exactly once. Tightening decoding to `revision == evidence_count` therefore preserves reachable production saves. It deliberately rejects synthetic snapshots that asserted extra revisions without additional solved cases. It does not authenticate against an attacker who can rewrite the entire local save and checksum.

## Runtime validation status

All proofs and source checks in the current repository are either independently implemented Python or authored NUnit source. The actual C# test execution and Unity editor compilation must be completed before accepting any runtime correctness claim.
