#!/usr/bin/env python3
"""Static contract for bounded first-import recovery; not a Unity execution test."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "Assets/_Project/Editor/OrderFirstImportSetup.cs"


def validate(source: str) -> list[str]:
    required = {
        "success is only recorded after entering Play Mode":
            "state == PlayModeStateChange.EnteredPlayMode" in source
            and "SceneManager.GetActiveScene()" in source
            and "ChapterOneExperience chapter = UnityEngine.Object.FindObjectOfType<ChapterOneExperience>();" in source
            and "chapter != null && chapter.isActiveAndEnabled && chapter.IsChapterReady" in source
            and source.index("state == PlayModeStateChange.EnteredPlayMode") < source.index("SessionState.SetBool(SessionLaunchKey, true);")
            and source.index("SessionState.SetBool(SessionLaunchKey, true);") < source.index("else if (state == PlayModeStateChange.EnteredEditMode)")
            and "SessionState.SetBool(SessionLaunchKey, true);" not in source.split("private static void TryInitialize()", 1)[1],
        "completion is gated on a pending request": "SessionState.GetBool(SessionPendingKey, false)" in source
            and "SessionState.SetBool(SessionPendingKey, true);" in source,
        "failed transitions clear pending state": "state == PlayModeStateChange.EnteredEditMode" in source
            and "SessionState.SetBool(SessionPendingKey, false);" in source,
        "state listener is registered": "EditorApplication.playModeStateChanged += OnPlayModeStateChanged;" in source,
        "bounded automatic retries": "private const int MaxAutomaticAttempts = 3;" in source
            and "attempts >= MaxAutomaticAttempts" in source
            and "attempts + 1 < MaxAutomaticAttempts" in source,
        "retry attempts are persisted per session": "SessionState.SetInt(SessionAttemptsKey, attempts + 1);" in source,
        "reentrancy is blocked": "Application.isBatchMode || isAttempting" in source
            and "isAttempting = true;" in source
            and "isAttempting = false;" in source,
        "duplicate retries are suppressed": "if (retryScheduled)" in source,
        "import and compilation are deferred": "EditorApplication.isCompiling || EditorApplication.isUpdating" in source,
        "unsaved user scenes are preserved": "SceneManager.GetActiveScene().path != ScenePath" in source
            and "Save your open scene" in source,
        "manual recovery exists": '[MenuItem("Sable & Sigil/Retry Chapter One Launch")]' in source
            and "SessionState.SetInt(SessionAttemptsKey, 0);" in source,
        "opt-out respected": "File.Exists(OptOutMarker)" in source,
        "scene validation precedes play": source.find("SableChapterBuildRoute.Validate()")
            >= 0 and source.find("SableChapterBuildRoute.Validate()")
            < source.index("EditorApplication.isPlaying = true;"),
    }
    return [name for name, passed in required.items() if not passed]


def main() -> int:
    if not SOURCE.is_file():
        print("FAIL: missing first-import setup")
        return 1
    problems = validate(SOURCE.read_text(encoding="utf-8"))
    for problem in problems:
        print("FAIL:", problem)
    if not problems:
        print("STATIC_PASS_ONLY: bounded Unity editor startup recovery")
    return int(bool(problems))


if __name__ == "__main__":
    raise SystemExit(main())
