#!/usr/bin/env python3
"""Offline regression gate for chapter-location state and bounded image residency.

This checks source contracts only; it does not compile Unity or measure GPU memory.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path('Assets/_Project/Runtime/ChapterGalleryView.cs')
PLAYMODE = Path('Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs')


def method(source: str, signature: str) -> str:
    start = source.find(signature)
    if start < 0:
        return ''
    brace = source.find('{', start + len(signature))
    if brace < 0:
        return ''
    level = 0
    for index in range(brace, len(source)):
        if source[index] == '{':
            level += 1
        if source[index] == '}':
            level -= 1
            if level == 0:
                return source[brace:index + 1]
    return ''


def validate(source: str, tests: str) -> list[str]:
    issues = []
    mapping = method(source, 'public static int GetChapterForLocation(int locationNumber)')
    select = method(source, 'public void SelectLocation(int number)')
    navigate = method(source, 'private void NavigateLocation(int delta)')
    refresh = method(source, 'private void Refresh()')
    if 'locationNumber < 1 || locationNumber > LocationCount' not in mapping or \
            'return LocationChapters[locationNumber - 1];' not in mapping:
        issues.append('Location chapter mapping lacks bounds or ownership')
    if 'selectedIndex = GetChapterForLocation(number) - 1;' not in select:
        issues.append('Direct location selection does not synchronize selected chapter')
    if 'selectedIndex = GetChapterForLocation(locationIndex + 1) - 1;' not in navigate:
        issues.append('Location navigation does not synchronize selected chapter')
    location_branch = refresh.split('if (locationMode)', 1)
    if len(location_branch) < 2:
        issues.append('Missing location-mode rendering branch')
    else:
        render = location_branch[1].split('return;', 1)[0]
        if 'artwork.texture = scene;' not in render or 'ReleaseChapterTexture();' not in render:
            issues.append('Location atlas retains chapter artwork during exclusive rendering')
        elif render.index('artwork.texture = scene;') > render.index('ReleaseChapterTexture();'):
            issues.append('Chapter artwork released before incoming image is attached')
    if 'ChapterAndLocationImagesNeverStayResidentTogether' not in tests or \
            'gallery.ResidentChapterArtworkCount, Is.Zero' not in tests:
        issues.append('No PlayMode assertion for mutually exclusive chapter and location image ownership')
    if 'LocationChapterMappingRejectsInvalidInputs' not in tests:
        issues.append('No PlayMode test for invalid or cross-chapter location mapping')
    return issues


def check(root: Path = ROOT) -> list[str]:
    if not (root / SOURCE).is_file() or not (root / PLAYMODE).is_file():
        return ['Required Unity source or PlayMode test file is missing']
    return validate((root / SOURCE).read_text(encoding='utf-8'),
                    (root / PLAYMODE).read_text(encoding='utf-8'))


if __name__ == '__main__':
    issues = check()
    for issue in issues:
        print('FAIL:', issue)
    if not issues:
        print('STATIC_PASS_ONLY: chapter location ownership and exclusive texture residency')
    raise SystemExit(bool(issues))
