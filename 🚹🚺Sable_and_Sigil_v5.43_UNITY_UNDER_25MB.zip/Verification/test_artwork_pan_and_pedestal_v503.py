"""Fail-closed mutation checks for new v5.03 artwork and 3D pedestal contracts."""
from __future__ import annotations

from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_artwork_pan_and_pedestal_v503 import ROOT, FILES, audit


class ArtworkPanAndPedestalSafetyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.originals = {
            name: (ROOT / path).read_text(encoding='utf-8-sig')
            for name, path in FILES.items()
        }

    def mutate(self, source_name: str, old: str, replacement: str, error_prefix: str):
        original = self.originals[source_name]
        self.assertIn(old, original)
        changed = original.replace(old, replacement, 1)
        errors = audit(overrides={source_name: changed})['errors']
        self.assertTrue(any(error.startswith(error_prefix) for error in errors), errors)

    def test_complete_static_contract_and_geometry_oracle(self):
        result = audit()
        self.assertEqual([], result['errors'])
        self.assertEqual(20, result['authored_relics'])
        self.assertGreater(result['minimum_oracle_triangle_area'], 0.)
        self.assertFalse(result['unity_compiled'])

    def test_missing_artwork_viewport_is_rejected(self):
        self.mutate('viewport', 'public sealed class ChapterArtworkViewport',
                    'public sealed class BrokenViewport', 'UV_VIEWPORT_CONTRACT_MISSING')

    def test_zoom_limits_cannot_be_removed(self):
        self.mutate('viewport', 'public const float MaximumZoom = 3f;',
                    'public const float MaximumZoom = 30f;', 'UV_VIEWPORT_CONTRACT_MISSING')

    def test_artwork_pan_must_reject_nonfinite_input(self):
        self.mutate('viewport', 'if (!Finite(deltaU) || !Finite(deltaV) ||',
                    'if (false ||', 'UV_VIEWPORT_CONTRACT_MISSING')

    def test_uv_window_must_be_clamped_to_image(self):
        self.mutate('viewport', 'float nextX = Clamp(centerX + deltaU, half, 1f - half);',
                    'float nextX = centerX + deltaU;', 'UV_VIEWPORT_CONTRACT_MISSING')

    def test_pedestal_geometry_rejects_excessive_motifs(self):
        self.mutate('inlays', 'if (motifCount < MinimumMotifs || motifCount > MaximumMotifs)',
                    'if (false)', 'PEDESTAL_MESH_CONTRACT_MISSING')

    def test_pedestal_winding_must_remain_upward(self):
        self.mutate('inlays', 'triangles.Add(start + 2);',
                    'triangles.Add(start + 1);', 'PEDESTAL_MESH_CONTRACT_MISSING')

    def test_pedestal_mesh_must_compute_normals(self):
        self.mutate('inlays', 'mesh.RecalculateNormals();',
                    'mesh.RecalculateTangents();', 'PEDESTAL_MESH_CONTRACT_MISSING')

    def test_pedestal_geometry_must_be_evidence_specific(self):
        self.mutate('world', 'ChapterWorldPedestalInlayGeometry.Create(visual.MotifCount);',
                    'ChapterWorldPedestalInlayGeometry.Create(1);',
                    'WORLD_ARTWORK_OR_MESH_WIRING_MISSING')

    def test_pedestal_ornament_must_not_capture_raycast(self):
        self.mutate('world', 'pedestalInlay.layer = SceneryLayer;',
                    'pedestalInlay.layer = EvidenceLayer;',
                    'WORLD_ARTWORK_OR_MESH_WIRING_MISSING')

    def test_image_drag_must_normalize_local_coordinates(self):
        self.mutate('world', 'RectTransformUtility.ScreenPointToLocalPointInRectangle(imageRect,',
                    'RectTransformUtility.RectangleContainsScreenPoint(imageRect,',
                    'WORLD_ARTWORK_OR_MESH_WIRING_MISSING')

    def test_image_pan_buttons_must_be_connected(self):
        self.mutate('world', 'AddButton("ART PAN LEFT", artworkOverlay.transform',
                    'AddButton("ART PAN NORTH", artworkOverlay.transform',
                    'WORLD_ARTWORK_OR_MESH_WIRING_MISSING')

    def test_image_texture_replacement_is_rejected(self):
        self.mutate('world', 'artworkImage.texture = image;',
                    'artworkImage.texture = null;',
                    'WORLD_ARTWORK_OR_MESH_WIRING_MISSING')

    def test_unity_tests_must_keep_mesh_disposal_assertion(self):
        self.mutate('play', 'Assert.IsTrue(pedestalInlays.All(mesh => mesh == null)',
                    'Assert.IsFalse(pedestalInlays.All(mesh => mesh == null)',
                    'UNITY_REGRESSION_COVERAGE_MISSING')

    def test_unity_tests_must_cover_photo_pan(self):
        self.mutate('play', 'ArtworkPan_UsesOriginalImageAndCannotChangeInvestigationProgress',
                    'ArtworkPan_WithoutSafetyAssertions',
                    'UNITY_REGRESSION_COVERAGE_MISSING')

    def test_domain_never_depends_on_unity(self):
        result = audit(overrides={'viewport': self.originals['viewport'] + '\nusing UnityEngine;'})
        self.assertIn('DOMAIN_VIEWPORT_MUST_BE_UNITY_FREE_AND_TRANSIENT', result['errors'])

    def test_geometry_does_not_write_puzzle_progress(self):
        result = audit(overrides={'inlays': self.originals['inlays'] + '\nPlayerPrefs.SetInt("skip", 1);'})
        self.assertIn('MESH_MUST_NOT_CHANGE_PUZZLE_STATE', result['errors'])


if __name__ == '__main__':
    unittest.main()
