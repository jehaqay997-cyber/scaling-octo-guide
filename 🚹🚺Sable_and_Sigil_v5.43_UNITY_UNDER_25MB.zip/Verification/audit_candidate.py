#!/usr/bin/env python3
"""Offline structural integrity audit for the TheOrderRoom source candidate."""
from pathlib import Path
import json, re, hashlib, sys, collections

ROOT=Path(__file__).resolve().parents[1]
def scan():
    failures=[]; warnings=[]
    files=[p for p in ROOT.rglob('*') if p.is_file()]
    manifest=ROOT/'Packages'/'manifest.json'
    if not manifest.is_file(): failures.append('Packages/manifest.json missing')
    else:
        try: json.loads(manifest.read_text(encoding='utf-8'))
        except (ValueError,UnicodeError) as e: failures.append('Invalid Packages/manifest.json: '+str(e))
    version=ROOT/'ProjectSettings'/'ProjectVersion.txt'
    if not version.exists(): failures.append('ProjectVersion.txt missing')
    elif not re.search(r'm_EditorVersion:\s*2022\.3\.62f3',version.read_text(encoding='utf-8')):
        warnings.append('Editor version differs from original 2022.3.62f3 baseline')
    code=[p for p in files if p.suffix=='.cs']
    if not code:failures.append('No C# scripts found')
    guid_seen={}; collision=[]
    for p in files:
        if p.suffix!='.meta':continue
        match=re.search(r'(?m)^guid:\s*([0-9a-fA-F]{32})\s*$',p.read_text(encoding='utf-8',errors='replace'))
        if match:
            guid=match.group(1).lower()
            if guid in guid_seen:collision.append([str(guid_seen[guid].relative_to(ROOT)),str(p.relative_to(ROOT))])
            else:guid_seen[guid]=p
    if collision: failures.append('Duplicate GUIDs: '+str(collision[:10]))
    for p in files:
        if 'Assets' in p.relative_to(ROOT).parts and p.suffix in ('.cs','.asmdef','.png','.unity','.asset') and not Path(str(p)+'.meta').exists():
            warnings.append('Missing metadata: '+str(p.relative_to(ROOT)))
    asmdefs={}
    for p in files:
        if p.suffix!='.asmdef':continue
        try:
            data=json.loads(p.read_text(encoding='utf-8'))
            asmdefs[data['name']]=data
        except (ValueError,KeyError) as e:failures.append('Invalid asmdef '+str(p.relative_to(ROOT))+': '+str(e))
    for name, data in asmdefs.items():
        for ref in data.get('references',[]):
            if ref.startswith('GUID:'):continue
            if ref not in asmdefs and not ref.startswith(('Unity.','UnityEngine.','UnityEditor.')):
                warnings.append('Potential external assembly reference: '+name+' -> '+ref)
    domain=list((ROOT/'Assets'/'_Project'/'Domain').glob('*.cs'))
    for p in domain:
        text=p.read_text(encoding='utf-8',errors='replace')
        if re.search(r'(?m)^\s*using\s+UnityEngine\b',text):failures.append('Domain Unity dependency: '+p.name)
    legacy_results=list((ROOT/'Verification'/'TestResults').glob('*.xml'))
    return {'status':'STATIC_PASS' if not failures else 'STATIC_FAIL',
            'scope':'Offline file structure and JSON, not C# compilation or Unity testing',
            'file_count':len(files),'csharp_count':len(code),'asmdef_count':len(asmdefs),
            'guid_count':len(guid_seen),'historic_result_xml_count':len(legacy_results),
            'failures':failures,'warnings':warnings,
            'unity_compiled':False,'unity_tests_executed':False,'android_device_verified':False}
if __name__=='__main__':
    result=scan()
    print(json.dumps(result,indent=2))
    sys.exit(0 if result['status']=='STATIC_PASS' else 1)
