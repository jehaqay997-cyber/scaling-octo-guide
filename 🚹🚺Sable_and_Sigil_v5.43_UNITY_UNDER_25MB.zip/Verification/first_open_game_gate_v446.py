#!/usr/bin/env python3
"""Static contract for first-opening the integrated Unity scene and browser preview.

This gate never claims Unity has compiled or entered Play Mode.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIRST = ROOT / "Assets/_Project/Editor/OrderFirstImportSetup.cs"
BOOTSTRAP = ROOT / "Assets/_Project/Editor/OrderProjectBootstrap.cs"
PREVIEW = ROOT / "PLAY_GAME_NOW.html"


def validate(first: str, bootstrap: str, html: str) -> list[str]:
    problems: list[str] = []
    contracts = (
        ("editor session reentry prevention", "SessionState.GetBool(SessionLaunchKey" in first and "SessionState.SetBool(SessionLaunchKey, true)" in first),
        ("batch isolation", "Application.isBatchMode" in first),
        ("import stability", "EditorApplication.isCompiling || EditorApplication.isUpdating" in first),
        ("error disclosure", "automatic game launch failed" in first),
        ("scene startup", "ChapterOneSceneBuilder.EnsureChapterOne(true)" in first and "ChapterCaseSceneBuilder.EnsureCaseScenes();" in first),
        ("active scene guard", "SceneManager.GetActiveScene().path != ScenePath" in first),
        ("scene validation before play", first.find("SableChapterBuildRoute.Validate()") < first.find("EditorApplication.isPlaying = true") and "SableChapterBuildRoute.Validate()" in first),
        ("direct game view", 'ExecuteMenuItem("Window/General/Game")' in first),
        ("automatic play", "EditorApplication.isPlaying = true;" in first),
        ("scene generation", "if (!File.Exists(ScenePath)) CreateMainScene();" in bootstrap),
        ("non-destructive scene save", "SaveCurrentModifiedScenesIfUserWantsTo()" in bootstrap),
        ("scene activation", "EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);" in bootstrap),
        ("browser canvas", 'id="zones"' in html and 'id="tokens"' in html),
        ("browser progression", "state.level=(state.level+1)%12" in html),
        ("browser undo", "state.undo.push(copy())" in html),
        ("browser drag", "dragstart" in html and "drop" in html),
        ("browser persistence", "localStorage.setItem" in html),
    )
    for name, passed in contracts:
        if not passed:
            problems.append("First-open contract missing: " + name)
    if re.search(r'<script[^>]+src=', html, re.I):
        problems.append("Browser preview requires an external script")
    return problems


def main() -> int:
    errors = validate(FIRST.read_text(encoding="utf-8"), BOOTSTRAP.read_text(encoding="utf-8"), PREVIEW.read_text(encoding="utf-8"))
    for error in errors:
        print("FAIL:", error)
    if not errors:
        print("STATIC_PASS_ONLY: editor startup and self-contained playable browser preview")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
