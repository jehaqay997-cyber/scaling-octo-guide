# v4.74 Hint UI Lifecycle Hardening

Scope: targeted Unity source changes only.

- Disabling a hint controller disables its button and blocks direct ShowNextHint calls.
- Rebinding the hint label clears both old and new labels, resetting reveal tier to prevent stale content.
- Reenabling recomputes button availability without revealing a hint.
- Three Unity EditMode regression tests added; they have NOT been executed in Unity.
- Existing project Editor version remains 2022.3.62f3; compatibility with target 6000.3.28f1 is NOT verified.
- No Unity compile, PlayMode, scene, or Android validation was performed.
