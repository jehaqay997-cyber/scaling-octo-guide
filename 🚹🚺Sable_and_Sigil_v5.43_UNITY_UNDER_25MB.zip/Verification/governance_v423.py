#!/usr/bin/env python3
"""Fail-closed Unity source governance checks. Does not claim C# compilation."""
from pathlib import Path
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "Assets"
ERRORS = []

def fail(message):
    ERRORS.append(message)

def check():
    if not (ROOT / "ProjectSettings" / "ProjectVersion.txt").is_file():
        fail("Missing ProjectVersion.txt")
    if not (ROOT / "Packages" / "manifest.json").is_file():
        fail("Missing Packages/manifest.json")
    try:
        packages = json.loads((ROOT / "Packages" / "manifest.json").read_text(encoding="utf-8"))
        if not isinstance(packages.get("dependencies"), dict):
            fail("Invalid Unity package dependencies")
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        fail("Unreadable package manifest: " + str(error))
    meta_guid = {}
    for meta in sorted(ASSETS.rglob("*.meta")):
        try:
            data = meta.read_text(encoding="utf-8-sig")
        except (UnicodeError, OSError) as error:
            fail(f"Unreadable meta: {meta.relative_to(ROOT)}: {error}")
            continue
        match = re.search(r"(?m)^guid:\s*([0-9a-f]{32})\s*$",data)
        if not match:
            fail(f"Invalid GUID: {meta.relative_to(ROOT)}")
            continue
        guid = match.group(1)
        if guid in meta_guid:
            fail(f"Duplicate GUID {guid}: {meta.relative_to(ROOT)} and {meta_guid[guid]}")
        meta_guid[guid] = str(meta.relative_to(ROOT))
        owner = Path(str(meta)[:-5])
        if not owner.exists(): fail(f"Orphan meta: {meta.relative_to(ROOT)}")
    sources = sorted(ASSETS.rglob("*.cs"))
    for source in sources:
        if not Path(str(source) + ".meta").is_file():
            fail(f"Missing source meta: {source.relative_to(ROOT)}")
    definitions = sorted(ASSETS.rglob("*.asmdef"))
    names = set()
    for assembly in definitions:
        try:
            definition = json.loads(assembly.read_text(encoding="utf-8-sig"))
            name = definition["name"]
            if name in names: fail(f"Duplicate assembly name: {name}")
            names.add(name)
            if not Path(str(assembly) + ".meta").is_file():
                fail(f"Missing assembly meta: {assembly.relative_to(ROOT)}")
        except (OSError, UnicodeError, ValueError, KeyError) as error:
            fail(f"Invalid assembly definition {assembly.relative_to(ROOT)}: {error}")
    for file in sorted((ASSETS / "_Project" / "Domain").glob("*.cs")) + sorted((ASSETS / "_Project" / "AppCore").glob("*.cs")):
        code = file.read_text(encoding="utf-8-sig")
        if re.search(r"\busing\s+Unity(?:Engine|Editor)\b|\bUnityEngine\.", code):
            fail(f"Unity API in pure layer: {file.relative_to(ROOT)}")
    return {"source_files": len(sources), "asmdefs": len(definitions), "guids": len(meta_guid), "issues": ERRORS,
            "status": "FAIL" if ERRORS else "STATIC_PASS_ONLY",
            "compile_verified": False, "editmode_verified": False, "device_verified": False}

if __name__ == "__main__":
    report = check()
    output = ROOT / "Verification" / "GOVERNANCE_v4.23.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    sys.exit(1 if ERRORS else 0)
