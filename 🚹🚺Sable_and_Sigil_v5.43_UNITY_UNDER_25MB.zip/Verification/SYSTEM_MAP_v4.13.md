# System wiring and evidence

| File | Responsibility | Dependencies |
| --- | --- | --- |
| Domain/LinkedPuzzleRules.cs | Linked pairs and exact-drawer key constraints | Pure C#, PuzzleRule |
| Domain/CampaignPuzzles.cs | Versioned authored rule integration | LinkedPuzzleRules, OrderBoard |
| Runtime/OrderLevels.cs | Restore the correct content version | Domain |
| Runtime/OrderGame.cs | Version-aware rules/hints and viewport input boundary | Domain, Unity |
| Runtime/OrderSaveStore.cs | Preserve legacy version 1 and accept version 2 | OrderLevels |
| Runtime/OrderScreenLayout.cs | Safe area, responsive HUD and perspective framing | Unity camera, UGUI |
| Runtime/ArtifactInspectionView.cs | Inspection camera matches central safe viewport | Unity |
| Editor/OrderProjectBootstrap.cs | Generate and wire safe-area root and layout | Runtime, UnityEditor |
| Editor/OrderSceneValidator.cs | Reject missing layout references before build | Runtime, UnityEditor |
| Tests/EditMode/LinkedPuzzleRulesTests.cs | State rejection, linking and campaign regressions | NUnit, Domain |

All source paths above are relative to Assets/_Project/.

## Executed checks

- 159 portable NUnit logic tests passed.
- 57 portable persistence NUnit tests passed using the supplied JSON adapter.
- 4218 standalone core assertions passed across 24 content-version/level combinations.
- 64 perspective corner checks passed across eight screen dimensions.
- Full source syntax, asmdef references, GUID uniqueness and archive integrity checked during packaging.

## Verification gates

DESIGN_VERIFIED: partial; changes reviewed, broader requested architecture still pending.
COMPILE_VERIFIED: false for Unity; portable core and persistence compiled successfully.
TEST_VERIFIED: partial; portable suites passed, Unity EditMode/PlayMode pending.
DEVICE_VERIFIED: false; Android rendering, safe areas, orientation and touch require device execution.

Domain remains independent of Unity. The existing OrderBoard owns puzzle state. This release does not rename it to PuzzleBoard or claim the requested full AppCore/Infrastructure/Input/Presentation assembly split exists.

## Remaining visual acceptance checks

Open the fresh archive in the target editor. Validate scene references, then verify landscape and portrait Game views, a notched device safe area, drag cancellation outside the board viewport, and artifact inspection. Confirm all labels and rule descriptions remain readable on the actual target device. Existing profiles continue their original content version; new profiles receive the advanced rules.

## API references

https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Camera-fieldOfView.html
https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Screen-safeArea.html
