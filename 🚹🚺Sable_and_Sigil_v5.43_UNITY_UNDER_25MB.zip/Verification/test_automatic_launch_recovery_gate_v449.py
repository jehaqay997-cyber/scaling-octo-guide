"""Mutation checks for the first-import startup safety contract."""
import importlib.util
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "automatic_launch_recovery_gate_v449", HERE / "automatic_launch_recovery_gate_v449.py"
)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
SOURCE = (HERE.parent / "Assets/_Project/Editor/OrderFirstImportSetup.cs").read_text(encoding="utf-8")


class AutomaticLaunchRecoveryTests(unittest.TestCase):
    def test_original_passes(self):
        self.assertEqual([], gate.validate(SOURCE))

    def test_unbounded_retries_rejected(self):
        self.assertTrue(gate.validate(SOURCE.replace("attempts + 1 < MaxAutomaticAttempts", "true")))

    def test_early_success_rejected(self):
        change = SOURCE.replace(
            'EditorApplication.isPlaying = true;\n                Debug.Log(',
            'EditorApplication.isPlaying = true;\n                SessionState.SetBool(SessionLaunchKey, true);\n                Debug.Log('
        )
        self.assertNotEqual(change, SOURCE)
        self.assertTrue(gate.validate(change))

    def test_missing_play_mode_callback_rejected(self):
        change = SOURCE.replace('state == PlayModeStateChange.EnteredPlayMode', 'state == PlayModeStateChange.ExitingPlayMode')
        self.assertTrue(gate.validate(change))

    def test_missing_pending_request_rejected(self):
        change = SOURCE.replace('SessionState.SetBool(SessionPendingKey, true);', '')
        self.assertTrue(gate.validate(change))

    def test_missing_game_instance_check_rejected(self):
        change = SOURCE.replace(
            'ChapterOneExperience chapter = UnityEngine.Object.FindObjectOfType<ChapterOneExperience>();',
            'ChapterOneExperience chapter = null;')
        self.assertNotEqual(change, SOURCE)
        self.assertTrue(gate.validate(change))

    def test_disabled_chapter_must_not_pass_launch(self):
        change = SOURCE.replace('chapter.isActiveAndEnabled && chapter.IsChapterReady',
                                'chapter.IsChapterReady')
        self.assertNotEqual(change, SOURCE)
        self.assertTrue(gate.validate(change))

    def test_uninitialized_chapter_must_not_pass_launch(self):
        change = SOURCE.replace('chapter.isActiveAndEnabled && chapter.IsChapterReady',
                                'chapter.isActiveAndEnabled')
        self.assertNotEqual(change, SOURCE)
        self.assertTrue(gate.validate(change))

    def test_listener_removed_rejected(self):
        change = SOURCE.replace('EditorApplication.playModeStateChanged += OnPlayModeStateChanged;', '')
        self.assertTrue(gate.validate(change))

    def test_missing_manual_recovery_rejected(self):
        self.assertTrue(gate.validate(SOURCE.replace(
            '[MenuItem("Sable & Sigil/Retry Chapter One Launch")]', "")))

    def test_removed_opt_out_rejected(self):
        self.assertTrue(gate.validate(SOURCE.replace("File.Exists(OptOutMarker)", "false")))

    def test_missing_reentrancy_guard_rejected(self):
        self.assertTrue(gate.validate(SOURCE.replace(
            "Application.isBatchMode || isAttempting", "Application.isBatchMode")))

    def test_gate_in_full_audit(self):
        audit = (HERE / "run_full_static_audit_v443.py").read_text(encoding="utf-8")
        self.assertEqual(audit.count('"automatic_launch_recovery_gate_v449.py",'), 1)


if __name__ == "__main__":
    unittest.main()
