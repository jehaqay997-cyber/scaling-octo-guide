[CmdletBinding()]
param(
    [string]$UnityEditorPath = "",
    [string]$ProjectPath = "",
    [string]$OutputRoot = "",
    [switch]$BuildAndroid
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

function Require-File([string]$Path, [string]$Purpose) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "$Purpose not found: $Path"
    }
}

function Require-UnityVersion([string]$EditorPath, [string]$RequiredVersion) {
    Require-File $EditorPath "Unity Editor"
    $response = @(& $EditorPath -version 2>&1 | ForEach-Object { $_.ToString().Trim() })
    if ($LASTEXITCODE -ne 0) {
        throw "Unity version query failed: $($response -join ' | ')"
    }
    $versions = @($response | Where-Object {
        $_ -match '^\d+\.\d+\.\d+[abfp]\d+$'
    } | Select-Object -Unique)
    if ($versions.Count -ne 1 -or $versions[0] -cne $RequiredVersion) {
        throw "Unity version mismatch. Required $RequiredVersion. Actual: $($response -join ' | ')"
    }
}

if ([string]::IsNullOrWhiteSpace($ProjectPath)) {
    $ProjectPath = Join-Path $PSScriptRoot ".."
}
$ProjectPath = (Resolve-Path -LiteralPath $ProjectPath).Path
$projectVersionPath = Join-Path $ProjectPath "ProjectSettings\ProjectVersion.txt"
Require-File $projectVersionPath "Unity project version"
$versionContent = [System.IO.File]::ReadAllText($projectVersionPath)
if ($versionContent -notmatch 'm_EditorVersion:\s*(\S+)') {
    throw "The project does not declare its Unity version."
}
$requiredVersion = $Matches[1]
if ($requiredVersion -cne "2022.3.62f3") {
    throw "This acceptance gate only supports Unity 2022.3.62f3, not $requiredVersion."
}

if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
    $OutputRoot = Join-Path (Split-Path -Parent $ProjectPath) "SableSigilVerification"
}
[System.IO.Directory]::CreateDirectory($OutputRoot) | Out-Null
$OutputRoot = (Resolve-Path -LiteralPath $OutputRoot).Path
$runId = (Get-Date).ToUniversalTime().ToString("yyyyMMdd_HHmmss_fff") + "_" + $PID
$runPath = Join-Path $OutputRoot $runId
[System.IO.Directory]::CreateDirectory($runPath) | Out-Null
$finalReportPath = Join-Path $runPath "sable-acceptance.json"

$report = [ordered]@{
    project = "Sable & Sigil"
    source_baseline = "v5.30"
    candidate_revision = "v5.43"
    unity_editor_required = $requiredVersion
    run_id = $runId
    editor_source_import = "NOT_RUN"
    scene_generation = "NOT_RUN"
    image_and_world_assets = "NOT_RUN"
    editmode_tests = "NOT_RUN"
    playmode_tests = "NOT_RUN"
    required_editmode_fixtures = @()
    required_playmode_fixtures = @()
    playmode_graphics = "NOT_RUN"
    test_manifest_sha256 = $null
    editmode_fixture_count = 0
    playmode_fixture_count = 0
    android_build = "NOT_REQUESTED"
    device_verification = "NOT_VERIFIED"
    commercial_release_approved = $false
    status = "BLOCKED"
    evidence_directory = $runPath
    error = $null
}
$errorDescription = $null
try {
    if ([string]::IsNullOrWhiteSpace($UnityEditorPath)) {
        if ([string]::IsNullOrWhiteSpace($env:ProgramFiles)) {
            throw "ProgramFiles is unavailable. Supply -UnityEditorPath explicitly."
        }
        $UnityEditorPath = Join-Path $env:ProgramFiles "Unity\Hub\Editor\$requiredVersion\Editor\Unity.exe"
    }
    $UnityEditorPath = [System.IO.Path]::GetFullPath($UnityEditorPath)
    Require-UnityVersion $UnityEditorPath $requiredVersion

    $preflightLog = Join-Path $runPath "chapter-and-3d-preflight.log"
    $arguments = @(
        "-batchmode", "-nographics", "-quit", "-projectPath", $ProjectPath,
        "-logFile", $preflightLog,
        "-executeMethod", "TheOrderRoom.Editor.SableLaunchAcceptance.PrepareAndValidateBatch"
    )
    & $UnityEditorPath @arguments
    $exitCode = $LASTEXITCODE
    if ($null -eq $exitCode -or $exitCode -ne 0) {
        throw "Unity launch preflight returned exit code $exitCode. See $preflightLog"
    }
    Require-File $preflightLog "Unity preflight log"
    $logText = [System.IO.File]::ReadAllText($preflightLog)
    if ($logText -notmatch 'SABLE_SIGIL_LAUNCH_PREFLIGHT_PASS') {
        throw "Scene and asset success marker was not emitted. See $preflightLog"
    }
    if ($logText -match '(?im)\berror CS\d{4}\b|\bCompilation failed\b|\bScripts have compiler errors\b') {
        throw "Compiler errors were reported in the Unity preflight log."
    }
    foreach ($relative in @(
        "Assets\_Project\Scenes\ChapterOne.unity",
        "Assets\_Project\Scenes\ChapterTwo.unity",
        "Assets\_Project\Scenes\ChapterThree.unity",
        "Assets\_Project\Scenes\ChapterFour.unity"
    )) {
        Require-File (Join-Path $ProjectPath $relative) "Generated Unity scene"
    }
    $report.editor_source_import = "PASS"
    $report.scene_generation = "PASS"
    $report.image_and_world_assets = "PASS"

    $runner = Join-Path $PSScriptRoot "Run-UnityVerification.ps1"
    Require-File $runner "Full Unity acceptance runner"
    $runnerArgs = @{
        UnityEditorPath = $UnityEditorPath
        ProjectPath = $ProjectPath
        OutputPath = $runPath
    }
    if ($BuildAndroid) {
        $runnerArgs.BuildAndroid = $true
        $runnerArgs.AndroidOutputPath = Join-Path $OutputRoot ("Android_" + $runId)
        $report.android_build = "PENDING"
    }
    & $runner @runnerArgs
    $runnerReportPath = Join-Path $runPath "verification.json"
    Require-File $runnerReportPath "Unity NUnit and source integrity report"
    $unityReport = Get-Content -LiteralPath $runnerReportPath -Raw | ConvertFrom-Json
    if ($unityReport.status -ne "PASS" -or
        $unityReport.source_integrity -ne "PASS" -or
        $unityReport.bootstrap -ne "PASS" -or
        $unityReport.editmode -ne "PASS" -or
        $unityReport.playmode -ne "PASS" -or
        [int]$unityReport.total -lt 1 -or
        [int]$unityReport.playmode_total -lt 1) {
        throw "Full Unity verification did not produce passing EditMode and PlayMode evidence."
    }
    Require-File (Join-Path $runPath "editmode-results.xml") "EditMode NUnit XML"
    Require-File (Join-Path $runPath "playmode-results.xml") "PlayMode NUnit XML"
    $report.editmode_tests = "PASS"
    $report.playmode_tests = "PASS"
    $report.required_editmode_fixtures = @($unityReport.editmode_required_fixtures)
    $report.required_playmode_fixtures = @($unityReport.playmode_required_fixtures)
    $report.playmode_graphics = $unityReport.graphics_playmode
    $report.test_manifest_sha256 = $unityReport.test_manifest_sha256
    $report.editmode_fixture_count = [int]$unityReport.editmode_fixture_count
    $report.playmode_fixture_count = [int]$unityReport.playmode_fixture_count
    $inventoryPath = Join-Path $ProjectPath 'Verification\EXPECTED_NUNIT_FIXTURES_v494.json'
    Require-File $inventoryPath 'Reviewed complete NUnit fixture inventory'
    $inventoryHash = (Get-FileHash -LiteralPath $inventoryPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($inventoryHash -cne [string]$report.test_manifest_sha256 -or
        $report.editmode_fixture_count -lt 71 -or
        $report.playmode_fixture_count -lt 6 -or
        $report.editmode_fixture_count -ne $report.required_editmode_fixtures.Count -or
        $report.playmode_fixture_count -ne $report.required_playmode_fixtures.Count) {
        throw 'Full NUnit fixture inventory evidence is missing, inconsistent or modified.'
    }
    foreach ($stage in @('editmode', 'playmode')) {
        $xmlName = $stage + '-results.xml'
        $evidenceHash = (Get-FileHash -LiteralPath (Join-Path $runPath $xmlName) -Algorithm SHA256).Hash.ToLowerInvariant()
        $declaredHash = if ($stage -ceq 'editmode') {
            [string]$unityReport.editmode_nunit_sha256
        } else {
            [string]$unityReport.playmode_nunit_sha256
        }
        if ($evidenceHash -cne $declaredHash) {
            throw "NUnit result evidence changed after $stage verification."
        }
    }
    if ($report.required_editmode_fixtures.Count -lt 71 -or
        $report.required_playmode_fixtures.Count -lt 6 -or
        $report.playmode_graphics -cne "ENABLED") {
        throw "Required test suite coverage or graphics-enabled PlayMode evidence is missing."
    }
    if ($BuildAndroid) {
        if ($unityReport.android -ne "PASS" -or
            [string]::IsNullOrWhiteSpace($unityReport.android_apk_path) -or
            [string]::IsNullOrWhiteSpace($unityReport.android_apk_sha256)) {
            throw "Verified Android build evidence is absent."
        }
        Require-File $unityReport.android_apk_path "Android APK"
        $actualHash = (Get-FileHash -LiteralPath $unityReport.android_apk_path -Algorithm SHA256).Hash
        if ($actualHash -cne $unityReport.android_apk_sha256) {
            throw "The published APK does not match the build evidence SHA-256."
        }
        $report.android_build = "PASS"
        $report.status = "ANDROID_BUILD_VERIFIED_DEVICE_PENDING"
    } else {
        $report.status = "EDITOR_AND_UNITY_TESTS_VERIFIED_ANDROID_PENDING"
    }
} catch {
    $errorDescription = $_.Exception.Message
    $report.error = $errorDescription
    $report.status = "BLOCKED"
} finally {
    $report | ConvertTo-Json -Depth 6 |
        Set-Content -LiteralPath $finalReportPath -Encoding UTF8
    Write-Host "Acceptance report: $finalReportPath"
    Write-Host "Acceptance status: $($report.status)"
}

if ($null -ne $errorDescription) {
    throw "Sable & Sigil is not verified for launch: $errorDescription"
}
