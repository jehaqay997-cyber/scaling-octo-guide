#!/usr/bin/env python3
"""Run every maintained offline gate and regression suite in an isolated process.

The resulting evidence is STATIC ONLY. Unity compilation, editor tests and
Android device tests must be executed using Run-UnityVerification.ps1.
"""
from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "Verification" / "LocalResults"
GATES = (
    "governance_gate.py",
    "governance_v423.py",
    "architecture_gate_v426.py",
    "camera_contract_gate_v427.py",
    "integration_gate_v428.py",
    "lifecycle_gate_v429.py",
    "screen_layout_gate_v430.py",
    "responsive_layout_gate_v431.py",
    "gesture_integrity_gate_v432.py",
    "restore_integrity_gate_v433.py",
    "history_pacing_gate_v434.py",
    "release_source_gate_v435.py",
    "final_integrity_gate_v436.py",
    "interaction_energy_gate_v437.py",
    "fail_closed_session_gate_v438.py",
    "ui_event_delivery_gate_v439.py",
    "playmode_release_gate_v440.py",
    "ui_pointer_allocation_gate_v444.py",
    "nunit_evidence_gate_v445.py",
    "presentation_quality_gate_v445.py",
    "first_open_game_gate_v446.py",
    "unity_first_run_gate_v447.py",
    "automatic_launch_recovery_gate_v449.py",
    "brand_and_linkage_gate_v451.py",
    "chapter_one_gothic_gate_v452.py",
    "chapter_art_linkage_gate_v453.py",
    "location_art_gate_v454.py",
    "location_gallery_state_gate_v455.py",
    "gallery_viewport_gate_v456.py",
    "chapter_checkpoint_gate_v457.py",
    "chapter_runtime_readiness_gate_v458.py",
    "chapter_resource_lifecycle_gate_v459.py",
    "chapter_texture_memory_gate_v460.py",
    "chapter_catalog_integrity_gate_v461.py",
    "chapter_atlas_coherence_gate_v462.py",
    "chapter_interaction_persistence_gate_v463.py",
    "chapter_test_isolation_gate_v464.py",
    "verify_chapter_story_graph_v484.py",
    "verify_chapter_art_v484.py",
    "verify_story_dossiers_v485.py",
    "verify_chapter_progression_v486.py",
    "verify_case_inspection_v487.py",
    "verify_world_3d_v488.py",
    "verify_world_architecture_v489.py",
    "verify_world_visual_upgrade_v490.py",
    "verify_world_gestures_v491.py",
    "release_source_preflight_v492.py",
    "verify_acceptance_coverage_v493.py",
    "verify_test_inventory_v494.py",
    "verify_relic_models_v495.py",
    "verify_world_artwork_and_sigil_v496.py",
    "verify_reference_graph_v497.py",
    "verify_script_identity_v498.py",
    "verify_build_integrity_v499.py",
    "verify_world_focus_v501.py",
    "verify_relic_interaction_v502.py",
    "verify_artwork_pan_and_pedestal_v503.py",
    "verify_location_lighting_v504.py",
    "verify_threshold_crest_v505.py",
    "verify_crest_diagram_v506.py",
    "verify_chapter_one_relief_v507.py",
    "verify_chapter_one_interactive_crest_v508.py",
    "verify_chapter_one_hint_v509.py",
    "verify_chapter_one_camera_art_v510.py",
    "verify_first_chapter_occlusion_v511.py",
    "verify_spiral_baluster_v512.py",
    "verify_chapter_one_preunity_v513.py",
    "verify_chapter_one_input_integrity_v514.py",
    "verify_chapter_two_v515.py",
    "verify_chapter_two_relief_v516.py",
    "verify_chapter_two_focus_v517.py",
    "verify_chapter_two_back_v518.py",
    "verify_chapter_three_v519.py",
    "verify_chapter_three_modal_v520.py",
    "verify_chapter_three_disclosure_v521.py",
    "verify_chapter_three_closeout_v522.py",
    "verify_chapter_three_atlas_gate_v523.py",
    "verify_three_chapter_unity_ready_v524.py",
    "verify_three_chapter_release_hardening_v525.py",
    "verify_chapter_four_meridian_v526.py",
    "verify_cross_file_hardening_v527.py",
    "verify_story_audio_energy_v528.py",
    "verify_project_integrity_v529.py",
    "verify_runtime_hardening_v530.py",
    "verify_android_publication_v531.py",
    "verify_story_continuity_art_v532.py",
    "verify_ui_privacy_puzzles_v533.py",
    "verify_finale_puzzle_math_v534.py",
    "verify_final_audit_v535.py",
    "verify_cinematic_exploration_v536.py",
    "verify_cinematic_production_v537.py",
    "verify_cinematic_story_fusion_v538.py",
    "verify_physical_meridian_audio_v539.py",
    "verify_scenic_hud_navigation_v540.py",
    "verify_canonical_chapter_route_v541.py",
    "verify_chapter_runtime_route_v542.py",
    "verify_chapter_atlas_route_v543.py",
)
TIMEOUT_SECONDS = 120


def commands() -> tuple[tuple[str, ...], ...]:
    gate_commands = tuple((sys.executable, "Verification/" + filename) for filename in GATES)
    suite = (sys.executable, "-m", "unittest", "discover", "-s", "Verification",
             "-p", "test_*.py", "-q")
    return gate_commands + (suite,)


def execute() -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    executions = []
    for index, arguments in enumerate(commands()):
        label = arguments[1].split("/")[-1] if len(arguments) == 2 else "all_python_regressions"
        evidence_name = f"{index:02d}_{label}"
        missing = [argument for argument in arguments[1:] if argument.startswith("Verification/")
                   and not (ROOT / argument).is_file()]
        if missing:
            result = {"gate": label, "exit_code": None, "status": "FAIL",
                      "error": "Required gate missing: " + ", ".join(missing)}
        else:
            try:
                process = subprocess.run(arguments, cwd=ROOT, capture_output=True,
                                         text=True, errors="replace", timeout=TIMEOUT_SECONDS,
                                         check=False)
                (RESULTS / f"{evidence_name}.stdout.log").write_text(process.stdout, encoding="utf-8")
                (RESULTS / f"{evidence_name}.stderr.log").write_text(process.stderr, encoding="utf-8")
                result = {"gate": label, "exit_code": process.returncode,
                          "status": "PASS" if process.returncode == 0 else "FAIL"}
            except subprocess.TimeoutExpired:
                result = {"gate": label, "exit_code": None, "status": "FAIL",
                          "error": "Audit timed out"}
            except OSError as exc:
                result = {"gate": label, "exit_code": None, "status": "FAIL",
                          "error": type(exc).__name__}
        executions.append(result)
        print(f"{result['status']}: {label}", flush=True)
    status = "STATIC_PASS_ONLY" if all(item["status"] == "PASS" for item in executions) else "FAIL"
    report = {"generated_utc": datetime.now(timezone.utc).isoformat(), "status": status,
              "checked_gate_count": len(GATES), "runs": executions,
              "unity_compile_verified": False, "editmode_executed": False,
              "playmode_executed": False, "android_build_verified": False,
              "device_verified": False}
    (RESULTS / "static-audit-v443.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    return 0 if status == "STATIC_PASS_ONLY" else 1


if __name__ == "__main__":
    sys.exit(execute())
