#!/usr/bin/env python3
"""Static contract checks for input, saves, and global performance ownership.

This is not a substitute for compilation, Unity Test Runner, or device profiling.
"""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / 'Assets' / '_Project' / 'Runtime'

CHECKS = {
    'bounded_save_stream': ('OrderSaveStore.cs', r'using\s*\(var stream = new FileStream\(path, FileMode.Open, FileAccess.Read, FileShare.Read\)\)'),
    'size_checked_before_allocation': ('OrderSaveStore.cs', r'if\s*\(stream.Length > MaxSaveBytes\)'),
    'dynamic_allocation': ('OrderSaveStore.cs', r'int capacity = checked\(\(int\)expectedLength \+ 1\);'),
    'reject_concurrent_mutation': ('OrderSaveStore.cs', r'used != expectedLength \|\| stream.ReadByte\(\) != -1'),
    'strict_utf8': ('OrderSaveStore.cs', r'new UTF8Encoding\(false, true\)'),
    'save_writer_lock': ('OrderSaveStore.cs', r'FileShare.None'),
    'input_ui_guard': ('OrderGame.cs', r'IsScreenPointOverUi\(point\)'),
    'gesture_revision_guard': ('OrderGame.cs', r'return CanUseWorld\(point\) && ReferenceEquals\(gestureBoard, board\) && board.Revision == gestureRevision;'),
    'touch_cancel_on_pause': ('OrderPointerInput.cs', r'OnApplicationPause\(bool paused\)'),
    'touch_cancel_on_focus_loss': ('OrderPointerInput.cs', r'OnApplicationFocus\(bool focused\)'),
    'single_performance_owner': ('OrderPerformanceGovernor.cs', r'private static OrderPerformanceGovernor activeOwner;'),
    'duplicate_governor_disabled': ('OrderPerformanceGovernor.cs', r'if \(activeOwner != null && activeOwner != this\)'),
    'settings_restored_by_owner': ('OrderPerformanceGovernor.cs', r'if \(activeOwner != this\) return;'),
    'camera_layout_restoration': ('OrderScreenLayout.cs', r'private void OnDisable\(\)\s*\{\s*RestoreCamera\(\);'),
}

def evaluate(base=RUNTIME):
    issues=[]
    for name,(file,pattern) in CHECKS.items():
        body=(base/file).read_text(encoding='utf-8-sig')
        if not re.search(pattern,body):
            issues.append(name)
    body=(base/'OrderSaveStore.cs').read_text(encoding='utf-8-sig')
    if 'new byte[(int)MaxSaveBytes + 1]' in body:
        issues.append('unnecessary_full_megabyte_save_allocation')
    return {'status':'STATIC_PASS_ONLY' if not issues else 'FAIL', 'checks':len(CHECKS)+1,
            'issues':issues, 'compile_verified':False, 'editmode_verified':False,
            'android_device_verified':False}

if __name__=='__main__':
    result=evaluate()
    (ROOT/'Verification'/'INTEGRATION_REPORT_v4.28.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
    sys.exit(bool(result['issues']))
