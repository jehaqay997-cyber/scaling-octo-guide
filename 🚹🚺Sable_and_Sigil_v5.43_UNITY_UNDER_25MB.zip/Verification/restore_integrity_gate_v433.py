#!/usr/bin/env python3
"""Fail-closed static regression guard for OrderBoard snapshot restoration."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'Assets/_Project/Domain/OrderBoard.cs'
TESTS = ROOT / 'Assets/_Project/Tests/EditMode/BoardRestoreAtomicityTests.cs'


def validate(source: str, tests: str) -> list[str]:
    errors = []
    anchor = 'private bool RestoreCore(IDictionary<string, string> saved)'
    marker = 'private bool ValidateSnapshot('
    if anchor not in source or marker not in source:
        return ['Missing restore method or validation boundary']
    body = source.split(anchor, 1)[1].split(marker, 1)[0]
    if not re.search(r'candidate\.Add\(pair\.Key,\s*pair\.Value\)', body):
        errors.append('Restore does not copy each validated entry into candidate')
    copy_pos = body.find('candidate.Add(pair.Key, pair.Value)')
    verify_pos = body.find('ValidateSnapshot(candidate, false')
    publish_pos = body.find('locations = candidate')
    if min(copy_pos, verify_pos, publish_pos) < 0 or not copy_pos < verify_pos < publish_pos:
        errors.append('Restore must populate then validate then publish authoritative state')
    if 'candidate.ContainsKey(pair.Key)' not in body or '!items.ContainsKey(pair.Key)' not in body:
        errors.append('Restore must reject unknown and duplicate item keys')
    if 'Revision++; issued.Clear();' not in body:
        errors.append('Successful restore must increment revision and invalidate transfer tickets')
    for title in ('ValidSnapshotRestoresEveryItemAtomically',
                  'RestoringOriginalTrayStateIsValid',
                  'InvalidSnapshotDoesNotChangeStateRevisionOrPendingTransfer',
                  'RestoreInvalidatesPreparedTransferAfterSuccessfulCommit',
                  'MissingAndUnknownItemsAreRejected'):
        if title not in tests:
            errors.append(f'Missing executable NUnit case: {title}')
    return errors


def main() -> int:
    errors = validate(SOURCE.read_text(), TESTS.read_text())
    print('PASS: restoration ordering and regression tests present' if not errors
          else 'FAIL: ' + '; '.join(errors))
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
