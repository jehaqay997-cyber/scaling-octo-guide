#!/usr/bin/env python3
"""Offline governance gate for v4.36. This does not execute Unity or PowerShell."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("release_source", ROOT / "Verification" / "release_source_gate_v435.py")
release_source = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(release_source)


def fingerprint(root: Path, generated: bool = False) -> dict[str, str]:
    """Model the source/generated path partition used by Run-UnityVerification.ps1."""
    project = root / "Assets" / "_Project"
    generated_dirs = (project / "Scenes", project / "Art" / "Materials")
    files: list[Path] = []
    for path in project.rglob("*"):
        if not path.is_file():
            continue
        is_generated = any(path.is_relative_to(folder) or path == Path(str(folder) + ".meta") for folder in generated_dirs)
        if is_generated == generated:
            files.append(path)
    if generated:
        lock = root / "Packages" / "packages-lock.json"
        if lock.is_file():
            files.append(lock)
    else:
        for relative in ("Packages/manifest.json", "ProjectSettings/ProjectVersion.txt", "ProjectSettings/ProjectSettings.asset"):
            path = root / relative
            if path.is_file():
                files.append(path)
    return {path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(files)}


def verify_runner(script: str) -> list[str]:
    required = (
        "Get-SourceFingerprint", "Get-GeneratedFingerprint",
        "Get-FileFingerprint", "Assert-SourceUnchanged $sourceBaseline",
        "Assert-SourceUnchanged $generatedBaseline",
        "if ($report.bootstrap -eq \"PASS\")",
        "ProjectSettings\\ProjectSettings.asset", "Packages\\manifest.json",
        "Art\\Materials", "Scenes", "packages-lock.json",
        "-Algorithm SHA256", "-runTests", "-testPlatform", "EditMode",
        "SableLaunchAcceptance.PrepareAndValidateBatch", "bootstrap.log", "editmode.log",
    )
    return [f"Runner integrity contract missing: {part}" for part in required if part not in script]


def audit(root: Path = ROOT) -> dict:
    base = release_source.audit(root)
    problems = list(base["issues"])
    runner = (root / "Verification" / "Run-UnityVerification.ps1").read_text(encoding="utf-8-sig")
    problems.extend(verify_runner(runner))
    source = fingerprint(root)
    generated = fingerprint(root, generated=True)
    if "Assets/_Project/Art/PNG/sun.png" not in source:
        problems.append("Authored sprite is not tracked by source fingerprint")
    if "Assets/_Project/Domain/OrderBoard.cs" not in source:
        problems.append("Domain source is not tracked by source fingerprint")
    if "ProjectSettings/ProjectSettings.asset" not in source:
        problems.append("Player settings are not tracked by source fingerprint")
    if "Assets/_Project/Art/PNG/puzzle_assets.json" not in source:
        problems.append("Content catalog is not tracked by source fingerprint")
    if set(source) & set(generated):
        problems.append("Source/generated partitions overlap")
    return {
        "status": "STATIC_PASS_ONLY" if not problems else "FAIL",
        "authored_files": len(source),
        "generated_files_at_baseline": len(generated),
        "assemblies": base["assembly_count"],
        "csharp_files": base["csharp_files"],
        "guid_count": base["unity_guid_count"],
        "source_root_sha256": hashlib.sha256(json.dumps(source, sort_keys=True).encode("utf-8")).hexdigest(),
        "unity_compilation_verified": False,
        "android_verified": False,
        "issues": sorted(set(problems)),
    }


if __name__ == "__main__":
    result = audit()
    print(json.dumps(result, indent=2))
    sys.exit(bool(result["issues"]))
