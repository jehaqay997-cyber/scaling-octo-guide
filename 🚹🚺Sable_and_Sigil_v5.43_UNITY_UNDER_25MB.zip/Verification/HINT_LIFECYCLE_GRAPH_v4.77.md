# v4.77 source patch and verification boundaries

Source: v4.76 candidate. Changes are limited to the hint controller, hint catalog, and EditMode tests.

- P1 fixed in source: resetting the disclosure tier when disabling/re-enabling the UI prevents skipping a hidden hint.
- P1 fixed in source: prerequisite graph now rejects circular dependencies during catalog initialization.
- Added a regression test and updated the earlier lifecycle assertion to match the corrected behavior.
- No claim of Unity compilation, EditMode execution, PlayMode, or Android device verification.
- P0 unresolved: hint evidence is still passed by callers and not bound to an authoritative progression repository.
- P0 unresolved: Editor version in ProjectSettings targets 2022.3.62f3 rather than the requested 6000.3.28f1.
- The scene builder is editor-only; a saved scene is not bundled. Generate it in a disposable project clone after successful import.
- Test coverage of cyclic graphs still requires a Unity test fixture that can inject malformed catalog data.

Verification: archive integrity, source patch assertions, JSON parsing and source-file presence only.
