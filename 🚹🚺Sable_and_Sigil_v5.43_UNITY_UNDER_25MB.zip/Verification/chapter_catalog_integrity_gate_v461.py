#!/usr/bin/env python3
"""Static chapter catalog and checkpoint-write contract checks; Unity execution not implied."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
GALLERY_PATH = Path('Assets/_Project/Runtime/ChapterGalleryView.cs')
PROGRESS_PATH = Path('Assets/_Project/Domain/ChapterOneProgress.cs')
EXPERIENCE_PATH = Path('Assets/_Project/Runtime/ChapterOneExperience.cs')
PLAYMODE_PATH = Path('Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs')
EDITMODE_PATH = Path('Assets/_Project/Tests/EditMode/ChapterOneProgressTests.cs')


def evaluate(gallery: str, progress: str, experience: str, playmode: str, editmode: str) -> list[str]:
    errors = []
    required_gallery = (
        'public static bool ValidateContentCatalog(out string error)',
        'ChapterNames.Length != ChapterCount',
        'ChapterDescriptions.Length != ChapterCount',
        'LocationNames.Length != LocationCount',
        'LocationDescriptions.Length != LocationCount',
        'LocationChapters.Length != LocationCount',
        'chapterNumber < 1 || chapterNumber > ChapterCount || chapterNumber < previousChapter',
        'chaptersWithLocations[chapterNumber - 1] = true;',
        'if (!ValidateContentCatalog(out string catalogError))',
    )
    if any(item not in gallery for item in required_gallery):
        errors.append('Catalog is not checked for completeness, order and chapter ownership')
    if 'if (currentDigit == digit) return false;' not in progress:
        errors.append('Unchanged cipher digits must not report a state mutation')
    if 'if (progress.SetDigit(index, (current + 1) % 10))\n                SaveProgress();' not in experience:
        errors.append('Cipher digit UI persists without checking a real state mutation')
    if 'if (progress.EnterObservatory())\n                SaveProgress();' not in experience:
        errors.append('Repeated observatory entry may trigger redundant checkpoint writes')
    if 'ChapterCatalogHasCompleteOrderedUniqueLocationMappings' not in playmode:
        errors.append('Catalog integrity lacks a Unity test')
    if 'CipherDial_NoOpDoesNotMutateOrReportProgress' not in editmode:
        errors.append('Cipher no-op persistence contract lacks an EditMode test')
    m = re.search(r'LocationChapters\s*=\s*\{([^}]*)\}', gallery)
    if not m:
        errors.append('Location-to-chapter manifest missing')
    else:
        values = [int(x.strip()) for x in m.group(1).split(',') if x.strip()]
        if len(values) != 10 or values != sorted(values) or set(values) != {1, 2, 3, 4}:
            errors.append('Location chapter map must have ten ordered entries covering four chapters')
    return errors


def check(root: Path = ROOT) -> list[str]:
    paths = (GALLERY_PATH, PROGRESS_PATH, EXPERIENCE_PATH, PLAYMODE_PATH, EDITMODE_PATH)
    absent = [str(path) for path in paths if not (root / path).is_file() or (root / path).stat().st_size == 0]
    if absent:
        return ['Missing or empty file: ' + ', '.join(absent)]
    errors = evaluate(*((root / path).read_text(encoding='utf-8') for path in paths))
    for i in range(1, 5):
        image = root / 'Assets/_Project/Resources/ChapterArt' / f'Chapter_{i:02}.jpg'
        if not image.is_file() or not image.with_suffix(image.suffix + '.meta').is_file():
            errors.append(f'Missing image or .meta for chapter {i}')
    for i in range(1, 11):
        image = root / 'Assets/_Project/Resources/LocationArt' / f'Scene_{i:02}.jpg'
        if not image.is_file() or not image.with_suffix(image.suffix + '.meta').is_file():
            errors.append(f'Missing image or .meta for location {i}')
    return errors


if __name__ == '__main__':
    issues = check()
    for issue in issues:
        print('FAIL:', issue)
    if not issues:
        print('STATIC_PASS_ONLY: chapter catalog and checkpoint-write contracts')
    raise SystemExit(bool(issues))
