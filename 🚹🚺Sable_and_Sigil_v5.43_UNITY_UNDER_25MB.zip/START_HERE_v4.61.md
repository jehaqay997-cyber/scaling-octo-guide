# Sable & Sigil v4.61

Extract to a local Windows folder and open `OPEN_GAME.cmd`. Match the project editor version in `ProjectSettings/ProjectVersion.txt` (currently Unity 2022.3.62f3). Do not open with a different editor without an explicit migration plan.

Offline check (Python 3):
`python Verification/run_full_static_audit_v443.py`

Unity acceptance (PowerShell from project root, after installing matching editor):
`powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1`

Android build acceptance requires the Android modules and is optional:
`powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1 -BuildAndroid`

Required evidence: compile log, EditMode results, PlayMode results, APK report and device measurements. If any stage fails, do not declare the build production-ready.
