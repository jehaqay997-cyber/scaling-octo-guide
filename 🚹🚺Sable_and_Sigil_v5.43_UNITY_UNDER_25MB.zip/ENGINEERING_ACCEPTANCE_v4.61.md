# Sable & Sigil v4.61 — Engineering Acceptance

## Scope and evidence
The v4.60 Unity project was inspected and modified in place. No Unity Editor or Android device execution occurred in this environment. SOURCE_STATIC_VERIFIED is not COMPILE_VERIFIED, PLAYMODE_VERIFIED, or DEVICE_VERIFIED.

## Confirmed repairs
1. ChapterGalleryView.ValidateContentCatalog rejects missing/duplicate chapter or location names, missing descriptions, invalid chapter numbers, out-of-order chapter progression, and chapters without a mapped location. Validation executes before constructing the gallery UI.
2. ChapterOneProgress.SetDigit rejects an unchanged digit, so a no-op cannot masquerade as progress. ChapterOneExperience.CycleDigit persists only actual dial changes.
3. ChapterOneExperience.EnterObservatory persists the transition only once. Repeated entry cannot generate an unnecessary checkpoint write.
4. Added EditMode cipher regression, PlayMode catalog regression, and an independent static mutation gate that deliberately removes required checks and corrupts the chapter-to-location mapping.
5. The chapter catalog integrity gate is now mandatory in run_full_static_audit_v443.py.

## Execution evidence
- Python unittest discovery: 191 passed, 0 failed.
- Offline unified audit: 35/35 stages passed; report status STATIC_PASS_ONLY.
- Archived source file inventory and SHA-256 validation performed after packaging.
- The existing four chapter artwork assets, ten location reference artworks and Unity .meta companions were retained.

## Outstanding release blockers
- Unity C# compile, import and editor initialization are NOT verified.
- EditMode/PlayMode C# tests and ChapterOne scene rendering are NOT executed.
- Android APK/device frame pacing, GPU memory, battery drain and thermal behavior are NOT measured.
- Future chapters 2–4 remain art concepts, NOT playable chapters.
- Chapter one is still a programmatically generated room and not a production-quality photorealistic environment.

## Quality controls and references
- Unity 2022.3 Screen.safeArea and CanvasScaler documentation: https://docs.unity.cn/ScriptReference/Screen-safeArea.html and https://docs.unity.cn/2022.1/Documentation/Manual/script-CanvasScaler.html
- Unity 2022.3 resource memory lifecycle: https://docs.unity.cn/Documentation/ScriptReference/Resources.html
- OWASP SAMM requirements-driven verification: https://owaspsamm.org/model/verification/requirements-driven-testing/
- NIST SSDF: https://csrc.nist.gov/pubs/sp/800/218/final

The gates are preventive contracts and are not evidence of 100% defect freedom.
