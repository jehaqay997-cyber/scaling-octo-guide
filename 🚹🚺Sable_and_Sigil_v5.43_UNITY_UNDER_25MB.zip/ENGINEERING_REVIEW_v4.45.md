# TheOrderRoom v4.45 — Engineering Acceptance and Visual Identity

## Scope
A real, bounded source update to the v4.44 baseline. The existing domain, persistence,
input, camera and campaign logic are retained. The generated scene now has a coherent
antique-archive visual treatment: a dark tabletop with four brass-colored, collider-free
inlays, two non-interactive UI backdrop panels, and more legible gold-toned button states.
This changes the visible game, rather than only its audit reports.

## Modified files
- `Assets/_Project/Editor/OrderProjectBootstrap.cs`: create non-colliding tabletop detail,
  non-raycast panels and tactile button state colors when generating the integrated scene.
- `Assets/_Project/Editor/OrderSceneValidator.cs`: reject missing, interactive or
  collider-obstructing decorative parts in the authored scene.
- `Assets/_Project/Tests/PlayMode/IntegratedSceneSmokeTests.cs`: executable Unity assertions
  covering the visual components and input safety.
- `Verification/run_full_static_audit_v443.py`: add the dedicated presentation contract gate.

## Added files
- `Verification/presentation_quality_gate_v445.py` and
  `Verification/test_presentation_quality_gate_v445.py`: source contract checks plus
  negative mutation tests.
- This engineering report, acceptance guide, and SHA-256 file manifest.

## Preexisting game content
The code already defines a 12-room puzzle campaign, narrative clues and revelations,
artifact inspection, seal scanning, reward collection and energy restoration. These
systems were not replaced or represented as newly implemented in this version.

## Evidence and limitations
- All existing offline source gates and the new presentation gate completed successfully.
- The Python regression suite contains 108 passing tests in the local run.
- A Unity C# compiler, Unity Test Runner, Windows PowerShell and an Android target
  are unavailable here. `COMPILE_VERIFIED`, `EDITMODE_VERIFIED`,
  `PLAYMODE_VERIFIED`, `ANDROID_BUILD_VERIFIED`, and `DEVICE_VERIFIED` are all **false**.
- Static pattern and Python mutation tests do not substitute for compiling C# or
  interacting with the rendered scene on a device.
- ProjectSettings/ProjectVersion.txt still declares Unity 2022.3.62f3.
- The ZIP contains source and auto-generation logic; Main.unity is created by the
  Unity editor bootstrap, not prebuilt in this archive.

## Release sequence
1. Use the exact Unity editor required by ProjectSettings/ProjectVersion.txt.
2. Run `Verification/Run-UnityVerification.ps1` with source immutability checks,
   bootstrap and complete NUnit evidence for EditMode and PlayMode.
3. Repeat with `-BuildAndroid` after installing Android Build Support and SDK/NDK/JDK.
4. Inspect PlayMode screenshots, screen sizes, raycasts, memory/GC and device input.
5. Promote only after recorded evidence for all required release gates.

## Technical baselines
Official Unity docs: `Canvas`, `GraphicRaycaster`, `Button`, `EditorSceneManager`,
`Unity Test Framework` (2022.3 era). Microsoft .NET and NIST SSDF are governance
references, not certificates of this project's production readiness.
