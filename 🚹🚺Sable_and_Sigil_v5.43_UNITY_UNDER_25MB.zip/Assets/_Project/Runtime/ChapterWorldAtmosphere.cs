using System;
using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Optional procedural, device-local chapter atmosphere. One three-second clip,
    /// one 2D AudioSource and no per-frame synthesis. The scene owns both objects.
    /// Preference changes are polled at a bounded cadence; sound never affects progress.
    /// </summary>
    [RequireComponent(typeof(AudioSource))]
    [DisallowMultipleComponent]
    public sealed class ChapterWorldAtmosphere : MonoBehaviour
    {
        private const float CheckIntervalSeconds = .5f;
        private AudioSource audioSource;
        private AudioClip clip;
        private float nextPreferenceCheck;
        private bool paused;
        private bool focused = true;
        private bool initialized;

        private void Awake()
        {
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
            {
                enabled = false;
                return;
            }
            audioSource.playOnAwake = false;
            audioSource.loop = true;
            audioSource.spatialBlend = 0f;
            audioSource.spatialize = false;
            audioSource.volume = .19f;
        }

        public void Initialize(int chapterNumber)
        {
            if (initialized) throw new InvalidOperationException("Chapter ambience is already configured.");
            if (chapterNumber < 1 || chapterNumber > 4)
                throw new ArgumentOutOfRangeException(nameof(chapterNumber));
            if (audioSource == null)
                throw new InvalidOperationException("Chapter ambience requires AudioSource.");
            float[] samples = CinematicAmbientSynthesis.Create(chapterNumber);
            AudioClip created = null;
            try
            {
                created = AudioClip.Create("Original Chapter Atmosphere " + chapterNumber,
                    CinematicAmbientSynthesis.SampleCount, 1,
                    CinematicAmbientSynthesis.SampleRate, false);
                if (created == null || !created.SetData(samples, 0))
                    throw new InvalidOperationException("Ambient clip creation failed.");
                clip = created;
                audioSource.clip = clip;
                initialized = true;
                Refresh();
            }
            catch
            {
                // A failed SetData may leave a partially initialized AudioClip.
                // Detach it before destroying the native resource and keep the
                // component uninitialized so gameplay can safely continue silent.
                audioSource.clip = null;
                clip = null;
                initialized = false;
                if (created != null) DestroyClip(created);
                throw;
            }
        }

        private void Update()
        {
            if (!initialized || Time.unscaledTime < nextPreferenceCheck) return;
            nextPreferenceCheck = Time.unscaledTime + CheckIntervalSeconds;
            Refresh();
        }

        private void Refresh()
        {
            if (audioSource == null || !initialized) return;
            bool shouldPlay = isActiveAndEnabled && focused && !paused &&
                !AudioListener.pause && LocalPrivacyPreferences.AudioEnabled;
            if (shouldPlay && !audioSource.isPlaying) audioSource.Play();
            else if (!shouldPlay && audioSource.isPlaying) audioSource.Stop();
        }

        private void OnApplicationPause(bool value)
        {
            paused = value;
            Refresh();
        }

        private void OnApplicationFocus(bool value)
        {
            focused = value;
            Refresh();
        }

        private void OnEnable()
        {
            Refresh();
        }

        private void OnDisable()
        {
            if (audioSource != null) audioSource.Stop();
        }

        private void OnDestroy()
        {
            if (audioSource != null)
            {
                audioSource.Stop();
                audioSource.clip = null;
            }
            if (clip != null) DestroyClip(clip);
            clip = null;
            initialized = false;
        }

        private static void DestroyClip(AudioClip sound)
        {
            if (Application.isPlaying) UnityEngine.Object.Destroy(sound);
            else UnityEngine.Object.DestroyImmediate(sound);
        }
    }
}
