using System;
using System.Collections.Generic;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// One bounded, front-facing relief for each authored Chapter Two mechanism.
    /// The caller owns the mesh. Geometry is decorative, collider-free, and has
    /// no authority over clues, answers, saves, or campaign progression.
    /// </summary>
    public static class ChapterTwoReliefMesh
    {
        public const int FirstLocation = 3;
        public const int LastLocation = 6;
        public const int MaximumTriangles = 512;
        private const float Pi = Mathf.PI;

        public static Mesh Create(int locationNumber, bool solved)
        {
            ValidateLocation(locationNumber);
            var mesh = new Mesh { name = "Owned Chapter Two Mechanism Relief" };
            try
            {
                mesh.MarkDynamic();
                Rebuild(mesh, locationNumber, solved);
                return mesh;
            }
            catch
            {
                if (Application.isPlaying) UnityEngine.Object.Destroy(mesh);
                else UnityEngine.Object.DestroyImmediate(mesh);
                throw;
            }
        }

        /// <summary>
        /// Repaints an existing owned mesh only when the puzzle is solved.
        /// Mesh identity remains stable across the state transition.
        /// </summary>
        public static void Rebuild(Mesh mesh, int locationNumber, bool solved)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));
            ValidateLocation(locationNumber);
            var geometry = new ReliefBuilder();
            switch (locationNumber)
            {
                case 3:
                    BuildLunar(geometry, solved);
                    break;
                case 4:
                    BuildRose(geometry, solved);
                    break;
                case 5:
                    BuildFountain(geometry, solved);
                    break;
                case 6:
                    BuildCrossing(geometry, solved);
                    break;
            }
            if (geometry.TriangleCount < 1 || geometry.TriangleCount > MaximumTriangles)
                throw new InvalidOperationException("Chapter Two relief exceeds its triangle budget.");

            mesh.Clear();
            mesh.SetVertices(geometry.Vertices);
            mesh.SetNormals(geometry.Normals);
            mesh.SetTriangles(geometry.Triangles, 0);
            mesh.RecalculateBounds();
        }

        private static void ValidateLocation(int locationNumber)
        {
            if (locationNumber < FirstLocation || locationNumber > LastLocation)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
        }

        private static float Slot(int index, int count)
        {
            return (index - (count - 1) * .5f) * (count == 5 ? .78f : .94f);
        }

        private static void BuildLunar(ReliefBuilder geometry, bool solved)
        {
            for (int index = 0; index < 4; index++)
            {
                float x = Slot(index, 4);
                geometry.Ring(x, 0f, .19f, .16f, 20);
                if (index == 1) geometry.Sector(x, 0f, .13f, -Pi * .5f, Pi * .5f, 12);
                else if (index == 2 && solved) geometry.Sector(x, 0f, .13f, 0f, Pi * 2f, 24);
                else if (index == 3) geometry.Sector(x, 0f, .13f, Pi * .5f, Pi * 1.5f, 12);
            }
        }

        private static void BuildRose(ReliefBuilder geometry, bool solved)
        {
            int[] counts = { 2, 3, 5, 8, 13 };
            for (int index = 0; index < counts.Length; index++)
            {
                float x = Slot(index, counts.Length);
                geometry.Ring(x, 0f, .17f, .15f, 16);
                if (index == 4 && !solved) continue;
                int petals = counts[index];
                for (int petal = 0; petal < petals; petal++)
                {
                    float angle = petal * (Pi * 2f / petals);
                    Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
                    Vector2 across = new Vector2(-direction.y, direction.x);
                    Vector2 center = new Vector2(x, 0f);
                    geometry.Triangle(center + direction * .055f + across * .022f,
                        center + direction * .15f,
                        center + direction * .055f - across * .022f);
                }
                geometry.Sector(x, 0f, .036f, 0f, Pi * 2f, 8);
            }
        }

        private static void BuildFountain(ReliefBuilder geometry, bool solved)
        {
            int[] restoredHeights = { 1, 3, 2, 4 };
            for (int index = 0; index < 4; index++)
            {
                float x = Slot(index, 4);
                geometry.Quad(x - .19f, -.19f, x + .19f, -.16f);
                bool visible = solved || index == 0 || index == 3;
                if (visible)
                {
                    float height = .086f * restoredHeights[index];
                    geometry.Quad(x - .10f, -.16f, x + .10f, -.16f + height);
                    geometry.Quad(x - .14f, -.16f + height, x + .14f, -.14f + height);
                }
                else geometry.Ring(x, 0f, .115f, .095f, 16);
            }
        }

        private static void BuildCrossing(ReliefBuilder geometry, bool solved)
        {
            for (int index = 0; index < 4; index++)
            {
                float x = Slot(index, 4);
                geometry.Ring(x, 0f, .19f, .17f, 16);
                if (index == 0) geometry.Arrow(x, 0f, 0f, .13f);
                else if (index == 1) geometry.Arrow(x, 0f, -Pi * .5f, .13f);
                else if (index == 2) geometry.Arrow(x, 0f, Pi, .13f);
                else if (solved)
                {
                    geometry.Arrow(x - .10f, .04f, -Pi * .5f, .054f);
                    geometry.Arrow(x, .04f, 0f, .054f);
                    geometry.Arrow(x + .10f, .04f, Pi, .054f);
                }
            }
        }

        private sealed class ReliefBuilder
        {
            public readonly List<Vector3> Vertices = new List<Vector3>(768);
            public readonly List<Vector3> Normals = new List<Vector3>(768);
            public readonly List<int> Triangles = new List<int>(768);
            public int TriangleCount => Triangles.Count / 3;

            public void Triangle(Vector2 a, Vector2 b, Vector2 c)
            {
                float winding = (b.x - a.x) * (c.y - a.y) -
                    (b.y - a.y) * (c.x - a.x);
                if (Mathf.Abs(winding) <= .0000001f)
                    throw new InvalidOperationException("Degenerate Chapter Two relief triangle.");
                if (winding > 0f)
                {
                    Vector2 swap = b;
                    b = c;
                    c = swap;
                }
                int start = Vertices.Count;
                Vertices.Add(new Vector3(a.x, a.y, 0f));
                Vertices.Add(new Vector3(b.x, b.y, 0f));
                Vertices.Add(new Vector3(c.x, c.y, 0f));
                Normals.Add(Vector3.back);
                Normals.Add(Vector3.back);
                Normals.Add(Vector3.back);
                Triangles.Add(start);
                Triangles.Add(start + 1);
                Triangles.Add(start + 2);
            }

            public void Quad(float left, float bottom, float right, float top)
            {
                Vector2 a = new Vector2(left, bottom);
                Vector2 b = new Vector2(right, bottom);
                Vector2 c = new Vector2(right, top);
                Vector2 d = new Vector2(left, top);
                Triangle(a, c, b);
                Triangle(a, d, c);
            }

            public void Sector(float x, float y, float radius, float first, float last, int steps)
            {
                Vector2 center = new Vector2(x, y);
                for (int i = 0; i < steps; i++)
                {
                    float a = first + (last - first) * i / steps;
                    float b = first + (last - first) * (i + 1) / steps;
                    Triangle(center,
                        center + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * radius,
                        center + new Vector2(Mathf.Cos(b), Mathf.Sin(b)) * radius);
                }
            }

            public void Ring(float x, float y, float outer, float inner, int steps)
            {
                Vector2 center = new Vector2(x, y);
                for (int index = 0; index < steps; index++)
                {
                    float a = index * Pi * 2f / steps;
                    float b = (index + 1) * Pi * 2f / steps;
                    Vector2 dirA = new Vector2(Mathf.Cos(a), Mathf.Sin(a));
                    Vector2 dirB = new Vector2(Mathf.Cos(b), Mathf.Sin(b));
                    Vector2 outA = center + dirA * outer;
                    Vector2 outB = center + dirB * outer;
                    Vector2 inA = center + dirA * inner;
                    Vector2 inB = center + dirB * inner;
                    Triangle(outA, inA, outB);
                    Triangle(inA, inB, outB);
                }
            }

            public void Arrow(float x, float y, float angle, float length)
            {
                Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
                Vector2 across = new Vector2(-direction.y, direction.x);
                Vector2 center = new Vector2(x, y);
                Vector2 tail = center - direction * (length * .7f);
                Vector2 basePoint = center + direction * (length * .3f);
                float halfWidth = length * .13f;
                Triangle(tail - across * halfWidth, basePoint - across * halfWidth,
                    basePoint + across * halfWidth);
                Triangle(tail - across * halfWidth, basePoint + across * halfWidth,
                    tail + across * halfWidth);
                Triangle(basePoint - across * (length * .43f),
                    center + direction * length,
                    basePoint + across * (length * .43f));
            }
        }
    }
}
