namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// A transient, allocation-free input barrier. A pointer held across a
    /// focus or pause transition must be fully released before a new gesture.
    /// A release frame is never interpreted as a fresh click or pinch.
    /// </summary>
    public sealed class WorldPointerResumeGate
    {
        private bool awaitingRelease;

        public bool IsAwaitingRelease => awaitingRelease;

        public void Suspend()
        {
            awaitingRelease = true;
        }

        public void Reset()
        {
            awaitingRelease = false;
        }

        /// <summary>Returns false for every suspended frame, including the release frame.</summary>
        public bool MayProcessFrame(bool anyPointerHeld)
        {
            if (!awaitingRelease) return true;
            if (!anyPointerHeld) awaitingRelease = false;
            return false;
        }
    }
}
