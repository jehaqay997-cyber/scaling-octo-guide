using System;
using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>Identifies an interactive artifact without granting a save-state mutation.</summary>
    public sealed class ChapterWorldEvidenceMarker : MonoBehaviour
    {
        public int LocationNumber { get; private set; }
        public int EvidenceIndex { get; private set; }

        public void Configure(int locationNumber, int evidenceIndex)
        {
            ChapterWorldSceneCatalog.Get(locationNumber);
            if (evidenceIndex < 0 || evidenceIndex > 1)
                throw new ArgumentOutOfRangeException(nameof(evidenceIndex));
            LocationNumber = locationNumber;
            EvidenceIndex = evidenceIndex;
        }
    }
}
