using System;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Creates a bounded, double-sided pointed barrel vault without physics colliders.
    /// The caller owns the returned mesh and must release it when the world closes.
    /// </summary>
    public static class ChapterWorldVaultGeometry
    {
        public const int MinimumWidthSegments = 4;
        public const int MaximumWidthSegments = 48;
        public const int MinimumLengthSegments = 2;
        public const int MaximumLengthSegments = 24;

        public static Mesh CreateVault(float halfSpan, float springHeight, float rise,
            float nearZ, float farZ, int widthSegments, int lengthSegments)
        {
            ValidatePositive(halfSpan, nameof(halfSpan));
            ValidatePositive(rise, nameof(rise));
            ValidateFinite(springHeight, nameof(springHeight));
            ValidateFinite(nearZ, nameof(nearZ));
            ValidateFinite(farZ, nameof(farZ));
            if (halfSpan > 12f || rise > 8f || Mathf.Abs(springHeight) > 20f)
                throw new ArgumentOutOfRangeException(nameof(halfSpan), "Vault dimensions exceed the bounded scene budget.");
            if (farZ <= nearZ || farZ - nearZ > 20f)
                throw new ArgumentOutOfRangeException(nameof(farZ));
            if (widthSegments < MinimumWidthSegments || widthSegments > MaximumWidthSegments)
                throw new ArgumentOutOfRangeException(nameof(widthSegments));
            if (lengthSegments < MinimumLengthSegments || lengthSegments > MaximumLengthSegments)
                throw new ArgumentOutOfRangeException(nameof(lengthSegments));

            int rowSize = widthSegments + 1;
            int sheetVertices = rowSize * (lengthSegments + 1);
            var vertices = new Vector3[sheetVertices * 2];
            var uvs = new Vector2[vertices.Length];
            var triangles = new int[widthSegments * lengthSegments * 12];
            for (int row = 0; row <= lengthSegments; row++)
            {
                float zFraction = (float)row / lengthSegments;
                float z = Mathf.Lerp(nearZ, farZ, zFraction);
                for (int column = 0; column <= widthSegments; column++)
                {
                    float xFraction = (float)column / widthSegments;
                    float normalized = 2f * xFraction - 1f;
                    float distance = Mathf.Abs(normalized);
                    float gothicCurve = 1f - distance * (.65f + .35f * distance);
                    float height = springHeight + rise * gothicCurve;
                    int index = row * rowSize + column;
                    var vertex = new Vector3(normalized * halfSpan, height, z);
                    var uv = new Vector2(xFraction * 6f, zFraction * 4f);
                    vertices[index] = vertex;
                    vertices[index + sheetVertices] = vertex;
                    uvs[index] = uv;
                    uvs[index + sheetVertices] = uv;
                }
            }

            int triangleIndex = 0;
            for (int row = 0; row < lengthSegments; row++)
            {
                for (int column = 0; column < widthSegments; column++)
                {
                    int a = row * rowSize + column;
                    int b = a + 1;
                    int c = a + rowSize;
                    int d = c + 1;
                    // Underside faces into the hall; the second sheet faces outward.
                    triangles[triangleIndex++] = a;
                    triangles[triangleIndex++] = b;
                    triangles[triangleIndex++] = c;
                    triangles[triangleIndex++] = b;
                    triangles[triangleIndex++] = d;
                    triangles[triangleIndex++] = c;
                    int outer = sheetVertices;
                    triangles[triangleIndex++] = outer + a;
                    triangles[triangleIndex++] = outer + c;
                    triangles[triangleIndex++] = outer + b;
                    triangles[triangleIndex++] = outer + b;
                    triangles[triangleIndex++] = outer + c;
                    triangles[triangleIndex++] = outer + d;
                }
            }

            var mesh = new Mesh { name = "Owned Gothic Vault Geometry" };
            mesh.vertices = vertices;
            mesh.uv = uvs;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private static void ValidatePositive(float value, string name)
        {
            ValidateFinite(value, name);
            if (value <= 0f) throw new ArgumentOutOfRangeException(name);
        }

        private static void ValidateFinite(float value, string name)
        {
            if (float.IsNaN(value) || float.IsInfinity(value))
                throw new ArgumentOutOfRangeException(name);
        }
    }
}
