using System;
using UnityEngine;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Entry controller for Chapters Two, Three and Four. The gallery and physical
    /// investigation run on demand; neither story progress nor chapter completion
    /// is granted by loading this scene.
    /// </summary>
    public sealed class ChapterCaseSceneBootstrap : MonoBehaviour
    {
        [SerializeField] private int chapterNumber = 2;

        public int ChapterNumber => chapterNumber;

        public void Configure(int number)
        {
            if (number < 2 || number > 4)
                throw new ArgumentOutOfRangeException(nameof(number));
            chapterNumber = number;
        }

        private void Awake()
        {
            if (chapterNumber < 2 || chapterNumber > 4)
                throw new InvalidOperationException("Chapter case scene must target Chapters Two through Four.");

            // Chapter One and Main have their own frame governor, but these
            // independently loaded chapter scenes must own one as well.
            if (GetComponent<OrderPerformanceGovernor>() == null)
                gameObject.AddComponent<OrderPerformanceGovernor>();

            // A chapter-case scene initially contains only a UI gallery. Its
            // 3D investigation camera is created on demand and deliberately
            // has no AudioListener. Without this listener all feedback is mute.
            // Never create a second listener if one already exists in the scene.
            if (UnityEngine.Object.FindObjectOfType<AudioListener>() == null)
                gameObject.AddComponent<AudioListener>();

            if (EventSystem.current == null)
            {
                var events = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
                events.AddComponent<InputSystemUIInputModule>();
#else
                events.AddComponent<StandaloneInputModule>();
#endif
            }
        }

        private void Start()
        {
            ChapterGalleryView gallery = GetComponent<ChapterGalleryView>();
            if (gallery == null) throw new InvalidOperationException("Chapter scene has no ChapterGalleryView.");
            gallery.Show();
            gallery.SelectChapter(chapterNumber);
        }
    }
}
