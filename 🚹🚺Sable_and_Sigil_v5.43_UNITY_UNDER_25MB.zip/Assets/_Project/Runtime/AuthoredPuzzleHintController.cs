using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// A presentation-only hint adapter. Evidence must be supplied by the authoritative
    /// progression system; this component never awards evidence or changes saved progress.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class AuthoredPuzzleHintController : MonoBehaviour
    {
        [SerializeField] private AuthoredPuzzleHintCatalog catalog;
        [SerializeField] private Button hintButton;
        [SerializeField] private Text hintLabel;
        [SerializeField] private string puzzleId;

        private readonly HashSet<string> evidence = new HashSet<string>(StringComparer.Ordinal);
        private int revealedTier;
        private bool configured;

        public int RevealedTier => revealedTier;
        public string PuzzleId => puzzleId;

        private void Awake()
        {
            if (catalog == null) catalog = GetComponent<AuthoredPuzzleHintCatalog>();
        }

        private void OnEnable()
        {
            if (hintButton != null)
            {
                hintButton.onClick.RemoveListener(OnHintClicked);
                hintButton.onClick.AddListener(OnHintClicked);
            }
            // The label is cleared on disable; reset the disclosure cursor as well.
            // Otherwise the next click could skip a tier that is no longer visible.
            revealedTier = 0;
            if (hintLabel != null) hintLabel.text = string.Empty;
            RefreshButton();
        }

        private void OnDisable()
        {
            // A hidden hint must not remain counted as visibly disclosed.
            revealedTier = 0;
            if (hintLabel != null) hintLabel.text = string.Empty;
            if (hintButton != null)
            {
                hintButton.onClick.RemoveListener(OnHintClicked);
                hintButton.interactable = false;
            }
        }

        /// <summary>Explicit UI wiring, useful for a scene factory and isolated tests.</summary>
        public void Configure(AuthoredPuzzleHintCatalog source, Button button, Text label)
        {
            if (isActiveAndEnabled && hintButton != null)
                hintButton.onClick.RemoveListener(OnHintClicked);
            // A newly bound label must never inherit an unrelated puzzle's hint.
            bool changedCatalog = catalog != source;
            bool changedLabel = hintLabel != label;
            if (changedCatalog)
            {
                // A different catalog has a different authority boundary.
                // Never carry evidence or a puzzle identifier into it.
                revealedTier = 0;
                puzzleId = string.Empty;
                evidence.Clear();
            }
            if (changedCatalog || changedLabel)
            {
                if (hintLabel != null) hintLabel.text = string.Empty;
                if (label != null) label.text = string.Empty;
                // A changed view cannot safely reconstruct the previously revealed tier.
                revealedTier = 0;
            }
            catalog = source;
            hintButton = button;
            hintLabel = label;
            configured = source != null && button != null && label != null;
            if (isActiveAndEnabled && hintButton != null)
                hintButton.onClick.AddListener(OnHintClicked);
            RefreshButton();
        }

        /// <summary>
        /// Replace the evidence snapshot atomically. Never pass unvalidated user input
        /// as authoritative progression data.
        /// </summary>
        public bool SetContext(string newPuzzleId, IEnumerable<string> collectedEvidence)
        {
            if (string.IsNullOrWhiteSpace(newPuzzleId) || newPuzzleId.Length > 256 ||
                collectedEvidence == null)
                return false;

            var next = new HashSet<string>(StringComparer.Ordinal);
            try
            {
                foreach (var id in collectedEvidence)
                {
                    if (string.IsNullOrWhiteSpace(id) || id.Length > 256)
                        return false;
                    if (!next.Add(id)) return false;
                    if (next.Count > 4096) return false;
                }
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"Evidence snapshot enumeration failed: {exception.GetType().Name}", this);
                return false;
            }

            bool changed = !string.Equals(puzzleId, newPuzzleId, StringComparison.Ordinal);
            puzzleId = newPuzzleId;
            evidence.Clear();
            evidence.UnionWith(next);
            if (changed || (revealedTier > 0 &&
                (catalog == null || !catalog.TryGetHint(puzzleId, revealedTier, evidence, out _))))
            {
                revealedTier = 0;
                if (hintLabel != null) hintLabel.text = string.Empty;
            }
            RefreshButton();
            return true;
        }

        public bool ShowNextHint()
        {
            if (!isActiveAndEnabled || !configured || catalog == null || hintLabel == null ||
                revealedTier >= 3) return false;
            // Revalidate the currently revealed tier before any further disclosure.
            if (revealedTier > 0 && !catalog.TryGetHint(puzzleId, revealedTier, evidence, out _))
            {
                revealedTier = 0;
                hintLabel.text = string.Empty;
                RefreshButton();
                return false;
            }
            if (!catalog.TryGetHint(puzzleId, revealedTier + 1, evidence, out var hint))
            {
                RefreshButton();
                return false;
            }
            if (string.IsNullOrWhiteSpace(hint)) return false;
            hintLabel.text = hint;
            revealedTier++;
            RefreshButton();
            return true;
        }

        private void OnHintClicked()
        {
            ShowNextHint();
        }

        private void RefreshButton()
        {
            if (hintButton == null) return;
            bool canShow = isActiveAndEnabled && configured && catalog != null && revealedTier < 3 &&
                (revealedTier == 0 || catalog.TryGetHint(puzzleId, revealedTier, evidence, out _)) &&
                catalog.TryGetHint(puzzleId, revealedTier + 1, evidence, out _);
            hintButton.interactable = canShow;
        }
    }
}
