using System;
using TheOrderRoom.Domain;
using UnityEngine;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Original-art-first exploration for the ten authored locations. This component
    /// owns only local UI objects, never copies photographs, and never modifies a
    /// puzzle, chapter unlock or persistent save. The 3D investigation remains
    /// available as an explicit inspection mode.
    /// </summary>
    public sealed class CinematicScenePresentation
    {
        private readonly GameObject scenicRoot;
        private readonly RectTransform motionRoot;
        private readonly CinematicViewportState viewport = new CinematicViewportState();
        private bool modalBlocked;
        private bool externalModalBlocked;
        private readonly StoryDossierCase caseFile;
        private readonly ChapterWorldSceneSpec worldSpec;
        private GameObject previewRoot;
        private Text previewHeading;
        private Text previewContent;
        private Action<int> inspectionCallback;
        private int pendingEvidenceIndex = -1;
        private bool pinchActive;
        private readonly Button[] evidenceButtons = new Button[2];
        private readonly Image[] evidenceMarkers = new Image[2];
        private readonly Button mechanismButton;
        private readonly Text mechanismLabel;
        private readonly RawImage photograph;
        private bool scenic;

        public bool IsScenic => scenic && scenicRoot != null && scenicRoot.activeSelf;
        public bool IsEvidencePreviewOpen => previewRoot != null && previewRoot.activeSelf;
        public bool CanNavigate => IsScenic && !modalBlocked;
        public Texture Photograph => photograph != null ? photograph.texture : null;

        public CinematicScenePresentation(Transform layoutRoot, Texture2D source,
            int locationNumber, Action<int> inspectEvidence, Action openMechanism)
        {
            if (layoutRoot == null) throw new ArgumentNullException(nameof(layoutRoot));
            if (source == null || source.width <= 0 || source.height <= 0)
                throw new ArgumentException("Valid original scene artwork is required.", nameof(source));
            if (inspectEvidence == null) throw new ArgumentNullException(nameof(inspectEvidence));
            if (openMechanism == null) throw new ArgumentNullException(nameof(openMechanism));
            if (!CinematicSceneMap.Validate(out string error) ||
                !CinematicHudClearance.Validate(out error))
                throw new InvalidOperationException(error);
            ScenicLocation scene = CinematicSceneMap.Get(locationNumber);
            caseFile = StoryDossierCatalog.Get(locationNumber);
            worldSpec = ChapterWorldSceneCatalog.Get(locationNumber);
            inspectionCallback = inspectEvidence;

            scenicRoot = new GameObject("Photographic Adventure Scene", typeof(RectTransform), typeof(RectMask2D));
            scenicRoot.transform.SetParent(layoutRoot, false);
            Stretch(scenicRoot.GetComponent<RectTransform>());
            var movableObject = new GameObject("Synchronized Panoramic Artwork And Clues", typeof(RectTransform));
            motionRoot = movableObject.GetComponent<RectTransform>();
            motionRoot.SetParent(scenicRoot.transform, false);
            Stretch(motionRoot);

            var imageObject = new GameObject("Original Cinematic Environment",
                typeof(RectTransform), typeof(RawImage));
            imageObject.transform.SetParent(motionRoot, false);
            Stretch(imageObject.GetComponent<RectTransform>());
            photograph = imageObject.GetComponent<RawImage>();
            photograph.texture = source;
            photograph.uvRect = new Rect(0f, 0f, 1f, 1f);
            photograph.color = Color.white;
            photograph.raycastTarget = false;

            AddShadowBand("Upper Natural Contrast", new Vector2(0f, .81f),
                new Vector2(1f, 1f), .27f);
            AddShadowBand("Lower Natural Contrast", new Vector2(0f, 0f),
                new Vector2(1f, .27f), .34f);

            var dragPlane = new GameObject("Panoramic Gesture Surface", typeof(RectTransform),
                typeof(Image), typeof(CinematicSceneDragSurface));
            dragPlane.transform.SetParent(motionRoot, false);
            Stretch(dragPlane.GetComponent<RectTransform>());
            Image input = dragPlane.GetComponent<Image>();
            input.color = new Color(0f, 0f, 0f, 0f);
            input.raycastTarget = true;
            dragPlane.GetComponent<CinematicSceneDragSurface>().Configure(
                scenicRoot.GetComponent<RectTransform>(), () => IsScenic && !modalBlocked && !pinchActive,
                delta => TryPan(delta.x, delta.y), steps => TryZoom(steps * .06f));

            evidenceButtons[0] = CreateHotspot("SCENIC EVIDENCE A", "I", scene.EvidenceA,
                () => OpenEvidencePreview(0), out evidenceMarkers[0]);
            evidenceButtons[1] = CreateHotspot("SCENIC EVIDENCE B", "II", scene.EvidenceB,
                () => OpenEvidencePreview(1), out evidenceMarkers[1]);
            mechanismButton = CreateHotspot("SCENIC MECHANISM", "SEAL", scene.Mechanism,
                () => openMechanism(), out _);
            mechanismLabel = mechanismButton.GetComponentInChildren<Text>();
            // Keep the complete camera toolbar below the lowest authored hotspots.
            // The old upper-right position obstructed location seven's mechanism.
            AddCameraButton("SCENE ZOOM IN", "+",
                new Vector2(CinematicHudClearance.CameraZoomInX, CinematicHudClearance.CameraY),
                () => TryZoom(.12f));
            AddCameraButton("SCENE ZOOM OUT", "-",
                new Vector2(CinematicHudClearance.CameraZoomOutX, CinematicHudClearance.CameraY),
                () => TryZoom(-.12f));
            AddCameraButton("SCENE RESET VIEW", "RESET",
                new Vector2(CinematicHudClearance.CameraResetX, CinematicHudClearance.CameraY),
                ResetView);
            BuildEvidencePreview();
            scenic = true;
            ApplyViewport();
        }

        public void SetScenic(bool value, Camera camera)
        {
            scenic = value;
            if (scenicRoot != null) scenicRoot.SetActive(value);
            if (camera != null) camera.enabled = !value;
        }

        public void Refresh(bool hasA, bool hasB, bool canOpenMechanism,
            bool anyModal)
        {
            if (scenicRoot == null) return;
            externalModalBlocked = anyModal;
            modalBlocked = anyModal || IsEvidencePreviewOpen;
            evidenceButtons[0].interactable = !hasA && !modalBlocked;
            evidenceButtons[1].interactable = !hasB && !modalBlocked;
            evidenceMarkers[0].color = hasA ? CompleteTint : PendingTint;
            evidenceMarkers[1].color = hasB ? CompleteTint : PendingTint;
            mechanismButton.gameObject.SetActive(canOpenMechanism && !modalBlocked);
            mechanismButton.interactable = canOpenMechanism && !modalBlocked;
            if (mechanismLabel != null) mechanismLabel.text = "EXAMINE";
        }

        public void Release()
        {
            if (photograph != null) photograph.texture = null;
            if (previewRoot != null) previewRoot.SetActive(false);
            inspectionCallback = null;
            pendingEvidenceIndex = -1;
            viewport.Reset();
            modalBlocked = true;
            pinchActive = false;
            if (scenicRoot != null) scenicRoot.SetActive(false);
        }


        public void SetPinchActive(bool active)
        {
            pinchActive = active;
        }

        public float Zoom => viewport.Zoom;
        public float PanX => viewport.PanX;
        public float PanY => viewport.PanY;

        public bool TryZoom(float delta)
        {
            if (!IsScenic || modalBlocked || !viewport.TryZoom(delta)) return false;
            ApplyViewport();
            return true;
        }

        public bool TryPan(float deltaX, float deltaY)
        {
            if (!IsScenic || modalBlocked || !viewport.TryPan(deltaX, deltaY)) return false;
            ApplyViewport();
            return true;
        }

        public void ResetView()
        {
            if (!IsScenic || modalBlocked) return;
            viewport.Reset();
            ApplyViewport();
        }

        private void ApplyViewport()
        {
            if (motionRoot == null) return;
            motionRoot.localScale = Vector3.one * viewport.Zoom;
            motionRoot.anchoredPosition = new Vector2(viewport.PanX, viewport.PanY);
        }

        /// <summary>
        /// A deliberate confirmation displays the canonical authored evidence before
        /// the existing investigation state records it. Decorative text or symbols
        /// in a generated backdrop are not treated as puzzle answers.
        /// </summary>
        private void OpenEvidencePreview(int evidenceIndex)
        {
            if (!IsScenic || modalBlocked || evidenceIndex < 0 ||
                evidenceIndex >= evidenceButtons.Length ||
                !evidenceButtons[evidenceIndex].interactable ||
                previewRoot == null || inspectionCallback == null) return;

            pendingEvidenceIndex = evidenceIndex;
            CinematicEnvironmentSpec authored;
            bool featured = CinematicEnvironmentCatalog.TryGetFeatured(worldSpec.LocationNumber, out authored);
            string subject = evidenceIndex == 0 ?
                (featured ? authored.InspectionA : worldSpec.EvidenceALabel) :
                (featured ? authored.InspectionB : worldSpec.EvidenceBLabel);
            previewHeading.text = "EXAMINE  " + subject;
            previewContent.text = caseFile.EvidenceFragments[evidenceIndex];
            previewRoot.SetActive(true);
            modalBlocked = true;
        }

        public bool TryCloseEvidencePreview()
        {
            if (!IsEvidencePreviewOpen) return false;
            pendingEvidenceIndex = -1;
            previewRoot.SetActive(false);
            modalBlocked = externalModalBlocked;
            return true;
        }

        private void RecordPreviewEvidence()
        {
            if (!IsScenic || externalModalBlocked || !IsEvidencePreviewOpen ||
                pendingEvidenceIndex < 0 || inspectionCallback == null) return;
            int index = pendingEvidenceIndex;
            TryCloseEvidencePreview();
            inspectionCallback(index);
        }

        private void BuildEvidencePreview()
        {
            previewRoot = new GameObject("Authored Evidence Inspection", typeof(RectTransform), typeof(Image));
            previewRoot.transform.SetParent(scenicRoot.transform, false);
            Stretch(previewRoot.GetComponent<RectTransform>());
            Image scrim = previewRoot.GetComponent<Image>();
            scrim.color = new Color(.012f, .020f, .026f, .91f);
            scrim.raycastTarget = true;

            GameObject panel = new GameObject("Evidence Notebook Panel", typeof(RectTransform), typeof(Image));
            panel.transform.SetParent(previewRoot.transform, false);
            RectTransform panelRect = panel.GetComponent<RectTransform>();
            panelRect.anchorMin = panelRect.anchorMax = new Vector2(.5f, .5f);
            panelRect.anchoredPosition = Vector2.zero;
            panelRect.sizeDelta = new Vector2(1080f, 510f);
            panel.GetComponent<Image>().color = new Color(.07f, .085f, .085f, .97f);
            Outline border = panel.AddComponent<Outline>();
            border.effectColor = new Color(.59f, .42f, .21f, .9f);
            border.effectDistance = new Vector2(3f, -3f);

            previewHeading = CreatePreviewText("Evidence Subject", panelRect,
                new Vector2(0f, 157f), new Vector2(960f, 94f), 33);
            previewContent = CreatePreviewText("Canonical Evidence Fragment", panelRect,
                new Vector2(0f, 18f), new Vector2(930f, 205f), 29);
            CreatePreviewButton("RECORD IN JOURNAL", panelRect, new Vector2(235f, -177f),
                new Vector2(410f, 74f), RecordPreviewEvidence);
            CreatePreviewButton("KEEP EXPLORING", panelRect, new Vector2(-265f, -177f),
                new Vector2(390f, 74f), () => TryCloseEvidencePreview());
            previewRoot.SetActive(false);
        }

        private static Text CreatePreviewText(string name, Transform parent, Vector2 center,
            Vector2 size, int fontSize)
        {
            var root = new GameObject(name, typeof(RectTransform), typeof(Text));
            root.transform.SetParent(parent, false);
            RectTransform rect = root.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = center;
            rect.sizeDelta = size;
            Text label = root.GetComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.fontSize = fontSize;
            label.resizeTextForBestFit = true;
            label.resizeTextMinSize = 19;
            label.resizeTextMaxSize = fontSize;
            label.alignment = TextAnchor.MiddleCenter;
            label.color = new Color(.95f, .91f, .83f, 1f);
            label.raycastTarget = false;
            return label;
        }

        private static void CreatePreviewButton(string title, Transform parent, Vector2 center,
            Vector2 size, Action callback)
        {
            var root = new GameObject(title, typeof(RectTransform), typeof(Image), typeof(Button));
            root.transform.SetParent(parent, false);
            RectTransform rect = root.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = center;
            rect.sizeDelta = size;
            root.GetComponent<Image>().color = new Color(.18f, .20f, .19f, 1f);
            Button button = root.GetComponent<Button>();
            button.onClick.AddListener(() => callback());
            Text text = CreatePreviewText(title + " Label", root.transform, Vector2.zero,
                size, 23);
            text.text = title;
        }

        private void AddCameraButton(string name, string caption, Vector2 position, Action handler)
        {
            var root = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            root.transform.SetParent(scenicRoot.transform, false);
            var rect = root.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = new Vector2(106f, 60f);
            var backdrop = root.GetComponent<Image>();
            backdrop.color = new Color(.035f, .044f, .050f, .85f);
            var button = root.GetComponent<Button>();
            button.onClick.AddListener(() => handler());
            var labelObject = new GameObject("Camera Button Text", typeof(RectTransform), typeof(Text));
            labelObject.transform.SetParent(root.transform, false);
            Stretch(labelObject.GetComponent<RectTransform>());
            Text label = labelObject.GetComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.text = caption;
            label.fontSize = 20;
            label.alignment = TextAnchor.MiddleCenter;
            label.color = CaptionTint;
            label.raycastTarget = false;
        }

        private static readonly Color PendingTint = new Color(.20f, .16f, .12f, .80f);
        private static readonly Color CompleteTint = new Color(.16f, .26f, .22f, .78f);
        private static readonly Color CaptionTint = new Color(.96f, .88f, .71f, 1f);

        private Button CreateHotspot(string name, string caption, ScenicPoint point,
            UnityEngine.Events.UnityAction action, out Image marker)
        {
            var root = new GameObject(name, typeof(RectTransform), typeof(Image),
                typeof(Button));
            root.transform.SetParent(motionRoot, false);
            RectTransform rect = root.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = new Vector2(point.X * CinematicSceneMap.CanvasWidth,
                point.Y * CinematicSceneMap.CanvasHeight);
            rect.sizeDelta = new Vector2(112f, 76f);
            marker = root.GetComponent<Image>();
            marker.color = PendingTint;
            marker.raycastTarget = true;
            var outline = root.AddComponent<Outline>();
            outline.effectColor = new Color(.66f, .51f, .31f, .85f);
            outline.effectDistance = new Vector2(2f, -2f);
            Button button = root.GetComponent<Button>();
            ColorBlock colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1.14f, 1.10f, 1.06f, 1f);
            colors.pressedColor = new Color(.78f, .75f, .70f, 1f);
            colors.disabledColor = new Color(.60f, .73f, .68f, .84f);
            button.colors = colors;
            button.onClick.AddListener(action);
            var labelObject = new GameObject("Evidence Marker Caption",
                typeof(RectTransform), typeof(Text));
            labelObject.transform.SetParent(root.transform, false);
            RectTransform labelRect = labelObject.GetComponent<RectTransform>();
            Stretch(labelRect);
            Text label = labelObject.GetComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.text = caption;
            label.fontSize = 23;
            label.resizeTextForBestFit = true;
            label.resizeTextMinSize = 15;
            label.resizeTextMaxSize = 23;
            label.alignment = TextAnchor.MiddleCenter;
            label.color = CaptionTint;
            label.raycastTarget = false;
            return button;
        }

        private void AddShadowBand(string name, Vector2 min, Vector2 max, float opacity)
        {
            var shadow = new GameObject(name, typeof(RectTransform), typeof(Image));
            shadow.transform.SetParent(motionRoot, false);
            RectTransform rect = shadow.GetComponent<RectTransform>();
            rect.anchorMin = min;
            rect.anchorMax = max;
            rect.offsetMin = rect.offsetMax = Vector2.zero;
            Image tint = shadow.GetComponent<Image>();
            tint.color = new Color(.025f, .026f, .030f, opacity);
            tint.raycastTarget = false;
        }

        private static void Stretch(RectTransform rect)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = rect.offsetMax = Vector2.zero;
        }
    }
}
