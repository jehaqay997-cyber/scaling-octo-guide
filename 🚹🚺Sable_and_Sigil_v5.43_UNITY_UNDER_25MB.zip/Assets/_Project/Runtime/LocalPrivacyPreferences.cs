using System;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Device-local audio preference. Never uses network, advertising, device identifiers,
    /// analytics, or any background data transfer. No personal information is stored.
    /// </summary>
    public static class LocalPrivacyPreferences
    {
        public const string AudioEnabledKey = "SableAndSigil.Settings.AudioEnabled.v1";

        public static bool AudioEnabled => PlayerPrefs.GetInt(AudioEnabledKey, 1) != 0;

        public static bool TrySetAudioEnabled(bool enabled, out string error)
        {
            error = null;
            try
            {
                PlayerPrefs.SetInt(AudioEnabledKey, enabled ? 1 : 0);
                PlayerPrefs.Save();
                return true;
            }
            catch (Exception exception)
            {
                error = "Audio preference could not be saved: " + exception.GetType().Name;
                return false;
            }
        }
    }
}
