using System;
using System.Collections.Generic;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Deterministic, bounded geometry for equilateral pointed-arch masonry.
    /// The returned Mesh is owned by the caller and must be destroyed when the world closes.
    /// No static cache, hidden GameObject, shared Mesh mutation or persistence side effects.
    /// </summary>
    public static class ChapterWorldGothicGeometry
    {
        public const int MinimumSegmentsPerSide = 4;
        public const int MaximumSegmentsPerSide = 48;

        public static Mesh CreatePointedArch(float halfSpan, float bandThickness,
            float depth, float springHeight, int segmentsPerSide)
        {
            RequireFinitePositive(halfSpan, nameof(halfSpan));
            RequireFinitePositive(bandThickness, nameof(bandThickness));
            RequireFinitePositive(depth, nameof(depth));
            if (float.IsNaN(springHeight) || float.IsInfinity(springHeight))
                throw new ArgumentOutOfRangeException(nameof(springHeight));
            if (halfSpan > 20f)
                throw new ArgumentOutOfRangeException(nameof(halfSpan));
            if (depth > 4f)
                throw new ArgumentOutOfRangeException(nameof(depth));
            if (Mathf.Abs(springHeight) > 20f)
                throw new ArgumentOutOfRangeException(nameof(springHeight));
            if (bandThickness >= halfSpan)
                throw new ArgumentOutOfRangeException(nameof(bandThickness),
                    "The masonry band must be narrower than the arch half-span.");
            if (segmentsPerSide < MinimumSegmentsPerSide ||
                segmentsPerSide > MaximumSegmentsPerSide)
                throw new ArgumentOutOfRangeException(nameof(segmentsPerSide));

            int vertexCount = 2 * (segmentsPerSide + 1) * 4;
            var vertices = new Vector3[vertexCount];
            var triangles = new List<int>(2 * (8 * segmentsPerSide + 4) * 3);
            float outerRadius = halfSpan * 2f;
            float innerRadius = outerRadius - bandThickness;
            float halfDepth = depth * .5f;

            for (int side = 0; side < 2; side++)
            {
                int offset = side * (segmentsPerSide + 1) * 4;
                float centerX = side == 0 ? halfSpan : -halfSpan;
                for (int step = 0; step <= segmentsPerSide; step++)
                {
                    float t = (float)step / segmentsPerSide;
                    float angle = side == 0 ?
                        Mathf.PI * (1f - t / 3f) : Mathf.PI * (1f - t) / 3f;
                    float cosine = Mathf.Cos(angle);
                    float sine = Mathf.Sin(angle);
                    int start = offset + step * 4;
                    vertices[start] = new Vector3(centerX + outerRadius * cosine,
                        springHeight + outerRadius * sine, -halfDepth);
                    vertices[start + 1] = new Vector3(centerX + innerRadius * cosine,
                        springHeight + innerRadius * sine, -halfDepth);
                    vertices[start + 2] = new Vector3(vertices[start].x, vertices[start].y, halfDepth);
                    vertices[start + 3] = new Vector3(vertices[start + 1].x,
                        vertices[start + 1].y, halfDepth);
                }

                for (int step = 0; step < segmentsPerSide; step++)
                {
                    int a = offset + step * 4;
                    int b = a + 4;
                    AppendQuad(triangles, a, b, b + 1, a + 1);
                    AppendQuad(triangles, a + 2, a + 3, b + 3, b + 2);
                    AppendQuad(triangles, a, a + 2, b + 2, b);
                    AppendQuad(triangles, a + 1, b + 1, b + 3, a + 3);
                }

                int end = offset + segmentsPerSide * 4;
                AppendQuad(triangles, offset, offset + 1, offset + 3, offset + 2);
                AppendQuad(triangles, end, end + 2, end + 3, end + 1);
            }

            var mesh = new Mesh { name = "Owned Pointed Arch Geometry" };
            mesh.vertices = vertices;
            mesh.triangles = triangles.ToArray();
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private static void RequireFinitePositive(float value, string argument)
        {
            if (float.IsNaN(value) || float.IsInfinity(value) || value <= 0f)
                throw new ArgumentOutOfRangeException(argument);
        }

        private static void AppendQuad(List<int> indices, int a, int b, int c, int d)
        {
            indices.Add(a);
            indices.Add(b);
            indices.Add(c);
            indices.Add(a);
            indices.Add(c);
            indices.Add(d);
        }
    }
}
