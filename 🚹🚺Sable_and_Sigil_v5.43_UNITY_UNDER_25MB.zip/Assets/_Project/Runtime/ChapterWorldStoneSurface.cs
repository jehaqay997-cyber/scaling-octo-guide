using System;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// CPU-bounded, deterministic chapter stone albedo. No mutable random state,
    /// imported textures, static caches, or player persistence are touched.
    /// </summary>
    public static class ChapterWorldStoneSurface
    {
        public const int TextureSize = 128;
        public const int StoneBlockSize = 32;

        public static Texture2D Create(int chapterNumber)
        {
            Color32[] pixels = BuildPixels(chapterNumber);
            var texture = new Texture2D(TextureSize, TextureSize, TextureFormat.RGBA32, true)
            {
                name = "Owned Chapter Stone Surface",
                wrapMode = TextureWrapMode.Repeat,
                filterMode = FilterMode.Trilinear,
                anisoLevel = 1
            };
            try
            {
                texture.SetPixels32(pixels);
                texture.Apply(true, true);
                return texture;
            }
            catch
            {
                if (Application.isPlaying) UnityEngine.Object.Destroy(texture);
                else UnityEngine.Object.DestroyImmediate(texture);
                throw;
            }
        }

        public static Color32[] BuildPixels(int chapterNumber)
        {
            if (chapterNumber < 1 || chapterNumber > 4)
                throw new ArgumentOutOfRangeException(nameof(chapterNumber));

            var pixels = new Color32[TextureSize * TextureSize];
            for (int y = 0; y < TextureSize; y++)
            {
                for (int x = 0; x < TextureSize; x++)
                {
                    int mortarOffset = ((y / StoneBlockSize) & 1) * (StoneBlockSize / 2);
                    int blockX = (x + mortarOffset) % StoneBlockSize;
                    int blockY = y % StoneBlockSize;
                    bool seam = blockX <= 1 || blockY <= 1;
                    uint hash = Hash(x, y, chapterNumber);
                    int granular = (int)(hash % 32u) - 16;
                    int scratch = ((hash >> 5) & 63u) == 0u ? -19 : 0;
                    int baseTone = 122 + chapterNumber * 4 + granular + scratch;
                    if (seam) baseTone -= 49;
                    pixels[y * TextureSize + x] = new Color32(
                        ToByte(baseTone + (chapterNumber == 4 ? -9 : 6)),
                        ToByte(baseTone + (chapterNumber == 2 ? 8 : -2)),
                        ToByte(baseTone + (chapterNumber == 3 ? 12 : -4)), 255);
                }
            }
            return pixels;
        }

        private static uint Hash(int x, int y, int chapter)
        {
            unchecked
            {
                uint result = (uint)x * 374761393u + (uint)y * 668265263u + (uint)chapter * 2246822519u;
                result ^= result >> 13;
                result *= 1274126177u;
                return result ^ (result >> 16);
            }
        }

        private static byte ToByte(int value)
        {
            return (byte)Mathf.Clamp(value, 0, 255);
        }
    }
}
