using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>Unity-only adapter for the isolated, versioned investigation save.</summary>
    public sealed class PlayerPrefsDossierStorage : IStoryDossierStorage
    {
        public bool Contains(string key) => PlayerPrefs.HasKey(key);
        public string Read(string key) => PlayerPrefs.GetString(key, string.Empty);
        public void Write(string key, string value) => PlayerPrefs.SetString(key, value);
        public void Flush() => PlayerPrefs.Save();
    }
}
