using System;
using System.Collections.Generic;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Bounded planar relief for the first chapter's five/six-ray comparison plaques.
    /// The mesh is decorative only. Caller owns and destroys the returned Mesh.
    /// All triangles face the player (negative Z), without allocating per frame.
    /// </summary>
    public static class ChapterOneCrestReliefMesh
    {
        public const int MinimumSegments = 12;
        public const int MaximumSegments = 96;

        public static Mesh CreateRing(float outerRadius, float innerRadius, int segments)
        {
            if (!IsFinite(outerRadius) || !IsFinite(innerRadius) ||
                outerRadius <= 0f || outerRadius > 8f ||
                innerRadius <= 0f || innerRadius >= outerRadius ||
                segments < MinimumSegments || segments > MaximumSegments)
                throw new ArgumentOutOfRangeException(nameof(outerRadius),
                    "Crest relief radii or segment budget are invalid.");

            int vertexCount = segments * 2;
            var vertices = new Vector3[vertexCount];
            var normals = new Vector3[vertexCount];
            var uv = new Vector2[vertexCount];
            var triangles = new int[segments * 6];
            for (int index = 0; index < segments; index++)
            {
                float radians = index * (Mathf.PI * 2f / segments);
                float cosine = Mathf.Cos(radians);
                float sine = Mathf.Sin(radians);
                int outer = index * 2;
                int inner = outer + 1;
                vertices[outer] = new Vector3(cosine * outerRadius, sine * outerRadius, 0f);
                vertices[inner] = new Vector3(cosine * innerRadius, sine * innerRadius, 0f);
                normals[outer] = normals[inner] = Vector3.back;
                uv[outer] = new Vector2(.5f + cosine * .5f, .5f + sine * .5f);
                float ratio = innerRadius / outerRadius;
                uv[inner] = new Vector2(.5f + cosine * ratio * .5f,
                    .5f + sine * ratio * .5f);
                int nextOuter = (outer + 2) % vertexCount;
                int nextInner = (inner + 2) % vertexCount;
                int offset = index * 6;
                triangles[offset] = outer;
                triangles[offset + 1] = inner;
                triangles[offset + 2] = nextOuter;
                triangles[offset + 3] = inner;
                triangles[offset + 4] = nextInner;
                triangles[offset + 5] = nextOuter;
            }

            var mesh = new Mesh { name = "Owned First Chapter Crest Relief" };
            try
            {
                mesh.vertices = vertices;
                mesh.normals = normals;
                mesh.uv = uv;
                mesh.triangles = triangles;
                mesh.RecalculateBounds();
                return mesh;
            }
            catch
            {
                if (Application.isPlaying) UnityEngine.Object.Destroy(mesh);
                else UnityEngine.Object.DestroyImmediate(mesh);
                throw;
            }
        }

        /// <summary>
        /// One front-facing batch of miniature diamond studs for both crest plaques.
        /// Callers own the returned mesh. No colliders or gameplay authority are created.
        /// </summary>
        public static Mesh CreateStuds(IReadOnlyList<Vector2> centers, float halfExtent)
        {
            if (centers == null || centers.Count < 1 || centers.Count > 16 ||
                !IsFinite(halfExtent) || halfExtent < .005f || halfExtent > .09f)
                throw new ArgumentOutOfRangeException(nameof(centers),
                    "Crest stud count or size exceeds the bounded mesh contract.");
            int count = centers.Count;
            var vertices = new Vector3[count * 4];
            var normals = new Vector3[count * 4];
            var triangles = new int[count * 6];
            for (int index = 0; index < count; index++)
            {
                Vector2 center = centers[index];
                if (!IsFinite(center.x) || !IsFinite(center.y) ||
                    Mathf.Abs(center.x) > 6f || Mathf.Abs(center.y) > 6f)
                    throw new ArgumentOutOfRangeException(nameof(centers),
                        "Crest studs must have finite coordinates inside the stage.");
                int vertex = index * 4;
                vertices[vertex] = new Vector3(center.x, center.y + halfExtent, 0f);
                vertices[vertex + 1] = new Vector3(center.x + halfExtent, center.y, 0f);
                vertices[vertex + 2] = new Vector3(center.x, center.y - halfExtent, 0f);
                vertices[vertex + 3] = new Vector3(center.x - halfExtent, center.y, 0f);
                for (int corner = 0; corner < 4; corner++) normals[vertex + corner] = Vector3.back;
                int triangle = index * 6;
                triangles[triangle] = vertex;
                triangles[triangle + 1] = vertex + 1;
                triangles[triangle + 2] = vertex + 2;
                triangles[triangle + 3] = vertex;
                triangles[triangle + 4] = vertex + 2;
                triangles[triangle + 5] = vertex + 3;
            }
            var mesh = new Mesh { name = "Owned First Chapter Crest Ray Studs" };
            try
            {
                mesh.vertices = vertices;
                mesh.normals = normals;
                mesh.triangles = triangles;
                mesh.RecalculateBounds();
                return mesh;
            }
            catch
            {
                if (Application.isPlaying) UnityEngine.Object.Destroy(mesh);
                else UnityEngine.Object.DestroyImmediate(mesh);
                throw;
            }
        }

        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }
    }
}
