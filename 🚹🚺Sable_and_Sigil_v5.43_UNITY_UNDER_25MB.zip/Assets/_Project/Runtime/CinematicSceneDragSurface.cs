using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Transparent UI event surface placed behind investigation hotspots.
    /// Converts screen deltas to canvas-local coordinates for touch and mouse.
    /// Never changes case progress or persistent game state.
    /// </summary>
    public sealed class CinematicSceneDragSurface : MonoBehaviour,
        IBeginDragHandler, IDragHandler, IEndDragHandler, IScrollHandler
    {
        private RectTransform reference;
        private Action<Vector2> drag;
        private Action<float> scroll;
        private Func<bool> canInteract;
        private bool dragging;
        private int pointerId;

        public void Configure(RectTransform coordinates, Func<bool> allowed,
            Action<Vector2> onDrag, Action<float> onScroll)
        {
            reference = coordinates ?? throw new ArgumentNullException(nameof(coordinates));
            canInteract = allowed ?? throw new ArgumentNullException(nameof(allowed));
            drag = onDrag ?? throw new ArgumentNullException(nameof(onDrag));
            scroll = onScroll ?? throw new ArgumentNullException(nameof(onScroll));
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (dragging) return;
            if (eventData == null || eventData.button != PointerEventData.InputButton.Left ||
                reference == null || canInteract == null || !canInteract()) return;
            dragging = true;
            pointerId = eventData.pointerId;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!dragging || eventData == null || eventData.pointerId != pointerId ||
                reference == null || !canInteract())
            {
                dragging = false;
                return;
            }
            Camera inputCamera = eventData.pressEventCamera;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    reference, eventData.position, inputCamera, out Vector2 current) ||
                !RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    reference, eventData.position - eventData.delta, inputCamera, out Vector2 previous))
                return;
            drag(current - previous);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (eventData != null && eventData.pointerId == pointerId)
                dragging = false;
        }

        public void OnScroll(PointerEventData eventData)
        {
            if (eventData == null || reference == null || canInteract == null ||
                !canInteract()) return;
            float steps = eventData.scrollDelta.y;
            if (!float.IsNaN(steps) && !float.IsInfinity(steps)) scroll(steps);
        }

        private void OnDisable()
        {
            dragging = false;
        }
    }
}
