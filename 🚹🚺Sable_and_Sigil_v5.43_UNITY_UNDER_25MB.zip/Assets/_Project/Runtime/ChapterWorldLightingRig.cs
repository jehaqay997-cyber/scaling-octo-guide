using System;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// An immutable, authored lighting contract for one of the ten investigation locations.
    /// Lighting affects presentation only and never reads or writes puzzle or save state.
    /// </summary>
    public readonly struct ChapterWorldLightingProfile
    {
        public Color KeyColor { get; }
        public Color LeftFillColor { get; }
        public Color RightFillColor { get; }
        public float KeyIntensity { get; }
        public float FillIntensity { get; }

        internal ChapterWorldLightingProfile(Color keyColor, Color leftFillColor,
            Color rightFillColor, float keyIntensity, float fillIntensity)
        {
            KeyColor = keyColor;
            LeftFillColor = leftFillColor;
            RightFillColor = rightFillColor;
            KeyIntensity = keyIntensity;
            FillIntensity = fillIntensity;
        }
    }

    /// <summary>
    /// Owns a bounded, shadow-free, three-light theatrical rig under the world root.
    /// Secondary lights use vertex lighting to limit their real-time mobile cost.
    /// There are no static scene objects, global render settings, or per-frame updates.
    /// </summary>
    public static class ChapterWorldLightingRig
    {
        public const int AuthoredLocationCount = 10;
        public const int MaximumLights = 3;
        public const float KeyRange = 16f;
        public const float FillRange = 8.5f;

        private static readonly ChapterWorldLightingProfile[] Profiles =
        {
            New(.99f, .78f, .57f, .70f, .79f, .95f, .99f, .70f, .49f, 2.7f, .75f),
            New(.86f, .91f, .99f, .73f, .81f, .96f, .97f, .72f, .48f, 2.6f, .70f),
            New(.74f, .83f, .99f, .66f, .75f, .97f, .99f, .76f, .54f, 2.55f, .80f),
            New(.99f, .81f, .72f, .77f, .91f, .79f, .96f, .75f, .65f, 2.5f, .70f),
            New(.75f, .90f, .92f, .68f, .89f, .92f, .98f, .80f, .55f, 2.5f, .75f),
            New(.75f, .85f, .98f, .63f, .77f, .91f, .99f, .74f, .56f, 2.45f, .70f),
            New(.66f, .78f, .99f, .67f, .76f, .97f, .95f, .67f, .88f, 2.65f, .78f),
            New(.99f, .81f, .63f, .74f, .72f, .93f, .98f, .68f, .52f, 2.7f, .68f),
            New(.85f, .87f, .78f, .65f, .76f, .88f, .89f, .73f, .60f, 2.45f, .67f),
            New(.77f, .85f, .99f, .70f, .78f, .97f, .99f, .77f, .54f, 2.7f, .80f),
        };

        public static ChapterWorldLightingProfile Get(int locationNumber)
        {
            if (locationNumber < 1 || locationNumber > AuthoredLocationCount)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            return Profiles[locationNumber - 1];
        }

        public static bool Validate(out string error)
        {
            if (Profiles.Length != AuthoredLocationCount)
            {
                error = "The location lighting profile inventory is incomplete.";
                return false;
            }
            for (int index = 0; index < Profiles.Length; index++)
            {
                ChapterWorldLightingProfile profile = Profiles[index];
                if (!ValidColor(profile.KeyColor) || !ValidColor(profile.LeftFillColor) ||
                    !ValidColor(profile.RightFillColor) ||
                    !Finite(profile.KeyIntensity) || profile.KeyIntensity < 2f ||
                    profile.KeyIntensity > 3f || !Finite(profile.FillIntensity) ||
                    profile.FillIntensity < .5f || profile.FillIntensity > 1f)
                {
                    error = "Invalid bounded lighting profile at location " + (index + 1);
                    return false;
                }
            }
            error = null;
            return true;
        }

        public static Transform Create(Transform worldRoot, int locationNumber,
            int sceneryLayer, int evidenceLayer)
        {
            if (worldRoot == null) throw new ArgumentNullException(nameof(worldRoot));
            if (sceneryLayer < 0 || sceneryLayer > 31 || evidenceLayer < 0 ||
                evidenceLayer > 31 || sceneryLayer == evidenceLayer)
                throw new ArgumentOutOfRangeException(nameof(sceneryLayer),
                    "The scene and evidence layers must be distinct, valid Unity layers.");
            ChapterWorldLightingProfile profile = Get(locationNumber);
            if (!Validate(out string error)) throw new InvalidOperationException(error);

            int mask = (1 << sceneryLayer) | (1 << evidenceLayer);
            var rig = new GameObject("Location Lighting Rig");
            rig.transform.SetParent(worldRoot, false);
            try
            {
                AddLight(rig.transform, "Gallery Key Light", new Vector3(-3.6f, 5.8f, -2.3f),
                    profile.KeyColor, profile.KeyIntensity, KeyRange, mask, LightRenderMode.Auto);
                AddLight(rig.transform, "Left Evidence Fill", new Vector3(-4.45f, 3.30f, 1.0f),
                    profile.LeftFillColor, profile.FillIntensity, FillRange, mask,
                    LightRenderMode.ForceVertex);
                AddLight(rig.transform, "Right Evidence Fill", new Vector3(4.45f, 3.30f, 1.0f),
                    profile.RightFillColor, profile.FillIntensity, FillRange, mask,
                    LightRenderMode.ForceVertex);
                return rig.transform;
            }
            catch
            {
                rig.SetActive(false);
                if (Application.isPlaying) UnityEngine.Object.Destroy(rig);
                else UnityEngine.Object.DestroyImmediate(rig);
                throw;
            }
        }

        private static void AddLight(Transform parent, string label, Vector3 position,
            Color color, float intensity, float range, int mask, LightRenderMode renderMode)
        {
            var lightObject = new GameObject(label);
            lightObject.transform.SetParent(parent, false);
            lightObject.transform.localPosition = position;
            Light light = lightObject.AddComponent<Light>();
            light.type = LightType.Point;
            light.color = color;
            light.intensity = intensity;
            light.range = range;
            light.cullingMask = mask;
            light.renderMode = renderMode;
            light.shadows = LightShadows.None;
        }

        private static ChapterWorldLightingProfile New(float keyR, float keyG, float keyB,
            float leftR, float leftG, float leftB, float rightR, float rightG, float rightB,
            float keyIntensity, float fillIntensity)
        {
            return new ChapterWorldLightingProfile(
                new Color(keyR, keyG, keyB), new Color(leftR, leftG, leftB),
                new Color(rightR, rightG, rightB), keyIntensity, fillIntensity);
        }

        private static bool ValidColor(Color value)
        {
            return Channel(value.r) && Channel(value.g) && Channel(value.b) &&
                Channel(value.a);
        }

        private static bool Channel(float value)
        {
            return Finite(value) && value >= 0f && value <= 1f;
        }

        private static bool Finite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }
    }
}
