using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Deterministic, transient tap-versus-drag classifier for 3D evidence inspection.
    /// It owns no Unity objects and never mutates game or save state.
    /// </summary>
    public sealed class ChapterWorldGestureState
    {
        public const float DragThresholdPixels = 12f;
        private const float DragThresholdSquared = DragThresholdPixels * DragThresholdPixels;

        private Vector2 start;
        private Vector2 previous;
        private bool active;
        private bool dragged;

        public bool IsActive => active;
        public bool IsDragging => active && dragged;

        public void Begin(Vector2 position)
        {
            Cancel();
            if (!IsFinite(position)) return;
            start = previous = position;
            active = true;
        }

        /// <summary>Returns horizontal movement only after the drag threshold has been crossed.</summary>
        public float Move(Vector2 position)
        {
            if (!active) return 0f;
            if (!IsFinite(position))
            {
                Cancel();
                return 0f;
            }

            if (!dragged && (position - start).sqrMagnitude > DragThresholdSquared)
                dragged = true;
            float deltaX = position.x - previous.x;
            previous = position;
            return dragged ? deltaX : 0f;
        }

        /// <summary>True only for a completed tap; an aborted or dragged gesture never inspects evidence.</summary>
        public bool End(Vector2 position)
        {
            if (!active || !IsFinite(position))
            {
                Cancel();
                return false;
            }
            Move(position);
            bool tapped = active && !dragged;
            Cancel();
            return tapped;
        }

        public void Cancel()
        {
            active = false;
            dragged = false;
            start = Vector2.zero;
            previous = Vector2.zero;
        }

        private static bool IsFinite(Vector2 position)
        {
            return !float.IsNaN(position.x) && !float.IsInfinity(position.x) &&
                   !float.IsNaN(position.y) && !float.IsInfinity(position.y);
        }
    }
}
