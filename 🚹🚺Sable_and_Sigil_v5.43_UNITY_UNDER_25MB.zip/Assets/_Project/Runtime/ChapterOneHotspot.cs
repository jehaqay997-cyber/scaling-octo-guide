using UnityEngine;

namespace TheOrderRoom.Runtime
{
    public sealed class ChapterOneHotspot : MonoBehaviour
    {
        [SerializeField] private string hotspotId;
        public string HotspotId => hotspotId;
        public void SetId(string value) { hotspotId = value; }
    }
}
