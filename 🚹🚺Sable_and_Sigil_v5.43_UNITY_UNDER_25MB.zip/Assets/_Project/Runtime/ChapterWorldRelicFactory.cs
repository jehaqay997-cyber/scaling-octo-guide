using System;
using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Builds an isolated, bounded display-only composite relic for an authored case fragment.
    /// One primitive root owns the active collider; all ornaments have physics disabled.
    /// Destroying the owning scene root releases every generated object without extra materials.
    /// </summary>
    public static class ChapterWorldRelicFactory
    {
        public const int MaximumOrnamentsPerRelic = 12;

        public static GameObject Create(Transform parent, ChapterEvidenceVisualSpec visual,
            Vector3 position, int evidenceLayer, int sceneryLayer, Material evidenceMaterial,
            Material trimMaterial, Material accentMaterial)
        {
            if (parent == null) throw new ArgumentNullException(nameof(parent));
            if (visual == null) throw new ArgumentNullException(nameof(visual));
            if (evidenceMaterial == null) throw new ArgumentNullException(nameof(evidenceMaterial));
            if (trimMaterial == null) throw new ArgumentNullException(nameof(trimMaterial));
            if (accentMaterial == null) throw new ArgumentNullException(nameof(accentMaterial));
            if (visual.LocationNumber < 1 || visual.LocationNumber > ChapterWorldSceneCatalog.PrototypeCount ||
                visual.EvidenceIndex < 0 || visual.EvidenceIndex >= ChapterEvidenceVisualCatalog.EvidencePerLocation ||
                visual.MotifCount < 1 || visual.MotifCount > 8 ||
                !Enum.IsDefined(typeof(ChapterEvidenceSilhouette), visual.Silhouette))
                throw new ArgumentOutOfRangeException(nameof(visual));
            if (visual != ChapterEvidenceVisualCatalog.Get(visual.LocationNumber, visual.EvidenceIndex))
                throw new ArgumentException("Evidence visualization must belong to the authored catalog.", nameof(visual));
            if (evidenceLayer < 0 || evidenceLayer > 31 || sceneryLayer < 0 || sceneryLayer > 31 ||
                evidenceLayer == sceneryLayer)
                throw new ArgumentOutOfRangeException(nameof(evidenceLayer));
            if (!Finite(position)) throw new ArgumentOutOfRangeException(nameof(position));

            PrimitiveType bodyType;
            Vector3 bodyScale;
            bool roundMotifs;
            switch (visual.Silhouette)
            {
                case ChapterEvidenceSilhouette.Scroll:
                    bodyType = PrimitiveType.Cube; bodyScale = new Vector3(1.12f, .7f, .22f); roundMotifs = false; break;
                case ChapterEvidenceSilhouette.StarCrest:
                case ChapterEvidenceSilhouette.LunarDial:
                case ChapterEvidenceSilhouette.FloralRelief:
                case ChapterEvidenceSilhouette.DirectionCompass:
                case ChapterEvidenceSilhouette.MeridianRings:
                    bodyType = PrimitiveType.Cylinder; bodyScale = new Vector3(.59f, .12f, .59f); roundMotifs = true; break;
                case ChapterEvidenceSilhouette.PatternTile:
                case ChapterEvidenceSilhouette.Tablet:
                case ChapterEvidenceSilhouette.StainedGlass:
                case ChapterEvidenceSilhouette.Mirror:
                case ChapterEvidenceSilhouette.Memorial:
                case ChapterEvidenceSilhouette.Portrait:
                case ChapterEvidenceSilhouette.Epitaph:
                    bodyType = PrimitiveType.Cube; bodyScale = new Vector3(1.04f, .89f, .23f); roundMotifs = false; break;
                case ChapterEvidenceSilhouette.Baluster:
                    bodyType = PrimitiveType.Capsule; bodyScale = new Vector3(.44f, .57f, .42f); roundMotifs = false; break;
                case ChapterEvidenceSilhouette.Lantern:
                    bodyType = PrimitiveType.Capsule; bodyScale = new Vector3(.61f, .63f, .5f); roundMotifs = false; break;
                case ChapterEvidenceSilhouette.FountainSpout:
                    bodyType = PrimitiveType.Cylinder; bodyScale = new Vector3(.44f, .62f, .44f); roundMotifs = false; break;
                case ChapterEvidenceSilhouette.Boat:
                    bodyType = PrimitiveType.Cube; bodyScale = new Vector3(1.12f, .39f, .55f); roundMotifs = false; break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(visual));
            }

            GameObject root = null;
            try
            {
                root = GameObject.CreatePrimitive(bodyType);
                root.name = "Evidence " + (char)('A' + visual.EvidenceIndex) + " - " + visual.Label;
                root.layer = evidenceLayer;
                root.transform.SetParent(parent, false);
                root.transform.localPosition = position;
                root.transform.localScale = bodyScale;
                root.GetComponent<Renderer>().sharedMaterial = evidenceMaterial;
                if (roundMotifs)
                    root.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);

                int decorationCount = 0;
                for (int motif = 0; motif < visual.MotifCount; motif++)
                {
                    // Place relief marks on the camera-facing surface of the parent body.
                    float x;
                    float y;
                    if (roundMotifs)
                    {
                        float angle = (motif * Mathf.PI * 2f) / visual.MotifCount;
                        x = Mathf.Sin(angle) * .57f;
                        y = Mathf.Cos(angle) * .57f;
                    }
                    else
                    {
                        x = visual.MotifCount == 1 ? 0f :
                            (motif / (float)(visual.MotifCount - 1) - .5f) * 1.3f;
                        y = motif % 2 == 0 ? .15f : -.15f;
                    }
                    Ornament(root.transform, "Authored Motif " + (motif + 1),
                        motif % 2 == 0 ? PrimitiveType.Sphere : PrimitiveType.Cube,
                        roundMotifs ? new Vector3(x, -.82f, y) : new Vector3(x, y, -.68f),
                        new Vector3(.12f, .12f, .12f), motif % 2 == 0 ? trimMaterial : accentMaterial,
                        sceneryLayer, motif % 2 == 0 ? 0f : 45f);
                    decorationCount++;
                }
                if (visual.Silhouette == ChapterEvidenceSilhouette.Scroll)
                {
                    Ornament(root.transform, "Scroll Roller Left", PrimitiveType.Cylinder,
                        new Vector3(-.55f, 0f, 0f), new Vector3(.09f, .65f, .32f),
                        trimMaterial, sceneryLayer, 0f);
                    Ornament(root.transform, "Scroll Roller Right", PrimitiveType.Cylinder,
                        new Vector3(.55f, 0f, 0f), new Vector3(.09f, .65f, .32f),
                        trimMaterial, sceneryLayer, 0f);
                    decorationCount += 2;
                }
                else if (visual.Silhouette == ChapterEvidenceSilhouette.Portrait ||
                    visual.Silhouette == ChapterEvidenceSilhouette.Mirror ||
                    visual.Silhouette == ChapterEvidenceSilhouette.StainedGlass)
                {
                    Ornament(root.transform, "Evidence Frame Top", PrimitiveType.Cube,
                        new Vector3(0f, .58f, -.2f), new Vector3(1.06f, .09f, .18f),
                        trimMaterial, sceneryLayer, 0f);
                    Ornament(root.transform, "Evidence Frame Bottom", PrimitiveType.Cube,
                        new Vector3(0f, -.58f, -.2f), new Vector3(1.06f, .09f, .18f),
                        trimMaterial, sceneryLayer, 0f);
                    decorationCount += 2;
                }
                else if (visual.Silhouette == ChapterEvidenceSilhouette.Lantern)
                {
                    Ornament(root.transform, "Lantern Crown", PrimitiveType.Cylinder,
                        new Vector3(0f, .59f, 0f), new Vector3(.47f, .12f, .47f),
                        trimMaterial, sceneryLayer, 0f);
                    Ornament(root.transform, "Lantern Foot", PrimitiveType.Cylinder,
                        new Vector3(0f, -.59f, 0f), new Vector3(.47f, .12f, .47f),
                        trimMaterial, sceneryLayer, 0f);
                    decorationCount += 2;
                }
                if (decorationCount > MaximumOrnamentsPerRelic)
                    throw new InvalidOperationException("Evidence detail budget exceeded.");
                return root;
            }
            catch
            {
                if (root != null)
                {
                    root.SetActive(false);
                    if (Application.isPlaying) UnityEngine.Object.Destroy(root);
                    else UnityEngine.Object.DestroyImmediate(root);
                }
                throw;
            }
        }

        private static void Ornament(Transform parent, string label, PrimitiveType shape,
            Vector3 localPosition, Vector3 localScale, Material material, int sceneryLayer,
            float zRotation)
        {
            GameObject part = GameObject.CreatePrimitive(shape);
            part.name = label;
            part.layer = sceneryLayer;
            part.transform.SetParent(parent, false);
            part.transform.localPosition = localPosition;
            part.transform.localScale = localScale;
            part.transform.localRotation = Quaternion.Euler(0f, 0f, zRotation);
            part.GetComponent<Renderer>().sharedMaterial = material;
            Collider collider = part.GetComponent<Collider>();
            if (collider != null) collider.enabled = false;
        }

        private static bool Finite(Vector3 value)
        {
            return !float.IsNaN(value.x) && !float.IsInfinity(value.x) &&
                   !float.IsNaN(value.y) && !float.IsInfinity(value.y) &&
                   !float.IsNaN(value.z) && !float.IsInfinity(value.z);
        }
    }
}
