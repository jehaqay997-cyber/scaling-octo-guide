using System;
using System.Collections.Generic;
using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Builds a bounded, non-interactive floor inlay whose two radial motif groups
    /// correspond to the authored evidence fragments in a location. This mesh is
    /// presentation only: it never changes puzzle truth or persistent progress.
    /// </summary>
    public static class ChapterWorldFloorSigilGeometry
    {
        public const int OuterRingSegments = 48;
        public const int InnerRingSegments = 32;
        public const int MaximumVertices = 384;
        public const int MaximumTriangles = 192;

        public static Mesh Create(int locationNumber)
        {
            ChapterWorldSceneCatalog.Get(locationNumber);
            ChapterEvidenceVisualSpec first = ChapterEvidenceVisualCatalog.Get(locationNumber, 0);
            ChapterEvidenceVisualSpec second = ChapterEvidenceVisualCatalog.Get(locationNumber, 1);
            ValidateMotifs(first.MotifCount);
            ValidateMotifs(second.MotifCount);

            int quadrilaterals = OuterRingSegments + InnerRingSegments +
                first.MotifCount + second.MotifCount;
            var positions = new List<Vector3>(quadrilaterals * 4);
            var coordinates = new List<Vector2>(quadrilaterals * 4);
            var indices = new List<int>(quadrilaterals * 6);

            AddRing(positions, coordinates, indices, OuterRingSegments, 1.07f, 1.01f, .024f);
            AddRing(positions, coordinates, indices, InnerRingSegments, .56f, .52f, .026f);
            AddSpokes(positions, coordinates, indices, first.MotifCount, .95f, .67f, .032f);
            AddSpokes(positions, coordinates, indices, second.MotifCount, .48f, .20f, .035f);

            if (positions.Count > MaximumVertices || indices.Count / 3 > MaximumTriangles)
                throw new InvalidOperationException("Investigation floor inlay exceeded the geometry budget.");

            var mesh = new Mesh { name = "Owned Investigation Floor Sigil" };
            try
            {
                mesh.SetVertices(positions);
                mesh.SetUVs(0, coordinates);
                mesh.SetTriangles(indices, 0, true);
                mesh.RecalculateNormals();
                mesh.RecalculateBounds();
                return mesh;
            }
            catch
            {
                if (Application.isPlaying) UnityEngine.Object.Destroy(mesh);
                else UnityEngine.Object.DestroyImmediate(mesh);
                throw;
            }
        }

        private static void ValidateMotifs(int count)
        {
            if (count < 1 || count > 8)
                throw new ArgumentOutOfRangeException(nameof(count));
        }

        private static void AddRing(List<Vector3> vertices, List<Vector2> uvs,
            List<int> indices, int segments, float outer, float inner, float height)
        {
            for (int segment = 0; segment < segments; segment++)
            {
                float angle0 = segment * Mathf.PI * 2f / segments;
                float angle1 = (segment + 1) * Mathf.PI * 2f / segments;
                AddQuad(vertices, uvs, indices,
                    Polar(outer, angle0, height), Polar(inner, angle0, height),
                    Polar(inner, angle1, height), Polar(outer, angle1, height));
            }
        }

        private static void AddSpokes(List<Vector3> vertices, List<Vector2> uvs,
            List<int> indices, int count, float outer, float inner, float height)
        {
            float halfWidth = Mathf.Min(.085f, Mathf.PI / (count * 4f));
            for (int index = 0; index < count; index++)
            {
                float angle = index * 2f * Mathf.PI / count;
                AddQuad(vertices, uvs, indices,
                    Polar(outer, angle - halfWidth, height),
                    Polar(inner, angle - halfWidth, height),
                    Polar(inner, angle + halfWidth, height),
                    Polar(outer, angle + halfWidth, height));
            }
        }

        private static Vector3 Polar(float radius, float radians, float height)
        {
            return new Vector3(radius * Mathf.Cos(radians), height,
                radius * Mathf.Sin(radians));
        }

        private static void AddQuad(List<Vector3> vertices, List<Vector2> uvs,
            List<int> triangles, Vector3 a, Vector3 b, Vector3 c, Vector3 d)
        {
            int start = vertices.Count;
            vertices.Add(a);
            vertices.Add(b);
            vertices.Add(c);
            vertices.Add(d);
            AddUv(uvs, a);
            AddUv(uvs, b);
            AddUv(uvs, c);
            AddUv(uvs, d);
            triangles.Add(start);
            triangles.Add(start + 1);
            triangles.Add(start + 2);
            triangles.Add(start);
            triangles.Add(start + 2);
            triangles.Add(start + 3);
        }

        private static void AddUv(List<Vector2> uvs, Vector3 point)
        {
            uvs.Add(new Vector2(.5f + point.x / 2.2f, .5f + point.z / 2.2f));
        }
    }
}
