using System;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// A bounded manifold torus used for the physical meridian rings.
    /// The caller owns the returned mesh and must release it with the scene.
    /// Its annular opening is genuine geometry, not a thin cylinder or disc.
    /// </summary>
    public static class ChapterWorldRingGeometry
    {
        public const int MinimumMajorSegments = 12;
        public const int MaximumMajorSegments = 96;
        public const int MinimumTubeSegments = 6;
        public const int MaximumTubeSegments = 24;

        public static Mesh Create(float majorRadius, float tubeRadius,
            int majorSegments = 40, int tubeSegments = 10)
        {
            if (!Finite(majorRadius) || majorRadius <= 0f || majorRadius > 3f)
                throw new ArgumentOutOfRangeException(nameof(majorRadius));
            if (!Finite(tubeRadius) || tubeRadius <= 0f || tubeRadius >= majorRadius * .4f)
                throw new ArgumentOutOfRangeException(nameof(tubeRadius));
            if (majorSegments < MinimumMajorSegments || majorSegments > MaximumMajorSegments)
                throw new ArgumentOutOfRangeException(nameof(majorSegments));
            if (tubeSegments < MinimumTubeSegments || tubeSegments > MaximumTubeSegments)
                throw new ArgumentOutOfRangeException(nameof(tubeSegments));

            int stride = tubeSegments + 1;
            var vertices = new Vector3[(majorSegments + 1) * stride];
            var normals = new Vector3[vertices.Length];
            var uv = new Vector2[vertices.Length];
            var triangles = new int[majorSegments * tubeSegments * 6];
            const double fullCircle = Math.PI * 2.0;

            for (int ring = 0; ring <= majorSegments; ring++)
            {
                double azimuth = fullCircle * ring / majorSegments;
                float radialX = (float)Math.Cos(azimuth);
                float radialZ = (float)Math.Sin(azimuth);
                for (int crossSection = 0; crossSection <= tubeSegments; crossSection++)
                {
                    double angle = fullCircle * crossSection / tubeSegments;
                    float radial = (float)Math.Cos(angle);
                    float vertical = (float)Math.Sin(angle);
                    int index = ring * stride + crossSection;
                    float distance = majorRadius + tubeRadius * radial;
                    vertices[index] = new Vector3(distance * radialX,
                        tubeRadius * vertical, distance * radialZ);
                    normals[index] = new Vector3(radial * radialX,
                        vertical, radial * radialZ);
                    uv[index] = new Vector2((float)ring / majorSegments,
                        (float)crossSection / tubeSegments);
                }
            }

            int triangleIndex = 0;
            for (int ring = 0; ring < majorSegments; ring++)
            {
                for (int crossSection = 0; crossSection < tubeSegments; crossSection++)
                {
                    int a = ring * stride + crossSection;
                    int b = (ring + 1) * stride + crossSection;
                    int c = b + 1;
                    int d = a + 1;
                    // Outward winding for a right-handed azimuth / cross-section surface.
                    triangles[triangleIndex++] = a;
                    triangles[triangleIndex++] = c;
                    triangles[triangleIndex++] = b;
                    triangles[triangleIndex++] = a;
                    triangles[triangleIndex++] = d;
                    triangles[triangleIndex++] = c;
                }
            }

            var mesh = new Mesh { name = "Owned Meridian Torus" };
            mesh.vertices = vertices;
            mesh.normals = normals;
            mesh.uv = uv;
            mesh.triangles = triangles;
            mesh.RecalculateBounds();
            return mesh;
        }

        private static bool Finite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }
    }
}
