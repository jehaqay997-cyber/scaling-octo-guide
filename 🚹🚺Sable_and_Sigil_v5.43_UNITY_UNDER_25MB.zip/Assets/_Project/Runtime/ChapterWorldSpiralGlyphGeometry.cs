using System;
using System.Collections.Generic;
using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// One owned, collider-free mesh for the five surviving stair symbols and
    /// the empty sixth setting. The visual pattern is read from the domain catalog.
    /// </summary>
    public static class ChapterWorldSpiralGlyphGeometry
    {
        private const float OuterRadius = .24f;
        private const float InnerStarRadius = .105f;

        public static Mesh Create()
        {
            var mesh = new Mesh { name = "Owned Spiral Baluster Motifs" };
            try
            {
                WriteGeometry(mesh, false);
                return mesh;
            }
            catch
            {
                if (Application.isPlaying) UnityEngine.Object.Destroy(mesh);
                else UnityEngine.Object.DestroyImmediate(mesh);
                throw;
            }
        }

        /// <summary>
        /// Reuses the existing owned mesh to replace the empty slot with a star.
        /// No new GameObject, Mesh, Material, collider or light is allocated.
        /// </summary>
        public static void Repair(Mesh mesh)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));
            if (mesh.name != "Owned Spiral Baluster Motifs")
                throw new ArgumentException("Only the owned stair motif mesh can be repaired.", nameof(mesh));
            WriteGeometry(mesh, true);
        }

        private static void WriteGeometry(Mesh mesh, bool repaired)
        {
            if (!SpiralBalusterPuzzle.ValidatePattern())
                throw new InvalidOperationException("The authored baluster pattern is inconsistent.");
            var vertices = new List<Vector3>(144);
            var triangles = new List<int>(300);
            IReadOnlyList<BalusterSymbol> symbols = SpiralBalusterPuzzle.VisibleSequence;
            for (int index = 0; index < symbols.Count; index++)
            {
                Vector3 center = new Vector3(-2.4f + index * .96f,
                    1.46f + index * .21f, 1.27f - index * .55f);
                switch (symbols[index])
                {
                    case BalusterSymbol.Circle:
                        AddRadial(vertices, triangles, center, 16, false);
                        break;
                    case BalusterSymbol.Diamond:
                        AddRadial(vertices, triangles, center, 4, false);
                        break;
                    case BalusterSymbol.Star:
                        AddRadial(vertices, triangles, center, 10, true);
                        break;
                    case BalusterSymbol.Missing:
                        if (repaired)
                        {
                            AddRadial(vertices, triangles, center, 10, true);
                            break;
                        }
                        AddQuad(vertices, triangles, center + new Vector3(-.25f, .20f, 0f),
                            center + new Vector3(.25f, .20f, 0f), .052f);
                        AddQuad(vertices, triangles, center + new Vector3(-.25f, -.20f, 0f),
                            center + new Vector3(.25f, -.20f, 0f), .052f);
                        AddQuad(vertices, triangles, center + new Vector3(-.20f, -.25f, 0f),
                            center + new Vector3(-.20f, .25f, 0f), .052f);
                        AddQuad(vertices, triangles, center + new Vector3(.20f, -.25f, 0f),
                            center + new Vector3(.20f, .25f, 0f), .052f);
                        break;
                    default:
                        throw new InvalidOperationException("Unknown stair symbol.");
                }
            }
            mesh.Clear();
            mesh.SetVertices(vertices);
            mesh.SetTriangles(triangles, 0, true);
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
        }

        private static void AddRadial(List<Vector3> vertices, List<int> triangles,
            Vector3 center, int corners, bool star)
        {
            int first = vertices.Count;
            vertices.Add(center);
            for (int corner = 0; corner < corners; corner++)
            {
                float angle = (float)(Math.PI * 2.0 * corner / corners);
                float radius = star && (corner & 1) != 0 ? InnerStarRadius : OuterRadius;
                vertices.Add(center + new Vector3(Mathf.Sin(angle) * radius,
                    Mathf.Cos(angle) * radius, 0f));
            }
            for (int corner = 0; corner < corners; corner++)
            {
                triangles.Add(first);
                triangles.Add(first + 1 + corner);
                triangles.Add(first + 1 + ((corner + 1) % corners));
            }
        }

        private static void AddQuad(List<Vector3> vertices, List<int> triangles,
            Vector3 begin, Vector3 end, float width)
        {
            int first = vertices.Count;
            Vector3 delta = (end - begin).normalized;
            Vector3 across = new Vector3(-delta.y, delta.x, 0f) * (width * .5f);
            vertices.Add(begin + across);
            vertices.Add(end + across);
            vertices.Add(end - across);
            vertices.Add(begin - across);
            triangles.Add(first);
            triangles.Add(first + 1);
            triangles.Add(first + 2);
            triangles.Add(first);
            triangles.Add(first + 2);
            triangles.Add(first + 3);
        }
    }
}
