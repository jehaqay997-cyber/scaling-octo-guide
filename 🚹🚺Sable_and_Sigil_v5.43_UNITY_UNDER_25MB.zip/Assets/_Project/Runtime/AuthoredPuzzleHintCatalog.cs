using System;
using System.Collections.Generic;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>Read-only authored hints. No progress, save state, or rewards are mutated.</summary>
    public sealed class AuthoredPuzzleHintCatalog : MonoBehaviour
    {
        [Serializable] private sealed class Catalog { public int schemaVersion; public Entry[] entries; }
        [Serializable] private sealed class Entry
        {
            public string id;
            public int chapter;
            public string evidenceId;
            public string[] prerequisites;
            public string[] hintTiers;
        }

        private const int MaxEntries = 512;
        private const int MaxCatalogBytes = 1048576;
        private const int MaxIdentifierLength = 256;
        private const int MaxPrerequisitesPerEntry = 64;
        private const int MaxHintLength = 2048;

        private readonly Dictionary<string, Entry> entries = new Dictionary<string, Entry>(StringComparer.Ordinal);
        private bool ready;
        public bool IsReady => ready;

        private void Awake()
        {
            try
            {
                var asset = Resources.Load<TextAsset>("PuzzleHints/HintCatalog");
                if (asset == null) throw new InvalidOperationException("Hint catalog resource missing.");
                if (System.Text.Encoding.UTF8.GetByteCount(asset.text) > MaxCatalogBytes)
                    throw new InvalidOperationException("Hint catalog exceeds maximum size.");
                var catalog = JsonUtility.FromJson<Catalog>(asset.text);
                if (catalog == null || catalog.schemaVersion != 1 || catalog.entries == null || catalog.entries.Length == 0 || catalog.entries.Length > MaxEntries)
                    throw new InvalidOperationException("Hint catalog schema is invalid.");
                var evidenceIds = new HashSet<string>(StringComparer.Ordinal);
                foreach (var entry in catalog.entries)
                {
                    if (entry == null || string.IsNullOrWhiteSpace(entry.id) || entry.id.Length > MaxIdentifierLength || entry.chapter < 1 || entry.chapter > 4 ||
                        string.IsNullOrWhiteSpace(entry.evidenceId) || entry.evidenceId.Length > MaxIdentifierLength || entry.prerequisites == null || entry.prerequisites.Length > MaxPrerequisitesPerEntry ||
                        entry.hintTiers == null || entry.hintTiers.Length != 3 ||
                        entries.ContainsKey(entry.id) || !evidenceIds.Add(entry.evidenceId))
                        throw new InvalidOperationException("Hint catalog entry is invalid or duplicated.");
                    entries.Add(entry.id, entry);
                    foreach (var tier in entry.hintTiers)
                        if (string.IsNullOrWhiteSpace(tier) || tier.Length > MaxHintLength) throw new InvalidOperationException("Empty hint tier.");
                    var seenPrerequisites = new HashSet<string>(StringComparer.Ordinal);
                    foreach (var prerequisite in entry.prerequisites)
                        if (string.IsNullOrWhiteSpace(prerequisite) || prerequisite.Length > MaxIdentifierLength ||
                            !seenPrerequisites.Add(prerequisite) ||
                            string.Equals(prerequisite, entry.evidenceId, StringComparison.Ordinal))
                            throw new InvalidOperationException("Invalid prerequisite.");
                }
                foreach (var entry in entries.Values)
                    foreach (var prerequisite in entry.prerequisites)
                        if (!evidenceIds.Contains(prerequisite))
                            throw new InvalidOperationException("Hint prerequisite references unknown evidence.");
                // Validate the full prerequisite graph, not just local references.
                var byEvidence = new Dictionary<string, Entry>(StringComparer.Ordinal);
                foreach (var entry in entries.Values) byEvidence.Add(entry.evidenceId, entry);
                foreach (var entry in entries.Values)
                    foreach (var prerequisite in entry.prerequisites)
                        if (byEvidence[prerequisite].chapter > entry.chapter)
                            throw new InvalidOperationException("Hint prerequisite belongs to a future chapter.");
                var visiting = new HashSet<string>(StringComparer.Ordinal);
                var visited = new HashSet<string>(StringComparer.Ordinal);
                foreach (var evidenceId in byEvidence.Keys)
                    ValidateAcyclic(evidenceId, byEvidence, visiting, visited);
                ready = true;
            }
            catch (Exception error)
            {
                ready = false;
                entries.Clear();
                Debug.LogException(error, this);
            }
        }

        private static void ValidateAcyclic(
            string evidenceId,
            Dictionary<string, Entry> byEvidence,
            HashSet<string> visiting,
            HashSet<string> visited)
        {
            if (visited.Contains(evidenceId)) return;
            if (!visiting.Add(evidenceId))
                throw new InvalidOperationException("Circular hint evidence dependency.");
            foreach (var prerequisite in byEvidence[evidenceId].prerequisites)
                ValidateAcyclic(prerequisite, byEvidence, visiting, visited);
            visiting.Remove(evidenceId);
            visited.Add(evidenceId);
        }

        public bool TryGetHint(string puzzleId, int tier, ISet<string> collectedEvidence, out string hint)
        {
            hint = null;
            if (!ready || string.IsNullOrWhiteSpace(puzzleId) || tier < 1 || tier > 3 ||
                collectedEvidence == null || !entries.TryGetValue(puzzleId, out var entry)) return false;
            foreach (var prerequisite in entry.prerequisites)
                if (!collectedEvidence.Contains(prerequisite)) return false;
            hint = entry.hintTiers[tier - 1];
            return true;
        }
    }
}
