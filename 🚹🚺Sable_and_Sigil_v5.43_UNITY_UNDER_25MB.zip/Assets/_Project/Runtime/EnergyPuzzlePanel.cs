using TheOrderRoom.Domain;
using UnityEngine;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    public sealed class EnergyPuzzlePanel : MonoBehaviour
    {
        private EnergyPuzzle puzzle;
        private Text message;
        private readonly Text[] labels = new Text[9];
        private readonly Image[,] paths = new Image[9, 4];
        private readonly Button[] cells = new Button[9];
        public bool IsOpen => gameObject.activeSelf;
        public void Show(EnergyPuzzle state)
        {
            puzzle = state;
            if (message == null) Build();
            gameObject.SetActive(true); Refresh();
        }
        public void Close() => gameObject.SetActive(false);
        private void Build()
        {
            var root = (RectTransform)transform;
            root.anchorMin = Vector2.zero; root.anchorMax = Vector2.one;
            root.offsetMin = root.offsetMax = Vector2.zero;
            gameObject.AddComponent<Image>().color = new Color(.025f, .04f, .065f, 1);
            message = Label("Instructions", new Vector2(.5f, .9f), new Vector2(620, 100), 22);
            for (int index = 0; index < 9; index++)
            {
                int cell = index;
                cells[index] = Button("Cell " + index, new Vector2(.5f, .5f), new Vector2(116, 88),
                    () => { puzzle.Rotate(cell, puzzle.Revision); Refresh(); });
                ((RectTransform)cells[index].transform).anchoredPosition = new Vector2((index % 3 - 1) * 132, (1 - index / 3) * 104);
                labels[index] = cells[index].GetComponentInChildren<Text>();
                labels[index].rectTransform.anchoredPosition = new Vector2(0, 29);
                labels[index].rectTransform.sizeDelta = new Vector2(108, 22);
                for (int direction = 0; direction < 4; direction++)
                {
                    var segment = new GameObject("Port " + direction, typeof(RectTransform), typeof(Image));
                    segment.transform.SetParent(cells[index].transform, false);
                    var rect = (RectTransform)segment.transform;
                    rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
                    rect.anchoredPosition = new Vector2(direction == 1 ? 18 : direction == 3 ? -18 : 0,
                        -8 + (direction == 0 ? 14 : direction == 2 ? -14 : 0));
                    rect.sizeDelta = direction % 2 == 0 ? new Vector2(10, 28) : new Vector2(36, 10);
                    paths[index, direction] = segment.GetComponent<Image>(); paths[index, direction].raycastTarget = false;
                }
            }
            Button("HINT", new Vector2(.2f, .14f), new Vector2(120, 55), () =>
            {
                int index = puzzle.Hint();
                message.text = index < 0 ? "POWER RESTORED - CLOSE AND CLAIM" : "Rotate cell " + (index + 1) + " to continue the source-to-exit route.";
            });
            Button("UNDO", new Vector2(.4f, .14f), new Vector2(120, 55), () => { puzzle.Undo(); Refresh(); });
            Button("RESET", new Vector2(.6f, .14f), new Vector2(120, 55), () => { puzzle.Reset(); Refresh(); });
            Button("CLOSE", new Vector2(.8f, .14f), new Vector2(120, 55), Close);
        }
        private Text Label(string name, Vector2 anchor, Vector2 size, int fontSize)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(transform, false);
            var rect = (RectTransform)go.transform; rect.anchorMin = rect.anchorMax = anchor; rect.sizeDelta = size;
            var text = go.GetComponent<Text>(); text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.fontSize = fontSize; text.alignment = TextAnchor.MiddleCenter; text.color = Color.white;
            text.raycastTarget = false; text.resizeTextForBestFit = true; text.resizeTextMinSize = 12; text.resizeTextMaxSize = fontSize;
            return text;
        }
        private Button Button(string title, Vector2 anchor, Vector2 size, UnityEngine.Events.UnityAction action)
        {
            var go = new GameObject(title, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(transform, false);
            var rect = (RectTransform)go.transform; rect.anchorMin = rect.anchorMax = anchor; rect.sizeDelta = size;
            go.GetComponent<Image>().color = new Color(.14f, .22f, .3f);
            var button = go.GetComponent<Button>(); button.onClick.AddListener(action);
            var label = Label(title + " Label", new Vector2(.5f,.5f), size - new Vector2(8, 8), 21);
            label.transform.SetParent(go.transform, false); label.text = title;
            return button;
        }
        private void Refresh()
        {
            var powered = puzzle.Powered();
            for (int i = 0; i < 9; i++)
            {
                int ports = puzzle.Ports(i);
                labels[i].text = (i + 1) + "  " + (powered[i] ? "ON" : "OFF");
                for (int direction = 0; direction < 4; direction++)
                {
                    paths[i, direction].gameObject.SetActive((ports & (1 << direction)) != 0);
                    paths[i, direction].color = powered[i] ? new Color(.45f, 1f, .65f) : new Color(.65f, .75f, .85f);
                }
                cells[i].interactable = ports != 0 && !puzzle.IsSolved;
                cells[i].GetComponent<Image>().color = powered[i] ? new Color(.12f,.40f,.34f) : new Color(.14f,.22f,.3f);
            }
            message.text = puzzle.IsSolved ? "POWER RESTORED - CLOSE AND CLAIM" :
                "Route power: WEST of cell 1 to EAST of cell 9.\nTap a cell to rotate its N/E/S/W ports clockwise.";
        }
    }
}
