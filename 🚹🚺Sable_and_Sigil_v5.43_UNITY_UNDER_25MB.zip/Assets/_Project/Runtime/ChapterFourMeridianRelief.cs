using System;
using System.Collections.Generic;
using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    public enum MeridianReliefStage
    {
        Locked = 0,
        Investigating = 1,
        Restored = 2
    }

    /// <summary>
    /// A single caller-owned, collider-free mesh draws four inlaid meridian rings.
    /// World progress is controlled by ChapterFourMeridianPuzzle, never geometry.
    /// No native mesh is allocated by a successful Rebuild operation.
    /// </summary>
    public static class ChapterFourMeridianRelief
    {
        public const int MaximumTriangles = 256;
        private const int Segments = 20;

        public static Mesh Create(MeridianReliefStage stage, IReadOnlyList<char> order)
        {
            var mesh = new Mesh { name = "Owned Chapter Four Meridian Relief" };
            try
            {
                mesh.MarkDynamic();
                Rebuild(mesh, stage, order);
                return mesh;
            }
            catch
            {
                if (Application.isPlaying) UnityEngine.Object.Destroy(mesh);
                else UnityEngine.Object.DestroyImmediate(mesh);
                throw;
            }
        }

        public static void Rebuild(Mesh mesh, MeridianReliefStage stage, IReadOnlyList<char> order)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));
            if (stage != MeridianReliefStage.Locked &&
                stage != MeridianReliefStage.Investigating &&
                stage != MeridianReliefStage.Restored)
                throw new ArgumentOutOfRangeException(nameof(stage));
            if (!ChapterFourMeridianPuzzle.HasUniqueRings(order))
                throw new ArgumentException("The relief requires exactly four distinct rings.", nameof(order));
            if (stage == MeridianReliefStage.Restored &&
                !ChapterFourMeridianPuzzle.SatisfiesClues(order))
                throw new ArgumentException("A restored relief must satisfy the evidence constraints.", nameof(order));

            var vertices = new List<Vector3>(MaximumTriangles * 3);
            var normals = new List<Vector3>(MaximumTriangles * 3);
            var triangles = new List<int>(MaximumTriangles * 3);
            for (int slot = 0; slot < ChapterFourMeridianPuzzle.RingCount; slot++)
            {
                float x = (slot - 1.5f) * .91f;
                AddRing(vertices, normals, triangles, x, 0f, .325f, .24f);
                if (stage == MeridianReliefStage.Locked) continue;
                // Distinct visible studs represent A=1, B=2, C=3 and D=4.
                // They are disclosed only after inspecting both evidence fragments.
                int studs = order[slot] - 'A' + 1;
                for (int stud = 0; stud < studs; stud++)
                {
                    float offset = (stud - (studs - 1) * .5f) * .105f;
                    AddQuad(vertices, normals, triangles,
                        x + offset - .027f, -.045f, x + offset + .027f, .045f);
                }
            }
            if (stage == MeridianReliefStage.Restored)
                AddQuad(vertices, normals, triangles, -1.7f, -.39f, 1.7f, -.36f);
            if (triangles.Count == 0 || triangles.Count / 3 > MaximumTriangles)
                throw new InvalidOperationException("Meridian relief triangle budget exceeded.");
            mesh.Clear();
            mesh.SetVertices(vertices);
            mesh.SetNormals(normals);
            mesh.SetTriangles(triangles, 0);
            mesh.RecalculateBounds();
        }

        private static void AddRing(List<Vector3> vertices, List<Vector3> normals,
            List<int> indices, float x, float y, float outer, float inner)
        {
            for (int segment = 0; segment < Segments; segment++)
            {
                float from = segment * (2f * Mathf.PI / Segments);
                float to = (segment + 1) * (2f * Mathf.PI / Segments);
                var a = new Vector2(x + outer * Mathf.Cos(from), y + outer * Mathf.Sin(from));
                var b = new Vector2(x + outer * Mathf.Cos(to), y + outer * Mathf.Sin(to));
                var c = new Vector2(x + inner * Mathf.Cos(to), y + inner * Mathf.Sin(to));
                var d = new Vector2(x + inner * Mathf.Cos(from), y + inner * Mathf.Sin(from));
                AddTriangle(vertices, normals, indices, a, c, b);
                AddTriangle(vertices, normals, indices, a, d, c);
            }
        }

        private static void AddQuad(List<Vector3> vertices, List<Vector3> normals,
            List<int> indices, float xMin, float yMin, float xMax, float yMax)
        {
            AddTriangle(vertices, normals, indices, new Vector2(xMin, yMin),
                new Vector2(xMin, yMax), new Vector2(xMax, yMax));
            AddTriangle(vertices, normals, indices, new Vector2(xMin, yMin),
                new Vector2(xMax, yMax), new Vector2(xMax, yMin));
        }

        private static void AddTriangle(List<Vector3> vertices, List<Vector3> normals,
            List<int> indices, Vector2 a, Vector2 b, Vector2 c)
        {
            Vector2 ab = b - a;
            Vector2 ac = c - a;
            float winding = ab.x * ac.y - ab.y * ac.x;
            if (Mathf.Abs(winding) < .0000001f || winding >= 0f)
                throw new InvalidOperationException("Invalid meridian relief winding.");
            int start = vertices.Count;
            vertices.Add(new Vector3(a.x, a.y, 0f));
            vertices.Add(new Vector3(b.x, b.y, 0f));
            vertices.Add(new Vector3(c.x, c.y, 0f));
            normals.Add(Vector3.back);
            normals.Add(Vector3.back);
            normals.Add(Vector3.back);
            indices.Add(start);
            indices.Add(start + 1);
            indices.Add(start + 2);
        }
    }
}
