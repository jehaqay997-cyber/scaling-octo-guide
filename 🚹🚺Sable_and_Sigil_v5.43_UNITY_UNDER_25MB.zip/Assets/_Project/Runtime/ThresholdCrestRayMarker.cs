using System;
using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>Transient ray identifier owned by the first chapter world.</summary>
    public sealed class ThresholdCrestRayMarker : MonoBehaviour
    {
        public int RayIndex { get; private set; } = -1;

        public void Configure(int index)
        {
            if (index < 0 || index >= ThresholdCrestPuzzle.SealRayAngles.Count)
                throw new ArgumentOutOfRangeException(nameof(index));
            RayIndex = index;
        }
    }
}
