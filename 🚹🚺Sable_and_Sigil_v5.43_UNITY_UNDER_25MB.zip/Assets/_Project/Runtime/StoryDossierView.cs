using System;
using TheOrderRoom.Domain;
using UnityEngine;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// An interactive deduction overlay using existing location images.
    /// It does not create a 3D scene or award unrelated chapter achievements.
    /// </summary>
    public sealed class StoryDossierView : MonoBehaviour
    {
        private static readonly Color Background = new Color(.015f, .022f, .036f, 1f);
        private static readonly Color Parchment = new Color(.92f, .85f, .72f);
        private static readonly Color Brass = new Color(.83f, .69f, .46f);
        private GameObject overlay;
        private RawImage caseArtwork;
        private Text heading;
        private Text evidence;
        private Text question;
        private Text status;
        private Button clueButton;
        private readonly Button[] inspectionButtons = new Button[2];
        private StoryCaseInspection inspection;
        private readonly Button[] answers = new Button[4];
        private StoryDossierSession session;
        private StoryDossierCase current;
        private Action stateChanged;
        private OrderAudioFeedback audioFeedback;

        public void ConfigureAudio(OrderAudioFeedback feedback)
        {
            audioFeedback = feedback;
        }
        private int hintIndex = -1;
        private long displayedRevision;

        public bool IsOpen => overlay != null && overlay.activeSelf;

        public void Initialize(Transform layoutRoot, StoryDossierSession storySession, Action onStateChanged)
        {
            if (layoutRoot == null) throw new ArgumentNullException(nameof(layoutRoot));
            if (storySession == null) throw new ArgumentNullException(nameof(storySession));
            if (overlay != null) throw new InvalidOperationException("Dossier overlay is already initialized.");
            session = storySession;
            stateChanged = onStateChanged;
            Build(layoutRoot);
        }

        public void Open(int number, Texture2D referenceArt)
        {
            if (session == null) throw new InvalidOperationException("Dossier overlay was not initialized.");
            ChapterStoryGraph.GetLocation(number);
            if (!session.IsCompleted(number))
                throw new InvalidOperationException("Resolve the physical world mechanism before opening an uncompleted case.");
            OpenCore(number, referenceArt);
        }

        private void OpenCore(int number, Texture2D referenceArt)
        {
            if (overlay == null) throw new InvalidOperationException("Dossier overlay was not initialized.");
            if (overlay.activeSelf) throw new InvalidOperationException("Close the active dossier first.");
            if (!session.CanInvestigate(number)) throw new InvalidOperationException("Case is not unlocked.");
            if (referenceArt == null) throw new ArgumentNullException(nameof(referenceArt));
            StoryDossierCase nextCase = StoryDossierCatalog.Get(number);
            try
            {
                current = nextCase;
                inspection = new StoryCaseInspection(number);
                hintIndex = -1;
                displayedRevision = session.Revision;
                caseArtwork.texture = referenceArt;
                overlay.SetActive(true);
                overlay.transform.SetAsLastSibling();
                Refresh(string.Empty);
            }
            catch
            {
                Hide();
                throw;
            }
        }

        /// <summary>
        /// Transfers ephemeral, player-inspected world evidence into the existing
        /// dossier UI. Durable completion is still committed only by StoryDossierSession.
        /// </summary>
        public void OpenFromWorldEvidence(int number, Texture2D referenceArt,
            WorldInvestigationGrant verifiedHandoff)
        {
            // Validate all non-consuming preconditions before using the one-shot
            // capability. A missing image or active modal must not burn a valid grant.
            if (session == null || verifiedHandoff == null || overlay == null ||
                overlay.activeSelf || referenceArt == null ||
                ChapterStoryGraph.GetLocation(number).Chapter > 4 ||
                !session.CanInvestigate(number) ||
                caseArtwork == null ||
                !verifiedHandoff.TryReserve(number))
                throw new InvalidOperationException("A live, verified 3D investigation handoff is required.");
            try
            {
                OpenCore(number, referenceArt);
                if (!inspection.TryInspect(0, out _) || !inspection.TryInspect(1, out _))
                    throw new InvalidOperationException("World evidence could not be transferred.");
                Refresh(string.Empty);
                verifiedHandoff.CommitReservation(number);
            }
            catch
            {
                Hide();
                verifiedHandoff.ReleaseReservation(number);
                throw;
            }
            // Cosmetic audio must not invalidate a committed dossier handoff.
            if (audioFeedback != null)
            {
                try { audioFeedback.PlayDiscovery(); }
                catch (Exception exception)
                {
                    Debug.LogWarning("Dossier discovery sound could not play: " + exception.Message, this);
                }
            }
        }

        public void Close()
        {
            Hide();
            if (stateChanged != null) stateChanged();
        }

        public void Hide()
        {
            if (overlay == null) return;
            if (caseArtwork != null) caseArtwork.texture = null;
            overlay.SetActive(false);
            current = null;
            inspection = null;
        }

        private void Build(Transform parent)
        {
            overlay = new GameObject("Story Dossier Overlay", typeof(RectTransform), typeof(Image));
            var root = overlay.GetComponent<RectTransform>();
            root.SetParent(parent, false);
            root.anchorMin = root.anchorMax = new Vector2(.5f, .5f);
            root.anchoredPosition = Vector2.zero;
            root.sizeDelta = new Vector2(1600f, 900f);
            var backdrop = overlay.GetComponent<Image>();
            backdrop.color = Background;
            backdrop.raycastTarget = true;

            heading = MakeText("Dossier Heading", root, string.Empty,
                new Vector2(0f, 380f), new Vector2(1050f, 62f), 30);
            var art = new GameObject("Dossier Reference Artwork", typeof(RectTransform), typeof(RawImage));
            art.transform.SetParent(root, false);
            var artRect = art.GetComponent<RectTransform>();
            artRect.anchorMin = artRect.anchorMax = new Vector2(.5f, .5f);
            artRect.anchoredPosition = new Vector2(-408f, 130f);
            artRect.sizeDelta = new Vector2(708f, 398f);
            caseArtwork = art.GetComponent<RawImage>();
            caseArtwork.color = Color.white;
            caseArtwork.raycastTarget = false;

            evidence = MakeText("Dossier Evidence", root, string.Empty,
                new Vector2(394f, 158f), new Vector2(710f, 335f), 21);
            evidence.alignment = TextAnchor.MiddleLeft;
            evidence.resizeTextForBestFit = true;
            evidence.resizeTextMinSize = 15;
            evidence.resizeTextMaxSize = 21;
            question = MakeText("Dossier Question", root, string.Empty,
                new Vector2(390f, -49f), new Vector2(705f, 96f), 22);
            question.alignment = TextAnchor.MiddleLeft;
            question.resizeTextForBestFit = true;
            question.resizeTextMinSize = 16;
            question.resizeTextMaxSize = 22;
            status = MakeText("Dossier Status", root, string.Empty,
                new Vector2(390f, -140f), new Vector2(710f, 75f), 20);

            clueButton = MakeButton("DOSSIER HINT", root, new Vector2(-646f, 373f),
                new Vector2(225f, 58f), ShowNextHint);
            MakeButton("RETURN TO ATLAS", root, new Vector2(643f, 373f),
                new Vector2(260f, 58f), Close);
            for (int index = 0; index < inspectionButtons.Length; index++)
            {
                int evidenceIndex = index;
                inspectionButtons[index] = MakeButton("INSPECT EVIDENCE " + (char)('A' + index), root,
                    new Vector2(index == 0 ? -588f : -232f, -140f),
                    new Vector2(310f, 58f), () => InspectEvidence(evidenceIndex));
            }
            for (int index = 0; index < answers.Length; index++)
            {
                int answerIndex = index;
                float x = index % 2 == 0 ? -385f : 385f;
                float y = index < 2 ? -236f : -326f;
                answers[index] = MakeButton("Dossier Answer " + (index + 1), root,
                    new Vector2(x, y), new Vector2(710f, 72f), () => Submit(answerIndex));
                Text answerLabel = answers[index].GetComponentInChildren<Text>();
                if (answerLabel != null)
                {
                    answerLabel.resizeTextForBestFit = true;
                    answerLabel.resizeTextMinSize = 14;
                    answerLabel.resizeTextMaxSize = 18;
                }
            }
            overlay.SetActive(false);
        }

        private void Refresh(string message)
        {
            if (current == null) return;
            StoryLocation location = ChapterStoryGraph.GetLocation(current.Number);
            bool solved = session.IsCompleted(current.Number);
            heading.text = "CASE " + current.Number.ToString("00") + "  |  " + location.Title.ToUpperInvariant();
            string clue = hintIndex < 0 ? string.Empty : "\n\nCASE HINT " + (hintIndex + 1) +
                ": " + location.HintTiers[hintIndex];
            string transcript = inspection == null || inspection.SelectedEvidenceIndex < 0 ?
                current.Evidence : current.EvidenceFragments[inspection.SelectedEvidenceIndex];
            string chapterCoda = string.Empty;
            if (solved && session.TryGetChapterProgress(location.Chapter,
                out ChapterInvestigationProgress chapterProgress) && chapterProgress.IsComplete)
                chapterCoda = "\n\nCHAPTER CODA\n" + CampaignNarrative.ChapterCoda(location.Chapter);
            evidence.text = solved ? "CASE FINDING\n" + current.Explanation +
                "\n\nAFTERMATH\n" + CampaignNarrative.CaseConsequence(current.Number) + chapterCoda :
                "EVIDENCE FILE  " + (inspection == null ? "0" : inspection.InspectedCount.ToString()) +
                "/2\n" + transcript + clue;
            string nextLead = null;
            if (solved && session.IsReady)
            {
                for (int next = 1; next <= ChapterStoryGraph.LocationCount; next++)
                {
                    if (session.IsCompleted(next) || !session.CanInvestigate(next)) continue;
                    nextLead = "NEXT LEAD\n" + ChapterStoryGraph.GetLocation(next).Title;
                    break;
                }
            }
            question.text = !solved ? "DEDUCTION\n" + current.Question :
                nextLead ?? "INVESTIGATION COMPLETE\nReturn to Chapter IV to read the final record.";
            clueButton.interactable = !solved && hintIndex < 2;
            Text hintCaption = clueButton.GetComponentInChildren<Text>();
            if (hintCaption != null)
                hintCaption.text = hintIndex >= 2 ? "ALL HINTS SHOWN" : "REVEAL HINT " + (hintIndex + 2);
            for (int index = 0; index < inspectionButtons.Length; index++)
            {
                Text evidenceCaption = inspectionButtons[index].GetComponentInChildren<Text>();
                if (evidenceCaption != null)
                    evidenceCaption.text = (inspection != null && inspection.HasInspected(index) ? "REVIEW EVIDENCE " :
                        "INSPECT EVIDENCE ") + (char)('A' + index);
            }
            for (int index = 0; index < answers.Length; index++)
            {
                answers[index].interactable = !solved && session.IsReady &&
                    inspection != null && inspection.CanDeduce && displayedRevision == session.Revision;
                Text caption = answers[index].GetComponentInChildren<Text>();
                if (caption != null) caption.text = (index + 1) + ". " + current.Choices[index];
            }
            status.text = solved ? "EVIDENCE RECORDED  |  CASE CLOSED" :
                !string.IsNullOrEmpty(message) ? message :
                inspection == null || !inspection.CanDeduce ?
                    "Inspect both evidence files before forming a deduction." :
                    "Evidence reviewed. Choose the supported conclusion.";
        }

        private void InspectEvidence(int index)
        {
            if (current == null || inspection == null) return;
            if (inspection.TryInspect(index, out _))
            {
                Refresh(string.Empty);
                if (audioFeedback != null) audioFeedback.PlayDiscovery();
            }
        }

        private void ShowNextHint()
        {
            if (current == null) return;
            if (hintIndex < 2)
            {
                hintIndex++;
                if (audioFeedback != null) audioFeedback.PlayHint();
            }
            Refresh(string.Empty);
        }

        private void Submit(int index)
        {
            if (current == null || session == null) return;
            if (inspection == null || !inspection.CanDeduce)
            {
                Refresh("Inspect both evidence files before submitting a deduction.");
                return;
            }
            bool committed = session.TrySubmit(current.Number, index, displayedRevision, out string message);
            if (committed)
            {
                displayedRevision = session.Revision;
                if (audioFeedback != null) audioFeedback.PlaySuccess();
                if (stateChanged != null)
                {
                    try { stateChanged(); }
                    catch (Exception exception)
                    {
                        Debug.LogWarning("Committed dossier refresh failed: " + exception.GetType().Name, this);
                    }
                }
            }
            else if (audioFeedback != null)
            {
                audioFeedback.PlayWarning();
            }
            Refresh(message);
        }

        private static Text MakeText(string name, Transform parent, string value, Vector2 position,
            Vector2 size, int fontSize)
        {
            var objectWithText = new GameObject(name, typeof(RectTransform), typeof(Text));
            objectWithText.transform.SetParent(parent, false);
            var rect = objectWithText.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            var label = objectWithText.GetComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.text = value;
            label.fontSize = fontSize;
            label.color = Parchment;
            label.alignment = TextAnchor.MiddleCenter;
            label.horizontalOverflow = HorizontalWrapMode.Wrap;
            label.verticalOverflow = VerticalWrapMode.Truncate;
            label.raycastTarget = false;
            return label;
        }

        private static Button MakeButton(string name, Transform parent, Vector2 position,
            Vector2 size, UnityEngine.Events.UnityAction callback)
        {
            var objectWithButton = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            objectWithButton.transform.SetParent(parent, false);
            var rect = objectWithButton.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            objectWithButton.GetComponent<Image>().color = Brass;
            var button = objectWithButton.GetComponent<Button>();
            button.transition = Selectable.Transition.ColorTint;
            ColorBlock interaction = button.colors;
            interaction.normalColor = Color.white;
            interaction.highlightedColor = new Color(1f, .96f, .87f, 1f);
            interaction.selectedColor = interaction.highlightedColor;
            interaction.pressedColor = new Color(.78f, .78f, .76f, 1f);
            interaction.disabledColor = new Color(.78f, .78f, .78f, 1f);
            interaction.colorMultiplier = 1f;
            button.colors = interaction;
            button.onClick.AddListener(callback);
            Text caption = MakeText("Caption", objectWithButton.transform, name,
                Vector2.zero, new Vector2(size.x - 16f, size.y - 8f), 18);
            caption.color = Background;
            return button;
        }

        private void OnDisable()
        {
            Hide();
        }

        private void OnDestroy()
        {
            if (overlay != null) Destroy(overlay);
            overlay = null;
            current = null;
            inspection = null;
            stateChanged = null;
            audioFeedback = null;
        }
    }
}
