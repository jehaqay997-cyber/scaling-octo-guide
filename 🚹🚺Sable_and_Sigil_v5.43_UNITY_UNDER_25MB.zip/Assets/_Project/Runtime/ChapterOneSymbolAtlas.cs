using System;
using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Small, single-allocation RGBA icon atlas for Chapter One's stair puzzle.
    /// The immutable texture is owned and destroyed by ChapterWorldExplorer.
    /// The original authored location photographs are never modified.
    /// </summary>
    public static class ChapterOneSymbolAtlas
    {
        public const int IconSize = 96;
        public const int IconCount = 4;
        private static readonly Vector2[] StarVertices = MakeStarVertices();

        public static Rect GetUv(BalusterSymbol symbol)
        {
            if (symbol < BalusterSymbol.Circle || symbol > BalusterSymbol.Crescent)
                throw new ArgumentOutOfRangeException(nameof(symbol));
            return new Rect((int)symbol / (float)IconCount, 0f, 1f / IconCount, 1f);
        }

        public static Texture2D Create()
        {
            const int width = IconSize * IconCount;
            var pixels = new Color32[width * IconSize];
            for (int icon = 0; icon < IconCount; icon++)
            {
                for (int y = 0; y < IconSize; y++)
                {
                    for (int x = 0; x < IconSize; x++)
                    {
                        int coverage = 0;
                        for (int sampleY = 0; sampleY < 2; sampleY++)
                        {
                            for (int sampleX = 0; sampleX < 2; sampleX++)
                            {
                                float px = ((x + .25f + .5f * sampleX) / IconSize) * 2f - 1f;
                                float py = ((y + .25f + .5f * sampleY) / IconSize) * 2f - 1f;
                                if (Contains((BalusterSymbol)icon, px, py)) coverage++;
                            }
                        }
                        pixels[y * width + icon * IconSize + x] =
                            new Color32(255, 255, 255, (byte)(coverage * 255 / 4));
                    }
                }
            }
            Texture2D texture = null;
            try
            {
                texture = new Texture2D(width, IconSize, TextureFormat.RGBA32, false)
                {
                    name = "Owned Chapter One Stair Symbol Atlas",
                    filterMode = FilterMode.Bilinear,
                    wrapMode = TextureWrapMode.Clamp
                };
                texture.SetPixels32(pixels);
                texture.Apply(false, true);
                return texture;
            }
            catch
            {
                if (texture != null)
                {
                    if (Application.isPlaying) UnityEngine.Object.Destroy(texture);
                    else UnityEngine.Object.DestroyImmediate(texture);
                }
                throw;
            }
        }

        public static bool Contains(BalusterSymbol symbol, float x, float y)
        {
            if (symbol < BalusterSymbol.Circle || symbol > BalusterSymbol.Crescent ||
                float.IsNaN(x) || float.IsNaN(y) || float.IsInfinity(x) || float.IsInfinity(y))
                return false;
            float radiusSquared = x * x + y * y;
            switch (symbol)
            {
                case BalusterSymbol.Circle:
                    return radiusSquared <= .72f * .72f && radiusSquared >= .54f * .54f;
                case BalusterSymbol.Diamond:
                    float diamond = Mathf.Abs(x) + Mathf.Abs(y);
                    return diamond >= .66f && diamond <= .88f;
                case BalusterSymbol.Star:
                    return InFivePointStar(x, y);
                case BalusterSymbol.Crescent:
                    float cutX = x - .28f;
                    float cutY = y - .11f;
                    return radiusSquared <= .76f * .76f &&
                        cutX * cutX + cutY * cutY >= .59f * .59f;
                default:
                    return false;
            }
        }

        private static Vector2[] MakeStarVertices()
        {
            var vertices = new Vector2[10];
            for (int i = 0; i < vertices.Length; i++)
            {
                float angle = (-90f + i * 36f) * Mathf.Deg2Rad;
                float radius = (i % 2 == 0) ? .81f : .34f;
                vertices[i] = new Vector2(Mathf.Cos(angle) * radius,
                    Mathf.Sin(angle) * radius);
            }
            return vertices;
        }

        private static bool InFivePointStar(float x, float y)
        {
            // A filled concave decagon with precomputed alternating vertices.
            bool inside = false;
            Vector2 previous = StarVertices[StarVertices.Length - 1];
            for (int i = 0; i < StarVertices.Length; i++)
            {
                Vector2 next = StarVertices[i];
                if ((next.y > y) != (previous.y > y))
                {
                    float crossing = next.x + (previous.x - next.x) * (y - next.y) /
                        (previous.y - next.y);
                    if (x < crossing) inside = !inside;
                }
                previous = next;
            }
            return inside;
        }
    }
}
