using System;
using System.Threading;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// A one-shot runtime capability proving that a live 3D investigation
    /// reached its verified deduction boundary. Never saved or serialized.
    /// </summary>
    public sealed class WorldInvestigationGrant
    {
        private readonly int location;
        // 0 = available, 1 = reserved for UI initialization, 2 = committed.
        private int state;

        internal WorldInvestigationGrant(int locationNumber)
        {
            if (locationNumber < 1 || locationNumber > ChapterGalleryView.LocationCount)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            location = locationNumber;
        }

        internal int LocationNumber => location;

        internal bool TryReserve(int locationNumber)
        {
            return locationNumber == location &&
                Interlocked.CompareExchange(ref state, 1, 0) == 0;
        }

        internal void CommitReservation(int locationNumber)
        {
            if (locationNumber != location || Interlocked.CompareExchange(ref state, 2, 1) != 1)
                throw new InvalidOperationException("Investigation grant reservation is no longer valid.");
        }

        internal void ReleaseReservation(int locationNumber)
        {
            if (locationNumber == location)
                Interlocked.CompareExchange(ref state, 0, 1);
        }

        // Retain the one-shot contract for existing callers and legacy tests.
        internal bool TryConsume(int locationNumber)
        {
            return locationNumber == location &&
                Interlocked.CompareExchange(ref state, 2, 0) == 0;
        }
    }
}
