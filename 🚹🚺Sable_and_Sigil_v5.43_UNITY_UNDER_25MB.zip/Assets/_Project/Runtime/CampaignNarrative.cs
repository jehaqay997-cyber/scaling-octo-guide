using System;
namespace TheOrderRoom.Runtime
{
    /// <summary>Authored narrative identifiers and player-facing English fallback copy.</summary>
    public static class CampaignNarrative
    {
        private static readonly string[] ChapterTitles =
        {
            "THE HOUSE OF THE LAST STAR", "THE VEILED CONSERVATORY",
            "THE ASHEN GALLERY", "THE HOLLOW MERIDIAN"
        };
        private static readonly string[] ChapterHooks =
        {
            "Lady Vey's final letter and the altered star crest conceal the observatory's threshold.",
            "The lantern, rose basin, fountain and silent crossing trace a path through the glass gardens.",
            "The glass testament, impossible portrait and erased epitaph challenge the estate's history.",
            "The last meridian records the missing star and the testimony the archive was built to hide."
        };
        public static readonly string[] StageTitles = { "DISCOVER", "RECONSTRUCT", "UNSEAL" };
        private static readonly string[] CaseAftermath =
        {
            "A second carving beneath the altered crest leads toward the spiral stair.",
            "The restored stair motif exposes a passage overlooking the lantern path.",
            "The lantern's true phase points beyond the path toward the rose pavilion.",
            "The petals reveal a count that the fountain keeper recorded in secret.",
            "The fountain's sequence marks a route toward the silent crossing.",
            "The witnesses' directions identify a shore concealed behind the glass halls.",
            "The reordered glass symbols cast doubt on the gallery's official history.",
            "The impossible portrait calls every name in the memorial into question.",
            "The restored epitaph preserves the word that the meridian archive erased.",
            "The aligned rings expose the final record; the fate of the memory remains yours."
        };

        private static readonly string[] ChapterCodas =
        {
            "The threshold is no longer sealed. Lady Vey's altered crest names the gardens as the next witness.",
            "The garden's four mechanisms agree: the silent crossing leads into a gallery built to rewrite testimony.",
            "The gallery's false chronology collapses. The erased witness directs the search to the meridian archive.",
            "The archive is open. Its final testimony is preserved rather than erased, and the investigation can be reviewed."
        };

        private static readonly string[] FinaleHeadings =
        {
            "I. THE ALTERED THRESHOLD",
            "II. THE GARDEN AS WITNESS",
            "III. THE FALSE TESTIMONY",
            "IV. THE LAST HONEST RECORD"
        };

        private static readonly string[] FinalePages =
        {
            "Lady Vey left an exact drawing: five rays surrounding the lost star. " +
            "Someone carved a sixth into the threshold, then replaced a stair baluster " +
            "to conceal the route. The architecture was not ruined. It was edited, " +
            "as if a house could be made to forget what it had witnessed.

" +
            "The first two deductions restore the entrance to the truth.",

            "The lantern's lunar phase, the basin's additive petal counts, and the " +
            "fountain's ordered spouts are three independent pieces of one itinerary. " +
            "The statues finish it: South, then East, then West. None of these clues " +
            "is sufficient alone; together they lead beyond the silent crossing.

" +
            "The garden had never hidden a treasure. It had preserved a path for a witness.",

            "The mechanical glass carriage changes the outer panes, not the laws of light. " +
            "The memorial names a death in 1904; the portrait claims a live sitting in 1912. " +
            "The impossible eight-year gap exposes the false chronology. " +
            "Beneath the witness, the damaged word is restored: REMEMBER.

" +
            "The gallery's purpose was to make a lie appear older than its evidence.",

            "At the meridian, all twenty-four possible four-ring orders are considered. " +
            "Only A-B-C-D keeps B immediately after A, places A before C, and leaves D last. " +
            "The final mechanism opens the unedited register.

" +
            "The missing archivist did not erase the testimony; the archivist protected it. " +
            "The curator's edited account can now be challenged by the ten findings. " +
            "Lady Vey's last instruction is finally legible: preserve the record, " +
            "including its contradictions, and let the truth outlive the house.

" +
            "THE INVESTIGATION IS COMPLETE. All ten findings remain available for review."
        };

        public static string FinaleHeading(int page)
        {
            TheOrderRoom.Domain.StoryFinalePolicy.ValidatePage(page);
            return FinaleHeadings[page];
        }

        public static string FinaleText(int page)
        {
            TheOrderRoom.Domain.StoryFinalePolicy.ValidatePage(page);
            return FinalePages[page];
        }

        public static string ChapterCoda(int chapterNumber)
        {
            if (chapterNumber < 1 || chapterNumber > ChapterCodas.Length)
                throw new ArgumentOutOfRangeException(nameof(chapterNumber));
            return ChapterCodas[chapterNumber - 1];
        }

        public static string CaseConsequence(int locationNumber)
        {
            if (locationNumber < 1 || locationNumber > CaseAftermath.Length)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            return CaseAftermath[locationNumber - 1];
        }
        public static string Title(int zeroBasedLevel)
        {
            if (zeroBasedLevel < 0 || zeroBasedLevel >= 12) throw new ArgumentOutOfRangeException(nameof(zeroBasedLevel));
            return ChapterTitles[zeroBasedLevel / 3] + " / " + StageTitles[zeroBasedLevel % 3];
        }
        public static string Hook(int zeroBasedLevel)
        {
            if (zeroBasedLevel < 0 || zeroBasedLevel >= 12) throw new ArgumentOutOfRangeException(nameof(zeroBasedLevel));
            return ChapterHooks[zeroBasedLevel / 3];
        }
    }
}
