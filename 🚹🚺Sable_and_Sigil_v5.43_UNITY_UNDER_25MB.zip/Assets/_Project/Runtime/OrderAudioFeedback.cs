using System;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>Original short procedural sounds; no streamed files, per-frame allocations or mixer polling.</summary>
    [RequireComponent(typeof(AudioSource))]
    [DisallowMultipleComponent]
    public sealed class OrderAudioFeedback : MonoBehaviour
    {
        private AudioSource source;
        private AudioClip success;
        private AudioClip warning;
        private AudioClip discovery;
        private AudioClip hint;
        private float lastPlayed = -10f;
        private bool applicationPaused;
        private bool applicationFocused = true;
        private bool outputFailureReported;

        private void Awake()
        {
            source = GetComponent<AudioSource>();
            if (source == null)
            {
                Debug.LogWarning("Audio feedback is unavailable because its AudioSource is missing.", this);
                enabled = false;
                return;
            }
            source.playOnAwake = false;
            source.loop = false;
            source.spatialBlend = 0f;
            source.volume = .40f;
            source.spatialize = false;
            try
            {
                success = MakeTone("OrderSuccess", 587.33f, 0.14f, 880f);
                warning = MakeTone("OrderWarning", 220f, 0.12f, 196f);
                discovery = MakeTone("OrderDiscovery", 783.99f, 0.16f, 1174.66f);
                hint = MakeTone("OrderHint", 392f, 0.14f, 523.25f);
            }
            catch (Exception exception)
            {
                ReleaseClips();
                Debug.LogWarning("Optional audio initialization failed: " + exception.GetType().Name, this);
                enabled = false;
            }
        }

        private static AudioClip MakeTone(string name, float hz, float durationSeconds, float harmonyHz)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(durationSeconds * sampleRate);
            var data = new float[count];
            for (int i = 0; i < count; i++)
            {
                float phase = i * (2f * Mathf.PI * hz / sampleRate);
                float envelope = Mathf.Sin(Mathf.PI * i / (count - 1));
                float harmonyPhase = i * (2f * Mathf.PI * harmonyHz / sampleRate);
                data[i] = (Mathf.Sin(phase) * .70f + Mathf.Sin(harmonyPhase) * .30f) *
                    envelope * envelope * .35f;
            }
            var clip = AudioClip.Create(name, count, 1, sampleRate, false);
            if (clip == null)
                throw new InvalidOperationException("Failed to create audio feedback clip.");
            if (!clip.SetData(data, 0))
            {
                Destroy(clip);
                throw new InvalidOperationException("Failed to initialize audio feedback clip.");
            }
            return clip;
        }

        private void Play(AudioClip clip)
        {
            if (clip == null || source == null || !isActiveAndEnabled || applicationPaused ||
                !applicationFocused || AudioListener.pause || !LocalPrivacyPreferences.AudioEnabled) return;
            if (Time.unscaledTime - lastPlayed < .075f) return;
            lastPlayed = Time.unscaledTime;
            try
            {
                source.PlayOneShot(clip);
            }
            catch (Exception exception)
            {
                if (!outputFailureReported)
                {
                    outputFailureReported = true;
                    Debug.LogWarning("Optional audio playback failed: " + exception.GetType().Name, this);
                }
                enabled = false;
            }
        }

        public void PlaySuccess() => Play(success);
        public void PlayWarning() => Play(warning);
        public void PlayDiscovery() => Play(discovery);
        public void PlayHint() => Play(hint);

        public void StopPlayback()
        {
            if (source != null) source.Stop();
        }

        private void OnApplicationPause(bool paused)
        {
            applicationPaused = paused;
            if (paused && source != null) source.Stop();
        }

        private void OnApplicationFocus(bool focused)
        {
            applicationFocused = focused;
            if (!focused && source != null) source.Stop();
        }

        private void OnDisable()
        {
            if (source != null) source.Stop();
        }

        private void OnDestroy()
        {
            ReleaseClips();
        }

        private void ReleaseClips()
        {
            if (success != null) Destroy(success);
            if (warning != null) Destroy(warning);
            if (discovery != null) Destroy(discovery);
            if (hint != null) Destroy(hint);
            success = null;
            warning = null;
            discovery = null;
            hint = null;
        }
    }
}
