using System;
using System.Collections.Generic;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// A single non-interactive, upward-facing relief mesh for each authored evidence pedestal.
    /// The existing evidence catalog determines the count; no puzzle state is read or modified.
    /// </summary>
    public static class ChapterWorldPedestalInlayGeometry
    {
        public const int MinimumMotifs = 1;
        public const int MaximumMotifs = 8;
        public const int MaximumVertices = MaximumMotifs * 4;
        public const int MaximumTriangles = MaximumMotifs * 2;

        public static Mesh Create(int motifCount)
        {
            if (motifCount < MinimumMotifs || motifCount > MaximumMotifs)
                throw new ArgumentOutOfRangeException(nameof(motifCount));

            var vertices = new List<Vector3>(motifCount * 4);
            var uvs = new List<Vector2>(motifCount * 4);
            var triangles = new List<int>(motifCount * 6);
            const float innerRadius = .46f;
            const float outerRadius = .62f;
            const float halfAngle = .135f;

            for (int i = 0; i < motifCount; i++)
            {
                float angle = (i + .5f) * (Mathf.PI * 2f / motifCount);
                float a = angle - halfAngle;
                float b = angle + halfAngle;
                int start = vertices.Count;
                AddVertex(innerRadius, a, vertices, uvs);
                AddVertex(outerRadius, a, vertices, uvs);
                AddVertex(outerRadius, b, vertices, uvs);
                AddVertex(innerRadius, b, vertices, uvs);
                // The XZ-plane winding below points towards positive Y.
                triangles.Add(start);
                triangles.Add(start + 2);
                triangles.Add(start + 1);
                triangles.Add(start);
                triangles.Add(start + 3);
                triangles.Add(start + 2);
            }

            var mesh = new Mesh { name = "Owned Evidence Pedestal Inlay" };
            mesh.SetVertices(vertices);
            mesh.SetUVs(0, uvs);
            mesh.SetTriangles(triangles, 0);
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private static void AddVertex(float radius, float angle,
            List<Vector3> vertices, List<Vector2> uvs)
        {
            float x = Mathf.Cos(angle) * radius;
            float z = Mathf.Sin(angle) * radius;
            vertices.Add(new Vector3(x, 0f, z));
            uvs.Add(new Vector2(.5f + x / 1.3f, .5f + z / 1.3f));
        }
    }
}
