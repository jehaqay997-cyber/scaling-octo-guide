using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    [DisallowMultipleComponent]
    public sealed class OrderScreenLayout : MonoBehaviour
    {
        [SerializeField] private Camera boardCamera;
        [SerializeField] private RectTransform content;
        [SerializeField] private CanvasScaler scaler;
        private int lastWidth, lastHeight;
        private Rect lastSafeArea;
        private float lastFieldOfView;
        private Quaternion cameraRotation;
        private Rect originalViewport;
        private Vector3 originalPosition;
        private Vector2 originalAnchorMin;
        private Vector2 originalAnchorMax;
        private Vector2 originalOffsetMin;
        private Vector2 originalOffsetMax;
        private Vector2 originalReferenceResolution;
        private CanvasScaler.ScreenMatchMode originalScreenMatchMode;
        private CanvasScaler.ScaleMode originalScaleMode;
        private float originalMatchWidthOrHeight;
        private float availableLayoutWidth;
        private bool configured;
        private readonly Dictionary<RectTransform, RectSnapshot> originalRects =
            new Dictionary<RectTransform, RectSnapshot>();
        private readonly Dictionary<Text, TextSnapshot> originalTexts =
            new Dictionary<Text, TextSnapshot>();

        private struct RectSnapshot
        {
            public Vector2 AnchorMin;
            public Vector2 AnchorMax;
            public Vector2 OffsetMin;
            public Vector2 OffsetMax;
            public Vector2 AnchoredPosition;
            public Vector2 SizeDelta;
        }

        private struct TextSnapshot
        {
            public bool ResizeForBestFit;
            public int MinimumSize;
            public int MaximumSize;
        }

        private void Remember(RectTransform rect)
        {
            if (rect == null || originalRects.ContainsKey(rect)) return;
            originalRects.Add(rect, new RectSnapshot
            {
                AnchorMin = rect.anchorMin,
                AnchorMax = rect.anchorMax,
                OffsetMin = rect.offsetMin,
                OffsetMax = rect.offsetMax,
                AnchoredPosition = rect.anchoredPosition,
                SizeDelta = rect.sizeDelta
            });
        }

        private void Remember(Text label)
        {
            if (label == null || originalTexts.ContainsKey(label)) return;
            originalTexts.Add(label, new TextSnapshot
            {
                ResizeForBestFit = label.resizeTextForBestFit,
                MinimumSize = label.resizeTextMinSize,
                MaximumSize = label.resizeTextMaxSize
            });
        }

        public void Configure(Camera camera, RectTransform root, CanvasScaler canvasScaler)
        {
            if (configured) RestoreCamera();
            boardCamera = camera; content = root; scaler = canvasScaler;
            CaptureCamera();
        }
        private void OnEnable() => CaptureCamera();

        private void CaptureCamera()
        {
            if (boardCamera == null || content == null || scaler == null) return;
            originalRects.Clear();
            originalTexts.Clear();
            originalViewport = boardCamera.rect;
            originalPosition = boardCamera.transform.position;
            cameraRotation = boardCamera.transform.rotation;
            originalAnchorMin = content.anchorMin;
            originalAnchorMax = content.anchorMax;
            originalOffsetMin = content.offsetMin;
            originalOffsetMax = content.offsetMax;
            originalReferenceResolution = scaler.referenceResolution;
            originalScreenMatchMode = scaler.screenMatchMode;
            originalScaleMode = scaler.uiScaleMode;
            originalMatchWidthOrHeight = scaler.matchWidthOrHeight;
            configured = true;
            lastWidth = 0;
        }

        private void RestoreCamera()
        {
            if (!configured) return;
            if (boardCamera != null)
            {
                boardCamera.rect = originalViewport;
                boardCamera.transform.SetPositionAndRotation(originalPosition, cameraRotation);
            }
            if (content != null)
            {
                content.anchorMin = originalAnchorMin;
                content.anchorMax = originalAnchorMax;
                content.offsetMin = originalOffsetMin;
                content.offsetMax = originalOffsetMax;
            }
            if (scaler != null)
            {
                scaler.referenceResolution = originalReferenceResolution;
                scaler.screenMatchMode = originalScreenMatchMode;
                scaler.uiScaleMode = originalScaleMode;
                scaler.matchWidthOrHeight = originalMatchWidthOrHeight;
            }
            foreach (var entry in originalRects)
            {
                var rect = entry.Key;
                if (rect == null) continue;
                var snapshot = entry.Value;
                rect.anchorMin = snapshot.AnchorMin;
                rect.anchorMax = snapshot.AnchorMax;
                rect.offsetMin = snapshot.OffsetMin;
                rect.offsetMax = snapshot.OffsetMax;
                rect.anchoredPosition = snapshot.AnchoredPosition;
                rect.sizeDelta = snapshot.SizeDelta;
            }
            foreach (var entry in originalTexts)
            {
                var label = entry.Key;
                if (label == null) continue;
                var snapshot = entry.Value;
                label.resizeTextForBestFit = snapshot.ResizeForBestFit;
                label.resizeTextMinSize = snapshot.MinimumSize;
                label.resizeTextMaxSize = snapshot.MaximumSize;
            }
            originalRects.Clear();
            originalTexts.Clear();
            configured = false;
        }
        private void LateUpdate()
        {
            if (!configured || boardCamera == null || content == null || scaler == null || Screen.width <= 0 || Screen.height <= 0) return;
            Rect safe = Screen.safeArea;
            float xMin = Mathf.Clamp(safe.xMin, 0f, Screen.width);
            float xMax = Mathf.Clamp(safe.xMax, 0f, Screen.width);
            float yMin = Mathf.Clamp(safe.yMin, 0f, Screen.height);
            float yMax = Mathf.Clamp(safe.yMax, 0f, Screen.height);
            safe = Rect.MinMaxRect(xMin, yMin, xMax, yMax);
            if (safe.width <= 0f || safe.height <= 0f) return;
            if (Screen.width == lastWidth && Screen.height == lastHeight && safe == lastSafeArea &&
                Mathf.Approximately(lastFieldOfView, boardCamera.fieldOfView)) return;
            lastWidth = Screen.width; lastHeight = Screen.height; lastSafeArea = safe;
            lastFieldOfView = boardCamera.fieldOfView;
            content.anchorMin = new Vector2(safe.xMin / Screen.width, safe.yMin / Screen.height);
            content.anchorMax = new Vector2(safe.xMax / Screen.width, safe.yMax / Screen.height);
            content.offsetMin = content.offsetMax = Vector2.zero;
            bool portrait = safe.height > safe.width;
            Vector2 reference = portrait ? new Vector2(720f, 1280f) : new Vector2(1280f, 720f);
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = reference;
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
            float scale = Mathf.Min(Screen.width / reference.x, Screen.height / reference.y);
            availableLayoutWidth = safe.width / Mathf.Max(scale, .0001f);
            Arrange(portrait);
            float bottom = portrait ? .28f : .30f;
            float height = portrait ? .43f : .42f;
            boardCamera.rect = new Rect(safe.x / Screen.width, (safe.y + safe.height * bottom) / Screen.height,
                safe.width / Screen.width, safe.height * height / Screen.height);
            FitBoard(safe.width / (safe.height * height));
        }
        private void FitBoard(float aspect)
        {
            // Fit all eight table bounds corners in camera space, without frame-dependent smoothing.
            Vector3 center = new Vector3(0, .4f, 0);
            Vector3 extents = new Vector3(6.2f, 1.1f, 3.7f);
            Quaternion inverse = Quaternion.Inverse(cameraRotation);
            float tangent = Mathf.Tan(Mathf.Clamp(boardCamera.fieldOfView, 1, 170) * Mathf.Deg2Rad * .5f);
            float distance = 0;
            for (int x = -1; x <= 1; x += 2)
                for (int y = -1; y <= 1; y += 2)
                    for (int z = -1; z <= 1; z += 2)
                    {
                        Vector3 corner = inverse * Vector3.Scale(extents, new Vector3(x, y, z));
                        distance = Mathf.Max(distance, Mathf.Abs(corner.x) / (tangent * aspect) - corner.z,
                            Mathf.Abs(corner.y) / tangent - corner.z);
                        distance = Mathf.Max(distance, boardCamera.nearClipPlane - corner.z + .1f);
                    }
            boardCamera.transform.SetPositionAndRotation(center - cameraRotation * Vector3.forward * (distance + .4f), cameraRotation);
        }
        private void Arrange(bool portrait)
        {
            Place("Title", .5f, portrait ? .94f : .95f, portrait ? 650 : 780, 60);
            Place("Collection Journal", .5f, .86f, portrait ? 660 : 1100, portrait ? 65 : 50);
            Place("Status", .5f, portrait ? .245f : .26f, portrait ? 660 : 1100, portrait ? 85 : 45);
            Place("Inspection Instructions", .5f, portrait ? .19f : .192f, portrait ? 660 : 1050, portrait ? 50 : 36);
            Place("RULES", .16f, portrait ? .79f : .77f, portrait ? 190 : 180, portrait ? 58 : 48);
            Place("HINT", .84f, portrait ? .79f : .77f, portrait ? 190 : 180, portrait ? 58 : 48);
            string[] actions = { "RESET", "UNDO", "REDO", "NEXT" };
            for (int i = 0; i < actions.Length; i++) PlaceInSlots(actions[i], (i + .5f) / 4, portrait ? .045f : .055f, portrait ? 155 : 180, portrait ? 58 : 44, 4);
            string[] inspection = { "INSPECT", "TURN LEFT", "SCAN", "TURN RIGHT", "CLAIM" };
            for (int i = 0; i < inspection.Length; i++) PlaceInSlots(inspection[i], (i + .5f) / 5, portrait ? .115f : .125f, portrait ? 130 : 180, portrait ? 58 : 44, 5);
            Place("FOCUS -", .35f, .735f, 155, 40);
            Place("FOCUS +", .65f, .735f, 155, 40);
            Place("SUN Symbol", .35f, .79f, 50, 50);
            Place("MOON Symbol", .5f, .79f, 50, 50);
            Place("STAR Symbol", .65f, .79f, 50, 50);
            Place("Artifact Reveal", .5f, .50f, portrait ? 650 : 1080, 180);
            Place("Puzzle Rules", .5f, .5f, portrait ? 660 : 1120, portrait ? 680 : 420);
            var rules = content.Find("Puzzle Rules/Rule Details") as RectTransform;
            if (rules != null)
            {
                Remember(rules);
                rules.sizeDelta = new Vector2(Mathf.Min(portrait ? 620f : 1080f, Mathf.Max(1f, availableLayoutWidth * .86f)), portrait ? 640f : 390f);
            }
        }
        private void Place(string name, float x, float y, float width, float height)
        {
            PlaceInSlots(name, x, y, width, height, 0);
        }

        private void PlaceInSlots(string name, float x, float y, float width, float height, int slots)
        {
            var rect = content.Find(name) as RectTransform;
            if (rect == null) return;
            Remember(rect);
            rect.anchorMin = rect.anchorMax = new Vector2(x, y);
            rect.anchoredPosition = Vector2.zero;
            float maximumWidth = slots > 0
                ? availableLayoutWidth > 0f ? availableLayoutWidth / slots * .86f : width
                : availableLayoutWidth > 0f ? availableLayoutWidth * .92f : width;
            rect.sizeDelta = new Vector2(Mathf.Min(width, maximumWidth), height);
            var label = rect.GetComponentInChildren<Text>(true);
            if (label != null)
            {
                Remember(label);
                label.resizeTextForBestFit = true;
                label.resizeTextMinSize = Mathf.Min(12, Mathf.Max(1, label.fontSize));
                label.resizeTextMaxSize = Mathf.Max(1, label.fontSize);
                if (rect.GetComponent<Button>() != null)
                {
                    Remember(label.rectTransform);
                    label.rectTransform.anchorMin = Vector2.zero;
                    label.rectTransform.anchorMax = Vector2.one;
                    label.rectTransform.offsetMin = new Vector2(5, 3);
                    label.rectTransform.offsetMax = new Vector2(-5, -3);
                }
            }
        }
        private void OnDisable()
        {
            RestoreCamera();
        }
    }
}
