using System;
using System.Collections.Generic;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// One bounded, front-facing relief for each authored Chapter Three mechanism.
    /// The caller owns the mesh. Geometry is decorative, collider-free, and has
    /// no authority over clues, answers, saves, or campaign progression.
    /// </summary>
    public enum ChapterThreeReliefStage
    {
        Locked = 0,
        Investigating = 1,
        Restored = 2
    }

    public static class ChapterThreeReliefMesh
    {
        public const int FirstLocation = 7;
        public const int LastLocation = 9;
        public const int MaximumTriangles = 512;
        private const float Pi = Mathf.PI;

        // Preserve the original two-state API for existing authored tooling.
        // World exploration uses the explicit three-stage overload below.
        public static Mesh Create(int locationNumber, bool solved)
        {
            return Create(locationNumber, solved ? ChapterThreeReliefStage.Restored :
                ChapterThreeReliefStage.Investigating);
        }

        public static Mesh Create(int locationNumber, ChapterThreeReliefStage stage)
        {
            ValidateLocation(locationNumber);
            ValidateStage(stage);
            var mesh = new Mesh { name = "Owned Chapter Three Mechanism Relief" };
            try
            {
                mesh.MarkDynamic();
                Rebuild(mesh, locationNumber, stage);
                return mesh;
            }
            catch
            {
                if (Application.isPlaying) UnityEngine.Object.Destroy(mesh);
                else UnityEngine.Object.DestroyImmediate(mesh);
                throw;
            }
        }

        public static void Rebuild(Mesh mesh, int locationNumber, bool solved)
        {
            Rebuild(mesh, locationNumber, solved ? ChapterThreeReliefStage.Restored :
                ChapterThreeReliefStage.Investigating);
        }

        /// <summary>
        /// Rebuilds the same caller-owned mesh at an explicit disclosure stage.
        /// Invalid requests fail before Clear(), preserving the existing mesh.
        /// The locked drawing contains no authored clue sequence or answer glyph.
        /// </summary>
        public static void Rebuild(Mesh mesh, int locationNumber, ChapterThreeReliefStage stage)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));
            ValidateLocation(locationNumber);
            ValidateStage(stage);
            var geometry = new ReliefBuilder();
            if (stage == ChapterThreeReliefStage.Locked)
            {
                BuildLockedRelief(geometry, locationNumber);
            }
            else
            {
                bool solved = stage == ChapterThreeReliefStage.Restored;
                switch (locationNumber)
                {
                    case 7:
                        BuildGlassTestament(geometry, solved);
                        break;
                    case 8:
                        BuildMemorial(geometry, solved);
                        break;
                    case 9:
                        BuildEpitaph(geometry, solved);
                        break;
                }
            }
            if (geometry.TriangleCount < 1 || geometry.TriangleCount > MaximumTriangles)
                throw new InvalidOperationException("Chapter Three relief exceeds its triangle budget.");

            mesh.Clear();
            mesh.SetVertices(geometry.Vertices);
            mesh.SetNormals(geometry.Normals);
            mesh.SetTriangles(geometry.Triangles, 0);
            mesh.RecalculateBounds();
        }

        private static void ValidateStage(ChapterThreeReliefStage stage)
        {
            if (stage != ChapterThreeReliefStage.Locked &&
                stage != ChapterThreeReliefStage.Investigating &&
                stage != ChapterThreeReliefStage.Restored)
                throw new ArgumentOutOfRangeException(nameof(stage));
        }

        private static void BuildLockedRelief(ReliefBuilder geometry, int locationNumber)
        {
            switch (locationNumber)
            {
                case 7:
                    // Symmetric glass frames, with neither the source nor reflection sequence.
                    for (int column = 0; column < 2; column++)
                    {
                        float x = column == 0 ? -.78f : .78f;
                        geometry.Quad(x - .29f, -.43f, x - .24f, .43f);
                        geometry.Quad(x + .24f, -.43f, x + .29f, .43f);
                        geometry.Quad(x - .29f, -.43f, x + .29f, -.38f);
                        geometry.Quad(x - .29f, .38f, x + .29f, .43f);
                    }
                    break;
                case 8:
                    // Equal, undated memorial silhouettes: no timeline ordering encoded.
                    for (int pillar = 0; pillar < 2; pillar++)
                    {
                        float x = pillar == 0 ? -.82f : .82f;
                        geometry.Quad(x - .24f, -.34f, x + .24f, -.28f);
                        geometry.Quad(x - .17f, -.28f, x + .17f, .25f);
                        geometry.Quad(x - .24f, .25f, x + .24f, .32f);
                    }
                    break;
                case 9:
                    // Blank epitaph sockets; no letterforms or missing-glyph position.
                    for (int socket = 0; socket < 8; socket++)
                    {
                        float x = (socket - 3.5f) * .39f;
                        geometry.Ring(x, .02f, .135f, .113f, 12);
                    }
                    break;
            }
        }

        private static void ValidateLocation(int locationNumber)
        {
            if (locationNumber < FirstLocation || locationNumber > LastLocation)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
        }

        private static float Slot(int index, int count)
        {
            return (index - (count - 1) * .5f) * (count == 5 ? .78f : .94f);
        }

        private static void BuildGlassTestament(ReliefBuilder geometry, bool solved)
        {
            // Two three-slot lancet windows: authored pane and reconstructed reflection.
            // The mirror occupies only the right column and stays blank until verified.
            for (int column = 0; column < 2; column++)
            {
                float x = column == 0 ? -.78f : .78f;
                geometry.Quad(x - .28f, -.41f, x - .24f, .41f);
                geometry.Quad(x + .24f, -.41f, x + .28f, .41f);
                for (int row = 0; row < 3; row++)
                {
                    float y = .26f - row * .26f;
                    geometry.Ring(x, y, .112f, .098f, 16);
                    if (column == 1 && !solved) continue;
                    int symbol = column == 0 ? row : 2 - row;
                    if (symbol == 0)
                    {
                        geometry.Triangle(new Vector2(x, y + .076f),
                            new Vector2(x - .071f, y - .056f),
                            new Vector2(x + .071f, y - .056f));
                    }
                    else if (symbol == 1)
                    {
                        geometry.Ring(x, y, .062f, .042f, 12);
                    }
                    else
                    {
                        for (int ray = -1; ray <= 1; ray++)
                            geometry.Arrow(x + ray * .047f, y, Mathf.PI * .5f, .055f);
                    }
                }
            }
        }

        private static void BuildMemorial(ReliefBuilder geometry, bool solved)
        {
            // The two dated pillars remain visible in both states. Only the impossible
            // personal-sitting claim is identified after both independent clues are read.
            geometry.Quad(-1.24f, -.39f, -.40f, -.36f);
            geometry.Quad(.40f, -.39f, 1.24f, -.36f);
            for (int index = 0; index < 2; index++)
            {
                float x = index == 0 ? -.82f : .82f;
                geometry.Quad(x - .28f, -.34f, x + .28f, -.26f);
                geometry.Quad(x - .19f, -.26f, x + .19f, .20f);
                geometry.Ring(x, .29f, .16f, .115f, 20);
                for (int band = 0; band < (index == 0 ? 4 : 8); band++)
                {
                    float bandY = -.22f + band * .048f;
                    geometry.Quad(x - .16f, bandY, x + .16f, bandY + .012f);
                }
            }
            if (solved)
            {
                geometry.Arrow(0f, 0f, -Mathf.PI * .5f, .28f);
                geometry.Quad(-.18f, -.38f, .18f, -.34f);
            }
            else
            {
                geometry.Ring(0f, .04f, .16f, .13f, 20);
            }
        }

        private static void BuildEpitaph(ReliefBuilder geometry, bool solved)
        {
            // Nine carved glyph sockets. The missing second slot is filled, not spawned.
            // The decorative inlay has no colliders; only its parent backplate is pickable.
            for (int index = 0; index < 8; index++)
            {
                float x = (index - 3.5f) * .39f;
                geometry.Ring(x, .02f, .135f, .113f, 12);
                if (index == 1 && !solved) continue;
                if (index == 1)
                {
                    geometry.Quad(x - .058f, -.072f, x - .035f, .082f);
                    geometry.Quad(x - .052f, .064f, x + .057f, .083f);
                    geometry.Quad(x - .052f, -.01f, x + .036f, .008f);
                    geometry.Quad(x - .052f, -.075f, x + .057f, -.055f);
                }
                else
                {
                    geometry.Quad(x - .032f, -.077f, x + .032f, .067f);
                    geometry.Quad(x - .057f, -.077f, x + .057f, -.058f);
                }
            }
        }

        private sealed class ReliefBuilder
        {
            public readonly List<Vector3> Vertices = new List<Vector3>(768);
            public readonly List<Vector3> Normals = new List<Vector3>(768);
            public readonly List<int> Triangles = new List<int>(768);
            public int TriangleCount => Triangles.Count / 3;

            public void Triangle(Vector2 a, Vector2 b, Vector2 c)
            {
                float winding = (b.x - a.x) * (c.y - a.y) -
                    (b.y - a.y) * (c.x - a.x);
                if (Mathf.Abs(winding) <= .0000001f)
                    throw new InvalidOperationException("Degenerate Chapter Three relief triangle.");
                if (winding > 0f)
                {
                    Vector2 swap = b;
                    b = c;
                    c = swap;
                }
                int start = Vertices.Count;
                Vertices.Add(new Vector3(a.x, a.y, 0f));
                Vertices.Add(new Vector3(b.x, b.y, 0f));
                Vertices.Add(new Vector3(c.x, c.y, 0f));
                Normals.Add(Vector3.back);
                Normals.Add(Vector3.back);
                Normals.Add(Vector3.back);
                Triangles.Add(start);
                Triangles.Add(start + 1);
                Triangles.Add(start + 2);
            }

            public void Quad(float left, float bottom, float right, float top)
            {
                Vector2 a = new Vector2(left, bottom);
                Vector2 b = new Vector2(right, bottom);
                Vector2 c = new Vector2(right, top);
                Vector2 d = new Vector2(left, top);
                Triangle(a, c, b);
                Triangle(a, d, c);
            }

            public void Sector(float x, float y, float radius, float first, float last, int steps)
            {
                Vector2 center = new Vector2(x, y);
                for (int i = 0; i < steps; i++)
                {
                    float a = first + (last - first) * i / steps;
                    float b = first + (last - first) * (i + 1) / steps;
                    Triangle(center,
                        center + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * radius,
                        center + new Vector2(Mathf.Cos(b), Mathf.Sin(b)) * radius);
                }
            }

            public void Ring(float x, float y, float outer, float inner, int steps)
            {
                Vector2 center = new Vector2(x, y);
                for (int index = 0; index < steps; index++)
                {
                    float a = index * Pi * 2f / steps;
                    float b = (index + 1) * Pi * 2f / steps;
                    Vector2 dirA = new Vector2(Mathf.Cos(a), Mathf.Sin(a));
                    Vector2 dirB = new Vector2(Mathf.Cos(b), Mathf.Sin(b));
                    Vector2 outA = center + dirA * outer;
                    Vector2 outB = center + dirB * outer;
                    Vector2 inA = center + dirA * inner;
                    Vector2 inB = center + dirB * inner;
                    Triangle(outA, inA, outB);
                    Triangle(inA, inB, outB);
                }
            }

            public void Arrow(float x, float y, float angle, float length)
            {
                Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
                Vector2 across = new Vector2(-direction.y, direction.x);
                Vector2 center = new Vector2(x, y);
                Vector2 tail = center - direction * (length * .7f);
                Vector2 basePoint = center + direction * (length * .3f);
                float halfWidth = length * .13f;
                Triangle(tail - across * halfWidth, basePoint - across * halfWidth,
                    basePoint + across * halfWidth);
                Triangle(tail - across * halfWidth, basePoint + across * halfWidth,
                    tail + across * halfWidth);
                Triangle(basePoint - across * (length * .43f),
                    center + direction * length,
                    basePoint + across * (length * .43f));
            }
        }
    }
}
