using System;
using UnityEditor;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Separate quality-controlled full-bleed backgrounds from legacy evidence JPGs.
    /// These photographs are only screen-space UI, so mipmaps and CPU readback
    /// are unnecessary. Unity selects the platform's supported compression format.
    /// </summary>
    public sealed class SableCinematicArtworkImport : AssetPostprocessor
    {
        private void OnPreprocessTexture()
        {
            if (!assetPath.StartsWith("Assets/_Project/Resources/CinematicLocations/", StringComparison.Ordinal) ||
                (!assetPath.EndsWith(".png", StringComparison.OrdinalIgnoreCase) &&
                !assetPath.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase))) return;
            if (!(assetImporter is TextureImporter texture)) return;
            texture.textureType = TextureImporterType.Default;
            texture.sRGBTexture = true;
            texture.isReadable = false;
            texture.mipmapEnabled = false;
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.filterMode = FilterMode.Bilinear;
            texture.textureCompression = TextureImporterCompression.Compressed;
            texture.maxTextureSize = 2048;
        }
    }
}
