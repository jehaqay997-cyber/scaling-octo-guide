#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Opens the integrated game scene after import and confirms entry into Play Mode.
    /// Transient failures are retried a bounded number of times per editor session.
    /// Existing unsaved scenes are never discarded automatically.
    /// </summary>
    [InitializeOnLoad]
    public static class OrderFirstImportSetup
    {
        private const string ScenePath = ChapterOneSceneBuilder.ScenePath;
        private const string OptOutMarker = "Assets/_Project/Scenes/.skip-auto-bootstrap";
        private const string SessionLaunchKey = "TheOrderRoom.Editor.AutoLaunchCompleted";
        private const string SessionAttemptsKey = "TheOrderRoom.Editor.AutoLaunchAttempts";
        private const string SessionPendingKey = "TheOrderRoom.Editor.AutoLaunchPending";
        private const int MaxAutomaticAttempts = 3;
        private static bool isAttempting;
        private static bool retryScheduled;

        static OrderFirstImportSetup()
        {
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
            // Automatic scene creation and Play Mode entry are disabled by default.
            // Use the explicit Sable & Sigil menu commands after compilation.
        }

        private static void OnPlayModeStateChanged(PlayModeStateChange state)
        {
            if (Application.isBatchMode || !SessionState.GetBool(SessionPendingKey, false))
                return;

            if (state == PlayModeStateChange.EnteredPlayMode)
            {
                var activeScene = SceneManager.GetActiveScene();
                ChapterOneExperience chapter = UnityEngine.Object.FindObjectOfType<ChapterOneExperience>();
                bool ready = activeScene.IsValid() && activeScene.path == ScenePath &&
                    chapter != null && chapter.isActiveAndEnabled && chapter.IsChapterReady;
                if (!ready)
                {
                    Debug.LogError("TheOrderRoom: Play Mode entered without an active integrated game scene. " +
                        "Automatic launch will exit Play Mode and retry if attempts remain.");
                    EditorApplication.isPlaying = false;
                    return;
                }

                SessionState.SetBool(SessionPendingKey, false);
                SessionState.SetBool(SessionLaunchKey, true);
                Debug.Log("TheOrderRoom: entered Play Mode with an active integrated game scene.");
            }
            else if (state == PlayModeStateChange.EnteredEditMode)
            {
                SessionState.SetBool(SessionPendingKey, false);
                if (SessionState.GetInt(SessionAttemptsKey, 0) < MaxAutomaticAttempts)
                    ScheduleRetry();
                else
                    Debug.LogError("TheOrderRoom: Play Mode entry failed and automatic retries are exhausted. " +
                        "Choose Sable & Sigil > Retry Chapter One Launch after resolving the error.");
            }
        }

        [MenuItem("Sable & Sigil/Retry Chapter One Launch")]
        public static void RetryFromMenu()
        {
            if (Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode)
                return;

            SessionState.SetBool(SessionLaunchKey, false);
            SessionState.SetInt(SessionAttemptsKey, 0);
            SessionState.SetBool(SessionPendingKey, false);
            ScheduleRetry();
        }

        private static void ScheduleRetry()
        {
            if (retryScheduled)
                return;

            retryScheduled = true;
            EditorApplication.delayCall += () =>
            {
                retryScheduled = false;
                TryInitialize();
            };
        }

        private static void TryInitialize()
        {
            if (Application.isBatchMode || isAttempting ||
                SessionState.GetBool(SessionLaunchKey, false) ||
                SessionState.GetBool(SessionPendingKey, false) ||
                File.Exists(OptOutMarker) || EditorApplication.isPlayingOrWillChangePlaymode)
                return;

            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                ScheduleRetry();
                return;
            }

            int attempts = SessionState.GetInt(SessionAttemptsKey, 0);
            if (attempts >= MaxAutomaticAttempts)
                return;

            isAttempting = true;
            SessionState.SetInt(SessionAttemptsKey, attempts + 1);
            try
            {
                ChapterOneSceneBuilder.EnsureChapterOne(true);
                ChapterCaseSceneBuilder.EnsureCaseScenes();
                if (SceneManager.GetActiveScene().path != ScenePath)
                {
                    // The user may have declined saving an open scene. Do not show
                    // repeated dialogs or override the user's decision.
                    Debug.LogWarning("TheOrderRoom: Main scene is prepared but not active. " +
                        "Save your open scene, then choose TheOrderRoom > Retry Automatic Game Launch.");
                    return;
                }

                var problems = SableChapterBuildRoute.Validate();
                if (!File.Exists(ChapterOneSceneBuilder.ScenePath))
                    problems.Add("Chapter One scene was not generated.");
                if (problems.Count != 0)
                    throw new InvalidOperationException("Scene validation failed: " +
                        string.Join("; ", problems));

                EditorApplication.ExecuteMenuItem("Window/General/Game");
                SessionState.SetBool(SessionPendingKey, true);
                EditorApplication.isPlaying = true;
                Debug.Log("TheOrderRoom: validated scene; Play Mode entry requested. Awaiting confirmation.");
            }
            catch (Exception error)
            {
                SessionState.SetBool(SessionPendingKey, false);
                Debug.LogError("TheOrderRoom: automatic game launch failed (attempt " +
                    (attempts + 1) + "/" + MaxAutomaticAttempts + "). " + error);
                if (attempts + 1 < MaxAutomaticAttempts)
                    ScheduleRetry();
                else
                    Debug.LogError("TheOrderRoom: automatic retries exhausted. " +
                        "Choose Sable & Sigil > Retry Chapter One Launch after resolving the error.");
            }
            finally
            {
                isAttempting = false;
            }
        }
    }
}
#endif
