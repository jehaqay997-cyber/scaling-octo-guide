#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Non-destructive, idempotent chapter-case scene builder.
    /// Scene serialization is performed by Unity, never by a text generator.
    /// </summary>
    public static class ChapterCaseSceneBuilder
    {
        public const string ChapterTwoScene = "Assets/_Project/Scenes/ChapterTwo.unity";
        public const string ChapterThreeScene = "Assets/_Project/Scenes/ChapterThree.unity";
        public const string ChapterFourScene = "Assets/_Project/Scenes/ChapterFour.unity";

        [MenuItem("Sable & Sigil/Prepare Chapters One to Four")]
        public static void PrepareInteractive()
        {
            if (Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode ||
                EditorApplication.isCompiling || EditorApplication.isUpdating)
                throw new InvalidOperationException("Unity must be idle before preparing chapter scenes.");
            ChapterOneSceneBuilder.EnsureChapterOne(false);
            EnsureCaseScenes();
            SableLaunchAcceptance.RequireImportedSourceAndScenes();
            Debug.Log("SABLE_SIGIL_FOUR_CHAPTER_SCENES_PREPARED_NOT_PLAYMODE_VERIFIED");
        }

        public static void EnsureCaseScenes()
        {
            EnsureScene(ChapterTwoScene, 2);
            EnsureScene(ChapterThreeScene, 3);
            EnsureScene(ChapterFourScene, 4);
            SableChapterBuildRoute.Configure();
            AssetDatabase.SaveAssets();
        }

        /// <summary>
        /// Existing scenes are not automatically trusted. An invalid or dirty scene
        /// is rejected without overwriting user edits or adding it to Build Settings.
        /// Only a scene loaded by this validator may be closed by the validator.
        /// </summary>
        private static void ValidateExistingScene(string path, int expectedChapter)
        {
            Scene scene = SceneManager.GetSceneByPath(path);
            bool openedHere = !scene.IsValid() || !scene.isLoaded;
            Scene previouslyActive = SceneManager.GetActiveScene();
            try
            {
                if (openedHere)
                    scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Additive);
                if (!scene.IsValid() || !scene.isLoaded || scene.isDirty)
                    throw new InvalidOperationException("Existing chapter scene is unavailable or has unsaved changes: " + path);

                ChapterCaseSceneBootstrap bootstrap = null;
                ChapterGalleryView gallery = null;
                int bootstraps = 0;
                int galleries = 0;
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    foreach (ChapterCaseSceneBootstrap component in
                        root.GetComponentsInChildren<ChapterCaseSceneBootstrap>(true))
                    {
                        bootstrap = component;
                        bootstraps++;
                    }
                    foreach (ChapterGalleryView component in
                        root.GetComponentsInChildren<ChapterGalleryView>(true))
                    {
                        gallery = component;
                        galleries++;
                    }
                    foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
                    {
                        if (GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(child.gameObject) != 0)
                            throw new InvalidOperationException("Existing chapter scene contains a missing script: " + path);
                    }
                }
                if (bootstraps != 1 || galleries != 1 || bootstrap == null || gallery == null ||
                    !bootstrap.isActiveAndEnabled || bootstrap.ChapterNumber != expectedChapter ||
                    !gallery.isActiveAndEnabled || gallery.gameObject != bootstrap.gameObject)
                    throw new InvalidOperationException("Existing chapter scene has an invalid chapter bootstrap or gallery: " + path);
            }
            finally
            {
                if (openedHere && scene.IsValid() && scene.isLoaded)
                    EditorSceneManager.CloseScene(scene, true);
                if (previouslyActive.IsValid() && previouslyActive.isLoaded)
                    SceneManager.SetActiveScene(previouslyActive);
            }
        }

        private static void EnsureScene(string path, int chapter)
        {
            if (File.Exists(path))
            {
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
                    throw new InvalidOperationException("Existing chapter scene failed to import: " + path);
                ValidateExistingScene(path, chapter);
                return;
            }
            const string projectFolder = "Assets/_Project";
            if (!AssetDatabase.IsValidFolder(projectFolder + "/Scenes"))
                AssetDatabase.CreateFolder(projectFolder, "Scenes");
            Scene previous = SceneManager.GetActiveScene();
            Scene created = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            try
            {
                if (!SceneManager.SetActiveScene(created))
                    throw new InvalidOperationException("Could not activate Chapter " + chapter + " scene.");
                var root = new GameObject("Sable & Sigil - Chapter " + chapter);
                root.AddComponent<ChapterGalleryView>();
                root.AddComponent<ChapterCaseSceneBootstrap>().Configure(chapter);
                if (!EditorSceneManager.SaveScene(created, path))
                    throw new IOException("Could not persist Chapter " + chapter + " scene.");
                AssetDatabase.SaveAssets();
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
                    throw new InvalidOperationException("Generated scene was not imported: " + path);
            }
            finally
            {
                if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
                if (created.IsValid() && created.isLoaded) EditorSceneManager.CloseScene(created, true);
            }
        }
    }
}
#endif
