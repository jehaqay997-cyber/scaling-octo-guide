#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Checks Unity-imported references, which cannot be proven by a text-only source audit.
    /// A passing result is not a substitute for compilation, PlayMode, or device tests.
    /// </summary>
    public static class SableAssetReferenceValidator
    {
        private const string SourceRoot = "Assets/_Project";

        [MenuItem("Sable & Sigil/Validate Imported Source References")]
        public static void ValidateMenu()
        {
            List<string> errors = ValidateImportedReferences();
            if (errors.Count != 0)
            {
                Debug.LogError("Sable & Sigil imported source reference validation failed:\n" +
                    string.Join("\n", errors));
                return;
            }
            Debug.Log("SABLE_SIGIL_IMPORTED_REFERENCES_VALID_STATIC_ONLY");
        }

        public static List<string> ValidateImportedReferences()
        {
            var errors = new List<string>();
            string absoluteSource = Path.Combine(Application.dataPath, "_Project");
            if (!Directory.Exists(absoluteSource))
            {
                errors.Add("Project source directory is missing.");
                return errors;
            }

            ValidateImportedFiles(absoluteSource, "*.cs", typeof(MonoScript), errors);
            ValidateImportedFiles(absoluteSource, "*.asmdef", null, errors);
            ValidateCompiledRuntimeComponentScripts(errors);
            foreach (string image in new[] { "sun.png", "moon.png", "star.png" })
            {
                string path = SourceRoot + "/Art/PNG/" + image;
                if (AssetDatabase.LoadAssetAtPath<Sprite>(path) == null)
                    errors.Add("Symbol sprite has not been imported: " + path);
                RequireGuidRoundTrip(path, errors);
            }

            for (int number = 1; number <= 4; number++)
            {
                string path = SourceRoot + "/Resources/ChapterArt/Chapter_" +
                    number.ToString("00") + ".jpg";
                RequireImportedTexture(path, errors);
            }
            for (int number = 1; number <= 10; number++)
            {
                string path = SourceRoot + "/Resources/LocationArt/Scene_" +
                    number.ToString("00") + ".jpg";
                RequireImportedTexture(path, errors);
            }
            string hints = SourceRoot + "/Resources/PuzzleHints/HintCatalog.json";
            if (AssetDatabase.LoadAssetAtPath<TextAsset>(hints) == null)
                errors.Add("Hint catalog has not been imported as a TextAsset: " + hints);
            RequireGuidRoundTrip(hints, errors);
            ValidateImportedSceneDependencies(errors);
            return errors;
        }

        private static void ValidateImportedFiles(string absoluteSource, string searchPattern,
            Type requiredAssetType, List<string> errors)
        {
            string[] paths = Directory.GetFiles(absoluteSource, searchPattern, SearchOption.AllDirectories);
            if (paths.Length == 0)
            {
                errors.Add("No files found matching " + searchPattern);
                return;
            }
            foreach (string fullPath in paths)
            {
                string normalized = fullPath.Replace('\\', '/');
                string normalizedRoot = Application.dataPath.Replace('\\', '/');
                if (!normalized.StartsWith(normalizedRoot + "/", StringComparison.Ordinal))
                {
                    errors.Add("Source path is outside the Assets directory: " + fullPath);
                    continue;
                }
                string assetPath = "Assets/" + normalized.Substring(normalizedRoot.Length + 1);
                RequireGuidRoundTrip(assetPath, errors);
                if (requiredAssetType == typeof(MonoScript) &&
                    AssetDatabase.LoadAssetAtPath<MonoScript>(assetPath) == null)
                    errors.Add("C# script has no imported MonoScript asset: " + assetPath);
            }
        }

        /// <summary>
        /// Verifies every compiled runtime MonoBehaviour maps back to a matching,
        /// correctly named Unity MonoScript. This catches classes hidden in a
        /// differently named .cs file that a source-only GUID scan cannot detect.
        /// </summary>
        private static void ValidateCompiledRuntimeComponentScripts(List<string> errors)
        {
            Type[] compiledTypes;
            try
            {
                compiledTypes = typeof(ChapterOneExperience).Assembly.GetTypes();
            }
            catch (System.Reflection.ReflectionTypeLoadException error)
            {
                errors.Add("Cannot enumerate compiled runtime component types: " + error.Message);
                return;
            }
            catch (Exception error)
            {
                errors.Add("Runtime assembly inspection failed: " + error.GetType().Name + ": " + error.Message);
                return;
            }

            int componentCount = 0;
            foreach (Type componentType in compiledTypes)
            {
                if (componentType == null || componentType.IsAbstract ||
                    componentType.ContainsGenericParameters ||
                    !typeof(MonoBehaviour).IsAssignableFrom(componentType))
                    continue;

                componentCount++;
                string sourcePath = SourceRoot + "/Runtime/" + componentType.Name + ".cs";
                MonoScript script = AssetDatabase.LoadAssetAtPath<MonoScript>(sourcePath);
                if (script == null)
                {
                    errors.Add("Runtime component has no matching MonoScript: " +
                        componentType.FullName + " expected at " + sourcePath);
                    continue;
                }

                Type importedType = script.GetClass();
                if (importedType != componentType)
                {
                    errors.Add("MonoScript resolves to an unexpected compiled class: " +
                        sourcePath + " expected " + componentType.FullName +
                        ", resolved " + (importedType == null ? "null" : importedType.FullName));
                }
                RequireGuidRoundTrip(sourcePath, errors);
            }
            if (componentCount == 0)
                errors.Add("Runtime assembly contains no inspectable MonoBehaviour components.");
        }

        /// <summary>
        /// Validates the imported project-owned dependencies of both generated scenes.
        /// Built-in Unity and external package dependencies are resolved by the Editor,
        /// so they are deliberately not treated as project GUID files.
        /// </summary>
        private static void ValidateImportedSceneDependencies(List<string> errors)
        {
            foreach (string scenePath in new[]
            {
                ChapterOneSceneBuilder.ScenePath,
                ChapterCaseSceneBuilder.ChapterTwoScene,
                ChapterCaseSceneBuilder.ChapterThreeScene,
                ChapterCaseSceneBuilder.ChapterFourScene
            })
            {
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath) == null)
                {
                    errors.Add("Generated scene cannot be imported: " + scenePath);
                    continue;
                }

                string[] dependencies;
                try
                {
                    dependencies = AssetDatabase.GetDependencies(scenePath, true);
                }
                catch (Exception error)
                {
                    errors.Add("Cannot enumerate scene asset dependencies for " + scenePath +
                        ": " + error.GetType().Name + ": " + error.Message);
                    continue;
                }

                foreach (string dependency in dependencies)
                {
                    if (string.IsNullOrEmpty(dependency))
                    {
                        errors.Add("Scene dependency returned an empty path: " + scenePath);
                        continue;
                    }
                    if (!dependency.StartsWith("Assets/", StringComparison.Ordinal))
                        continue;
                    // An imported asset outside this source tree cannot be relied on by
                    // the distributable project, even if it exists on the author's machine.
                    if (!dependency.StartsWith(SourceRoot + "/", StringComparison.Ordinal))
                    {
                        errors.Add("Scene depends on an asset outside the distributable source: " +
                            scenePath + " -> " + dependency);
                        continue;
                    }
                    if (AssetDatabase.LoadMainAssetAtPath(dependency) == null)
                    {
                        errors.Add("Imported scene dependency cannot be loaded: " +
                            scenePath + " -> " + dependency);
                    }
                    RequireGuidRoundTrip(dependency, errors);
                }
                ValidateSerializedSceneBindings(scenePath, errors);
            }
        }

        /// <summary>
        /// Inspect imported scene objects as well as asset paths. Dependency enumeration
        /// alone does not report a script or serialized reference that Unity failed to bind.
        /// This is editor-only and never mutates or re-saves a user scene.
        /// </summary>
        private static void ValidateSerializedSceneBindings(string scenePath, List<string> errors)
        {
            Scene scene = SceneManager.GetSceneByPath(scenePath);
            bool openedHere = !scene.IsValid() || !scene.isLoaded;
            Scene previous = SceneManager.GetActiveScene();
            try
            {
                if (openedHere)
                    scene = EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Additive);
                if (!scene.IsValid() || !scene.isLoaded)
                {
                    errors.Add("Imported scene could not be loaded for binding verification: " + scenePath);
                    return;
                }
                if (scene.isDirty)
                    errors.Add("Imported scene contains unsaved changes: " + scenePath);

                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    foreach (Transform item in root.GetComponentsInChildren<Transform>(true))
                    {
                        GameObject owner = item.gameObject;
                        if (GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(owner) != 0)
                            errors.Add("Scene GameObject has a missing script: " + scenePath + " -> " + owner.name);
                        foreach (MonoBehaviour behaviour in owner.GetComponents<MonoBehaviour>())
                        {
                            if (behaviour == null) continue;
                            Type actualType = behaviour.GetType();
                            if (actualType.FullName != null &&
                                actualType.FullName.StartsWith("TheOrderRoom.", StringComparison.Ordinal))
                            {
                                MonoScript source = MonoScript.FromMonoBehaviour(behaviour);
                                if (source == null || source.GetClass() != actualType)
                                    errors.Add("Scene component is not bound to its compiled MonoScript: " +
                                        scenePath + " -> " + actualType.FullName);
                                else
                                {
                                    string sourcePath = AssetDatabase.GetAssetPath(source);
                                    if (!sourcePath.StartsWith(SourceRoot + "/", StringComparison.Ordinal) ||
                                        !string.Equals(Path.GetFileNameWithoutExtension(sourcePath),
                                            actualType.Name, StringComparison.Ordinal))
                                        errors.Add("Scene component source name or location is invalid: " +
                                            scenePath + " -> " + actualType.FullName + " -> " + sourcePath);
                                    else
                                        RequireGuidRoundTrip(sourcePath, errors);
                                }
                            }
                        }
                        foreach (Component component in owner.GetComponents<Component>())
                        {
                            if (component == null) continue;
                            SerializedObject serialized = new SerializedObject(component);
                            SerializedProperty property = serialized.GetIterator();
                            while (property.NextVisible(true))
                            {
                                if (property.propertyType == SerializedPropertyType.ObjectReference &&
                                    property.objectReferenceValue == null &&
                                    property.objectReferenceInstanceIDValue != 0)
                                {
                                    errors.Add("Scene contains an unresolved serialized reference: " +
                                        scenePath + " -> " + owner.name + "/" +
                                        component.GetType().Name + "." + property.propertyPath);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception error)
            {
                errors.Add("Serialized scene binding audit failed: " + scenePath + " -> " +
                    error.GetType().Name + ": " + error.Message);
            }
            finally
            {
                if (openedHere && scene.IsValid() && scene.isLoaded)
                    EditorSceneManager.CloseScene(scene, true);
                if (previous.IsValid() && previous.isLoaded)
                    SceneManager.SetActiveScene(previous);
            }
        }

        private static void RequireImportedTexture(string path, List<string> errors)
        {
            Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (texture == null || texture.width != 1280 || texture.height != 720)
                errors.Add("Artwork is absent or has unexpected dimensions: " + path);
            RequireGuidRoundTrip(path, errors);
        }

        private static void RequireGuidRoundTrip(string path, List<string> errors)
        {
            string guid = AssetDatabase.AssetPathToGUID(path);
            if (string.IsNullOrEmpty(guid) ||
                !string.Equals(AssetDatabase.GUIDToAssetPath(guid), path, StringComparison.Ordinal))
                errors.Add("Asset GUID cannot resolve back to its source path: " + path);
        }
    }
}
#endif
