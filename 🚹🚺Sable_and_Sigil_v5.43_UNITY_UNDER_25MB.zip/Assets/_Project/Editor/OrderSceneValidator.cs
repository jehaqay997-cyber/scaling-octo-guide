#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace TheOrderRoom.Editor
{
    public static class OrderSceneValidator
    {
        public const string MainScene = "Assets/_Project/Scenes/Main.unity";
        [MenuItem("Legacy Diagnostics/TheOrderRoom/Validate Project & Scene")]
        public static void ValidateMenu()
        {
            var problems = ValidateProject();
            if (problems.Count == 0) Debug.Log("TheOrderRoom: structural scene validation passed. Runtime/device verification is separate.");
            else Debug.LogError("TheOrderRoom validation failed:\n" + string.Join("\n", problems));
        }
        public static List<string> ValidateProject()
        {
            var problems = new List<string>();
            foreach (string name in new[] { "sun", "moon", "star" })
                if (AssetDatabase.LoadAssetAtPath<Sprite>("Assets/_Project/Art/PNG/" + name + ".png") == null)
                    problems.Add("Missing imported sprite: " + name);
            if (!File.Exists(MainScene)) { problems.Add("Missing generated Main scene."); return problems; }
            Scene previous = SceneManager.GetActiveScene();
            Scene scene = SceneManager.GetSceneByPath(MainScene);
            bool opened = !scene.IsValid() || !scene.isLoaded;
            try
            {
                if (opened) scene = EditorSceneManager.OpenScene(MainScene, OpenSceneMode.Additive);
                if (scene.isDirty) problems.Add("Save Main scene before validation/build.");
                ValidateScene(scene, problems);
            }
            catch (Exception error) { problems.Add("Scene validation failed: " + error.GetType().Name + ": " + error.Message); }
            finally
            {
                if (opened && scene.IsValid() && scene.isLoaded) EditorSceneManager.CloseScene(scene, true);
                if (previous.IsValid() && previous.isLoaded) SceneManager.SetActiveScene(previous);
            }
            return problems;
        }
        private static T[] Components<T>(Scene scene) where T : Component =>
            scene.GetRootGameObjects().SelectMany(root => root.GetComponentsInChildren<T>(true)).ToArray();
        public static void ValidateScene(Scene scene, List<string> problems)
        {
            if (!scene.IsValid() || !scene.isLoaded) { problems.Add("Scene is not loaded."); return; }
            foreach (var root in scene.GetRootGameObjects())
                foreach (var transform in root.GetComponentsInChildren<Transform>(true))
                    if (GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(transform.gameObject) != 0)
                        problems.Add("Missing script: " + transform.name);
            var games = Components<OrderGame>(scene);
            if (games.Length != 1) { problems.Add("Expected exactly one OrderGame."); return; }
            var game = games[0];
            if (!game.enabled || !game.gameObject.activeInHierarchy) problems.Add("OrderGame is inactive.");
            var serialized = new SerializedObject(game);
            foreach (string name in new[] { "heading", "status", "collectionText", "revealText", "inspectionText",
                "pieces", "sceneCamera", "audioFeedback", "inspectionView", "rulesText", "rulesPanel" })
            {
                var property = serialized.FindProperty(name);
                if (property == null || property.objectReferenceValue == null) problems.Add("Unbound game reference: " + name);
                else
                {
                    var component = property.objectReferenceValue as Component;
                    var obj = property.objectReferenceValue as GameObject;
                    if ((component != null && component.gameObject.scene != scene) || (obj != null && obj.scene != scene))
                        problems.Add("Reference belongs to a different scene: " + name);
                }
            }
            var cameras = Components<Camera>(scene);
            if (cameras.Count(x => x.enabled && x.CompareTag("MainCamera")) != 1)
                problems.Add("Expected one enabled tagged main camera.");
            if (cameras.Count(x => x.enabled && x.CompareTag("MainCamera")) == 1)
            {
                var mainCamera = cameras.First(x => x.enabled && x.CompareTag("MainCamera"));
                if (mainCamera.orthographic || mainCamera.nearClipPlane <= 0f ||
                    mainCamera.farClipPlane <= mainCamera.nearClipPlane ||
                    mainCamera.fieldOfView <= 1f || mainCamera.fieldOfView >= 170f)
                    problems.Add("Invalid main camera projection or clipping planes.");
                if ((mainCamera.cullingMask & ArtifactInspectionView.InspectionMask) != 0)
                    problems.Add("Main camera must exclude the inspection-only layer.");
                if (serialized.FindProperty("sceneCamera")?.objectReferenceValue != mainCamera)
                    problems.Add("OrderGame must reference the active main camera.");
                if (mainCamera.GetComponent<AudioListener>() == null)
                    problems.Add("The main camera must own the scene's AudioListener.");
            }
            var views = Components<ArtifactInspectionView>(scene);
            if (views.Length != 1 || serialized.FindProperty("inspectionView")?.objectReferenceValue != views[0])
                problems.Add("Expected exactly one inspection controller linked to OrderGame.");
            else if ((views[0].gameObject.layer & 31) == ArtifactInspectionView.InspectionLayer)
                problems.Add("Inspection controller root must not be on the inspection-only rendering layer.");
            var systems = Components<EventSystem>(scene);
            if (systems.Length != 1)
                problems.Add("Expected exactly one EventSystem.");
            else if (!systems[0].isActiveAndEnabled)
                problems.Add("The EventSystem must be active and enabled.");
#if ENABLE_INPUT_SYSTEM
            else
            {
                var module = systems[0].GetComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
                if (module == null || !module.isActiveAndEnabled)
                    problems.Add("An active InputSystemUIInputModule is required for UI pointer events.");
                if (systems[0].GetComponents<BaseInputModule>().Count(x => x.isActiveAndEnabled) != 1)
                    problems.Add("Exactly one active UI input module is required.");
            }
#else
            else
            {
                var module = systems[0].GetComponent<StandaloneInputModule>();
                if (module == null || !module.isActiveAndEnabled)
                    problems.Add("An active StandaloneInputModule is required for UI pointer events.");
                if (systems[0].GetComponents<BaseInputModule>().Count(x => x.isActiveAndEnabled) != 1)
                    problems.Add("Exactly one active UI input module is required.");
            }
#endif
            var canvases = Components<Canvas>(scene);
            if (canvases.Length == 0) problems.Add("Missing Canvas.");
            else if (!canvases.Any(canvas => canvas.isActiveAndEnabled))
                problems.Add("No active and enabled Canvas is available for input.");
            foreach (var canvas in canvases.Where(x => x.isActiveAndEnabled))
            {
                if (!canvas.TryGetComponent<GraphicRaycaster>(out var raycaster) || !raycaster.isActiveAndEnabled)
                    problems.Add("Active Canvas lacks an active GraphicRaycaster: " + canvas.name);
            }
            var layouts = Components<OrderScreenLayout>(scene);
            if (layouts.Length != 1) problems.Add("Expected one responsive screen layout.");
            else
            {
                var layout = new SerializedObject(layouts[0]);
                foreach (string name in new[] { "boardCamera", "content", "scaler" })
                    if (layout.FindProperty(name).objectReferenceValue == null) problems.Add("Unbound layout reference: " + name);
                if (cameras.Count(x => x.enabled && x.CompareTag("MainCamera")) == 1 &&
                    layout.FindProperty("boardCamera")?.objectReferenceValue != cameras.First(x => x.enabled && x.CompareTag("MainCamera")))
                    problems.Add("Responsive layout must use the same active camera as OrderGame.");
                if (layout.FindProperty("content")?.objectReferenceValue is RectTransform rootContent &&
                    rootContent.GetComponentInParent<Canvas>() == null)
                    problems.Add("Responsive content root must be owned by a Canvas.");
            }
            var governors = Components<OrderPerformanceGovernor>(scene);
            if (governors.Length != 1)
                problems.Add("Expected one frame and energy governor.");
            else if (!governors[0].isActiveAndEnabled)
                problems.Add("The frame and energy governor must be active and enabled.");
            var audioProviders = Components<OrderAudioFeedback>(scene);
            if (audioProviders.Length != 1)
                problems.Add("Expected one initialized sound feedback provider.");
            else if (!audioProviders[0].isActiveAndEnabled)
                problems.Add("The audio feedback provider must be active and enabled.");
            var audioListeners = Components<AudioListener>(scene);
            if (audioListeners.Length != 1) problems.Add("Expected exactly one audio listener.");
            var pointers = Components<OrderPointerInput>(scene);
            if (pointers.Length != 1 || pointers[0].Game != game)
                problems.Add("Expected one pointer source bound to this game.");
            else if (!pointers[0].isActiveAndEnabled)
                problems.Add("The pointer source must be active and enabled.");
            var found = new HashSet<string>(StringComparer.Ordinal);
            foreach (var destination in Components<OrderDestination>(scene))
            {
                if (destination.Game != game || destination.Label == null) problems.Add("Unbound destination: " + destination.name);
                if (string.IsNullOrWhiteSpace(destination.Destination) || !found.Add(destination.Destination))
                    problems.Add("Invalid/duplicate destination: " + destination.name);
            }
            foreach (string id in new[] { "SUN", "MOON", "STAR", "SUN_A", "SUN_B", "MOON_A", "MOON_B", "STAR_A", "STAR_B", "TRAY" })
                if (!found.Contains(id)) problems.Add("Missing destination: " + id);
            // Presentation decorations are optional for gameplay but required for the authored
            // integrated scene. None may intercept UI or puzzle-world pointer events.
            foreach (string name in new[] { "Upper Archive Header", "Lower Control Deck" })
            {
                var matches = Components<Image>(scene).Where(image => image.name == name).ToArray();
                if (matches.Length != 1 || !matches[0].isActiveAndEnabled || matches[0].raycastTarget ||
                    matches[0].GetComponentInParent<Canvas>() == null)
                    problems.Add("Invalid non-interactive UI decoration: " + name);
            }
            foreach (string name in new[] { "North Inlay", "South Inlay", "East Inlay", "West Inlay" })
            {
                var matches = Components<MeshRenderer>(scene).Where(renderer => renderer.name == name).ToArray();
                if (matches.Length != 1 || !matches[0].enabled ||
                    matches[0].GetComponent<Collider>() != null)
                    problems.Add("Invalid collider-free board inlay: " + name);
            }
            // Validate each button and its exact persistent callback; a name-only callback set
            // cannot detect swapped controls, duplicate handlers, or disabled events.
            var requiredButtons = new Dictionary<string, string>(StringComparer.Ordinal)
            {
                { "RESET", "ResetBoard" }, { "UNDO", "Undo" }, { "REDO", "Redo" },
                { "NEXT", "NextLevel" }, { "RULES", "ShowRules" }, { "HINT", "Hint" },
                { "FOCUS +", "FocusIn" }, { "FOCUS -", "FocusOut" },
                { "INSPECT", "InspectArtifact" }, { "TURN LEFT", "TurnArtifactLeft" },
                { "TURN RIGHT", "TurnArtifactRight" }, { "SCAN", "ScanArtifact" },
                { "CLAIM", "ClaimArtifact" }
            };
            var observedButtons = new HashSet<string>(StringComparer.Ordinal);
            foreach (var button in Components<Button>(scene))
            {
                if (!requiredButtons.TryGetValue(button.gameObject.name, out var expectedMethod))
                {
                    problems.Add("Unrecognized interactive button: " + button.gameObject.name);
                    continue;
                }
                if (!observedButtons.Add(button.gameObject.name))
                {
                    problems.Add("Duplicate interactive button: " + button.gameObject.name);
                    continue;
                }
                if (!button.gameObject.activeInHierarchy || !button.enabled || !button.interactable)
                    problems.Add("Inactive or disabled interactive button: " + button.gameObject.name);
                if (button.targetGraphic == null || !button.targetGraphic.isActiveAndEnabled ||
                    !button.targetGraphic.raycastTarget)
                    problems.Add("Button has no active raycast target graphic: " + button.gameObject.name);
                var parentCanvas = button.GetComponentInParent<Canvas>();
                if (parentCanvas == null || !parentCanvas.isActiveAndEnabled ||
                    !parentCanvas.TryGetComponent<GraphicRaycaster>(out var buttonRaycaster) ||
                    !buttonRaycaster.isActiveAndEnabled)
                    problems.Add("Button does not belong to a raycast-capable Canvas: " + button.gameObject.name);
                if (button.onClick.GetPersistentEventCount() != 1 ||
                    button.onClick.GetPersistentTarget(0) != game ||
                    button.onClick.GetPersistentMethodName(0) != expectedMethod ||
                    (button.onClick.GetPersistentListenerState(0) != UnityEngine.Events.UnityEventCallState.RuntimeOnly &&
                     button.onClick.GetPersistentListenerState(0) != UnityEngine.Events.UnityEventCallState.EditorAndRuntime))
                    problems.Add("Invalid button callback: " + button.gameObject.name + " -> " + expectedMethod);
            }
            foreach (var pair in requiredButtons)
                if (!observedButtons.Contains(pair.Key))
                    problems.Add("Missing interactive button: " + pair.Key);
        }
    }
}
#endif
