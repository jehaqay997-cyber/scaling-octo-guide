#if UNITY_EDITOR
using System.Collections.Generic;
using TheOrderRoom.Domain;
using UnityEditor;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Editor-only import and material preflight for the procedural 3D case prototypes.
    /// This never marks actual rendering, controls, or device behavior as verified.
    /// </summary>
    public static class ChapterWorldPrototypeValidator
    {
        [MenuItem("Sable & Sigil/Validate 3D Case Prototypes")]
        public static void ValidateMenu()
        {
            List<string> problems = ValidateAssets();
            if (problems.Count == 0)
                Debug.Log("All ten 3D prototype contracts and reference assets imported. PlayMode verification is still required.");
            else
                Debug.LogError("3D prototype preflight failed:\n" + string.Join("\n", problems));
        }

        public static List<string> ValidateAssets()
        {
            var problems = new List<string>();
            if (!ChapterWorldSceneCatalog.Validate(out string graphError))
            {
                problems.Add(graphError);
                return problems;
            }
            if (!CinematicSceneMap.Validate(out string scenicError))
                problems.Add(scenicError);
            if (!CinematicEnvironmentCatalog.Validate(out string artContractError))
                problems.Add(artContractError);
            for (int number = 1; number <= ChapterWorldSceneCatalog.PrototypeCount; number++)
            {
                ChapterWorldSceneSpec spec = ChapterWorldSceneCatalog.Get(number);
                string path = "Assets/_Project/Resources/" + spec.ArtResource + ".jpg";
                Texture2D texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
                if (texture == null)
                {
                    problems.Add("Missing imported 3D location artwork: " + path);
                    continue;
                }
                if (texture.width != 1280 || texture.height != 720)
                    problems.Add("Invalid location image dimensions: " + path);
                var importer = AssetImporter.GetAtPath(path) as TextureImporter;
                if (importer == null || importer.textureType != TextureImporterType.Default)
                    problems.Add("Location image must import as Texture2D, not sprite: " + path);
            }
            string approvedPath = "Assets/_Project/Resources/CinematicLocations/Location_01.png";
            Texture2D approvedScene = AssetDatabase.LoadAssetAtPath<Texture2D>(approvedPath);
            if (approvedScene == null || approvedScene.width < 1600 || approvedScene.height < 900)
                problems.Add("Missing or undersized quality-approved cinematic entrance: " + approvedPath);
            TextureImporter approvedImporter = AssetImporter.GetAtPath(approvedPath) as TextureImporter;
            if (approvedImporter == null || approvedImporter.isReadable || approvedImporter.mipmapEnabled)
                problems.Add("Full-bleed scene must import without CPU readback or mipmaps: " + approvedPath);
            // Reject a missing production plate before scene creation claims success.
            // The original ten reference JPEGs remain independently validated above.
            foreach (int location in new[] { 2, 4, 5, 7, 10 })
            {
                if (!CinematicEnvironmentCatalog.TryGetFeatured(location, out CinematicEnvironmentSpec scene))
                {
                    problems.Add("Featured narrative scene contract missing: " + location);
                    continue;
                }
                string assetPath = "Assets/_Project/Resources/" + scene.ResourcePath + ".jpg";
                Texture2D art = AssetDatabase.LoadAssetAtPath<Texture2D>(assetPath);
                if (art == null || art.width < 1600 || art.height < 900)
                    problems.Add("Required imported cinematic background is missing or undersized: " + assetPath);
                TextureImporter importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
                if (importer == null || importer.textureType != TextureImporterType.Default ||
                    importer.isReadable || importer.mipmapEnabled)
                    problems.Add("Cinematic background has an unsafe texture import contract: " + assetPath);
            }
            if (Shader.Find("Standard") == null && Shader.Find("Unlit/Color") == null)
                problems.Add("No compatible procedural 3D surface shader is available.");
            if (Shader.Find("Unlit/Texture") == null && Shader.Find("Standard") == null)
                problems.Add("No compatible original-art reference shader is available.");
            return problems;
        }
    }
}
#endif
