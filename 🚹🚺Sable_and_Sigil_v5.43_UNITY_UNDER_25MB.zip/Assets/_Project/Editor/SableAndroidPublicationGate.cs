#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Blocks Android production builds until required Google Play settings are explicit.
    /// This is a configuration gate, not proof that the generated bundle is publishable.
    /// </summary>
    public sealed class SableAndroidPublicationGate : IPreprocessBuildWithReport
    {
        private const int RequiredTargetSdk = 36;
        private const string RequiredEditor = "2022.3.62f3";
        private const string ProjectPrefix = "Sable & Sigil";

        public int callbackOrder => -1000;

        public void OnPreprocessBuild(BuildReport report)
        {
            if (report == null)
                throw new ArgumentNullException(nameof(report));
            if (report.summary.platform != BuildTarget.Android)
                return;
            if ((report.summary.options & BuildOptions.Development) != 0)
                return;

            RequirePublicationReady();
        }

        [MenuItem("Sable & Sigil/Android/Validate Google Play Configuration")]
        public static void ValidateMenu()
        {
            RequirePublicationReady();
            Debug.Log("SABLE_ANDROID_CONFIGURATION_PASS: Configuration only; inspect the final AAB and test on hardware.");
        }

        public static void ValidateBatch()
        {
            RequirePublicationReady();
            Debug.Log("SABLE_ANDROID_CONFIGURATION_PASS: Configuration only; no build or device verification was performed.");
        }

        public static void RequirePublicationReady()
        {
            var problems = CollectProblems();
            if (problems.Count > 0)
                throw new BuildFailedException(ProjectPrefix + " Android publication blocked:\n" +
                    string.Join("\n", problems));
        }

        public static List<string> CollectProblems()
        {
            var issues = new List<string>();
            if (!string.Equals(Application.unityVersion, RequiredEditor, StringComparison.Ordinal))
                issues.Add("The source is pinned to Unity " + RequiredEditor +
                    "; validate the build in that editor before updating the compatibility baseline.");

            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
                issues.Add("Switch the active build target to Android.");

            if (PlayerSettings.GetScriptingBackend(BuildTargetGroup.Android) != ScriptingImplementation.IL2CPP)
                issues.Add("Use the IL2CPP scripting backend for Android publication.");

            if ((PlayerSettings.Android.targetArchitectures & AndroidArchitecture.ARM64) == 0)
                issues.Add("Include ARM64 in Android target architectures.");

            var requestedSdk = PlayerSettings.Android.targetSdkVersion.ToString();
            int api;
            if (!TryParseExplicitApi(requestedSdk, out api))
                issues.Add("Target API must be explicitly selected and verified as API 36 or higher. " +
                    "Auto is not sufficient release evidence. Current setting: " + requestedSdk);
            else if (api < RequiredTargetSdk)
                issues.Add("Target API " + api.ToString(CultureInfo.InvariantCulture) +
                    " is below Google Play's Android 16 / API 36 requirement.");

            if (!EditorUserBuildSettings.buildAppBundle)
                issues.Add("Enable Android App Bundle (.aab) for Google Play publication.");

            if (PlayerSettings.Android.bundleVersionCode < 1)
                issues.Add("Set a positive Android bundle version code.");

            if (EditorBuildSettings.scenes == null || EditorBuildSettings.scenes.Length == 0)
                issues.Add("No build scenes are registered; generate and validate all chapter scenes first.");

            return issues;
        }

        private static bool TryParseExplicitApi(string name, out int api)
        {
            api = 0;
            const string prefix = "AndroidApiLevel";
            if (string.IsNullOrEmpty(name) || !name.StartsWith(prefix, StringComparison.Ordinal))
                return false;
            var text = name.Substring(prefix.Length);
            return int.TryParse(text, NumberStyles.None, CultureInfo.InvariantCulture, out api) && api > 0;
        }
    }
}
#endif
