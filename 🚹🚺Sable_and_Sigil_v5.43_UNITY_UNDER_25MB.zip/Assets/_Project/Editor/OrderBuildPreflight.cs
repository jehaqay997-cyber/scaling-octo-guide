#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

namespace TheOrderRoom.Editor
{
    public static class OrderBuildPreflight
    {
        [MenuItem("Legacy Diagnostics/TheOrderRoom/Validate Commercial Prototype")]
        public static void Validate() => OrderSceneValidator.ValidateMenu();
    }

    /// <summary>
    /// Enforces the same imported-source, generated-scene and callback requirements
    /// for all player builds as the explicit editor acceptance entry point.
    /// </summary>
    public sealed class OrderBuildGate : IPreprocessBuildWithReport
    {
        public int callbackOrder => 0;

        public void OnPreprocessBuild(BuildReport report)
        {
            if (report == null)
                throw new BuildFailedException("A Unity BuildReport is required for launch preflight.");

            try
            {
                SableLaunchAcceptance.RequireImportedSourceAndScenes();
            }
            catch (Exception error)
            {
                throw new BuildFailedException(
                    "Sable & Sigil player build blocked by imported-source or scene validation: " +
                    error.GetType().Name + ": " + error.Message);
            }

            var routeErrors = SableChapterBuildRoute.Validate();
            if (routeErrors.Count > 0)
                throw new BuildFailedException("Noncanonical shipping scene route: " +
                    string.Join("; ", routeErrors));
        }
    }
}
#endif
