#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Fail-closed Editor validation for the Sable & Sigil launch baseline.
    /// This validates imported source and generated scenes, not game runtime or hardware.
    /// </summary>
    public static class SableLaunchAcceptance
    {
        public const string SuccessMarker = "SABLE_SIGIL_LAUNCH_PREFLIGHT_PASS";

        [MenuItem("Sable & Sigil/Prepare and Validate Playable Chapter")]
        public static void PrepareInteractive()
        {
            if (Application.isBatchMode || EditorApplication.isCompiling ||
                EditorApplication.isUpdating || EditorApplication.isPlayingOrWillChangePlaymode)
            {
                throw new InvalidOperationException("The Editor must be idle before preparing the launch scene.");
            }

            // A declined Save dialog is never treated as a successful launch.
            ChapterOneSceneBuilder.EnsureChapterOne(true);
            ChapterCaseSceneBuilder.EnsureCaseScenes();
            if (SceneManager.GetActiveScene().path != ChapterOneSceneBuilder.ScenePath)
            {
                Debug.LogWarning("Sable & Sigil: the authored scene was not activated; keep the current unsaved scene.");
                return;
            }

            RequireImportedSourceAndScenes();
            Debug.Log("SABLE_SIGIL_EDITOR_PREPARED_NOT_TEST_VERIFIED");
        }

        /// <summary>Entry point for Unity -batchmode -executeMethod. A failure throws and emits no success marker.</summary>
        public static void PrepareAndValidateBatch()
        {
            if (!Application.isBatchMode)
            {
                throw new InvalidOperationException("PrepareAndValidateBatch requires Unity batch mode.");
            }

            ChapterOneSceneBuilder.EnsureChapterOne(false);
            ChapterCaseSceneBuilder.EnsureCaseScenes();
            RequireImportedSourceAndScenes();
            Debug.Log(SuccessMarker);
        }

        public static void RequireImportedSourceAndScenes()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                throw new InvalidOperationException("Editor source import or compilation is still active.");
            }

            List<string> problems = new List<string>();
            problems.AddRange(ChapterWorldPrototypeValidator.ValidateAssets());
            problems.AddRange(SableAssetReferenceValidator.ValidateImportedReferences());

            string chapterPath = ChapterOneSceneBuilder.ScenePath;
            string secondPath = ChapterCaseSceneBuilder.ChapterTwoScene;
            string thirdPath = ChapterCaseSceneBuilder.ChapterThreeScene;
            string fourthPath = ChapterCaseSceneBuilder.ChapterFourScene;
            if (!File.Exists(chapterPath) ||
                AssetDatabase.LoadAssetAtPath<SceneAsset>(chapterPath) == null)
            {
                problems.Add("Chapter One scene has not been generated and imported.");
            }
            foreach (string path in new[] { secondPath, thirdPath, fourthPath })
                if (!File.Exists(path) || AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
                    problems.Add("Chapter case scene has not been generated and imported: " + path);

            problems.AddRange(SableChapterBuildRoute.Validate());
            foreach (string path in new[] { secondPath, thirdPath, fourthPath })
            {
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) != null)
                    ValidateCaseScene(path, path == secondPath ? 2 : path == thirdPath ? 3 : 4, problems);
            }

            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(chapterPath) != null)
            {
                ValidateChapterScene(chapterPath, problems);
            }

            if (problems.Count > 0)
            {
                throw new InvalidOperationException(
                    "Sable & Sigil launch source preflight failed:\n" + string.Join("\n", problems));
            }
        }

        private static void ValidateCaseScene(string path, int chapterNumber, List<string> problems)
        {
            Scene scene = SceneManager.GetSceneByPath(path);
            bool openedHere = !scene.IsValid() || !scene.isLoaded;
            Scene previous = SceneManager.GetActiveScene();
            try
            {
                if (openedHere) scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Additive);
                if (!scene.IsValid() || !scene.isLoaded)
                {
                    problems.Add("Cannot load chapter case scene: " + path);
                    return;
                }
                if (scene.isDirty) problems.Add("Chapter case scene has unsaved changes: " + path);
                GameObject[] roots = scene.GetRootGameObjects();
                ChapterCaseSceneBootstrap[] bootstraps = roots.SelectMany(root =>
                    root.GetComponentsInChildren<ChapterCaseSceneBootstrap>(true)).ToArray();
                ChapterGalleryView[] galleries = roots.SelectMany(root =>
                    root.GetComponentsInChildren<ChapterGalleryView>(true)).ToArray();
                if (bootstraps.Length != 1 || !bootstraps[0].isActiveAndEnabled ||
                    bootstraps[0].ChapterNumber != chapterNumber || galleries.Length != 1 ||
                    galleries[0].gameObject != bootstraps[0].gameObject)
                    problems.Add("Chapter " + chapterNumber + " requires one enabled case bootstrap and gallery.");
                foreach (GameObject root in roots)
                    foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
                        if (GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(child.gameObject) > 0)
                            problems.Add("Missing script in " + path + " on " + child.name);
            }
            catch (Exception error)
            {
                problems.Add("Chapter " + chapterNumber + " scene inspection failed: " + error.Message);
            }
            finally
            {
                if (openedHere && scene.IsValid() && scene.isLoaded)
                    EditorSceneManager.CloseScene(scene, true);
                if (previous.IsValid() && previous.isLoaded)
                    SceneManager.SetActiveScene(previous);
            }
        }

        private static void ValidateChapterScene(string chapterPath, List<string> problems)
        {
            Scene chapter = SceneManager.GetSceneByPath(chapterPath);
            bool openedHere = !chapter.IsValid() || !chapter.isLoaded;
            Scene previous = SceneManager.GetActiveScene();
            try
            {
                if (openedHere)
                {
                    chapter = EditorSceneManager.OpenScene(chapterPath, OpenSceneMode.Additive);
                }
                if (!chapter.IsValid() || !chapter.isLoaded)
                {
                    problems.Add("Chapter One scene could not be loaded.");
                    return;
                }
                if (chapter.isDirty)
                {
                    problems.Add("Chapter One contains unsaved changes.");
                }

                GameObject[] roots = chapter.GetRootGameObjects();
                ChapterOneExperience[] controllers = roots
                    .SelectMany(root => root.GetComponentsInChildren<ChapterOneExperience>(true))
                    .ToArray();
                if (controllers.Length != 1 || !controllers[0].enabled ||
                    !controllers[0].gameObject.activeInHierarchy)
                {
                    problems.Add("Chapter One needs exactly one active ChapterOneExperience.");
                }
                foreach (GameObject root in roots)
                {
                    foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
                    {
                        if (GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(child.gameObject) > 0)
                        {
                            problems.Add("Chapter One contains a missing script on " + child.name);
                        }
                    }
                }
            }
            catch (Exception error)
            {
                problems.Add("Chapter One inspection failed: " + error.GetType().Name + ": " + error.Message);
            }
            finally
            {
                if (openedHere && chapter.IsValid() && chapter.isLoaded)
                {
                    EditorSceneManager.CloseScene(chapter, true);
                }
                if (previous.IsValid() && previous.isLoaded)
                {
                    SceneManager.SetActiveScene(previous);
                }
            }
        }
    }
}
#endif
