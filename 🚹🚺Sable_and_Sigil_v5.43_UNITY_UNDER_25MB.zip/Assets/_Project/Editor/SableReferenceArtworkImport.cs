using System;
using UnityEditor;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Import authored reference photographs for screen-space previews and world
    /// materials. The source JPEG bytes remain unchanged and CPU texture copies
    /// are not retained after GPU upload.
    /// </summary>
    public sealed class SableReferenceArtworkImport : AssetPostprocessor
    {
        private void OnPreprocessTexture()
        {
            bool chapterArt = assetPath.StartsWith("Assets/_Project/Resources/ChapterArt/", StringComparison.Ordinal);
            bool locationArt = assetPath.StartsWith("Assets/_Project/Resources/LocationArt/", StringComparison.Ordinal);
            if ((!chapterArt && !locationArt) ||
                !assetPath.EndsWith(".jpg", StringComparison.OrdinalIgnoreCase)) return;

            var importer = assetImporter as TextureImporter;
            if (importer == null) return;
            importer.textureType = TextureImporterType.Default;
            importer.sRGBTexture = true;
            importer.isReadable = false;
            // World investigation uses oblique perspective surfaces, so preserve
            // mipmaps to prevent aliasing rather than stripping them globally.
            importer.mipmapEnabled = true;
            importer.wrapMode = TextureWrapMode.Clamp;
            importer.filterMode = FilterMode.Trilinear;
            importer.textureCompression = TextureImporterCompression.Compressed;
            importer.maxTextureSize = 2048;
        }
    }
}
