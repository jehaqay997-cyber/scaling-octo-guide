using System.Collections;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterStoryIntegrationTests
    {
        private const string ScenePath = "Assets/_Project/Scenes/ChapterOne.unity";

        [UnityTest]
        public IEnumerator SceneAtlas_ExposesAuthoredHintsWithoutUnlockingPreviews()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            ChapterGalleryView gallery = null;
            try
            {
                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(3, new[] { 1, 2, 3 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();

                var operation = SceneManager.LoadSceneAsync(ScenePath, LoadSceneMode.Single);
                Assert.That(operation, Is.Not.Null);
                while (!operation.isDone) yield return null;
                yield return null;

                var experience = Object.FindObjectOfType<ChapterOneExperience>();
                Assert.That(experience, Is.Not.Null);
                Assert.That(experience.IsChapterReady, Is.True);
                gallery = experience.GetComponent<ChapterGalleryView>();
                if (gallery == null) gallery = experience.gameObject.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectLocation(4);

                var hint = System.Array.Find(gallery.GetComponentsInChildren<Button>(true),
                    button => button.name == "SCENE HINT");
                var details = System.Array.Find(gallery.GetComponentsInChildren<Text>(true),
                    label => label.name == "Selected Chapter Description");
                var enter = System.Array.Find(gallery.GetComponentsInChildren<Button>(true),
                    button => button.name == "ENTER CHAPTER I");
                Assert.That(hint, Is.Not.Null);
                Assert.That(details, Is.Not.Null);
                Assert.That(enter, Is.Not.Null);
                Assert.That(hint.gameObject.activeSelf, Is.True);
                Assert.That(hint.interactable, Is.True);
                Assert.That(enter.interactable, Is.False);

                var scene = ChapterStoryGraph.GetLocation(4);
                Assert.That(details.text, Does.Contain(scene.Mechanism.Replace('-', ' ').ToUpperInvariant()));
                Assert.That(details.text, Does.Not.Contain(scene.HintTiers[0]));
                hint.onClick.Invoke();
                Assert.That(details.text, Does.Contain(scene.HintTiers[0]));
                hint.onClick.Invoke();
                Assert.That(details.text, Does.Contain(scene.HintTiers[1]));
                hint.onClick.Invoke();
                Assert.That(details.text, Does.Contain(scene.HintTiers[2]));
                Assert.That(hint.interactable, Is.False);
                hint.onClick.Invoke();
                Assert.That(details.text, Does.Contain(scene.HintTiers[2]));
                Assert.That(details.text, Does.Not.Contain(scene.HintTiers[0]));

                gallery.SelectLocation(5);
                Assert.That(hint.interactable, Is.False);
                Assert.That(details.text,
                    Does.Not.Contain(ChapterStoryGraph.GetLocation(5).HintTiers[0]));
                gallery.SelectChapter(1);
                Assert.That(hint.gameObject.activeSelf, Is.False);
            }
            finally
            {
                if (gallery != null) gallery.Close();
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
        }

        [UnityTest]
        public IEnumerator ChapterRestoresRenderSettingsAndReusedCameraAfterUnload()
        {
            var operation = SceneManager.LoadSceneAsync(ScenePath, LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null);
            while (!operation.isDone) yield return null;
            yield return null;
            var initialChapter = Object.FindObjectOfType<ChapterOneExperience>();
            Assert.That(initialChapter, Is.Not.Null);
            Object.Destroy(initialChapter.gameObject);
            yield return null;

            Color oldAmbient = RenderSettings.ambientLight;
            bool oldFog = RenderSettings.fog;
            Color oldFogColor = RenderSettings.fogColor;
            FogMode oldFogMode = RenderSettings.fogMode;
            float oldDensity = RenderSettings.fogDensity;
            GameObject cameraObject = null;
            GameObject chapterObject = null;
            try
            {
                cameraObject = new GameObject("Restoration Test Main Camera");
                cameraObject.tag = "MainCamera";
                var camera = cameraObject.AddComponent<Camera>();
                camera.transform.position = new Vector3(13f, 9f, -7f);
                camera.transform.rotation = Quaternion.Euler(8f, 33f, 5f);
                camera.fieldOfView = 38f;
                camera.clearFlags = CameraClearFlags.Depth;
                camera.backgroundColor = Color.magenta;
                Vector3 originalPosition = camera.transform.position;
                Quaternion originalRotation = camera.transform.rotation;

                chapterObject = new GameObject("Transient Chapter");
                var chapter = chapterObject.AddComponent<ChapterOneExperience>();
                Assert.That(chapter.IsChapterReady, Is.True);
                Assert.That(camera.transform.position, Is.Not.EqualTo(originalPosition));
                Object.Destroy(chapterObject);
                chapterObject = null;
                yield return null;

                Assert.That(camera.transform.position, Is.EqualTo(originalPosition));
                Assert.That(camera.transform.rotation, Is.EqualTo(originalRotation));
                Assert.That(camera.fieldOfView, Is.EqualTo(38f).Within(.001f));
                Assert.That(camera.clearFlags, Is.EqualTo(CameraClearFlags.Depth));
                Assert.That(camera.backgroundColor, Is.EqualTo(Color.magenta));
                Assert.That(RenderSettings.ambientLight, Is.EqualTo(oldAmbient));
                Assert.That(RenderSettings.fog, Is.EqualTo(oldFog));
                Assert.That(RenderSettings.fogColor, Is.EqualTo(oldFogColor));
                Assert.That(RenderSettings.fogMode, Is.EqualTo(oldFogMode));
                Assert.That(RenderSettings.fogDensity, Is.EqualTo(oldDensity).Within(.00001f));
            }
            finally
            {
                if (chapterObject != null) Object.Destroy(chapterObject);
                if (cameraObject != null) Object.Destroy(cameraObject);
                RenderSettings.ambientLight = oldAmbient;
                RenderSettings.fog = oldFog;
                RenderSettings.fogColor = oldFogColor;
                RenderSettings.fogMode = oldFogMode;
                RenderSettings.fogDensity = oldDensity;
            }
        }
    }
}
