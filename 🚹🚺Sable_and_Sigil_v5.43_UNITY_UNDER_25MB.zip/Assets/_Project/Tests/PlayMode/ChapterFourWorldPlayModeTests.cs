using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterFourWorldPlayModeTests
    {
        [UnityTest]
        public IEnumerator MeridianRequiresBothRecordsAndTwoPhysicalSwapsBeforeDossier()
        {
            var host = new GameObject("Chapter Four Meridian Integration Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            Texture2D art = Resources.Load<Texture2D>(
                ChapterWorldSceneCatalog.Get(10).ArtResource);
            Assert.IsNotNull(art);
            int accepted = 0;
            MethodInfo finish = typeof(ChapterWorldExplorer).GetMethod("Finish",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(finish);
            try
            {
                world.Open(10, art, (location, toDossier, a, b) =>
                {
                    Assert.AreEqual(10, location);
                    Assert.IsTrue(toDossier && a && b);
                    accepted++;
                });
                Assert.IsFalse(world.CanDeduce);
                Assert.IsFalse(world.TryOpenChapterFourViewer());
                Assert.AreEqual(MeridianMoveResult.Invalid, world.TrySelectChapterFourPosition(0));
                var relief = world.GetComponentsInChildren<MeshFilter>(true)
                    .Single(item => item.name == "Meridian Four-Ring Physical Relief");
                Mesh original = relief.sharedMesh;
                int lockedTriangles = original.triangles.Length;
                Assert.IsTrue(world.TryInspectEvidence(0));
                Assert.IsFalse(world.TryOpenChapterFourViewer());
                Assert.AreEqual(lockedTriangles, original.triangles.Length);
                Assert.IsTrue(world.TryInspectEvidence(1));
                Assert.IsFalse(world.CanDeduce);
                Assert.IsTrue(world.TryOpenChapterFourViewer());
                Assert.AreEqual(MeridianMoveResult.Selected, world.TrySelectChapterFourPosition(0));
                Assert.AreEqual(MeridianMoveResult.Swapped, world.TrySelectChapterFourPosition(1));
                Assert.AreEqual("ABDC", world.ChapterFourOrder);
                Assert.IsFalse(world.CanDeduce);
                Assert.AreSame(original, relief.sharedMesh);
                Assert.AreNotEqual(lockedTriangles, original.triangles.Length);
                Assert.AreEqual(MeridianMoveResult.Selected, world.TrySelectChapterFourPosition(2));
                Assert.AreEqual(MeridianMoveResult.Verified, world.TrySelectChapterFourPosition(3));
                Assert.AreEqual("ABCD", world.ChapterFourOrder);
                Assert.IsTrue(world.IsChapterFourVerified);
                Assert.IsTrue(world.CanDeduce);
                Assert.IsFalse(world.TryInspectEvidence(0));
                finish.Invoke(world, new object[] { true });
                Assert.AreEqual(0, accepted);
                world.CloseChapterFourViewer();
                finish.Invoke(world, new object[] { true });
                Assert.AreEqual(1, accepted);
                Assert.IsFalse(world.IsOpen);
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator MissingReliefDuringCommittedSwapFailsClosedWithoutAwardingProgress()
        {
            var host = new GameObject("Chapter Four Visual Integrity Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            Texture2D art = Resources.Load<Texture2D>(
                ChapterWorldSceneCatalog.Get(ChapterFourMeridianPuzzle.LocationNumber).ArtResource);
            Assert.IsNotNull(art);
            int completed = 0;
            MethodInfo finish = typeof(ChapterWorldExplorer).GetMethod("Finish",
                BindingFlags.Instance | BindingFlags.NonPublic);
            FieldInfo reliefField = typeof(ChapterWorldExplorer).GetField("chapterFourReliefMesh",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(finish);
            Assert.IsNotNull(reliefField);
            try
            {
                world.Open(ChapterFourMeridianPuzzle.LocationNumber, art,
                    (number, toDossier, first, second) => completed++);
                Assert.IsTrue(world.TryInspectEvidence(0));
                Assert.IsTrue(world.TryInspectEvidence(1));
                Assert.IsTrue(world.TryOpenChapterFourViewer());
                Assert.AreEqual(MeridianMoveResult.Selected, world.TrySelectChapterFourPosition(0));
                Assert.AreEqual(MeridianMoveResult.Swapped, world.TrySelectChapterFourPosition(1));
                Assert.AreEqual(MeridianMoveResult.Selected, world.TrySelectChapterFourPosition(2));
                reliefField.SetValue(world, null);
                UnityEngine.TestTools.LogAssert.Expect(LogType.Exception,
                    new System.Text.RegularExpressions.Regex("Chapter Four relief is unavailable"));
                Assert.AreEqual(MeridianMoveResult.Invalid, world.TrySelectChapterFourPosition(3));
                Assert.IsTrue(world.IsChapterFourVisualDesynchronized);
                Assert.IsFalse(world.IsChapterFourVerified);
                Assert.IsFalse(world.CanDeduce);
                Assert.AreEqual(MeridianMoveResult.Invalid, world.TrySelectChapterFourPosition(0));
                world.CloseChapterFourViewer();
                finish.Invoke(world, new object[] { true });
                Assert.AreEqual(0, completed);
                Assert.IsTrue(world.IsOpen);
                world.Close();
                world.Open(ChapterFourMeridianPuzzle.LocationNumber, art,
                    (number, toDossier, first, second) => completed++);
                Assert.IsFalse(world.IsChapterFourVisualDesynchronized);
                Assert.AreEqual("BADC", world.ChapterFourOrder);
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator BackClosesMeridianBeforeWorldAndResetClearsTransientWork()
        {
            var host = new GameObject("Chapter Four Back Isolation Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            Texture2D art = Resources.Load<Texture2D>(
                ChapterWorldSceneCatalog.Get(10).ArtResource);
            Assert.IsNotNull(art);
            try
            {
                world.Open(10, art, (n, d, a, b) => { });
                Assert.IsTrue(world.TryInspectEvidence(0));
                Assert.IsTrue(world.TryInspectEvidence(1));
                Assert.IsTrue(world.TryOpenChapterFourViewer());
                Assert.IsTrue(world.TryNavigateChapterFourBack());
                Assert.IsTrue(world.IsOpen);
                Assert.IsFalse(world.IsChapterFourOpen);
                Assert.IsTrue(world.TryNavigateChapterFourBack());
                Assert.IsFalse(world.IsOpen);
                world.Open(10, art, (n, d, a, b) => { });
                Assert.IsFalse(world.CanDeduce);
                Assert.AreEqual("BADC", world.ChapterFourOrder);
                Assert.AreEqual(0, world.ChapterFourAttempts);
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }
    }
}
