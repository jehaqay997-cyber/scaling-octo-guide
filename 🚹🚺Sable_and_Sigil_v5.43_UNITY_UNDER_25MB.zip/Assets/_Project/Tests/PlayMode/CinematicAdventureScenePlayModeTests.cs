using System;
using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class CinematicAdventureScenePlayModeTests
    {
        [UnityTest]
        public IEnumerator PhotographicModeIsDefaultAndReversibleWithoutAwardingProgress()
        {
            var host = new GameObject("Cinematic Location Verification");
            var explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                foreach (int location in new[] { 1, 2, 4, 5, 7, 10 })
                {
                    Texture2D original = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.NotNull(original);
                    explorer.Open(location, original, (number, deduction, a, b) => { });
                    Assert.IsTrue(explorer.IsScenicMode);
                    Assert.IsFalse(explorer.SceneCamera.enabled,
                        "The hidden 3D camera must not consume a second render pass.");
                    RawImage photograph = explorer.GetComponentsInChildren<RawImage>(true)
                        .Single(image => image.name == "Original Cinematic Environment");
                    Texture2D approved = Resources.Load<Texture2D>(
                        "CinematicLocations/Location_" + location.ToString("00"));
                    Assert.AreSame(approved != null ? approved : original, photograph.texture);
                    Assert.IsTrue(explorer.TryZoomScenery(.12f));
                    Assert.Greater(explorer.ScenicZoom, 1f);
                    Assert.IsTrue(explorer.TryPanScenery(28f, -20f));
                    Assert.IsFalse(explorer.TryPanScenery(float.NaN, 2f));
                    Assert.AreEqual(new Rect(0f, 0f, 1f, 1f), photograph.uvRect);
                    Assert.IsFalse(photograph.raycastTarget);
                    Assert.AreEqual(0, explorer.InspectedCount);
                    Button first = Find(explorer, "SCENIC EVIDENCE A");
                    Button second = Find(explorer, "SCENIC EVIDENCE B");
                    Button mechanism = Find(explorer, "SCENIC MECHANISM");
                    Assert.IsFalse(mechanism.gameObject.activeSelf,
                        "Locked mechanisms must not be presented as available discoveries.");
                    first.onClick.Invoke();
                    Assert.AreEqual(0, explorer.InspectedCount,
                        "Looking at a generated plate must not silently record an answer.");
                    Assert.IsFalse(explorer.TrySetScenicMode(false),
                        "An evidence confirmation modal blocks view switches.");
                    Find(explorer, "KEEP EXPLORING").onClick.Invoke();
                    Assert.AreEqual(0, explorer.InspectedCount,
                        "Cancelling the inspection must not collect evidence.");
                    first.onClick.Invoke();
                    Find(explorer, "RECORD IN JOURNAL").onClick.Invoke();
                    Assert.AreEqual(1, explorer.InspectedCount);
                    Assert.IsFalse(first.interactable);
                    second.onClick.Invoke();
                    Assert.AreEqual(1, explorer.InspectedCount);
                    Find(explorer, "RECORD IN JOURNAL").onClick.Invoke();
                    Assert.AreEqual(2, explorer.InspectedCount);
                    Assert.IsTrue(mechanism.gameObject.activeSelf,
                        "The investigation marker appears only after both clues are inspected.");
                    Assert.IsFalse(explorer.CanDeduce,
                        "Photo exploration cannot bypass the original physical puzzle.");
                    Assert.IsTrue(explorer.TrySetScenicMode(false));
                    Assert.IsFalse(explorer.IsScenicMode);
                    Assert.IsTrue(explorer.SceneCamera.enabled);
                    Assert.IsTrue(explorer.TrySetScenicMode(true));
                    Assert.IsTrue(explorer.IsScenicMode);
                    Assert.AreEqual(2, explorer.InspectedCount);
                    explorer.Close();
                    Assert.IsFalse(explorer.IsOpen);
                    yield return null;
                }
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
        }

        [UnityTest]
        public IEnumerator ModalCannotBeBypassedByChangingViewMode()
        {
            var host = new GameObject("Cinematic Modal Boundary Verification");
            var explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                Texture2D original = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(1).ArtResource);
                explorer.Open(1, original, (location, deduction, a, b) => { });
                Find(explorer, "SCENIC EVIDENCE A").onClick.Invoke();
                Find(explorer, "RECORD IN JOURNAL").onClick.Invoke();
                Find(explorer, "SCENIC EVIDENCE B").onClick.Invoke();
                Find(explorer, "RECORD IN JOURNAL").onClick.Invoke();
                Assert.IsTrue(explorer.TryOpenThresholdViewer());
                Assert.IsFalse(explorer.TrySetScenicMode(false));
                Assert.IsTrue(explorer.IsScenicMode);
                Assert.IsFalse(explorer.SceneCamera.enabled);
                explorer.CloseThresholdViewer();
                Assert.IsTrue(explorer.TrySetScenicMode(false));
                Assert.IsTrue(explorer.SceneCamera.enabled);
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        private static Button Find(ChapterWorldExplorer explorer, string name)
        {
            return explorer.GetComponentsInChildren<Button>(true)
                .Single(button => button.name == name);
        }
    }
}
