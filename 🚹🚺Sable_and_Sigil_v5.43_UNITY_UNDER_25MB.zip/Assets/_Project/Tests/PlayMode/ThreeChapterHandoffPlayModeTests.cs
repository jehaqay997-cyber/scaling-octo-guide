using System;
using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ThreeChapterHandoffPlayModeTests
    {
        [UnityTest]
        public IEnumerator ChapterThreeRequiresTheVerifiedWorldBeforeAnUnfinishedDossierOpens()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(6, new[] { 1, 2, 3, 4, 5, 6 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Verified World Handoff Test Host");
                var gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectLocation(7);
                var dossier = host.GetComponent<StoryDossierView>();
                var explorer = host.GetComponent<ChapterWorldExplorer>();
                Assert.IsNotNull(dossier);
                Assert.IsNotNull(explorer);
                var artwork = gallery.GetComponentsInChildren<RawImage>(true)
                    .Single(item => item.name == "Selected Chapter Artwork");
                Assert.Throws<InvalidOperationException>(() =>
                    dossier.Open(7, (Texture2D)artwork.texture));
                Assert.Throws<InvalidOperationException>(() =>
                    dossier.OpenFromWorldEvidence(7, (Texture2D)artwork.texture, null));

                var worldButton = gallery.GetComponentsInChildren<Button>(true)
                    .Single(item => item.name == "EXPLORE 3D");
                worldButton.onClick.Invoke();
                Assert.IsTrue(explorer.IsOpen);
                Assert.AreEqual(7, explorer.ActiveLocation);
                Assert.IsFalse(explorer.CanDeduce);
                Assert.IsTrue(explorer.TryInspectEvidence(0));
                Assert.IsTrue(explorer.TryInspectEvidence(1));
                Assert.IsTrue(explorer.TryOpenChapterThreeViewer());
                StoryDossierCase authored = StoryDossierCatalog.Get(7);
                int correct = Enumerable.Range(0, 4).Single(authored.IsCorrect);
                Assert.AreEqual(ChapterThreeSelection.Verified,
                    explorer.TrySelectChapterThreeChoice(correct));
                explorer.CloseChapterThreeViewer();
                Assert.IsTrue(explorer.CanDeduce);
                var enter = explorer.GetComponentsInChildren<Button>(true)
                    .Single(item => item.name == "OPEN DEDUCTION");
                enter.onClick.Invoke();
                Assert.IsFalse(explorer.IsOpen);
                Assert.IsTrue(dossier.IsOpen);
                var progress = new StoryDossierSession(new PlayerPrefsDossierStorage());
                Assert.IsFalse(progress.IsCompleted(7),
                    "World handoff must not persist completion before the deduction is submitted.");
                dossier.Hide();
                gallery.Close();
            }
            finally
            {
                if (host != null)
                {
                    var gallery = host.GetComponent<ChapterGalleryView>();
                    if (gallery != null) gallery.Close();
                    Object.Destroy(host);
                }
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }
    }
}
