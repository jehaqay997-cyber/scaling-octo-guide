using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class IntegratedSceneSmokeTests
    {
        private const string ScenePath = "Assets/_Project/Scenes/ChapterOne.unity";

        [UnityTest]
        public IEnumerator CanonicalNarrativeScene_EntersPlayableChapterWithoutLegacyBoard()
        {
            AsyncOperation operation = SceneManager.LoadSceneAsync(ScenePath, LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null, "Chapter One is the required first build scene.");
            while (!operation.isDone)
                yield return null;
            yield return null;

            Scene scene = SceneManager.GetActiveScene();
            Assert.That(scene.isLoaded, Is.True);
            Assert.That(scene.path, Is.EqualTo(ScenePath));
            var roots = scene.GetRootGameObjects();
            var chapters = roots.SelectMany(root =>
                root.GetComponentsInChildren<ChapterOneExperience>(true)).ToArray();
            Assert.That(chapters.Length, Is.EqualTo(1));
            Assert.That(chapters[0].isActiveAndEnabled, Is.True);
            Assert.That(chapters[0].IsChapterReady, Is.True,
                "The authored narrative chapter must initialize before accepting input.");
            Assert.That(roots.SelectMany(root =>
                root.GetComponentsInChildren<OrderGame>(true)).Any(), Is.False,
                "Legacy symbol sorting must not share the narrative launch scene.");
            var events = roots.SelectMany(root =>
                root.GetComponentsInChildren<EventSystem>(true)).ToArray();
            Assert.That(events.Length, Is.EqualTo(1),
                "Exactly one UI event dispatcher is required for chapter interaction.");
            Assert.That(events[0].GetComponents<BaseInputModule>()
                .Count(module => module.isActiveAndEnabled), Is.EqualTo(1));
            var canvases = roots.SelectMany(root =>
                root.GetComponentsInChildren<Canvas>(true)).ToArray();
            Assert.That(canvases.Any(canvas => canvas.GetComponent<GraphicRaycaster>() != null),
                Is.True);
            Assert.That(roots.SelectMany(root =>
                root.GetComponentsInChildren<Button>(true)).Any(), Is.True);
        }
    }
}
