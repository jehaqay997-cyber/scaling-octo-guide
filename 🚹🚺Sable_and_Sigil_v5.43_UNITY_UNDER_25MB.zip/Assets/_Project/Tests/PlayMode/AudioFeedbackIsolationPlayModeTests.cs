using System.Collections;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class AudioFeedbackIsolationPlayModeTests
    {
        [UnityTest]
        public IEnumerator RepeatedLifecycleDoesNotRetainManagedAudioComponents()
        {
            for (int iteration = 0; iteration < 3; iteration++)
            {
                var host = new GameObject("Audio Feedback Lifecycle Test");
                var feedback = host.AddComponent<OrderAudioFeedback>();
                Assert.IsNotNull(feedback);
                Assert.IsNotNull(host.GetComponent<AudioSource>());
                feedback.PlayDiscovery();
                feedback.PlayHint();
                feedback.PlaySuccess();
                feedback.PlayWarning();
                feedback.enabled = false;
                Object.Destroy(host);
                yield return null;
                Assert.IsTrue(host == null);
            }
        }
    }
}
