using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterGalleryPrivacyPlayModeTests
    {
        [UnityTest]
        public IEnumerator PrivacyPanelBlocksNavigationAndSoundChoiceSurvivesReopening()
        {
            bool previousPreference = PlayerPrefs.HasKey(LocalPrivacyPreferences.AudioEnabledKey);
            int previousValue = PlayerPrefs.GetInt(LocalPrivacyPreferences.AudioEnabledKey, 1);
            GameObject host = null;
            try
            {
                host = new GameObject("Privacy Panel Test Host");
                var gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                Assert.IsFalse(gallery.IsPrivacyPanelOpen);
                int originalChapter = gallery.SelectedChapter;
                Button privacy = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "PRIVACY & AUDIO");
                privacy.onClick.Invoke();
                Assert.IsTrue(gallery.IsPrivacyPanelOpen);
                gallery.SelectChapter(2);
                Assert.AreEqual(originalChapter, gallery.SelectedChapter);
                var shield = gallery.GetComponentsInChildren<Image>(true)
                    .Single(image => image.name == "Privacy Input Shield");
                Assert.IsTrue(shield.raycastTarget);
                Button sound = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "TOGGLE SOUND");
                bool wasEnabled = LocalPrivacyPreferences.AudioEnabled;
                sound.onClick.Invoke();
                Assert.AreEqual(!wasEnabled, LocalPrivacyPreferences.AudioEnabled);
                gallery.ClosePrivacyPanel();
                Assert.IsFalse(gallery.IsPrivacyPanelOpen);
                gallery.SelectChapter(2);
                Assert.AreEqual(2, gallery.SelectedChapter);
                gallery.Close();
            }
            finally
            {
                if (previousPreference)
                    PlayerPrefs.SetInt(LocalPrivacyPreferences.AudioEnabledKey, previousValue);
                else PlayerPrefs.DeleteKey(LocalPrivacyPreferences.AudioEnabledKey);
                PlayerPrefs.Save();
                if (host != null) Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator LocationHintRequiresUnlockAndExplicitReveal()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Hint Disclosure Test Host");
                var gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectLocation(2);
                Button hint = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "SCENE HINT");
                Text summary = gallery.GetComponentsInChildren<Text>(true)
                    .Single(label => label.name == "Selected Chapter Description");
                Assert.IsFalse(hint.interactable);
                Assert.IsFalse(summary.text.Contains(ChapterStoryGraph.GetLocation(2).HintTiers[0]));
                gallery.SelectLocation(1);
                Assert.IsTrue(hint.interactable);
                Assert.IsFalse(summary.text.Contains(ChapterStoryGraph.GetLocation(1).HintTiers[0]));
                hint.onClick.Invoke();
                Assert.IsTrue(summary.text.Contains(ChapterStoryGraph.GetLocation(1).HintTiers[0]));
                hint.onClick.Invoke();
                hint.onClick.Invoke();
                Assert.IsFalse(hint.interactable);
                gallery.SelectLocation(2);
                Assert.IsFalse(summary.text.Contains(ChapterStoryGraph.GetLocation(2).HintTiers[0]));
                gallery.Close();
            }
            finally
            {
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
                if (host != null) Object.Destroy(host);
            }
            yield return null;
        }
    }
}
