using System;
using Object = UnityEngine.Object;
using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterWorldExplorerPlayModeTests
    {
        [UnityTest]
        public IEnumerator PointerOutsideViewportCancelsDragForEveryChapterOneAndLaterLocation()
        {
            GameObject host = new GameObject("Pointer Boundary Verification Host");
            var explorer = host.AddComponent<ChapterWorldExplorer>();
            var field = typeof(ChapterWorldExplorer).GetField("gesture",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            var method = typeof(ChapterWorldExplorer).GetMethod("ProcessPointer",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            var phaseType = typeof(ChapterWorldExplorer).GetNestedType("PointerPhase",
                System.Reflection.BindingFlags.NonPublic);
            Assert.That(field, Is.Not.Null);
            Assert.That(method, Is.Not.Null);
            Assert.That(phaseType, Is.Not.Null);
            object held = Enum.Parse(phaseType, "Held");
            object ended = Enum.Parse(phaseType, "Ended");
            try
            {
                foreach (int location in new[] { 1, 2, 3, 10 })
                {
                    Texture2D artwork = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.That(artwork, Is.Not.Null);
                    explorer.Open(location, artwork, (number, deduction, a, b) => { });
                    var gesture = (ChapterWorldGestureState)field.GetValue(explorer);
                    gesture.Begin(new Vector2(Screen.width * .5f, Screen.height * .5f));
                    Assert.IsTrue(gesture.IsActive);
                    float originalYaw = explorer.CameraYaw;
                    method.Invoke(explorer, new[] { (object)new Vector2(-64f, 200f), held });
                    Assert.IsFalse(gesture.IsActive,
                        "Leaving the camera viewport must invalidate the gesture in every location.");
                    method.Invoke(explorer, new[] { (object)new Vector2(-64f, 200f), ended });
                    Assert.AreEqual(originalYaw, explorer.CameraYaw);
                    Assert.AreEqual(0, explorer.InspectedCount);
                    explorer.Close();
                    yield return null;
                }
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
        }

        [UnityTest]
        public IEnumerator WorldEvidence_GatesDeductionAndReturnsToExistingSession()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string previousA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string previousB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("3D Integration Test Host");
                ChapterGalleryView gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectLocation(1);
                Button enterWorld = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "EXPLORE 3D");
                Assert.IsTrue(enterWorld.interactable);
                enterWorld.onClick.Invoke();
                var world = host.GetComponent<ChapterWorldExplorer>();
                Assert.IsNotNull(world);
                Assert.IsTrue(world.IsOpen);
                Assert.IsTrue(gallery.IsOpen, "3D mode must block underlying chapter input.");
                Assert.AreEqual(1, world.ActiveLocation);
                Assert.AreEqual(0, world.InspectedCount);
                Assert.IsFalse(world.CanDeduce);
                Assert.IsNotNull(world.SceneCamera);
                Assert.IsFalse(world.SceneCamera.CompareTag("MainCamera"),
                    "A 3D explorer camera must not steal Camera.main ownership.");
                var deduce = world.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "OPEN DEDUCTION");
                Assert.IsFalse(deduce.interactable);
                deduce.onClick.Invoke();
                Assert.IsTrue(world.IsOpen, "Premature deduction must not close the world.");
                var firstEvidence = world.GetComponentsInChildren<ChapterWorldEvidenceMarker>()
                    .Single(marker => marker.EvidenceIndex == 0);
                Material initialSurface = firstEvidence.GetComponent<Renderer>().sharedMaterial;
                Assert.IsTrue(world.TryInspectEvidence(0));
                Assert.AreNotSame(initialSurface, firstEvidence.GetComponent<Renderer>().sharedMaterial,
                    "Inspected evidence must change appearance without granting completion.");
                Assert.IsTrue(world.TryInspectEvidence(0));
                Assert.AreEqual(1, world.InspectedCount);
                Assert.IsFalse(world.TryInspectEvidence(-1));
                Assert.IsFalse(world.TryInspectEvidence(2));
                Assert.IsTrue(world.TryInspectEvidence(1));
                Assert.AreEqual(2, world.InspectedCount);
                Assert.IsFalse(world.CanDeduce,
                    "Two inspected fragments cannot bypass the physical crest lock.");
                Assert.AreEqual(ThresholdRaySelection.Incorrect,
                    world.TrySelectThresholdRay(0));
                Button crest = world.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "EXAMINE CREST LOCK");
                Assert.IsTrue(crest.interactable);
                crest.onClick.Invoke();
                Assert.IsTrue(world.IsThresholdOpen);
                Assert.AreEqual(ThresholdRaySelection.Verified,
                    world.TrySelectThresholdRay(ThresholdCrestPuzzle.AddedRayIndex));
                Assert.IsTrue(world.IsThresholdVerified);
                world.CloseThresholdViewer();
                Assert.IsTrue(world.CanDeduce);
                Assert.IsTrue(deduce.interactable);
                Assert.IsFalse(PlayerPrefs.HasKey(StoryDossierRepository.KeyA),
                    "World inspection is transient and must never persist completion.");
                deduce.onClick.Invoke();
                Assert.IsFalse(world.IsOpen);
                var dossier = host.GetComponent<StoryDossierView>();
                Assert.IsTrue(dossier.IsOpen);
                Button answer = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "Dossier Answer 3");
                Assert.IsTrue(answer.interactable,
                    "The dossier must inherit both inspected world evidence fragments.");
                gallery.Close();
                Assert.IsFalse(dossier.IsOpen);
            }
            finally
            {
                if (host != null) Object.Destroy(host);
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, previousA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, previousB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator SpiralStair_RequiresBothCluesAndPatternRepairBeforeDeduction()
        {
            GameObject host = new GameObject("Spiral Stair Integration Host");
            var explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                Texture2D artwork = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(2).ArtResource);
                Assert.IsNotNull(artwork);
                explorer.Open(2, artwork, (location, deduction, a, b) => { });
                Assert.IsFalse(explorer.CanDeduce);
                Assert.AreEqual(0, explorer.SpiralHintStage);
                Assert.IsFalse(explorer.TryRequestSpiralHint());
                Assert.IsFalse(explorer.TryOpenSpiralViewer());
                Assert.AreEqual(BalusterSelection.Invalid,
                    explorer.TrySelectSpiralSymbol(BalusterSymbol.Star));
                Assert.IsTrue(explorer.TryInspectEvidence(0));
                Assert.IsFalse(explorer.TryOpenSpiralViewer());
                Assert.IsTrue(explorer.TryInspectEvidence(1));
                Assert.IsFalse(explorer.CanDeduce);
                Assert.IsTrue(explorer.TryOpenSpiralViewer());
                RawImage missingGraphic = explorer.GetComponentsInChildren<RawImage>(true)
                    .Single(image => image.name == "Stair Motif Graphic 6");
                Assert.IsFalse(missingGraphic.gameObject.activeSelf);
                RawImage firstGraphic = explorer.GetComponentsInChildren<RawImage>(true)
                    .Single(image => image.name == "Stair Motif Graphic 1");
                Assert.IsTrue(firstGraphic.gameObject.activeSelf);
                Assert.AreEqual(ChapterOneSymbolAtlas.GetUv(BalusterSymbol.Circle), firstGraphic.uvRect);
                Assert.AreEqual(384, firstGraphic.texture.width);
                Assert.AreEqual(96, firstGraphic.texture.height);
                Assert.AreEqual(2, explorer.OwnedTextureCount);
                for (int stage = 1; stage <= 3; stage++)
                {
                    Assert.IsTrue(explorer.TryRequestSpiralHint());
                    Assert.AreEqual(stage, explorer.SpiralHintStage);
                    Assert.IsFalse(explorer.CanDeduce,
                        "Hints must never commit the missing stair symbol.");
                }
                Assert.IsFalse(explorer.TryRequestSpiralHint());
                Assert.IsFalse(explorer.TryInspectEvidence(0));
                Assert.IsFalse(explorer.TryFocusEvidence(1));
                Assert.IsFalse(explorer.TryOpenComparison());
                Assert.AreEqual(BalusterSelection.Invalid,
                    explorer.TrySelectSpiralSymbol(BalusterSymbol.Missing));
                Assert.AreEqual(BalusterSelection.Incorrect,
                    explorer.TrySelectSpiralSymbol(BalusterSymbol.Circle));
                Assert.AreEqual(1, explorer.SpiralAttempts);
                Assert.IsFalse(explorer.CanDeduce);
                Assert.AreEqual(BalusterSelection.Verified,
                    explorer.TrySelectSpiralSymbol(BalusterSymbol.Star));
                Assert.IsTrue(explorer.IsSpiralVerified);
                MeshFilter repairedGlyph = explorer.GetComponentsInChildren<MeshFilter>()
                    .Single(filter => filter.sharedMesh != null &&
                        filter.sharedMesh.name == "Owned Spiral Baluster Motifs");
                Assert.AreEqual(66, repairedGlyph.sharedMesh.vertexCount);
                Assert.AreEqual(180, repairedGlyph.sharedMesh.triangles.Length);
                Assert.IsNull(repairedGlyph.GetComponent<Collider>());
                Assert.AreEqual(8, explorer.OwnedMeshCount,
                    "The verified stair mesh must be repaired in place, not duplicated.");
                Assert.IsTrue(missingGraphic.gameObject.activeSelf,
                    "Solving the puzzle must restore the missing visual symbol.");
                Assert.AreEqual(ChapterOneSymbolAtlas.GetUv(BalusterSymbol.Star), missingGraphic.uvRect);
                Text completedCaption = explorer.GetComponentsInChildren<Text>(true)
                    .Single(label => label.name == "Stair Motif Identifier 6");
                Assert.AreEqual("STAR", completedCaption.text);
                Assert.IsFalse(explorer.TryRequestSpiralHint());
                Assert.AreEqual(2, explorer.SpiralAttempts);
                explorer.CloseSpiralViewer();
                Assert.IsTrue(explorer.CanDeduce);
                MeshFilter glyph = explorer.GetComponentsInChildren<MeshFilter>()
                    .Single(part => part.sharedMesh != null &&
                        part.sharedMesh.name == "Owned Spiral Baluster Motifs");
                Assert.AreEqual(26, glyph.gameObject.layer);
                Assert.IsNull(glyph.GetComponent<Collider>());
                explorer.Close();
                explorer.Open(2, artwork, (location, deduction, a, b) => { });
                Assert.IsFalse(explorer.IsSpiralVerified);
                Assert.AreEqual(71, explorer.GetComponentsInChildren<MeshFilter>()
                    .Single(filter => filter.sharedMesh != null &&
                        filter.sharedMesh.name == "Owned Spiral Baluster Motifs")
                    .sharedMesh.vertexCount,
                    "Reopening the investigation must restore the original unsolved mesh.");
                Assert.AreEqual(0, explorer.SpiralAttempts);
                Assert.AreEqual(0, explorer.SpiralHintStage);
                Assert.IsFalse(explorer.CanDeduce);
            }
            finally
            {
                explorer.Close();
                UnityEngine.Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator AllTenProceduralWorlds_BuildWithBoundedCameraAndCleanlyUnload()
        {
            GameObject host = new GameObject("3D Geometry Verification Host");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                Assert.IsTrue(ChapterWorldSceneCatalog.Validate(out string error), error);
                for (int number = 1; number <= ChapterWorldSceneCatalog.PrototypeCount; number++)
                {
                    ChapterWorldSceneSpec spec = ChapterWorldSceneCatalog.Get(number);
                    Texture2D artwork = Resources.Load<Texture2D>(spec.ArtResource);
                    Assert.IsNotNull(artwork, "3D prototype requires the original reference art.");
                    explorer.Open(number, artwork, (location, deduction, a, b) => { });
                    Assert.IsTrue(explorer.IsOpen);
                    Assert.AreEqual(number, explorer.ActiveLocation);
                    Assert.IsNotNull(explorer.SceneCamera);
                    Assert.AreEqual((1 << 26) | (1 << 27), explorer.SceneCamera.cullingMask);
                    Assert.IsFalse(explorer.SceneCamera.CompareTag("MainCamera"));
                    Light[] locationLights = explorer.GetComponentsInChildren<Light>();
                    Assert.AreEqual(ChapterWorldLightingRig.MaximumLights, locationLights.Length,
                        "Every location must have one key and two low-cost evidence fill lights.");
                    Transform lightingRoot = explorer.GetComponentsInChildren<Transform>()
                        .Single(item => item.name == "Location Lighting Rig");
                    Assert.AreEqual(3, lightingRoot.childCount);
                    ChapterWorldLightingProfile illumination = ChapterWorldLightingRig.Get(number);
                    Assert.AreEqual(illumination.KeyColor,
                        lightingRoot.Find("Gallery Key Light").GetComponent<Light>().color);
                    Assert.AreEqual(illumination.LeftFillColor,
                        lightingRoot.Find("Left Evidence Fill").GetComponent<Light>().color);
                    Assert.AreEqual(illumination.RightFillColor,
                        lightingRoot.Find("Right Evidence Fill").GetComponent<Light>().color);
                    Assert.AreEqual(LightRenderMode.ForceVertex,
                        lightingRoot.Find("Left Evidence Fill").GetComponent<Light>().renderMode);
                    Assert.AreEqual(LightRenderMode.ForceVertex,
                        lightingRoot.Find("Right Evidence Fill").GetComponent<Light>().renderMode);
                    foreach (Light light in locationLights)
                    {
                        Assert.AreEqual(LightShadows.None, light.shadows);
                        Assert.AreEqual((1 << 26) | (1 << 27), light.cullingMask);
                        Assert.IsNull(light.GetComponent<Collider>());
                    }
                    Assert.AreEqual(2, explorer.GetComponentsInChildren<ChapterWorldEvidenceMarker>().Length);
                    foreach (ChapterWorldEvidenceMarker relic in explorer.GetComponentsInChildren<ChapterWorldEvidenceMarker>())
                    {
                        ChapterEvidenceVisualSpec authored = ChapterEvidenceVisualCatalog.Get(number, relic.EvidenceIndex);
                        Assert.AreEqual(number, relic.LocationNumber);
                        Assert.IsTrue(relic.name.Contains(authored.Label));
                        Assert.AreEqual(authored.MotifCount,
                            relic.GetComponentsInChildren<Transform>()
                                .Count(part => part.name.StartsWith("Authored Motif ", StringComparison.Ordinal)));
                        Assert.AreEqual(1, relic.GetComponentsInChildren<Collider>()
                            .Count(collider => collider.enabled),
                            "Only the evidence root may own an enabled interaction collider.");
                        Assert.AreEqual(1 << 27, 1 << relic.gameObject.layer);
                    }
                    Mesh[] ownedArchMeshes = explorer.GetComponentsInChildren<MeshFilter>()
                        .Where(filter => filter.sharedMesh != null && filter.sharedMesh.name == "Owned Pointed Arch Geometry")
                        .Select(filter => filter.sharedMesh).ToArray();
                    Assert.AreEqual(3, ownedArchMeshes.Length,
                        "Each 3D case must include three independently owned architectural spans.");
                    Mesh ownedVault = explorer.GetComponentsInChildren<MeshFilter>()
                        .Select(filter => filter.sharedMesh)
                        .Single(mesh => mesh != null && mesh.name == "Owned Gothic Vault Geometry");
                    Assert.IsNotNull(ownedVault);
                    Assert.AreEqual(2 * 21 * 9, ownedVault.vertexCount);
                    Assert.AreEqual(20 * 8 * 12, ownedVault.triangles.Length);
                    Mesh ownedFloorSigil = explorer.GetComponentsInChildren<MeshFilter>()
                        .Select(filter => filter.sharedMesh)
                        .Single(mesh => mesh != null &&
                            mesh.name == "Owned Investigation Floor Sigil");
                    Assert.IsNotNull(ownedFloorSigil);
                    int motifQuads = ChapterWorldFloorSigilGeometry.OuterRingSegments +
                        ChapterWorldFloorSigilGeometry.InnerRingSegments +
                        ChapterEvidenceVisualCatalog.Get(number, 0).MotifCount +
                        ChapterEvidenceVisualCatalog.Get(number, 1).MotifCount;
                    Assert.AreEqual(motifQuads * 4, ownedFloorSigil.vertexCount);
                    Assert.AreEqual(motifQuads * 6, ownedFloorSigil.triangles.Length);
                    Transform inlay = explorer.GetComponentsInChildren<Transform>()
                        .Single(item => item.name == "Investigation Floor Sigil");
                    Assert.AreEqual(26, inlay.gameObject.layer);
                    Assert.IsNull(inlay.GetComponent<Collider>(),
                        "Decorative puzzle inlays must not intercept evidence interaction.");

                    Mesh[] pedestalInlays = explorer.GetComponentsInChildren<MeshFilter>()
                        .Where(filter => filter.sharedMesh != null &&
                            filter.sharedMesh.name == "Owned Evidence Pedestal Inlay")
                        .Select(filter => filter.sharedMesh).ToArray();
                    Assert.AreEqual(2, pedestalInlays.Length);
                    for (int index = 0; index < 2; index++)
                    {
                        Transform detail = explorer.GetComponentsInChildren<Transform>()
                            .Single(item => item.name == "Evidence Pedestal Inlay " + (char)('A' + index));
                        int motifs = ChapterEvidenceVisualCatalog.Get(number, index).MotifCount;
                        Assert.AreEqual(4 * motifs, detail.GetComponent<MeshFilter>().sharedMesh.vertexCount);
                        Assert.AreEqual(6 * motifs,
                            detail.GetComponent<MeshFilter>().sharedMesh.triangles.Length);
                        Assert.AreEqual(26, detail.gameObject.layer);
                        Assert.IsNull(detail.GetComponent<Collider>());
                    }

                    Button openArtwork = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "VIEW ORIGINAL ART");
                    RawImage artworkViewer = explorer.GetComponentsInChildren<RawImage>(true)
                        .Single(view => view.name == "Original Artwork Uncropped");
                    Assert.AreSame(artwork, artworkViewer.texture,
                        "The 3D image viewer must reuse the original imported texture.");
                    GameObject photoPanel = explorer.GetComponentsInChildren<Transform>()
                        .Single(item => item.name == "Original Location Reference Panel").gameObject;
                    Material photoSurface = photoPanel.GetComponent<Renderer>().sharedMaterial;
                    Assert.AreSame(artwork, photoSurface.mainTexture,
                        "The stage must not allocate a modified copy of the authored image.");
                    if (number == 1 && artwork.width == 1280 && artwork.height == 720)
                    {
                        Assert.That(photoSurface.mainTextureScale.x,
                            Is.EqualTo(432f / 1280f).Within(.0001f));
                        Assert.That(photoSurface.mainTextureOffset.x,
                            Is.EqualTo(424f / 1280f).Within(.0001f));
                        Assert.That(photoPanel.transform.localScale.x / photoPanel.transform.localScale.y,
                            Is.EqualTo(432f / 720f).Within(.0001f),
                            "The central doorway must not be stretched in the 3D scene.");
                    }
                    else if (number == 2 && artwork.width == 1280 && artwork.height == 720)
                    {
                        Assert.That(photoSurface.mainTextureScale.x,
                            Is.EqualTo(480f / 1280f).Within(.0001f));
                        Assert.That(photoSurface.mainTextureOffset.x,
                            Is.EqualTo(400f / 1280f).Within(.0001f));
                        Assert.That(photoPanel.transform.localScale.x / photoPanel.transform.localScale.y,
                            Is.EqualTo(480f / 720f).Within(.0001f),
                            "The spiral stair photo must not stretch in the 3D stage.");
                    }
                    else
                    {
                        Assert.AreEqual(Vector2.one, photoSurface.mainTextureScale);
                        Assert.AreEqual(Vector2.zero, photoSurface.mainTextureOffset);
                    }
                    Assert.IsFalse(explorer.IsArtworkOpen);
                    openArtwork.onClick.Invoke();
                    Assert.IsTrue(explorer.IsArtworkOpen);
                    Assert.AreEqual(0, explorer.InspectedCount,
                        "Studying the artwork must not inspect evidence or grant progress.");
                    Button artZoomIn = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "ART ZOOM +");
                    for (int repeats = 0; repeats < 10; repeats++) artZoomIn.onClick.Invoke();
                    Assert.That(explorer.ArtworkZoom, Is.EqualTo(3f).Within(.0001f));
                    Assert.That(artworkViewer.uvRect.width, Is.EqualTo(1f / 3f).Within(.0001f));
                    Button artClose = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "CLOSE ART");
                    artClose.onClick.Invoke();
                    Assert.IsFalse(explorer.IsArtworkOpen);
                    Assert.That(explorer.ArtworkZoom, Is.EqualTo(1f).Within(.0001f));
                    Assert.AreEqual(0, explorer.InspectedCount);

                    var referencePanel = explorer.GetComponentsInChildren<Transform>()
                        .Single(item => item.name == "Original Location Reference Panel");
                    Vector3 towardCamera = (explorer.SceneCamera.transform.position -
                        referencePanel.position).normalized;
                    Assert.Greater(Vector3.Dot(-referencePanel.forward, towardCamera), .5f,
                        "Reference artwork must face the active camera, not the rear wall.");
                    if (number == 2)
                        Assert.AreEqual(8, explorer.OwnedMeshCount,
                            "The spiral stair owns one additional combined symbol mesh.");
                    else
                        Assert.AreEqual(number == 1 ? 10 : number >= 2 && number <= 6 ? 8 : 7, explorer.OwnedMeshCount);
                    if (number == SpiralBalusterPuzzle.LocationNumber)
                        Assert.AreEqual(2, explorer.OwnedTextureCount);
                    else
                        Assert.AreEqual(1, explorer.OwnedTextureCount);
                    Texture ownedStoneTexture = explorer.GetComponentsInChildren<Renderer>()
                        .Where(renderer => renderer.sharedMaterial != null &&
                            renderer.sharedMaterial.name == "Chapter Stone")
                        .Select(renderer => renderer.sharedMaterial.mainTexture)
                        .FirstOrDefault(texture => texture != null);
                    Assert.IsNotNull(ownedStoneTexture);
                    Assert.AreNotSame(artwork, ownedStoneTexture,
                        "Generated stone albedo must never replace the authored reference image.");
                    Assert.GreaterOrEqual(explorer.OwnedMaterialCount, 6);
                    Button zoomIn = explorer.GetComponentsInChildren<Button>()
                        .Single(button => button.name == "ZOOM +");
                    Button rotateRight = explorer.GetComponentsInChildren<Button>()
                        .Single(button => button.name == "ROTATE RIGHT");
                    for (int repeat = 0; repeat < 25; repeat++)
                    {
                        zoomIn.onClick.Invoke();
                        rotateRight.onClick.Invoke();
                    }
                    Assert.That(explorer.CameraDistance, Is.EqualTo(6.6f).Within(.0001f));
                    Assert.That(explorer.CameraYaw, Is.EqualTo(31f).Within(.0001f));
                    Assert.IsTrue(ownedArchMeshes.All(mesh => mesh != null));
                    Physics.SyncTransforms();
                    foreach (ChapterWorldEvidenceMarker marker in
                        explorer.GetComponentsInChildren<ChapterWorldEvidenceMarker>())
                    {
                        Vector3 screenPoint = explorer.SceneCamera.WorldToScreenPoint(marker.transform.position);
                        Assert.Greater(screenPoint.z, 0f);
                        Ray ray = explorer.SceneCamera.ScreenPointToRay(screenPoint);
                        Assert.IsTrue(Physics.Raycast(ray, out RaycastHit hit, 100f,
                            1 << 27, QueryTriggerInteraction.Ignore));
                        Assert.AreEqual(marker, hit.collider.GetComponentInParent<ChapterWorldEvidenceMarker>(),
                            "Case evidence must be reachable by the 3D inspection raycast.");
                    }
                    Light firstOwnedLight = lightingRoot.Find("Gallery Key Light").GetComponent<Light>();
                    explorer.Close();
                    Assert.IsFalse(explorer.IsOpen);
                    Assert.IsNull(explorer.SceneCamera);
                    Assert.AreEqual(0, explorer.OwnedMeshCount);
                    Assert.AreEqual(0, explorer.OwnedMaterialCount);
                    Assert.AreEqual(0, explorer.OwnedTextureCount);
                    explorer.Close();
                    yield return null;
                    Assert.IsTrue(firstOwnedLight == null,
                        "Owned scene lights must be destroyed after the frame boundary.");
                    Assert.IsTrue(ownedStoneTexture == null,
                        "Owned albedo texture must be destroyed with the 3D world.");
                    Assert.IsTrue(ownedVault == null,
                        "The procedural vault must be destroyed after the frame boundary.");
                    Assert.IsTrue(ownedFloorSigil == null,
                        "Owned floor geometry must be destroyed after the frame boundary.");
                    Assert.IsTrue(pedestalInlays.All(mesh => mesh == null),
                        "Owned pedestal engravings must be destroyed after the frame boundary.");
                    Assert.IsTrue(ownedArchMeshes.All(mesh => mesh == null),
                        "Owned procedural meshes must be destroyed after the frame boundary.");
                }
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator FocusControls_TrackBothRelicsWithoutGrantingPuzzleProgress()
        {
            GameObject host = new GameObject("3D Focus Regression Host");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                Texture2D artwork = Resources.Load<Texture2D>(ChapterWorldSceneCatalog.Get(1).ArtResource);
                Assert.IsNotNull(artwork);
                explorer.Open(1, artwork, (location, deduction, a, b) => { });
                Assert.AreEqual(-1, explorer.FocusedEvidenceIndex);
                Assert.AreEqual(0, explorer.InspectedCount);
                Assert.IsFalse(explorer.CanDeduce);
                Assert.IsFalse(explorer.TryFocusEvidence(-1));
                Assert.IsFalse(explorer.TryFocusEvidence(2));
                Assert.AreEqual(-1, explorer.FocusedEvidenceIndex);
                Button focusA = explorer.GetComponentsInChildren<Button>()
                    .Single(button => button.name == "FOCUS EVIDENCE A");
                Button focusB = explorer.GetComponentsInChildren<Button>()
                    .Single(button => button.name == "FOCUS EVIDENCE B");
                Button overview = explorer.GetComponentsInChildren<Button>()
                    .Single(button => button.name == "RETURN TO OVERVIEW");
                focusA.onClick.Invoke();
                Assert.AreEqual(0, explorer.FocusedEvidenceIndex);
                Assert.That(explorer.CameraFocusTarget.x, Is.EqualTo(-2.35f).Within(.0001f));
                Assert.That(explorer.CameraDistance, Is.EqualTo(7.2f).Within(.0001f));
                Assert.AreEqual(0, explorer.InspectedCount);
                Assert.IsFalse(explorer.CanDeduce);
                focusB.onClick.Invoke();
                Assert.AreEqual(1, explorer.FocusedEvidenceIndex);
                Assert.That(explorer.CameraFocusTarget.x, Is.EqualTo(2.35f).Within(.0001f));
                Assert.AreEqual(0, explorer.InspectedCount);
                Assert.IsFalse(explorer.CanDeduce);
                Button originalArt = explorer.GetComponentsInChildren<Button>()
                    .Single(button => button.name == "VIEW ORIGINAL ART");
                originalArt.onClick.Invoke();
                Assert.IsTrue(explorer.IsArtworkOpen);
                Assert.IsFalse(explorer.TryFocusEvidence(0));
                Assert.AreEqual(1, explorer.FocusedEvidenceIndex);
                Assert.AreEqual(0, explorer.InspectedCount);
                explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "CLOSE ART").onClick.Invoke();
                overview.onClick.Invoke();
                Assert.AreEqual(-1, explorer.FocusedEvidenceIndex);
                Assert.That(explorer.CameraFocusTarget.x, Is.EqualTo(0f).Within(.0001f));
                Assert.That(explorer.CameraDistance, Is.EqualTo(8.7f).Within(.0001f));
                Assert.AreEqual(0, explorer.InspectedCount);
                Assert.IsFalse(explorer.CanDeduce);
                foreach (string part in new[] { "Left Lantern Diffuser", "Right Lantern Diffuser",
                    "Left Recessed Wall Panel", "Right Recessed Wall Panel" })
                {
                    Transform decoration = explorer.GetComponentsInChildren<Transform>()
                        .Single(item => item.name == part);
                    Assert.AreEqual(26, decoration.gameObject.layer);
                    Collider collider = decoration.GetComponent<Collider>();
                    Assert.IsTrue(collider == null || !collider.enabled,
                        "Decorative lanterns must never block evidence raycasts.");
                }
                explorer.Close();
                Assert.AreEqual(-1, explorer.FocusedEvidenceIndex);
                Assert.IsFalse(explorer.TryFocusEvidence(0));
                Assert.AreEqual(0, explorer.InspectedCount);
            }
            finally
            {
                explorer.Close();
                UnityEngine.Object.Destroy(host);
            }
            yield return null;
        }
        [UnityTest]
        public IEnumerator RelicRotationAndComparison_RespectInspectionAndResetAcrossCases()
        {
            GameObject host = new GameObject("Relic Comparison Regression Host");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                foreach (int location in new[] { 1, 3, 7, 10 })
                {
                    Texture2D artwork = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(artwork);
                    explorer.Open(location, artwork, (number, deduction, a, b) => { });
                    Assert.IsFalse(explorer.TryRotateFocusedRelic(22.5f));
                    Assert.IsFalse(explorer.TryResetFocusedRelic());
                    Assert.IsFalse(explorer.TryOpenComparison());
                    Assert.Throws<ArgumentOutOfRangeException>(() => explorer.GetRelicYawDegrees(-1));
                    Assert.Throws<ArgumentOutOfRangeException>(() => explorer.GetRelicYawDegrees(2));
                    Assert.AreEqual(0, explorer.InspectedCount);
                    Assert.IsFalse(explorer.CanDeduce);
                    Button compare = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "COMPARE CLUES");
                    Assert.IsFalse(compare.interactable);
                    Button focusA = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "FOCUS EVIDENCE A");
                    Button focusB = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "FOCUS EVIDENCE B");
                    Button left = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "TURN RELIC LEFT");
                    Button right = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "TURN RELIC RIGHT");
                    Button reset = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "RESET RELIC");
                    Assert.IsFalse(left.interactable);
                    Assert.IsFalse(right.interactable);
                    Assert.IsFalse(reset.interactable);
                    focusA.onClick.Invoke();
                    Assert.IsTrue(right.interactable);
                    ChapterWorldEvidenceMarker relicA = explorer
                        .GetComponentsInChildren<ChapterWorldEvidenceMarker>()
                        .Single(marker => marker.EvidenceIndex == 0);
                    ChapterWorldEvidenceMarker relicB = explorer
                        .GetComponentsInChildren<ChapterWorldEvidenceMarker>()
                        .Single(marker => marker.EvidenceIndex == 1);
                    Quaternion initialA = relicA.transform.localRotation;
                    Quaternion initialB = relicB.transform.localRotation;
                    Assert.IsFalse(explorer.TryRotateFocusedRelic(float.NaN));
                    Assert.IsFalse(explorer.TryRotateFocusedRelic(float.PositiveInfinity));
                    Assert.IsFalse(explorer.TryRotateFocusedRelic(60f));
                    Assert.IsFalse(explorer.TryRotateFocusedRelic(0f));
                    right.onClick.Invoke();
                    Assert.That(explorer.GetRelicYawDegrees(0), Is.EqualTo(22.5f).Within(.001f));
                    Assert.Greater(Quaternion.Angle(initialA, relicA.transform.localRotation), 20f);
                    Assert.Less(Quaternion.Angle(initialB, relicB.transform.localRotation), .001f);
                    left.onClick.Invoke();
                    Assert.That(explorer.GetRelicYawDegrees(0), Is.EqualTo(0f).Within(.001f));
                    Assert.Less(Quaternion.Angle(initialA, relicA.transform.localRotation), .001f);
                    for (int turn = 0; turn < 17; turn++) right.onClick.Invoke();
                    Assert.That(explorer.GetRelicYawDegrees(0), Is.EqualTo(22.5f).Within(.001f));
                    reset.onClick.Invoke();
                    Assert.That(explorer.GetRelicYawDegrees(0), Is.EqualTo(0f).Within(.001f));
                    Assert.Less(Quaternion.Angle(initialA, relicA.transform.localRotation), .001f);
                    Assert.AreEqual(0, explorer.InspectedCount,
                        "Relic manipulation must never claim an unexamined clue.");
                    Assert.IsTrue(explorer.TryInspectEvidence(0));
                    Assert.IsTrue(compare.interactable);
                    compare.onClick.Invoke();
                    Assert.IsTrue(explorer.IsComparisonOpen);
                    Assert.IsFalse(explorer.TryFocusEvidence(1));
                    Assert.IsFalse(explorer.TryRotateFocusedRelic(15f));
                    Assert.IsFalse(explorer.TryResetFocusedRelic());
                    Assert.IsFalse(explorer.TryOpenComparison());
                    Text transcriptA = explorer.GetComponentsInChildren<Text>(true)
                        .Single(text => text.name == "Evidence A Comparison");
                    Text transcriptB = explorer.GetComponentsInChildren<Text>(true)
                        .Single(text => text.name == "Evidence B Comparison");
                    Assert.IsTrue(transcriptA.text.Contains(
                        StoryDossierCatalog.Get(location).EvidenceFragments[0]));
                    Assert.IsFalse(transcriptB.text.Contains(
                        StoryDossierCatalog.Get(location).EvidenceFragments[1]));
                    StringAssert.Contains("NOT EXAMINED", transcriptB.text);
                    Assert.AreEqual(1, explorer.InspectedCount);
                    explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "CLOSE COMPARISON").onClick.Invoke();
                    Assert.IsFalse(explorer.IsComparisonOpen);
                    focusB.onClick.Invoke();
                    Assert.AreEqual(1, explorer.FocusedEvidenceIndex);
                    Assert.IsTrue(explorer.TryRotateFocusedRelic(-22.5f));
                    Assert.That(explorer.GetRelicYawDegrees(1), Is.EqualTo(-22.5f).Within(.001f));
                    Assert.IsTrue(explorer.TryInspectEvidence(1));
                    if (location == 1)
                    {
                        Assert.IsFalse(explorer.CanDeduce);
                        Assert.AreEqual(ThresholdRaySelection.Verified,
                            explorer.TrySelectThresholdRay(ThresholdCrestPuzzle.AddedRayIndex));
                    }
                    Assert.IsTrue(explorer.CanDeduce);
                    Assert.IsTrue(explorer.TryOpenComparison());
                    Assert.IsTrue(transcriptB.text.Contains(
                        StoryDossierCatalog.Get(location).EvidenceFragments[1]));
                    explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "CLOSE COMPARISON").onClick.Invoke();
                    explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "VIEW ORIGINAL ART").onClick.Invoke();
                    Assert.IsTrue(explorer.IsArtworkOpen);
                    Assert.IsFalse(explorer.TryOpenComparison());
                    Assert.IsFalse(explorer.TryRotateFocusedRelic(-22.5f));
                    explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "CLOSE ART").onClick.Invoke();
                    explorer.Close();
                    Assert.AreEqual(0f, explorer.GetRelicYawDegrees(0));
                    Assert.AreEqual(0f, explorer.GetRelicYawDegrees(1));
                    Assert.IsFalse(explorer.IsComparisonOpen);
                    Assert.IsFalse(explorer.TryOpenComparison());
                }
            }
            finally
            {
                explorer.Close();
                UnityEngine.Object.Destroy(host);
            }
            yield return null;
        }
        [UnityTest]
        public IEnumerator ArtworkPan_UsesOriginalImageAndCannotChangeInvestigationProgress()
        {
            GameObject host = new GameObject("Artwork UV Inspection Host");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                foreach (int location in new[] { 1, 3, 7, 10 })
                {
                    Texture2D original = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(original);
                    explorer.Open(location, original, (number, deduction, first, second) => { });
                    Assert.IsFalse(explorer.TryPanArtwork(.25f, 0f));
                    Button open = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "VIEW ORIGINAL ART");
                    open.onClick.Invoke();
                    Assert.IsTrue(explorer.IsArtworkOpen);
                    RawImage image = explorer.GetComponentsInChildren<RawImage>(true)
                        .Single(item => item.name == "Original Artwork Uncropped");
                    Assert.AreSame(original, image.texture);
                    Assert.IsFalse(explorer.TryPanArtwork(.25f, 0f));
                    Button zoom = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "ART ZOOM +");
                    for (int i = 0; i < 20; i++) zoom.onClick.Invoke();
                    Assert.That(explorer.ArtworkZoom, Is.EqualTo(3f).Within(.000001f));
                    Button panRight = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "ART PAN RIGHT");
                    panRight.onClick.Invoke();
                    Assert.Greater(image.uvRect.x, (1f - image.uvRect.width) * .5f);
                    Assert.IsFalse(explorer.TryPanArtwork(float.NaN, 0f));
                    Assert.IsFalse(explorer.TryPanArtwork(0f, float.PositiveInfinity));
                    Assert.IsTrue(explorer.TryPanArtwork(10f, -10f));
                    Assert.That(image.uvRect.xMax, Is.EqualTo(1f).Within(.000001f));
                    Assert.That(image.uvRect.yMin, Is.EqualTo(0f).Within(.000001f));
                    Assert.AreEqual(0, explorer.InspectedCount);
                    Assert.IsFalse(explorer.CanDeduce);
                    Assert.IsTrue(explorer.GetComponentsInChildren<UnityEngine.EventSystems.EventTrigger>(true)
                        .Any(trigger => trigger.name == "Artwork Pan Gesture Surface"));
                    Button close = explorer.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "CLOSE ART");
                    close.onClick.Invoke();
                    Assert.That(explorer.ArtworkZoom, Is.EqualTo(1f).Within(.000001f));
                    Assert.AreEqual(new Rect(0f, 0f, 1f, 1f), image.uvRect);
                    Assert.IsFalse(explorer.TryPanArtwork(.2f, .2f));
                    explorer.Close();
                    Assert.AreEqual(0, explorer.OwnedMeshCount);
                    yield return null;
                }
            }
            finally
            {
                explorer.Close();
                UnityEngine.Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator FirstChapter_OpaqueForegroundBlocksEvidenceUntilCleared()
        {
            var host = new GameObject("First Chapter Occlusion Host");
            var explorer = host.AddComponent<ChapterWorldExplorer>();
            GameObject blocker = null;
            try
            {
                Texture2D artwork = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(1).ArtResource);
                Assert.IsNotNull(artwork);
                explorer.Open(1, artwork, (number, deduction, a, b) => { });
                ChapterWorldEvidenceMarker evidence = explorer
                    .GetComponentsInChildren<ChapterWorldEvidenceMarker>()
                    .Single(item => item.EvidenceIndex == 0);
                Camera camera = explorer.SceneCamera;
                Assert.IsNotNull(camera);
                Vector3 worldPosition = evidence.transform.position;
                Vector3 screenPosition = camera.WorldToScreenPoint(worldPosition);
                Assert.Greater(screenPosition.z, 0f);
                var screenPoint = new Vector2(screenPosition.x, screenPosition.y);
                var inspect = typeof(ChapterWorldExplorer).GetMethod(
                    "InspectAtScreenPoint", System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic);
                Assert.IsNotNull(inspect);

                blocker = GameObject.CreatePrimitive(PrimitiveType.Cube);
                blocker.name = "Opaque Threshold Foreground";
                blocker.layer = 26;
                blocker.transform.position = Vector3.Lerp(camera.transform.position,
                    worldPosition, .40f);
                blocker.transform.localScale = Vector3.one * .85f;
                Physics.SyncTransforms();
                Assert.IsTrue(Physics.Raycast(camera.ScreenPointToRay(screenPoint),
                    out RaycastHit occluded, 100f, (1 << 26) | (1 << 27),
                    QueryTriggerInteraction.Ignore));
                Assert.AreSame(blocker.GetComponent<Collider>(), occluded.collider,
                    "The foreground must be the nearest surface before testing a hidden tap.");
                inspect.Invoke(explorer, new object[] { screenPoint });
                Assert.AreEqual(0, explorer.InspectedCount,
                    "An opaque foreground must prevent selecting concealed evidence.");
                Assert.AreEqual(0, explorer.ThresholdAttempts);

                blocker.SetActive(false);
                Physics.SyncTransforms();
                inspect.Invoke(explorer, new object[] { screenPoint });
                Assert.AreEqual(1, explorer.InspectedCount,
                    "Removing the blocker must restore the normal evidence interaction.");
                Assert.IsFalse(explorer.CanDeduce);
            }
            finally
            {
                explorer.Close();
                if (blocker != null) UnityEngine.Object.Destroy(blocker);
                UnityEngine.Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator SpiralStair_OpaqueForegroundBlocksEvidenceUntilCleared()
        {
            GameObject host = new GameObject("Second Chapter-One Location Occlusion Host");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            GameObject blocker = null;
            try
            {
                Texture2D artwork = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(2).ArtResource);
                Assert.IsNotNull(artwork);
                explorer.Open(2, artwork, (location, deduction, a, b) => { });
                ChapterWorldEvidenceMarker evidence = explorer
                    .GetComponentsInChildren<ChapterWorldEvidenceMarker>()
                    .Single(item => item.EvidenceIndex == 0);
                Camera camera = explorer.SceneCamera;
                Vector3 worldPosition = evidence.transform.position;
                Vector3 screenPosition = camera.WorldToScreenPoint(worldPosition);
                Assert.Greater(screenPosition.z, 0f);
                Vector2 screenPoint = new Vector2(screenPosition.x, screenPosition.y);
                var inspect = typeof(ChapterWorldExplorer).GetMethod(
                    "InspectAtScreenPoint", System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic);
                Assert.IsNotNull(inspect);
                blocker = GameObject.CreatePrimitive(PrimitiveType.Cube);
                blocker.name = "Opaque Spiral Foreground";
                blocker.layer = 26;
                blocker.transform.position = Vector3.Lerp(camera.transform.position,
                    worldPosition, .40f);
                blocker.transform.localScale = Vector3.one * .85f;
                Physics.SyncTransforms();
                Assert.IsTrue(Physics.Raycast(camera.ScreenPointToRay(screenPoint),
                    out RaycastHit occluded, 100f, (1 << 26) | (1 << 27),
                    QueryTriggerInteraction.Ignore));
                Assert.AreSame(blocker.GetComponent<Collider>(), occluded.collider);
                inspect.Invoke(explorer, new object[] { screenPoint });
                Assert.AreEqual(0, explorer.InspectedCount,
                    "The stair evidence cannot be selected through opaque scenery.");
                Assert.AreEqual(0, explorer.SpiralAttempts);
                blocker.SetActive(false);
                Physics.SyncTransforms();
                inspect.Invoke(explorer, new object[] { screenPoint });
                Assert.AreEqual(1, explorer.InspectedCount);
                Assert.IsFalse(explorer.CanDeduce);
            }
            finally
            {
                explorer.Close();
                if (blocker != null) UnityEngine.Object.Destroy(blocker);
                UnityEngine.Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ThresholdCrest_RaysRequireBothCluesAndResetAcrossSessions()
        {
            GameObject host = new GameObject("First Chapter Crest Regression Host");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                Texture2D artwork = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(1).ArtResource);
                Assert.IsNotNull(artwork);
                explorer.Open(1, artwork, (number, deduction, a, b) => { });
                ThresholdCrestRayMarker[] marks =
                    explorer.GetComponentsInChildren<ThresholdCrestRayMarker>();
                Assert.AreEqual(6, marks.Length);
                Assert.AreEqual(6, marks.Select(mark => mark.RayIndex).Distinct().Count());
                foreach (ThresholdCrestRayMarker mark in marks)
                {
                    Assert.AreEqual(27, mark.gameObject.layer);
                    Assert.IsTrue(mark.GetComponent<Collider>().enabled);
                }
                MeshFilter[] crests = explorer.GetComponentsInChildren<MeshFilter>()
                    .Where(filter => filter.sharedMesh != null &&
                        filter.sharedMesh.name == "Owned First Chapter Crest Relief").ToArray();
                Assert.AreEqual(2, crests.Length);
                MeshFilter studMesh = explorer.GetComponentsInChildren<MeshFilter>()
                    .Single(filter => filter.sharedMesh != null &&
                        filter.sharedMesh.name == "Owned First Chapter Crest Ray Studs");
                Assert.AreEqual(44, studMesh.sharedMesh.vertexCount);
                Assert.AreEqual(66, studMesh.sharedMesh.triangles.Length);
                Assert.AreEqual(26, studMesh.gameObject.layer);
                Assert.IsNull(studMesh.GetComponent<Collider>());
                Assert.IsFalse(explorer.IsCrestFocused);
                Button focusCrest = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "FOCUS CREST");
                focusCrest.onClick.Invoke();
                Assert.IsTrue(explorer.IsCrestFocused);
                Assert.That(explorer.CameraFocusTarget.x, Is.EqualTo(-1.07f).Within(.001f));
                Assert.That(explorer.CameraDistance, Is.EqualTo(4.8f).Within(.001f),
                    "Crest focus must move visibly closer than the default investigation camera.");
                Button closeZoom = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "ZOOM +");
                closeZoom.onClick.Invoke();
                Assert.That(explorer.CameraDistance, Is.EqualTo(3.8f).Within(.001f),
                    "First zoom step must zoom in, not jump out to room minimum.");
                for (int step = 0; step < 12; step++) closeZoom.onClick.Invoke();
                Assert.That(explorer.CameraDistance, Is.EqualTo(3.8f).Within(.001f),
                    "Crest close-up must clamp without crossing its camera near limit.");
                Button farZoom = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "ZOOM -");
                for (int step = 0; step < 12; step++) farZoom.onClick.Invoke();
                Assert.That(explorer.CameraDistance, Is.EqualTo(8.2f).Within(.001f),
                    "Crest zoom must stay within its own upper orbit distance.");
                Assert.AreEqual(0, explorer.InspectedCount);
                Assert.IsFalse(explorer.CanDeduce);
                explorer.ReturnToOverview();
                Assert.IsFalse(explorer.IsCrestFocused);
                foreach (MeshFilter crest in crests)
                {
                    Assert.AreEqual(96, crest.sharedMesh.vertexCount);
                    Assert.AreEqual(288, crest.sharedMesh.triangles.Length);
                    Assert.AreEqual(26, crest.gameObject.layer);
                    Assert.IsNull(crest.GetComponent<Collider>());
                }
                Transform[] treads = explorer.GetComponentsInChildren<Transform>()
                    .Where(item => item.name.StartsWith("Chapter One Stair Tread ",
                        StringComparison.Ordinal)).ToArray();
                Assert.AreEqual(4, treads.Length);
                Assert.IsTrue(treads.All(item => item.GetComponent<Collider>() != null &&
                    !item.GetComponent<Collider>().enabled));
                for (int step = 1; step < treads.Length; step++)
                    Assert.Greater(treads[step].localPosition.y, treads[step - 1].localPosition.y);
                Assert.AreEqual(ThresholdRaySelection.EvidenceRequired,
                    explorer.TrySelectThresholdRay(ThresholdCrestPuzzle.AddedRayIndex));
                Assert.AreEqual(0, explorer.ThresholdAttempts);
                Assert.IsFalse(explorer.TryOpenThresholdViewer());
                Assert.IsFalse(explorer.TryRequestCrestHint(),
                    "Hints require inspected evidence and an open crest viewer.");
                Assert.AreEqual(0, explorer.CrestHintStage);
                Assert.IsTrue(explorer.TryInspectEvidence(0));
                Assert.IsTrue(explorer.TryInspectEvidence(1));
                Assert.IsFalse(explorer.CanDeduce);
                Assert.IsTrue(explorer.TryOpenThresholdViewer());
                Assert.IsTrue(explorer.IsThresholdOpen);
                Assert.IsFalse(explorer.TryInspectEvidence(0),
                    "Modal crest comparison must not inspect evidence through its backdrop.");
                Assert.AreEqual(2, explorer.InspectedCount);
                Button hint = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "REQUEST CREST HINT");
                Text hintText = explorer.GetComponentsInChildren<Text>(true)
                    .Single(label => label.name == "Crest Hint Guidance");
                Assert.IsTrue(hint.interactable);
                Assert.AreEqual(string.Empty, hintText.text);
                for (int stage = 1; stage <= 3; stage++)
                {
                    Assert.IsTrue(explorer.TryRequestCrestHint());
                    Assert.AreEqual(stage, explorer.CrestHintStage);
                    Assert.IsTrue(hintText.text.StartsWith("HINT " + stage + " / 3"));
                    Assert.AreEqual(0, explorer.ThresholdAttempts);
                    Assert.IsFalse(explorer.IsThresholdVerified);
                    Assert.IsFalse(explorer.CanDeduce);
                }
                Assert.IsFalse(explorer.TryRequestCrestHint());
                Assert.IsFalse(hint.interactable);
                Assert.AreEqual(3, explorer.CrestHintStage);
                Assert.IsFalse(explorer.TryFocusCrest(),
                    "The crest camera must not move while its modal UI is open.");
                Image[] referenceDiagram = explorer.GetComponentsInChildren<Image>(true)
                    .Where(image => image.name.StartsWith("Original Letter Diagram Ray ",
                        StringComparison.Ordinal)).ToArray();
                Image[] alteredDiagram = explorer.GetComponentsInChildren<Image>(true)
                    .Where(image => image.name.StartsWith("Altered Seal Diagram Ray ",
                        StringComparison.Ordinal)).ToArray();
                Assert.AreEqual(5, referenceDiagram.Length);
                Assert.AreEqual(6, alteredDiagram.Length);
                foreach (Image ray in referenceDiagram.Concat(alteredDiagram))
                    Assert.IsFalse(ray.raycastTarget,
                        "Reference marks must never intercept modal button input.");
                Assert.AreEqual(6, explorer.GetComponentsInChildren<Text>(true)
                    .Count(label => label.name.StartsWith("Arch Diagram Ray Number ",
                        StringComparison.Ordinal)));
                Button[] directTargets = explorer.GetComponentsInChildren<Button>(true)
                    .Where(button => button.name.StartsWith("SELECT DIAGRAM RAY ",
                        StringComparison.Ordinal)).OrderBy(button => button.name).ToArray();
                Assert.AreEqual(6, directTargets.Length);
                foreach (Button button in directTargets)
                {
                    Assert.IsTrue(button.image.raycastTarget);
                    Assert.AreEqual(Selectable.Transition.None, button.transition);
                    Assert.GreaterOrEqual(button.GetComponent<RectTransform>().rect.width, 48f);
                    Assert.GreaterOrEqual(button.GetComponent<RectTransform>().rect.height, 48f);
                }
                Assert.IsFalse(explorer.TryOpenComparison());
                Assert.IsFalse(explorer.TryFocusEvidence(0));
                Assert.AreEqual(ThresholdRaySelection.Invalid,
                    explorer.TrySelectThresholdRay(-1));
                Assert.AreEqual(0, explorer.ThresholdAttempts);
                directTargets[3].onClick.Invoke();
                Assert.AreEqual(ThresholdRaySelection.Incorrect,
                    explorer.LastThresholdSelection);
                Assert.AreEqual(1, explorer.ThresholdAttempts);
                Assert.IsFalse(explorer.CanDeduce);
                Image rejectedRay = alteredDiagram.Single(image => image.name ==
                    "Altered Seal Diagram Ray 4");
                Assert.AreEqual(new Color(.86f, .35f, .35f), rejectedRay.color);
                Assert.AreEqual(new Color(.56f, .18f, .21f, 1f), directTargets[3].image.color);
                Renderer rejected3d = marks.Single(mark => mark.RayIndex == 3)
                    .GetComponent<Renderer>();
                Renderer verified3d = marks.Single(mark =>
                    mark.RayIndex == ThresholdCrestPuzzle.AddedRayIndex).GetComponent<Renderer>();
                Assert.AreEqual("Rejected Crest Ray", rejected3d.sharedMaterial.name);
                Assert.AreEqual(new Color(.86f, .35f, .35f),
                    rejected3d.sharedMaterial.color);
                directTargets[ThresholdCrestPuzzle.AddedRayIndex].onClick.Invoke();
                Assert.AreEqual(ThresholdRaySelection.Verified,
                    explorer.LastThresholdSelection);
                Assert.AreEqual(2, explorer.ThresholdAttempts);
                Image verifiedRay = alteredDiagram.Single(image => image.name ==
                    "Altered Seal Diagram Ray 5");
                Assert.AreEqual(new Color(.32f, .78f, .50f), verifiedRay.color);
                Assert.AreEqual(new Color(.18f, .47f, .31f, 1f),
                    directTargets[ThresholdCrestPuzzle.AddedRayIndex].image.color);
                Assert.AreEqual(new Color(.66f, .47f, .24f), rejectedRay.color);
                Assert.AreEqual("Antique Brass", rejected3d.sharedMaterial.name);
                Assert.AreEqual("Verified Crest Ray", verified3d.sharedMaterial.name);
                Assert.AreEqual(new Color(.32f, .78f, .50f),
                    verified3d.sharedMaterial.color);
                Assert.IsTrue(explorer.CanDeduce);
                Assert.IsTrue(explorer.IsThresholdVerified);
                Assert.IsFalse(explorer.TryRequestCrestHint());
                Assert.AreEqual(string.Empty, hintText.text);
                explorer.CloseThresholdViewer();
                explorer.Close();
                Assert.IsFalse(explorer.IsThresholdVerified);
                Assert.AreEqual(0, explorer.ThresholdAttempts);
                Assert.AreEqual(0, explorer.CrestHintStage);
                yield return null;
                explorer.Open(1, artwork, (number, deduction, a, b) => { });
                Assert.AreEqual(0, explorer.CrestHintStage);
                Assert.IsFalse(explorer.TryRequestCrestHint());
                Assert.IsFalse(explorer.IsThresholdVerified);
                Assert.IsFalse(explorer.CanDeduce);
                Assert.AreEqual(0, explorer.ThresholdAttempts);
                explorer.Close();
                yield return null;
                explorer.Open(2, Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(2).ArtResource),
                    (number, deduction, a, b) => { });
                Assert.AreEqual(0,
                    explorer.GetComponentsInChildren<ThresholdCrestRayMarker>().Length);
                Assert.IsFalse(explorer.TryOpenThresholdViewer());
                Assert.IsFalse(explorer.TryRequestCrestHint());
                Assert.AreEqual(0, explorer.CrestHintStage);
                Assert.IsFalse(explorer.TryFocusCrest(),
                    "Other locations must never accept chapter-one crest focusing.");
                Assert.IsFalse(explorer.GetComponentsInChildren<Button>(true)
                    .Any(button => button.name == "FOCUS CREST"));
                Assert.AreEqual(ThresholdRaySelection.Invalid,
                    explorer.TrySelectThresholdRay(ThresholdCrestPuzzle.AddedRayIndex));
            }
            finally
            {
                explorer.Close();
                UnityEngine.Object.Destroy(host);
            }
            yield return null;
        }

    }
}
