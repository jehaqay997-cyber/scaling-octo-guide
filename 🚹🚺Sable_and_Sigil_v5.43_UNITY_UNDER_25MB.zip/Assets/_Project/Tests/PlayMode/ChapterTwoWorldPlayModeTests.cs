using System.Collections;
using System.Reflection;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterTwoWorldPlayModeTests
    {
        [UnityTest]
        public IEnumerator ChapterTwoMechanisms_BlockPrematureDeductionAndRevealWorldResult()
        {
            GameObject host = new GameObject("Chapter Two Investigation Verification Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                for (int location = 3; location <= 6; location++)
                {
                    Texture2D reference = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(reference, "Missing source art at location " + location);
                    world.Open(location, reference, (number, deduction, a, b) => { });
                    Assert.AreEqual(location, world.ActiveLocation);
                    Assert.IsFalse(world.CanDeduce);
                    Assert.IsFalse(world.IsChapterTwoVerified);
                    Assert.IsFalse(world.TryOpenChapterTwoViewer());
                    Assert.AreEqual(ChapterTwoSelection.Invalid,
                        world.TrySelectChapterTwoChoice(0));
                    Assert.IsFalse(world.TryRequestChapterTwoHint());
                    Assert.IsTrue(world.TryInspectEvidence(0));
                    Assert.IsFalse(world.TryOpenChapterTwoViewer());
                    Assert.IsTrue(world.TryInspectEvidence(1));
                    Assert.AreEqual(2, world.InspectedCount);
                    Assert.IsFalse(world.CanDeduce);
                    var worldMark = world.GetComponentsInChildren<TextMesh>(true)
                        .Single(label => label.name == "Chapter Two Mechanism State");
                    string originalWorldMark = worldMark.text;
                    Assert.AreEqual(ChapterTwoVisualCatalog.Get(location).UnsolvedMark,
                        originalWorldMark);
                    int meshCount = world.OwnedMeshCount;
                    Assert.AreEqual(8, meshCount,
                        "Each Chapter Two room owns one combined relief, not four primitives.");
                    var reliefFilter = world.GetComponentsInChildren<MeshFilter>(true)
                        .Single(filter => filter.name == "Chapter Two Physical Relief");
                    Mesh reliefMesh = reliefFilter.sharedMesh;
                    Assert.IsNotNull(reliefMesh);
                    Assert.IsNull(reliefFilter.GetComponent<Collider>());
                    int unsolvedTriangles = reliefMesh.triangles.Length;
                    int materialCount = world.OwnedMaterialCount;
                    Assert.IsTrue(world.TryOpenChapterTwoViewer());
                    Assert.IsTrue(world.IsChapterTwoOpen);
                    Button deduction = world.GetComponentsInChildren<Button>(true)
                        .Single(button => button.name == "OPEN DEDUCTION");
                    Assert.IsFalse(deduction.interactable);
                    Assert.IsFalse(world.TryInspectEvidence(0));
                    Assert.IsFalse(world.TryOpenComparison());
                    Assert.IsFalse(world.TryFocusEvidence(0));
                    Assert.IsFalse(world.TryRotateFocusedRelic(12f));
                    Assert.IsTrue(world.TryRequestChapterTwoHint());
                    Assert.AreEqual(1, world.ChapterTwoHintStage);
                    int rightChoice = -1;
                    StoryDossierCase dossier = StoryDossierCatalog.Get(location);
                    for (int index = 0; index < dossier.Choices.Count; index++)
                        if (dossier.IsCorrect(index)) rightChoice = index;
                    Assert.GreaterOrEqual(rightChoice, 0);
                    int wrongChoice = (rightChoice + 1) % dossier.Choices.Count;
                    Assert.AreEqual(ChapterTwoSelection.Incorrect,
                        world.TrySelectChapterTwoChoice(wrongChoice));
                    Assert.IsFalse(world.CanDeduce);
                    Assert.AreEqual(1, world.ChapterTwoAttempts);
                    Assert.AreEqual(ChapterTwoSelection.Verified,
                        world.TrySelectChapterTwoChoice(rightChoice));
                    Assert.IsTrue(world.IsChapterTwoVerified);
                    Assert.IsTrue(world.CanDeduce);
                    Assert.AreEqual(2, world.ChapterTwoAttempts);
                    Assert.AreEqual(ChapterTwoVisualCatalog.Get(location).SolvedMark,
                        worldMark.text);
                    Assert.AreEqual(meshCount, world.OwnedMeshCount);
                    Assert.AreSame(reliefMesh, reliefFilter.sharedMesh);
                    Assert.AreNotEqual(unsolvedTriangles, reliefMesh.triangles.Length);
                    Assert.AreEqual(materialCount, world.OwnedMaterialCount);
                    Assert.IsFalse(world.TryRequestChapterTwoHint());
                    world.CloseChapterTwoViewer();
                    Assert.IsTrue(deduction.interactable);
                    world.Close();
                    yield return null;
                    Assert.IsFalse(world.IsChapterTwoVerified);
                    Assert.AreEqual(0, world.ChapterTwoAttempts);
                }
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator PhysicalMechanismCannotOpenBeforeEvidenceAndNeverBypassesUiGuard()
        {
            var host = new GameObject("Chapter Two Physical Interaction Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            MethodInfo inspect = typeof(ChapterWorldExplorer).GetMethod("InspectAtScreenPoint",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(inspect);
            try
            {
                foreach (int location in new[] { 3, 4, 5, 6 })
                {
                    Texture2D reference = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(reference);
                    world.Open(location, reference, (number, deduction, a, b) => { });
                    Collider target = world.GetComponentsInChildren<Collider>(true)
                        .Single(item => item.name == "Chapter Two Carved Mechanism Backplate");
                    Assert.IsTrue(target.enabled);
                    Assert.AreEqual(27, target.gameObject.layer);
                    Vector3 projection = world.SceneCamera.WorldToScreenPoint(target.bounds.center);
                    Assert.Greater(projection.z, 0f);
                    var screenPoint = new Vector2(projection.x, projection.y);
                    inspect.Invoke(world, new object[] { screenPoint });
                    Assert.IsFalse(world.IsChapterTwoOpen,
                        "A physical-world click cannot reveal an uninvestigated mechanism.");
                    Assert.AreEqual(0, world.ChapterTwoAttempts);
                    Assert.IsTrue(world.TryInspectEvidence(0));
                    Assert.IsTrue(world.TryInspectEvidence(1));
                    inspect.Invoke(world, new object[] { screenPoint });
                    Assert.IsTrue(world.IsChapterTwoOpen,
                        "The physical plate should open the same evidence-gated viewer.");
                    Assert.IsFalse(world.CanDeduce);
                    Assert.IsFalse(world.TryInspectEvidence(0));
                    world.CloseChapterTwoViewer();
                    Assert.IsFalse(world.IsChapterTwoOpen);
                    world.Close();
                    yield return null;
                }
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ChapterTwoPhysicalFocus_PreservesEvidenceAndUsesContinuousZoomBounds()
        {
            GameObject host = new GameObject("Chapter Two Focus Verification Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            MethodInfo zoom = typeof(ChapterWorldExplorer).GetMethod("Zoom",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(zoom);
            try
            {
                for (int location = 3; location <= 6; location++)
                {
                    Texture2D reference = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(reference, "Missing chapter artwork at site " + location);
                    world.Open(location, reference, (number, deduction, a, b) => { });
                    Assert.IsFalse(world.IsChapterTwoFocused);
                    Assert.AreEqual(0, world.InspectedCount);
                    Assert.AreEqual(0, world.ChapterTwoAttempts);
                    Assert.IsTrue(world.TryFocusChapterTwoMechanism());
                    Assert.IsTrue(world.IsChapterTwoFocused);
                    Assert.AreEqual(6.2f, world.CameraDistance, .0001f);
                    Assert.AreEqual(new Vector3(0f, 2.23f, .10f), world.CameraFocusTarget);
                    Assert.AreEqual(0, world.InspectedCount);
                    Assert.IsFalse(world.CanDeduce);
                    zoom.Invoke(world, new object[] { -1000f });
                    Assert.AreEqual(4.3f, world.CameraDistance, .0001f);
                    zoom.Invoke(world, new object[] { 1000f });
                    Assert.AreEqual(8.8f, world.CameraDistance, .0001f);
                    Assert.IsTrue(world.TryFocusEvidence(0));
                    Assert.IsFalse(world.IsChapterTwoFocused);
                    world.ReturnToOverview();
                    Assert.AreEqual(8.7f, world.CameraDistance, .0001f);
                    Assert.IsTrue(world.TryFocusChapterTwoMechanism());
                    Assert.IsTrue(world.TryInspectEvidence(0));
                    Assert.IsTrue(world.TryInspectEvidence(1));
                    Assert.IsTrue(world.TryOpenChapterTwoViewer());
                    Assert.IsFalse(world.TryFocusChapterTwoMechanism());
                    Assert.IsTrue(world.IsChapterTwoFocused);
                    world.CloseChapterTwoViewer();
                    Assert.IsTrue(world.TryFocusChapterTwoMechanism());
                    Assert.AreEqual(0, world.ChapterTwoAttempts);
                    Assert.IsFalse(world.IsChapterTwoVerified);
                    world.ReturnToOverview();
                    Assert.IsFalse(world.IsChapterTwoFocused);
                    Assert.AreEqual(new Vector3(0f, 1.83f, .6f), world.CameraFocusTarget);
                    world.Close();
                    yield return null;
                    Assert.IsFalse(world.IsChapterTwoFocused);
                }
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator AllFourSites_TransferOnlyVerifiedEvidenceToAuthoredDeduction()
        {
            GameObject host = new GameObject("Chapter Two Complete Route Verification Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            MethodInfo finish = typeof(ChapterWorldExplorer).GetMethod("Finish",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(finish);
            try
            {
                for (int location = 3; location <= 6; location++)
                {
                    int expectedLocation = location;
                    int callbackCount = 0;
                    Texture2D reference = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(reference);
                    world.Open(location, reference, (number, deduction, a, b) =>
                    {
                        Assert.AreEqual(expectedLocation, number);
                        Assert.IsTrue(deduction);
                        Assert.IsTrue(a);
                        Assert.IsTrue(b);
                        callbackCount++;
                    });
                    Assert.AreEqual(0, world.InspectedCount);
                    Assert.IsFalse(world.CanDeduce);
                    Assert.IsFalse(world.TryOpenChapterTwoViewer());
                    finish.Invoke(world, new object[] { true });
                    Assert.IsTrue(world.IsOpen,
                        "A location must not transfer to deduction without both clues and a restored mechanism.");
                    Assert.AreEqual(0, callbackCount);
                    Assert.IsTrue(world.TryInspectEvidence(0));
                    Assert.IsTrue(world.TryInspectEvidence(1));
                    Assert.IsFalse(world.CanDeduce);
                    Assert.IsTrue(world.TryOpenChapterTwoViewer());
                    StoryDossierCase dossier = StoryDossierCatalog.Get(location);
                    int correct = -1;
                    for (int index = 0; index < dossier.Choices.Count; index++)
                        if (dossier.IsCorrect(index)) correct = index;
                    Assert.GreaterOrEqual(correct, 0);
                    int incorrect = (correct + 1) % dossier.Choices.Count;
                    Assert.AreEqual(ChapterTwoSelection.Incorrect,
                        world.TrySelectChapterTwoChoice(incorrect));
                    Assert.IsFalse(world.CanDeduce);
                    Assert.AreEqual(ChapterTwoSelection.Verified,
                        world.TrySelectChapterTwoChoice(correct));
                    Assert.IsTrue(world.IsChapterTwoVerified);
                    Assert.AreEqual(2, world.ChapterTwoAttempts);
                    world.CloseChapterTwoViewer();
                    Assert.IsTrue(world.CanDeduce);
                    finish.Invoke(world, new object[] { true });
                    Assert.IsFalse(world.IsOpen);
                    Assert.AreEqual(1, callbackCount,
                        "Each verified site must transfer exactly once to the authored dossier.");
                    Assert.IsFalse(world.IsChapterTwoVerified);
                    yield return null;
                }
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ChapterTwo_BackNavigation_ClosesOnlyTheActiveLayerAndNeverCommits()
        {
            GameObject host = new GameObject("Chapter Two Back Navigation Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            MethodInfo setArtworkFocus = typeof(ChapterWorldExplorer).GetMethod(
                "SetArtworkFocus", BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(setArtworkFocus);
            try
            {
                for (int location = 3; location <= 6; location++)
                {
                    int expectedLocation = location;
                    int callbackCount = 0;
                    Texture2D reference = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(reference);
                    world.Open(location, reference, (number, toDossier, first, second) =>
                    {
                        Assert.AreEqual(expectedLocation, number);
                        Assert.IsFalse(toDossier);
                        Assert.IsTrue(first);
                        Assert.IsTrue(second);
                        callbackCount++;
                    });
                    Assert.IsTrue(world.TryFocusChapterTwoMechanism());
                    Assert.IsTrue(world.TryNavigateBack());
                    Assert.IsTrue(world.IsOpen);
                    Assert.IsFalse(world.IsChapterTwoFocused);
                    Assert.AreEqual(8.7f, world.CameraDistance, .0001f);
                    Assert.IsTrue(world.TryFocusEvidence(0));
                    Assert.IsTrue(world.TryNavigateBack());
                    Assert.AreEqual(-1, world.FocusedEvidenceIndex);
                    Assert.AreEqual(0, world.InspectedCount);
                    Assert.IsTrue(world.TryInspectEvidence(0));
                    Assert.IsTrue(world.TryOpenComparison());
                    Assert.IsTrue(world.IsComparisonOpen);
                    Assert.IsTrue(world.TryNavigateBack());
                    Assert.IsFalse(world.IsComparisonOpen);
                    Assert.AreEqual(1, world.InspectedCount);
                    setArtworkFocus.Invoke(world, new object[] { true });
                    Assert.IsTrue(world.IsArtworkOpen);
                    Assert.IsTrue(world.TryNavigateBack());
                    Assert.IsFalse(world.IsArtworkOpen);
                    Assert.AreEqual(1, world.InspectedCount);
                    Assert.IsTrue(world.TryInspectEvidence(1));
                    Assert.IsTrue(world.TryOpenChapterTwoViewer());
                    Assert.IsTrue(world.TryRequestChapterTwoHint());
                    Assert.IsTrue(world.TryNavigateBack());
                    Assert.IsFalse(world.IsChapterTwoOpen);
                    Assert.AreEqual(1, world.ChapterTwoHintStage);
                    Assert.AreEqual(0, world.ChapterTwoAttempts);
                    Assert.IsFalse(world.IsChapterTwoVerified);
                    Assert.IsFalse(world.CanDeduce);
                    Assert.AreEqual(0, callbackCount);
                    Assert.IsTrue(world.TryNavigateBack());
                    Assert.IsFalse(world.IsOpen);
                    Assert.AreEqual(1, callbackCount);
                    Assert.IsFalse(world.TryNavigateBack());
                    Assert.AreEqual(1, callbackCount);
                    yield return null;
                }
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ChapterTwo_BackNavigation_NeverInterceptsChapterOne()
        {
            var host = new GameObject("Chapter Two Back Isolation Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            Texture2D reference = Resources.Load<Texture2D>(
                ChapterWorldSceneCatalog.Get(1).ArtResource);
            Assert.IsNotNull(reference);
            try
            {
                world.Open(1, reference, (number, toDossier, first, second) =>
                {
                    Assert.Fail("Chapter Two back navigation must not close Chapter One.");
                });
                Assert.IsFalse(world.TryNavigateBack());
                Assert.IsTrue(world.IsOpen);
                Assert.AreEqual(0, world.InspectedCount);
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ReopeningChapterTwoCaseResetsOnlyTransientMechanismState()
        {
            var host = new GameObject("Chapter Two Replay Host");
            var world = host.AddComponent<ChapterWorldExplorer>();
            Texture2D reference = Resources.Load<Texture2D>(
                ChapterWorldSceneCatalog.Get(3).ArtResource);
            Assert.IsNotNull(reference);
            try
            {
                world.Open(3, reference, (number, deduction, a, b) => { });
                world.TryInspectEvidence(0);
                world.TryInspectEvidence(1);
                world.TryOpenChapterTwoViewer();
                Assert.AreEqual(ChapterTwoSelection.Verified,
                    world.TrySelectChapterTwoChoice(0));
                world.Close();
                yield return null;
                world.Open(3, reference, (number, deduction, a, b) => { });
                Assert.AreEqual(0, world.InspectedCount);
                Assert.IsFalse(world.CanDeduce);
                Assert.AreEqual(0, world.ChapterTwoHintStage);
                Assert.AreEqual(0, world.ChapterTwoAttempts);
                Assert.IsFalse(world.IsChapterTwoVerified);
                Assert.IsFalse(world.TryOpenChapterTwoViewer());
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }
    }
}
