using System;
using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterFinalePlayModeTests
    {
        [UnityTest]
        public IEnumerator InvalidatedDurableCheckpointRevokesFinaleAccess()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string originalA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string originalB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();

                var session = new StoryDossierSession(new PlayerPrefsDossierStorage());
                Assert.IsTrue(session.IsReady, session.Error);
                for (int number = 1; number <= StoryFinalePolicy.RequiredEvidenceCount; number++)
                {
                    StoryDossierCase dossier = StoryDossierCatalog.Get(number);
                    int solution = Enumerable.Range(0, dossier.Choices.Count).Single(dossier.IsCorrect);
                    Assert.IsTrue(session.TrySubmit(number, solution, session.Revision, out string reason), reason);
                }

                host = new GameObject("Finale Durable Authorization Host");
                var gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectChapter(4);
                Assert.IsTrue(gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "READ FINAL RECORD").gameObject.activeSelf);

                // The on-screen button still exists, but both saved slots are
                // externally corrupted after the gallery last checked them.
                PlayerPrefs.SetString(StoryDossierRepository.KeyA, "corrupted-A");
                PlayerPrefs.SetString(StoryDossierRepository.KeyB, "corrupted-B");
                PlayerPrefs.Save();
                gallery.OpenFinale();
                Assert.IsFalse(gallery.IsFinaleOpen);
                Assert.IsTrue(gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "RETRY SAVE RECOVERY").gameObject.activeSelf);
                gallery.Close();
            }
            finally
            {
                if (host != null) UnityEngine.Object.DestroyImmediate(host);
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, originalA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, originalB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator FinaleRemainsLockedUntilAllTenDeductionsAreDurable()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string oldA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string oldB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();

                host = new GameObject("Final Record Verification Host");
                var gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectChapter(4);
                gallery.OpenFinale();
                Assert.IsFalse(gallery.IsFinaleOpen);
                Button openButton = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "READ FINAL RECORD");
                Assert.IsFalse(openButton.gameObject.activeSelf);
                gallery.Close();
                UnityEngine.Object.DestroyImmediate(host);
                host = null;

                var save = new StoryDossierSession(new PlayerPrefsDossierStorage());
                Assert.IsTrue(save.IsReady, save.Error);
                for (int number = 1; number <= 10; number++)
                {
                    var dossier = StoryDossierCatalog.Get(number);
                    int answer = Enumerable.Range(0, dossier.Choices.Count)
                        .Single(dossier.IsCorrect);
                    Assert.IsTrue(save.TrySubmit(number, answer, save.Revision, out string error), error);
                }
                Assert.IsTrue(save.IsFinaleUnlocked);

                host = new GameObject("Completed Final Record Verification Host");
                gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectChapter(4);
                openButton = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "READ FINAL RECORD");
                Assert.IsTrue(openButton.gameObject.activeSelf);
                openButton.onClick.Invoke();
                Assert.IsTrue(gallery.IsFinaleOpen);
                var shield = gallery.GetComponentsInChildren<Image>(true)
                    .Single(image => image.name == "Final Record Modal");
                Assert.IsTrue(shield.raycastTarget);
                int selected = gallery.SelectedChapter;
                gallery.SelectChapter(1);
                Assert.AreEqual(selected, gallery.SelectedChapter);
                Assert.IsTrue(gallery.IsFinaleOpen);
                var title = gallery.GetComponentsInChildren<Text>(true)
                    .Single(label => label.name == "Finale Chapter Heading");
                Assert.AreEqual(CampaignNarrative.FinaleHeading(0), title.text);
                gallery.CloseFinale();
                Assert.IsFalse(gallery.IsFinaleOpen);
                gallery.SelectChapter(1);
                Assert.AreEqual(1, gallery.SelectedChapter);
                gallery.Close();
            }
            finally
            {
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, oldA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, oldB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
                if (host != null) UnityEngine.Object.DestroyImmediate(host);
            }
            yield return null;
        }
    }
}
