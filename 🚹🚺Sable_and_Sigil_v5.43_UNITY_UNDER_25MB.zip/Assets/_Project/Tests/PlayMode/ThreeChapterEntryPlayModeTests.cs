using System;
using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ThreeChapterEntryPlayModeTests
    {
        [Test]
        public void FirstNineAtlasCasesRequireWorldVerification()
        {
            for (int location = 1; location <= 9; location++)
            {
                Assert.IsFalse(ChapterGalleryView.CanOpenDossierFromAtlas(location, false));
                Assert.IsTrue(ChapterGalleryView.CanOpenDossierFromAtlas(location, true));
            }
            Assert.IsFalse(ChapterGalleryView.CanOpenDossierFromAtlas(10, false));
            Assert.IsTrue(ChapterGalleryView.CanOpenDossierFromAtlas(10, true));
        }

        [UnityTest]
        public IEnumerator UnlockedChaptersEnterTheirFirstActivePhysicalInvestigation()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(2, new[] { 1, 2 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Chapter Two Entry Test Host");
                var chapterTwo = host.AddComponent<ChapterGalleryView>();
                chapterTwo.Show();
                chapterTwo.SelectChapter(2);
                var button = chapterTwo.GetComponentsInChildren<Button>(true)
                    .Single(item => item.name == "ENTER CHAPTER I");
                Assert.IsTrue(button.interactable);
                Assert.AreEqual("ENTER CHAPTER II", button.GetComponentInChildren<Text>().text);
                chapterTwo.EnterSelectedChapter();
                var world = host.GetComponent<ChapterWorldExplorer>();
                Assert.IsNotNull(world);
                Assert.IsTrue(world.IsOpen);
                Assert.AreEqual(3, world.ActiveLocation);
                chapterTwo.Close();
                Object.Destroy(host);
                host = null;
                yield return null;

                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(6, new[] { 1, 2, 3, 4, 5, 6 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Chapter Three Entry Test Host");
                var chapterThree = host.AddComponent<ChapterGalleryView>();
                chapterThree.Show();
                chapterThree.SelectChapter(3);
                var thirdButton = chapterThree.GetComponentsInChildren<Button>(true)
                    .Single(item => item.name == "ENTER CHAPTER I");
                Assert.IsTrue(thirdButton.interactable);
                Assert.AreEqual("ENTER CHAPTER III", thirdButton.GetComponentInChildren<Text>().text);
                chapterThree.EnterSelectedChapter();
                var nextWorld = host.GetComponent<ChapterWorldExplorer>();
                Assert.IsNotNull(nextWorld);
                Assert.IsTrue(nextWorld.IsOpen);
                Assert.AreEqual(7, nextWorld.ActiveLocation);
                chapterThree.Show();
                chapterThree.SelectChapter(4);
                Assert.IsFalse(thirdButton.interactable);
                Assert.IsFalse(nextWorld.IsOpen);
                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(9, new[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                chapterThree.Show();
                chapterThree.SelectChapter(4);
                Assert.IsTrue(thirdButton.interactable);
                Assert.AreEqual("ENTER CHAPTER IV", thirdButton.GetComponentInChildren<Text>().text);
                chapterThree.EnterSelectedChapter();
                Assert.IsTrue(nextWorld.IsOpen);
                Assert.AreEqual(10, nextWorld.ActiveLocation);
                Assert.IsFalse(nextWorld.CanDeduce);
                chapterThree.Close();
            }
            finally
            {
                if (host != null)
                {
                    var gallery = host.GetComponent<ChapterGalleryView>();
                    if (gallery != null) gallery.Close();
                    Object.Destroy(host);
                }
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }
    }
}
