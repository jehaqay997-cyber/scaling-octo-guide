using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    /// <summary>
    /// Actual UI geometry and world lifecycle checks to execute in Unity.
    /// These tests are not substitutes for live-device touch and visual acceptance.
    /// </summary>
    public sealed class CinematicAccessibilityPlayModeTests
    {
        [UnityTest]
        public IEnumerator SeventhLocationMechanismIsNotCoveredByPanoramaControls()
        {
            GameObject host = new GameObject("Cinematic Location Seven Accessibility Test");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                Texture2D art = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(7).ArtResource);
                Assert.IsNotNull(art);
                explorer.Open(7, art, (number, journal, a, b) => { });
                Assert.IsTrue(explorer.IsScenicMode);
                Button mechanism = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "SCENIC MECHANISM");
                Button zoom = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "SCENE ZOOM IN");
                Button toggle = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "INSPECT 3D RELICS");
                RectTransform mechanismRect = mechanism.GetComponent<RectTransform>();
                RectTransform zoomRect = zoom.GetComponent<RectTransform>();
                RectTransform toggleRect = toggle.GetComponent<RectTransform>();
                Assert.AreEqual(CinematicHudClearance.CameraY, zoomRect.anchoredPosition.y);
                Assert.AreEqual(CinematicHudClearance.ScenicToggleY, toggleRect.anchoredPosition.y);
                Assert.IsFalse(CinematicHudClearance.IntersectsHotspot(
                    mechanismRect.anchoredPosition.x, mechanismRect.anchoredPosition.y,
                    zoomRect.anchoredPosition.x, zoomRect.anchoredPosition.y,
                    zoomRect.sizeDelta.x, zoomRect.sizeDelta.y));
                Assert.IsFalse(CinematicHudClearance.IntersectsHotspot(
                    mechanismRect.anchoredPosition.x, mechanismRect.anchoredPosition.y,
                    toggleRect.anchoredPosition.x, toggleRect.anchoredPosition.y,
                    toggleRect.sizeDelta.x, toggleRect.sizeDelta.y));
                Assert.IsTrue(explorer.TryInspectEvidence(0));
                Assert.IsTrue(explorer.TryInspectEvidence(1));
                Assert.IsTrue(mechanism.gameObject.activeSelf,
                    "A discovered mechanism must remain visible and pressable in scenic mode.");
                Assert.IsTrue(mechanism.interactable);
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator FeaturedArtworkIsOwnedAndReleasedOnRepeatedLocationEntry()
        {
            GameObject host = new GameObject("Cinematic Texture Lifecycle Test");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            FieldInfo resourceField = typeof(ChapterWorldExplorer).GetField(
                "featuredSceneTexture", BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(resourceField);
            try
            {
                foreach (int location in new[] { 2, 4, 5, 7, 10 })
                {
                    Texture2D art = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(art);
                    explorer.Open(location, art, (number, journal, a, b) => { });
                    Assert.IsTrue(explorer.IsOpen);
                    Assert.IsNotNull(resourceField.GetValue(explorer),
                        "Featured full-bleed artwork must be tracked until the world closes.");
                    explorer.Close();
                    Assert.IsNull(resourceField.GetValue(explorer),
                        "The world must not retain its previous panoramic texture.");
                    yield return null;
                }
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
        }

        [UnityTest]
        public IEnumerator FirstChapterBackClosesPhysicalPuzzleBeforeAtlasNavigation()
        {
            GameObject host = new GameObject("Chapter One Layered Back Test");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            int exits = 0;
            try
            {
                Texture2D art = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(1).ArtResource);
                Assert.IsNotNull(art);
                explorer.Open(1, art, (number, toJournal, a, b) =>
                {
                    Assert.AreEqual(1, number);
                    Assert.IsFalse(toJournal);
                    exits++;
                });
                Assert.IsTrue(explorer.TryInspectEvidence(0));
                Assert.IsTrue(explorer.TryInspectEvidence(1));
                Assert.IsTrue(explorer.TryOpenThresholdViewer());
                Assert.IsTrue(explorer.IsThresholdOpen);
                Button exit = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "RETURN TO ATLAS");
                exit.onClick.Invoke();
                Assert.IsTrue(explorer.IsOpen,
                    "A queued UI callback must not bypass an open physical puzzle.");
                Assert.AreEqual(0, exits);
                Assert.IsTrue(explorer.TryNavigateChapterOneBack());
                Assert.IsFalse(explorer.IsThresholdOpen);
                Assert.AreEqual(0, exits);
                Assert.IsTrue(explorer.TryNavigateChapterOneBack());
                Assert.IsFalse(explorer.IsOpen);
                Assert.AreEqual(1, exits);
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
            yield return null;
        }
    }
}
