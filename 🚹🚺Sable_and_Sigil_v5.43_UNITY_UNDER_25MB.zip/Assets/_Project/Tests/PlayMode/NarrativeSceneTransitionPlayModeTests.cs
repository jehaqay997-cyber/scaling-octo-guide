using System.Collections;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class NarrativeSceneTransitionPlayModeTests
    {
        private static IEnumerator AwaitScene(string expected)
        {
            for (int frame = 0; frame < 240; frame++)
            {
                if (SceneManager.GetActiveScene().name == expected)
                    yield break;
                yield return null;
            }
            Assert.Fail("Narrative scene transition timed out: " + expected);
        }

        private static Button FindGalleryButton(ChapterGalleryView gallery, string buttonName)
        {
            foreach (Button button in gallery.GetComponentsInChildren<Button>(true))
            {
                if (button.name == buttonName)
                    return button;
            }
            Assert.Fail("Gallery button not found: " + buttonName);
            return null;
        }

        [UnityTest]
        public IEnumerator AtlasExplorationUsesTheDestinationChapterScene()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string previousA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string previousB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            try
            {
                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(2, new[] { 1, 2 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();

                Assert.IsTrue(Application.CanStreamedLevelBeLoaded(NarrativeSceneRoute.SceneName(1)));
                Assert.IsTrue(Application.CanStreamedLevelBeLoaded(NarrativeSceneRoute.SceneName(2)));
                AsyncOperation initial = SceneManager.LoadSceneAsync(NarrativeSceneRoute.SceneName(1),
                    LoadSceneMode.Single);
                Assert.IsNotNull(initial);
                while (!initial.isDone) yield return null;
                yield return null;

                ChapterOneExperience first = Object.FindObjectOfType<ChapterOneExperience>();
                Assert.IsNotNull(first);
                Assert.IsTrue(first.IsChapterReady);
                ChapterGalleryView firstGallery = first.GetComponent<ChapterGalleryView>();
                if (firstGallery == null)
                    firstGallery = first.gameObject.AddComponent<ChapterGalleryView>();
                firstGallery.Show();
                firstGallery.SelectLocation(3);
                Button crossChapter = FindGalleryButton(firstGallery, "EXPLORE 3D");
                Assert.IsTrue(crossChapter.interactable);
                Assert.AreEqual("ENTER CHAPTER 2", crossChapter.GetComponentInChildren<Text>().text);
                crossChapter.onClick.Invoke();
                yield return AwaitScene(NarrativeSceneRoute.SceneName(2));
                yield return null;

                Assert.IsNull(Object.FindObjectOfType<ChapterOneExperience>());
                ChapterCaseSceneBootstrap second = Object.FindObjectOfType<ChapterCaseSceneBootstrap>();
                Assert.IsNotNull(second);
                Assert.AreEqual(2, second.ChapterNumber);
                ChapterGalleryView secondGallery = second.GetComponent<ChapterGalleryView>();
                Assert.IsNotNull(secondGallery);
                Assert.AreEqual(2, secondGallery.SelectedChapter);
                ChapterWorldExplorer world = second.GetComponent<ChapterWorldExplorer>();
                Assert.IsNotNull(world);
                Assert.IsFalse(world.IsOpen);

                secondGallery.SelectLocation(3);
                Button localWorld = FindGalleryButton(secondGallery, "EXPLORE 3D");
                Assert.IsTrue(localWorld.interactable);
                Assert.AreEqual("EXPLORE 3D", localWorld.GetComponentInChildren<Text>().text);
                localWorld.onClick.Invoke();
                Assert.IsTrue(world.IsOpen);
                Assert.AreEqual(3, world.ActiveLocation);
                world.Close();
                secondGallery.Close();
            }
            finally
            {
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, previousA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, previousB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
        }

        [UnityTest]
        public IEnumerator CanonicalGalleryLoadsOwnChapterThenReturnsToTheFirstScene()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string previousA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string previousB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            try
            {
                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(2, new[] { 1, 2 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();

                Assert.IsTrue(Application.CanStreamedLevelBeLoaded(NarrativeSceneRoute.SceneName(1)));
                Assert.IsTrue(Application.CanStreamedLevelBeLoaded(NarrativeSceneRoute.SceneName(2)));
                var initial = SceneManager.LoadSceneAsync(NarrativeSceneRoute.SceneName(1),
                    LoadSceneMode.Single);
                Assert.IsNotNull(initial);
                while (!initial.isDone) yield return null;
                yield return null;

                ChapterOneExperience first = Object.FindObjectOfType<ChapterOneExperience>();
                Assert.IsNotNull(first);
                Assert.IsTrue(first.IsChapterReady);
                ChapterGalleryView firstGallery = first.GetComponent<ChapterGalleryView>();
                if (firstGallery == null)
                    firstGallery = first.gameObject.AddComponent<ChapterGalleryView>();
                firstGallery.Show();
                firstGallery.SelectChapter(2);
                firstGallery.EnterSelectedChapter();
                yield return AwaitScene(NarrativeSceneRoute.SceneName(2));
                yield return null;

                ChapterCaseSceneBootstrap second = Object.FindObjectOfType<ChapterCaseSceneBootstrap>();
                Assert.IsNotNull(second);
                Assert.AreEqual(2, second.ChapterNumber);
                ChapterGalleryView secondGallery = second.GetComponent<ChapterGalleryView>();
                Assert.IsNotNull(secondGallery);
                Assert.AreEqual(2, secondGallery.SelectedChapter);
                secondGallery.EnterSelectedChapter();
                ChapterWorldExplorer world = second.GetComponent<ChapterWorldExplorer>();
                Assert.IsNotNull(world);
                Assert.IsTrue(world.IsOpen);
                Assert.AreEqual(3, world.ActiveLocation);

                secondGallery.Show();
                secondGallery.SelectChapter(1);
                secondGallery.EnterSelectedChapter();
                yield return AwaitScene(NarrativeSceneRoute.SceneName(1));
                yield return null;
                Assert.IsNotNull(Object.FindObjectOfType<ChapterOneExperience>());
                Assert.IsNull(Object.FindObjectOfType<ChapterCaseSceneBootstrap>());
            }
            finally
            {
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, previousA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, previousB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
        }
    }
}
