using System.Collections;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterCaseAudioPowerPlayModeTests
    {
        [UnityTest]
        public IEnumerator CaseBootstrapProvidesAudioListenerAndFrameGovernor()
        {
            int initialListeners = Object.FindObjectsOfType<AudioListener>().Length;
            var host = new GameObject("Chapter Case Services Test");
            try
            {
                host.AddComponent<ChapterCaseSceneBootstrap>();
                Assert.IsNotNull(host.GetComponent<OrderPerformanceGovernor>());
                Assert.AreEqual(initialListeners == 0 ? 1 : initialListeners,
                    Object.FindObjectsOfType<AudioListener>().Length);
                Assert.AreEqual(initialListeners == 0,
                    host.GetComponent<AudioListener>() != null);
            }
            finally
            {
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator CaseBootstrapReusesExistingGovernorAndListener()
        {
            var host = new GameObject("Chapter Case Idempotence Test");
            var existing = host.AddComponent<OrderPerformanceGovernor>();
            bool needsHostListener = Object.FindObjectOfType<AudioListener>() == null;
            if (needsHostListener) host.AddComponent<AudioListener>();
            int initialListeners = Object.FindObjectsOfType<AudioListener>().Length;
            try
            {
                host.AddComponent<ChapterCaseSceneBootstrap>();
                Assert.AreSame(existing, host.GetComponent<OrderPerformanceGovernor>());
                Assert.AreEqual(1, host.GetComponents<OrderPerformanceGovernor>().Length);
                Assert.AreEqual(needsHostListener ? 1 : 0,
                    host.GetComponents<AudioListener>().Length);
                Assert.AreEqual(initialListeners, Object.FindObjectsOfType<AudioListener>().Length);
            }
            finally
            {
                Object.Destroy(host);
            }
            yield return null;
        }
    }
}
