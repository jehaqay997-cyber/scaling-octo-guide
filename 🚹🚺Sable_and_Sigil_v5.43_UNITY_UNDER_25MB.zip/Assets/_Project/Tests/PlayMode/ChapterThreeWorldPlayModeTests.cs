using System.Collections;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterThreeWorldPlayModeTests
    {
        [UnityTest]
        public IEnumerator AllSitesRequireTwoCluesAndVerifiedPhysicalMechanism()
        {
            var host = new GameObject("Chapter Three Integrated Verification Host");
            ChapterWorldExplorer world = host.AddComponent<ChapterWorldExplorer>();
            MethodInfo finish = typeof(ChapterWorldExplorer).GetMethod("Finish",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(finish);
            try
            {
                for (int location = 7; location <= 9; location++)
                {
                    int callbacks = 0;
                    int expectedLocation = location;
                    Texture2D art = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(art);
                    world.Open(location, art, (number, toDossier, clueA, clueB) =>
                    {
                        Assert.AreEqual(expectedLocation, number);
                        Assert.IsTrue(toDossier);
                        Assert.IsTrue(clueA && clueB);
                        callbacks++;
                    });
                    TextMesh label = world.GetComponentsInChildren<TextMesh>(true)
                        .Single(item => item.name == "Chapter Three Mechanism State");
                    ChapterThreeVisualSpec visual = ChapterThreeVisualCatalog.Get(location);
                    Assert.AreEqual(visual.LockedMark, label.text);
                    MeshFilter relief = world.GetComponentsInChildren<MeshFilter>(true)
                        .Single(item => item.name == "Chapter Three Physical Relief");
                    Mesh originalMesh = relief.sharedMesh;
                    int lockedTriangleCount = originalMesh.triangles.Length;
                    Assert.That(lockedTriangleCount, Is.GreaterThan(0));
                    Assert.IsFalse(world.CanDeduce);
                    Assert.IsFalse(world.TryOpenChapterThreeViewer());
                    Assert.AreEqual(ChapterThreeSelection.Invalid,
                        world.TrySelectChapterThreeChoice(0));
                    finish.Invoke(world, new object[] { true });
                    Assert.IsTrue(world.IsOpen);
                    Assert.AreEqual(0, callbacks);
                    Assert.IsTrue(world.TryInspectEvidence(0));
                    Assert.AreEqual(visual.LockedMark, label.text);
                    Assert.AreEqual(lockedTriangleCount, originalMesh.triangles.Length);
                    Assert.IsFalse(world.CanDeduce);
                    Assert.IsFalse(world.TryOpenChapterThreeViewer());
                    Assert.IsTrue(world.TryInspectEvidence(1));
                    Assert.IsFalse(world.CanDeduce);
                    Assert.AreEqual(visual.UnsolvedMark, label.text);
                    Assert.AreSame(originalMesh, relief.sharedMesh);
                    int initialTriangleCount = originalMesh.triangles.Length;
                    Assert.AreNotEqual(lockedTriangleCount, initialTriangleCount);
                    int meshCount = world.OwnedMeshCount;
                    Assert.IsTrue(world.TryOpenChapterThreeViewer());
                    Button deduction = world.GetComponentsInChildren<Button>(true)
                        .Single(item => item.name == "OPEN DEDUCTION");
                    Assert.IsFalse(deduction.interactable);
                    Assert.IsFalse(world.TryInspectEvidence(0));
                    Assert.IsFalse(world.TryOpenComparison());
                    Assert.IsFalse(world.TryFocusChapterThreeMechanism());
                    Assert.IsTrue(world.TryRequestChapterThreeHint());
                    Assert.AreEqual(1, world.ChapterThreeHintStage);
                    StoryDossierCase dossier = StoryDossierCatalog.Get(location);
                    int solution = Enumerable.Range(0, 4).Single(dossier.IsCorrect);
                    int wrong = (solution + 1) % 4;
                    Assert.AreEqual(ChapterThreeSelection.Incorrect,
                        world.TrySelectChapterThreeChoice(wrong));
                    Assert.IsFalse(world.CanDeduce);
                    Assert.AreEqual(ChapterThreeSelection.Verified,
                        world.TrySelectChapterThreeChoice(solution));
                    Assert.IsTrue(world.IsChapterThreeVerified);
                    Assert.IsTrue(world.CanDeduce);
                    Assert.AreEqual(2, world.ChapterThreeAttempts);
                    Assert.AreEqual(visual.SolvedMark, label.text);
                    Assert.AreSame(originalMesh, relief.sharedMesh);
                    Assert.AreNotEqual(initialTriangleCount, originalMesh.triangles.Length);
                    Assert.AreEqual(meshCount, world.OwnedMeshCount);
                    world.CloseChapterThreeViewer();
                    Assert.IsTrue(deduction.interactable);
                    finish.Invoke(world, new object[] { true });
                    Assert.IsFalse(world.IsOpen);
                    Assert.AreEqual(1, callbacks);
                    finish.Invoke(world, new object[] { true });
                    Assert.AreEqual(1, callbacks);
                    yield return null;
                }
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator PhysicalPanelAndBackNavigationNeverCommitCluesOrSolutions()
        {
            var host = new GameObject("Chapter Three Physical Input Verification Host");
            ChapterWorldExplorer world = host.AddComponent<ChapterWorldExplorer>();
            MethodInfo inspect = typeof(ChapterWorldExplorer).GetMethod("InspectAtScreenPoint",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(inspect);
            try
            {
                foreach (int location in new[] { 7, 8, 9 })
                {
                    Texture2D art = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(art);
                    world.Open(location, art, (number, toDossier, a, b) => { });
                    Collider backplate = world.GetComponentsInChildren<Collider>(true)
                        .Single(item => item.name == "Chapter Three Carved Mechanism Backplate");
                    Assert.AreEqual(27, backplate.gameObject.layer);
                    Vector3 projected = world.SceneCamera.WorldToScreenPoint(backplate.bounds.center);
                    Assert.Greater(projected.z, 0f);
                    Vector2 screenPoint = new Vector2(projected.x, projected.y);
                    inspect.Invoke(world, new object[] { screenPoint });
                    Assert.IsFalse(world.IsChapterThreeOpen);
                    Assert.IsTrue(world.TryFocusChapterThreeMechanism());
                    Assert.AreEqual(6.2f, world.CameraDistance, .0001f);
                    Assert.AreEqual(0, world.InspectedCount);
                    Assert.IsTrue(world.TryNavigateChapterThreeBack());
                    Assert.IsFalse(world.IsChapterThreeFocused);
                    Assert.AreEqual(8.7f, world.CameraDistance, .0001f);
                    Assert.IsTrue(world.TryInspectEvidence(0));
                    Assert.IsTrue(world.TryInspectEvidence(1));
                    inspect.Invoke(world, new object[] { screenPoint });
                    Assert.IsTrue(world.IsChapterThreeOpen);
                    Assert.IsTrue(world.TryNavigateChapterThreeBack());
                    Assert.IsFalse(world.IsChapterThreeOpen);
                    Assert.AreEqual(2, world.InspectedCount);
                    Assert.IsFalse(world.IsChapterThreeVerified);
                    Assert.IsFalse(world.CanDeduce);
                    Assert.AreEqual(0, world.ChapterThreeAttempts);
                    world.Close();
                    yield return null;
                }
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator MechanismModalBlocksQueuedCameraAndAtlasCommands()
        {
            var host = new GameObject("Chapter Three Modal Camera Isolation Host");
            ChapterWorldExplorer world = host.AddComponent<ChapterWorldExplorer>();
            MethodInfo rotate = typeof(ChapterWorldExplorer).GetMethod("Rotate",
                BindingFlags.Instance | BindingFlags.NonPublic);
            MethodInfo zoom = typeof(ChapterWorldExplorer).GetMethod("Zoom",
                BindingFlags.Instance | BindingFlags.NonPublic);
            MethodInfo finish = typeof(ChapterWorldExplorer).GetMethod("Finish",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(rotate);
            Assert.IsNotNull(zoom);
            Assert.IsNotNull(finish);
            try
            {
                for (int location = 7; location <= 9; location++)
                {
                    int callbacks = 0;
                    Texture2D art = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(art);
                    world.Open(location, art, (number, deduced, a, b) => callbacks++);
                    Assert.IsTrue(world.TryInspectEvidence(0));
                    Assert.IsTrue(world.TryInspectEvidence(1));
                    Assert.IsTrue(world.TryFocusChapterThreeMechanism());
                    Assert.IsTrue(world.TryOpenChapterThreeViewer());
                    float previousYaw = world.CameraYaw;
                    float previousDistance = world.CameraDistance;
                    int previousMeshes = world.OwnedMeshCount;
                    rotate.Invoke(world, new object[] { 22f });
                    zoom.Invoke(world, new object[] { -2.0f });
                    Assert.IsFalse(world.TryFocusEvidence(0));
                    world.ReturnToOverview();
                    finish.Invoke(world, new object[] { false });
                    Assert.IsTrue(world.IsOpen, "Modal exit must be consumed first.");
                    Assert.IsTrue(world.IsChapterThreeOpen);
                    Assert.AreEqual(previousYaw, world.CameraYaw, .0001f);
                    Assert.AreEqual(previousDistance, world.CameraDistance, .0001f);
                    Assert.AreEqual(previousMeshes, world.OwnedMeshCount);
                    Assert.AreEqual(0, world.ChapterThreeAttempts);
                    Assert.IsFalse(world.IsChapterThreeVerified);
                    Assert.AreEqual(2, world.InspectedCount);
                    Assert.AreEqual(0, callbacks);
                    Assert.IsTrue(world.TryNavigateChapterThreeBack());
                    Assert.IsFalse(world.IsChapterThreeOpen);
                    rotate.Invoke(world, new object[] { 15f });
                    zoom.Invoke(world, new object[] { -1.0f });
                    Assert.AreEqual(15f, world.CameraYaw, .0001f);
                    Assert.Less(world.CameraDistance, previousDistance);
                    float stableYaw = world.CameraYaw;
                    rotate.Invoke(world, new object[] { float.NaN });
                    rotate.Invoke(world, new object[] { float.PositiveInfinity });
                    Assert.AreEqual(stableYaw, world.CameraYaw, .0001f);
                    finish.Invoke(world, new object[] { false });
                    Assert.IsFalse(world.IsOpen);
                    Assert.AreEqual(1, callbacks);
                    yield return null;
                }
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ArtworkAndComparisonModalPreventCameraMutation()
        {
            var host = new GameObject("Chapter Three Overlay Camera Isolation Host");
            ChapterWorldExplorer world = host.AddComponent<ChapterWorldExplorer>();
            MethodInfo rotate = typeof(ChapterWorldExplorer).GetMethod("Rotate",
                BindingFlags.Instance | BindingFlags.NonPublic);
            MethodInfo zoom = typeof(ChapterWorldExplorer).GetMethod("Zoom",
                BindingFlags.Instance | BindingFlags.NonPublic);
            MethodInfo artwork = typeof(ChapterWorldExplorer).GetMethod("SetArtworkFocus",
                BindingFlags.Instance | BindingFlags.NonPublic);
            MethodInfo finish = typeof(ChapterWorldExplorer).GetMethod("Finish",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(rotate);
            Assert.IsNotNull(zoom);
            Assert.IsNotNull(artwork);
            Assert.IsNotNull(finish);
            try
            {
                for (int location = 7; location <= 9; location++)
                {
                    int callbacks = 0;
                    Texture2D art = Resources.Load<Texture2D>(
                        ChapterWorldSceneCatalog.Get(location).ArtResource);
                    Assert.IsNotNull(art);
                    world.Open(location, art, (number, deduced, a, b) => callbacks++);
                    artwork.Invoke(world, new object[] { true });
                    Assert.IsTrue(world.IsArtworkOpen);
                    rotate.Invoke(world, new object[] { 28f });
                    zoom.Invoke(world, new object[] { -1.0f });
                    finish.Invoke(world, new object[] { false });
                    Assert.IsTrue(world.IsOpen);
                    Assert.AreEqual(0f, world.CameraYaw, .0001f);
                    Assert.AreEqual(8.7f, world.CameraDistance, .0001f);
                    Assert.IsTrue(world.TryNavigateChapterThreeBack());
                    Assert.IsFalse(world.IsArtworkOpen);
                    Assert.IsTrue(world.TryInspectEvidence(0));
                    Assert.IsTrue(world.TryOpenComparison());
                    rotate.Invoke(world, new object[] { 18f });
                    zoom.Invoke(world, new object[] { -2.0f });
                    finish.Invoke(world, new object[] { false });
                    Assert.IsTrue(world.IsOpen);
                    Assert.AreEqual(0f, world.CameraYaw, .0001f);
                    Assert.AreEqual(8.7f, world.CameraDistance, .0001f);
                    Assert.IsTrue(world.TryNavigateChapterThreeBack());
                    Assert.IsFalse(world.IsComparisonOpen);
                    Assert.AreEqual(1, world.InspectedCount);
                    Assert.AreEqual(0, world.ChapterThreeAttempts);
                    Assert.AreEqual(0, callbacks);
                    finish.Invoke(world, new object[] { false });
                    Assert.IsFalse(world.IsOpen);
                    Assert.AreEqual(1, callbacks);
                    yield return null;
                }
            }
            finally
            {
                world.Close();
                Object.Destroy(host);
            }
            yield return null;
        }
    }
}
