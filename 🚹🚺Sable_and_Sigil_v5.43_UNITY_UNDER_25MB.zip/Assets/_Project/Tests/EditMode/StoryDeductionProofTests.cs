using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class StoryDeductionProofTests
    {
        [Test]
        public void AllTenDeductionsHaveOneProvablyCorrectVisibleChoice()
        {
            Assert.IsTrue(StoryDossierCatalog.Validate(out string error), error);
            for (int number = 1; number <= ChapterStoryGraph.LocationCount; number++)
            {
                var dossier = StoryDossierCatalog.Get(number);
                var proof = StoryDeductionProof.Solve(number);
                Assert.AreEqual(number, proof.LocationNumber);
                Assert.AreEqual(1, proof.SolutionCount);
                Assert.IsNotEmpty(proof.Reasoning);
                Assert.IsTrue(StoryDeductionProof.VerifyCatalogCase(dossier, out error), error);
                Assert.AreEqual(1, dossier.Choices.Count(candidate =>
                    string.Equals(candidate, proof.ExpectedAnswer, StringComparison.OrdinalIgnoreCase)));
            }
        }

        [TestCase(2, "Star")]
        [TestCase(3, "Full Moon")]
        [TestCase(4, "13 petals")]
        [TestCase(5, "1-3-2-4")]
        [TestCase(7, "Three rays, ring, triangle")]
        [TestCase(9, "E")]
        [TestCase(10, "A-B-C-D")]
        public void MathematicalModelsDeriveTheAuthoredResults(int caseNumber, string expected)
        {
            Assert.AreEqual(expected, StoryDeductionProof.Solve(caseNumber).ExpectedAnswer);
        }

        [Test]
        public void InvalidProofRequestsFailBeforeAnyGameplayMutation()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => StoryDeductionProof.Solve(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => StoryDeductionProof.Solve(11));
            Assert.IsFalse(StoryDeductionProof.VerifyCatalogCase(null, out _));
        }

        [Test]
        public void ProofReadsDoNotChangeTheEvidenceLedgerOrRevision()
        {
            var ledger = new StoryEvidenceLedger();
            Assert.IsTrue(ledger.TryResolve(1, 0, out _));
            long before = ledger.Revision;
            int[] snapshot = ledger.Snapshot();
            for (int i = 1; i <= 10; i++) StoryDeductionProof.Solve(i);
            Assert.AreEqual(before, ledger.Revision);
            CollectionAssert.AreEqual(snapshot, ledger.Snapshot());
        }
    }
}
