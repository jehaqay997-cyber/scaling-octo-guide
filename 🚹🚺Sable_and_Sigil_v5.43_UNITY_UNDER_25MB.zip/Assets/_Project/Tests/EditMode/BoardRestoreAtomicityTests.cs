#if UNITY_INCLUDE_TESTS
using System;
using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests
{
    public sealed class BoardRestoreAtomicityTests
    {
        private static OrderBoard CreateBoard()
        {
            return new OrderBoard(
                new[] { new Item("A", "SUN", 2), new Item("B", "SUN", 3) },
                new[] { new Compartment("L", "SUN", 2, 5) });
        }

        private static Dictionary<string, string> Snapshot(OrderBoard board)
        {
            var copy = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var entry in board.Snapshot())
                copy.Add(entry.Key, entry.Value);
            return copy;
        }

        private static void AssertSnapshot(OrderBoard board, IDictionary<string, string> expected)
        {
            var current = board.Snapshot();
            Assert.AreEqual(expected.Count, current.Count);
            foreach (var entry in expected)
                Assert.AreEqual(entry.Value, current[entry.Key], entry.Key);
        }

        [Test]
        public void ValidSnapshotRestoresEveryItemAtomically()
        {
            var board = CreateBoard();
            long initialRevision = board.Revision;
            Assert.IsTrue(board.Restore(new Dictionary<string, string>(StringComparer.Ordinal)
            {
                { "A", "L" }, { "B", OrderBoard.Tray }
            }));
            Assert.AreEqual(initialRevision + 1, board.Revision);
            Assert.AreEqual("L", board.Location("A"));
            Assert.AreEqual(OrderBoard.Tray, board.Location("B"));
            Assert.AreEqual(1, board.CountIn("L"));
            Assert.AreEqual(2L, board.WeightIn("L"));
        }

        [Test]
        public void RestoringOriginalTrayStateIsValid()
        {
            var board = CreateBoard();
            var original = Snapshot(board);
            Assert.IsTrue(board.Move("A", "L", out _));
            Assert.IsTrue(board.Restore(original));
            AssertSnapshot(board, original);
            Assert.AreEqual(0, board.CountIn("L"));
            Assert.AreEqual(0L, board.WeightIn("L"));
        }

        [Test]
        public void InvalidSnapshotDoesNotChangeStateRevisionOrPendingTransfer()
        {
            var board = CreateBoard();
            var before = Snapshot(board);
            Assert.IsTrue(board.Prepare("A", "L", board.Revision, out Guid ticket, out _));
            long revision = board.Revision;
            Assert.IsFalse(board.Restore(new Dictionary<string, string>
            {
                { "A", "L" }, { "B", "UNKNOWN" }
            }));
            AssertSnapshot(board, before);
            Assert.AreEqual(revision, board.Revision);
            Assert.IsTrue(board.Commit(ticket, out _));
            Assert.AreEqual("L", board.Location("A"));
        }

        [Test]
        public void RestoreInvalidatesPreparedTransferAfterSuccessfulCommit()
        {
            var board = CreateBoard();
            Assert.IsTrue(board.Prepare("A", "L", board.Revision, out Guid ticket, out _));
            Assert.IsTrue(board.Restore(new Dictionary<string, string>
            {
                { "A", OrderBoard.Tray }, { "B", "L" }
            }));
            Assert.IsFalse(board.Commit(ticket, out _));
            Assert.AreEqual("L", board.Location("B"));
            Assert.AreEqual(1, board.CountIn("L"));
            Assert.AreEqual(3L, board.WeightIn("L"));
        }

        [Test]
        public void MissingAndUnknownItemsAreRejected()
        {
            var board = CreateBoard();
            long revision = board.Revision;
            Assert.IsFalse(board.Restore(new Dictionary<string, string>
            {
                { "A", "L" }
            }));
            Assert.IsFalse(board.Restore(new Dictionary<string, string>
            {
                { "A", "L" }, { "B", OrderBoard.Tray }, { "C", "L" }
            }));
            Assert.AreEqual(revision, board.Revision);
            Assert.AreEqual(OrderBoard.Tray, board.Location("A"));
        }
    }
}
#endif
