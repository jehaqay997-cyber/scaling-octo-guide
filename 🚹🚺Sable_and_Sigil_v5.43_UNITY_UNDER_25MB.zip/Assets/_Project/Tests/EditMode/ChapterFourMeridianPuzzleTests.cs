using System;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterFourMeridianPuzzleTests
    {
        [Test]
        public void AllTwentyFourPermutationsContainExactlyOneAuthoredSolution()
        {
            Assert.IsTrue(ChapterFourMeridianPuzzle.Validate(out string error), error);
            int unique = 0;
            var rings = new char[4];
            for (int a = 0; a < 4; a++)
            for (int b = 0; b < 4; b++)
            for (int c = 0; c < 4; c++)
            for (int d = 0; d < 4; d++)
            {
                rings[0] = (char)('A' + a);
                rings[1] = (char)('A' + b);
                rings[2] = (char)('A' + c);
                rings[3] = (char)('A' + d);
                if (!ChapterFourMeridianPuzzle.SatisfiesClues(rings)) continue;
                Assert.That(new string(rings), Is.EqualTo("ABCD"));
                unique++;
            }
            Assert.AreEqual(1, unique);
            Assert.IsFalse(ChapterFourMeridianPuzzle.HasUniqueRings(null));
            Assert.IsFalse(ChapterFourMeridianPuzzle.HasUniqueRings(new[] { 'A', 'A', 'B', 'C' }));
            Assert.IsFalse(ChapterFourMeridianPuzzle.SatisfiesClues(new[] { 'B', 'A', 'D', 'C' }));
        }

        [Test]
        public void EvidenceIsMandatoryAndInvalidSelectionsAreNonMutating()
        {
            var puzzle = new ChapterFourMeridianPuzzle();
            Assert.AreEqual("BADC", new string(new[] {
                puzzle.Order[0], puzzle.Order[1], puzzle.Order[2], puzzle.Order[3] }));
            Assert.AreEqual(-1, puzzle.SelectedIndex);
            Assert.AreEqual(MeridianMoveResult.Invalid, puzzle.SelectPosition(-1, true, true));
            Assert.AreEqual(MeridianMoveResult.Invalid, puzzle.SelectPosition(4, true, true));
            Assert.AreEqual(MeridianMoveResult.EvidenceRequired, puzzle.SelectPosition(0, true, false));
            Assert.IsFalse(puzzle.TryRevealHint(false, true));
            Assert.AreEqual(0, puzzle.Attempts);
            Assert.AreEqual(-1, puzzle.SelectedIndex);
            Assert.AreEqual(MeridianMoveResult.Selected, puzzle.SelectPosition(0, true, true));
            Assert.AreEqual(MeridianMoveResult.SelectionCancelled, puzzle.SelectPosition(0, true, true));
            Assert.AreEqual(0, puzzle.Attempts);
            Assert.AreEqual("BADC", new string(puzzle.Order.ToArray()));
        }

        [Test]
        public void SwapRequiresTwoPositionsAndCompletionIsIdempotent()
        {
            var puzzle = new ChapterFourMeridianPuzzle();
            Assert.AreEqual(MeridianMoveResult.Selected, puzzle.SelectPosition(0, true, true));
            Assert.AreEqual(MeridianMoveResult.Swapped, puzzle.SelectPosition(1, true, true));
            Assert.AreEqual(1, puzzle.Attempts);
            Assert.AreEqual(MeridianMoveResult.Selected, puzzle.SelectPosition(2, true, true));
            Assert.AreEqual(MeridianMoveResult.Verified, puzzle.SelectPosition(3, true, true));
            Assert.AreEqual(2, puzzle.Attempts);
            Assert.IsTrue(puzzle.IsVerified);
            Assert.AreEqual(MeridianMoveResult.AlreadyVerified, puzzle.SelectPosition(0, true, true));
            Assert.AreEqual(2, puzzle.Attempts);
            puzzle.Reset();
            Assert.IsFalse(puzzle.IsVerified);
            Assert.AreEqual(0, puzzle.Attempts);
            Assert.AreEqual(0, puzzle.HintStage);
            Assert.AreEqual('B', puzzle.Order[0]);
        }

        [Test]
        public void HintsAreBoundedAndCannotChangeProgress()
        {
            var puzzle = new ChapterFourMeridianPuzzle();
            for (int stage = 1; stage <= 3; stage++)
            {
                Assert.IsTrue(puzzle.TryRevealHint(true, true));
                Assert.AreEqual(stage, puzzle.HintStage);
            }
            Assert.IsFalse(puzzle.TryRevealHint(true, true));
            Assert.IsFalse(puzzle.IsVerified);
            Assert.AreEqual(0, puzzle.Attempts);
        }
    }
}
