using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class CampaignNarrativeTests
    {
        [TestCase(0, "THE HOUSE OF THE LAST STAR / DISCOVER")]
        [TestCase(2, "THE HOUSE OF THE LAST STAR / UNSEAL")]
        [TestCase(3, "THE VEILED CONSERVATORY / DISCOVER")]
        [TestCase(6, "THE ASHEN GALLERY / DISCOVER")]
        [TestCase(11, "THE HOLLOW MERIDIAN / UNSEAL")]
        public void StageTitleIsStable(int level, string expected)
            => Assert.AreEqual(expected, CampaignNarrative.Title(level));

        [Test]
        public void EveryDossierHasNonEmptyConsequence()
        {
            for (int location = 1; location <= 10; location++)
                Assert.IsNotEmpty(CampaignNarrative.CaseConsequence(location));
            Assert.Throws<System.ArgumentOutOfRangeException>(() => CampaignNarrative.CaseConsequence(0));
            Assert.Throws<System.ArgumentOutOfRangeException>(() => CampaignNarrative.CaseConsequence(11));
        }

        [Test]
        public void EveryChapterHasAuthoredCodaWithoutEarlyUnlock()
        {
            for (int chapter = 1; chapter <= 4; chapter++)
                Assert.IsNotEmpty(CampaignNarrative.ChapterCoda(chapter));
            Assert.Throws<System.ArgumentOutOfRangeException>(() => CampaignNarrative.ChapterCoda(0));
            Assert.Throws<System.ArgumentOutOfRangeException>(() => CampaignNarrative.ChapterCoda(5));
        }

        [Test]
        public void FinaleHasFourSequentialPagesAndARealNarrativeResolution()
        {
            for (int page = 0; page < TheOrderRoom.Domain.StoryFinalePolicy.PageCount; page++)
            {
                Assert.IsNotEmpty(CampaignNarrative.FinaleHeading(page));
                Assert.Greater(CampaignNarrative.FinaleText(page).Length, 200);
            }
            StringAssert.Contains("A-B-C-D", CampaignNarrative.FinaleText(3));
            StringAssert.Contains("REMEMBER", CampaignNarrative.FinaleText(2));
            Assert.Throws<System.ArgumentOutOfRangeException>(() => CampaignNarrative.FinaleHeading(-1));
            Assert.Throws<System.ArgumentOutOfRangeException>(() => CampaignNarrative.FinaleText(4));
        }

        [Test]
        public void EveryLevelHasNarrativeHook()
        {
            for (int i = 0; i < 12; i++)
                Assert.IsNotEmpty(CampaignNarrative.Hook(i));
        }
    }
}
