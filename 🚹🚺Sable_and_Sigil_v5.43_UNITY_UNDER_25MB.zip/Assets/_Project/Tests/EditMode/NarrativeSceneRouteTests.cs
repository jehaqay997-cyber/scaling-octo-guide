using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class NarrativeSceneRouteTests
    {
        [Test]
        public void AllAuthoredChaptersHaveExactIndependentSceneNamesAndPaths()
        {
            string[] expected = { "ChapterOne", "ChapterTwo", "ChapterThree", "ChapterFour" };
            Assert.AreEqual(expected.Length, NarrativeSceneRoute.ChapterCount);
            for (int chapter = 1; chapter <= NarrativeSceneRoute.ChapterCount; chapter++)
            {
                string name = NarrativeSceneRoute.SceneName(chapter);
                Assert.AreEqual(expected[chapter - 1], name);
                Assert.AreEqual("Assets/_Project/Scenes/" + name + ".unity",
                    NarrativeSceneRoute.ScenePath(chapter));
                Assert.IsTrue(NarrativeSceneRoute.IsCanonicalScene(name));
                Assert.IsFalse(NarrativeSceneRoute.RequiresSceneTransition(name, chapter));
                for (int other = 1; other <= NarrativeSceneRoute.ChapterCount; other++)
                    Assert.AreEqual(other != chapter,
                        NarrativeSceneRoute.RequiresSceneTransition(name, other));
            }
        }

        [Test]
        public void OldMainAndForgedSceneNamesCannotMasqueradeAsStoryChapters()
        {
            foreach (string invalid in new[] { null, "", "Main", "chapterone", "ChapterOne.unity", "ChapterFive" })
                Assert.IsFalse(NarrativeSceneRoute.IsCanonicalScene(invalid));
            Assert.IsTrue(NarrativeSceneRoute.RequiresSceneTransition("Main", 1));
            Assert.IsTrue(NarrativeSceneRoute.RequiresSceneTransition("", 4));
            Assert.Throws<ArgumentOutOfRangeException>(() => NarrativeSceneRoute.SceneName(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => NarrativeSceneRoute.SceneName(5));
            Assert.Throws<ArgumentOutOfRangeException>(() => NarrativeSceneRoute.ScenePath(-1));
            Assert.Throws<ArgumentOutOfRangeException>(() => NarrativeSceneRoute.RequiresSceneTransition("Main", 9));
        }
    }
}
