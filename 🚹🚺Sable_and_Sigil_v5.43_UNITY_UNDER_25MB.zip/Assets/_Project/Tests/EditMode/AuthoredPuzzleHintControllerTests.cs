using System;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.UI;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class AuthoredPuzzleHintControllerTests
    {
        private GameObject root;
        private AuthoredPuzzleHintController controller;
        private Button button;
        private Text label;

        [SetUp]
        public void SetUp()
        {
            root = new GameObject("HintTestRoot");
            root.SetActive(false);
            var catalog = root.AddComponent<AuthoredPuzzleHintCatalog>();
            controller = root.AddComponent<AuthoredPuzzleHintController>();
            button = root.AddComponent<Button>();
            label = root.AddComponent<Text>();
            root.SetActive(true);
            controller.Configure(catalog, button, label);
        }

        [TearDown]
        public void TearDown()
        {
            if (root != null) UnityEngine.Object.DestroyImmediate(root);
        }

        [Test]
        public void FirstPuzzleExposesThreeTiersInOrder()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            Assert.IsTrue(button.interactable);
            for (int tier = 1; tier <= 3; tier++)
            {
                Assert.IsTrue(controller.ShowNextHint());
                Assert.AreEqual(tier, controller.RevealedTier);
                Assert.IsFalse(string.IsNullOrWhiteSpace(label.text));
            }
            Assert.IsFalse(controller.ShowNextHint());
            Assert.IsFalse(button.interactable);
        }

        [Test]
        public void MissingPrerequisiteNeverRevealsHint()
        {
            Assert.IsTrue(controller.SetContext("scene_02", Array.Empty<string>()));
            Assert.IsFalse(controller.ShowNextHint());
            Assert.AreEqual(0, controller.RevealedTier);
            Assert.IsFalse(button.interactable);
        }

        [Test]
        public void AuthoritativeEvidenceUnlocksHint()
        {
            Assert.IsTrue(controller.SetContext("scene_02", new[] { "scene_01_evidence" }));
            Assert.IsTrue(button.interactable);
            Assert.IsTrue(controller.ShowNextHint());
        }

        [Test]
        public void InvalidEvidenceSnapshotDoesNotChangeContext()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            Assert.IsFalse(controller.SetContext("scene_02", new[] { "scene_01_evidence", "scene_01_evidence" }));
            Assert.AreEqual("scene_01", controller.PuzzleId);
            Assert.IsTrue(controller.ShowNextHint());
        }

        [Test]
        public void ChangingPuzzleResetsHintTier()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            Assert.IsTrue(controller.ShowNextHint());
            Assert.IsTrue(controller.SetContext("scene_02", new[] { "scene_01_evidence" }));
            Assert.AreEqual(0, controller.RevealedTier);
            Assert.AreEqual(string.Empty, label.text);
        }

        [Test]
        public void RevokedEvidenceClearsPreviouslyRevealedHint()
        {
            Assert.IsTrue(controller.SetContext("scene_02", new[] { "scene_01_evidence" }));
            Assert.IsTrue(controller.ShowNextHint());
            Assert.AreEqual(1, controller.RevealedTier);
            Assert.IsTrue(controller.SetContext("scene_02", Array.Empty<string>()));
            Assert.AreEqual(0, controller.RevealedTier);
            Assert.AreEqual(string.Empty, label.text);
            Assert.IsFalse(button.interactable);
        }

        [Test]
        public void ReplacingCatalogResetsRevealedHint()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            Assert.IsTrue(controller.ShowNextHint());
            var replacement = root.AddComponent<AuthoredPuzzleHintCatalog>();
            controller.Configure(replacement, button, label);
            Assert.AreEqual(0, controller.RevealedTier);
            Assert.AreEqual(string.Empty, label.text);
        }

        [Test]
        public void ReplacingCatalogRequiresFreshEvidenceContext()
        {
            Assert.IsTrue(controller.SetContext("scene_02", new[] { "scene_01_evidence" }));
            Assert.IsTrue(controller.ShowNextHint());
            var replacement = root.AddComponent<AuthoredPuzzleHintCatalog>();
            controller.Configure(replacement, button, label);
            Assert.AreEqual(string.Empty, controller.PuzzleId);
            Assert.AreEqual(0, controller.RevealedTier);
            Assert.AreEqual(string.Empty, label.text);
            Assert.IsFalse(button.interactable);
            Assert.IsTrue(controller.SetContext("scene_02", Array.Empty<string>()));
            Assert.IsFalse(controller.ShowNextHint());
        }

        [Test]
        public void RepeatedConfigureDoesNotDuplicateClickListener()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            var catalog = root.GetComponent<AuthoredPuzzleHintCatalog>();
            controller.Configure(catalog, button, label);
            controller.Configure(catalog, button, label);
            button.onClick.Invoke();
            Assert.AreEqual(1, controller.RevealedTier);
        }
        [Test]
        public void DisabledControllerCannotRevealHint()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            controller.enabled = false;
            Assert.IsFalse(button.interactable);
            Assert.IsFalse(controller.ShowNextHint());
            Assert.AreEqual(0, controller.RevealedTier);
        }

        [Test]
        public void RebindingLabelDoesNotExposeStaleHint()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            Assert.IsTrue(controller.ShowNextHint());
            var secondLabel = root.AddComponent<Text>();
            secondLabel.text = "stale";
            controller.Configure(root.GetComponent<AuthoredPuzzleHintCatalog>(), button, secondLabel);
            Assert.AreEqual(0, controller.RevealedTier);
            Assert.AreEqual(string.Empty, secondLabel.text);
            Assert.AreEqual(string.Empty, label.text);
        }

        [Test]
        public void ReenablingControllerRestoresAvailabilityWithoutAutoRevealing()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            controller.enabled = false;
            controller.enabled = true;
            Assert.IsTrue(button.interactable);
            Assert.AreEqual(0, controller.RevealedTier);
            button.onClick.Invoke();
            Assert.AreEqual(1, controller.RevealedTier);
        }

        [Test]
        public void DisablingClearsVisibleHintWithoutRevealingOnEnable()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            Assert.IsTrue(controller.ShowNextHint());
            controller.enabled = false;
            Assert.AreEqual(string.Empty, label.text);
            controller.enabled = true;
            Assert.AreEqual(string.Empty, label.text);
            Assert.AreEqual(0, controller.RevealedTier);
            Assert.IsTrue(controller.ShowNextHint());
            Assert.AreEqual(1, controller.RevealedTier);
        }

        [Test]
        public void ReenableDoesNotSkipPreviouslyHiddenHintTier()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            Assert.IsTrue(controller.ShowNextHint());
            Assert.IsTrue(controller.ShowNextHint());
            Assert.AreEqual(2, controller.RevealedTier);
            controller.enabled = false;
            controller.enabled = true;
            Assert.AreEqual(0, controller.RevealedTier);
            Assert.AreEqual(string.Empty, label.text);
            Assert.IsTrue(controller.ShowNextHint());
            Assert.AreEqual(1, controller.RevealedTier);
        }

        [Test]
        public void ExcessivelyLargeEvidenceSnapshotIsRejectedAtomically()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            Assert.IsFalse(controller.SetContext("scene_02", new[] { new string('x', 257) }));
            Assert.AreEqual("scene_01", controller.PuzzleId);
            Assert.IsTrue(controller.ShowNextHint());
        }

        [Test]
        public void NullEvidenceItemIsRejectedAtomically()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            Assert.IsFalse(controller.SetContext("scene_02", new string[] { null }));
            Assert.AreEqual("scene_01", controller.PuzzleId);
        }

        [Test]
        public void Exactly4096DistinctEvidenceIdentifiersAreAccepted()
        {
            var ids = new string[4096];
            for (int i = 0; i < ids.Length; i++) ids[i] = "evidence_" + i;
            Assert.IsTrue(controller.SetContext("scene_01", ids));
            Assert.AreEqual("scene_01", controller.PuzzleId);
        }

        [Test]
        public void EvidenceBeyond4096IsRejectedWithoutChangingContext()
        {
            Assert.IsTrue(controller.SetContext("scene_01", Array.Empty<string>()));
            var ids = new string[4097];
            for (int i = 0; i < ids.Length; i++) ids[i] = "evidence_" + i;
            Assert.IsFalse(controller.SetContext("scene_02", ids));
            Assert.AreEqual("scene_01", controller.PuzzleId);
        }

    }
}
