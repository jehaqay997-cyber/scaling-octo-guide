using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterThreeMechanismTests
    {
        [Test]
        public void AuthoredContracts_CoverExactlyThreeSites()
        {
            Assert.IsTrue(ChapterThreeMechanismPuzzle.Validate(out string error), error);
            Assert.IsFalse(ChapterThreeVisualCatalog.TryGet(6, out _));
            Assert.IsFalse(ChapterThreeVisualCatalog.TryGet(10, out _));
            Assert.Throws<ArgumentOutOfRangeException>(() => new ChapterThreeMechanismPuzzle(6));
            Assert.Throws<ArgumentOutOfRangeException>(() => new ChapterThreeMechanismPuzzle(10));
            for (int location = 7; location <= 9; location++)
            {
                var puzzle = new ChapterThreeMechanismPuzzle(location);
                Assert.AreEqual(3, ChapterStoryGraph.GetLocation(location).Chapter);
                Assert.AreEqual(4, puzzle.Case.Choices.Count);
                Assert.AreEqual(3, puzzle.Hints.Count);
                Assert.IsFalse(puzzle.IsVerified);
                Assert.IsNotEmpty(ChapterThreeVisualCatalog.Get(location).Inscription);
                Assert.IsNotEmpty(ChapterThreeVisualCatalog.Get(location).SolvedMark);
            }
        }

        [TestCase(7)]
        [TestCase(8)]
        [TestCase(9)]
        public void WorldInscriptionRevealsNeitherClueNorSolutionEarly(int location)
        {
            ChapterThreeVisualSpec visual = ChapterThreeVisualCatalog.Get(location);
            Assert.IsNotEmpty(visual.LockedMark);
            Assert.AreNotEqual(visual.UnsolvedMark, visual.LockedMark);
            Assert.AreNotEqual(visual.SolvedMark, visual.LockedMark);
            Assert.AreNotEqual(visual.SolvedMark, visual.UnsolvedMark);
            for (int first = 0; first <= 1; first++)
            {
                for (int second = 0; second <= 1; second++)
                {
                    bool both = first == 1 && second == 1;
                    Assert.AreEqual(both ? visual.UnsolvedMark : visual.LockedMark,
                        visual.GetVisibleMark(first == 1, second == 1, false));
                    Assert.AreEqual(both ? visual.SolvedMark : visual.LockedMark,
                        visual.GetVisibleMark(first == 1, second == 1, true));
                }
            }
        }

        [TestCase(7, 0)]
        [TestCase(8, 2)]
        [TestCase(9, 1)]
        public void ChoiceRequiresIndependentEvidenceAndCorrectAuthoredAnswer(int location, int solution)
        {
            var puzzle = new ChapterThreeMechanismPuzzle(location);
            Assert.IsTrue(puzzle.Case.IsCorrect(solution));
            Assert.AreEqual(ChapterThreeSelection.Invalid, puzzle.Select(-1, true, true));
            Assert.AreEqual(ChapterThreeSelection.Invalid, puzzle.Select(4, true, true));
            Assert.AreEqual(ChapterThreeSelection.EvidenceRequired,
                puzzle.Select(solution, false, true));
            Assert.AreEqual(ChapterThreeSelection.EvidenceRequired,
                puzzle.Select(solution, true, false));
            Assert.IsFalse(puzzle.TryRevealHint(false, true));
            Assert.AreEqual(0, puzzle.Attempts);
            Assert.AreEqual(-1, puzzle.LastChoice);
            int wrong = (solution + 1) % 4;
            Assert.AreEqual(ChapterThreeSelection.Incorrect, puzzle.Select(wrong, true, true));
            Assert.AreEqual(1, puzzle.Attempts);
            Assert.AreEqual(wrong, puzzle.LastChoice);
            Assert.IsFalse(puzzle.IsVerified);
            Assert.AreEqual(ChapterThreeSelection.Verified, puzzle.Select(solution, true, true));
            Assert.IsTrue(puzzle.IsVerified);
            Assert.AreEqual(2, puzzle.Attempts);
            Assert.AreEqual(ChapterThreeSelection.AlreadyVerified, puzzle.Select(wrong, true, true));
            Assert.AreEqual(2, puzzle.Attempts);
        }

        [TestCase(7)]
        [TestCase(8)]
        [TestCase(9)]
        public void HintBudgetAndResetNeverCreateProgress(int location)
        {
            var puzzle = new ChapterThreeMechanismPuzzle(location);
            Assert.IsFalse(puzzle.TryRevealHint(false, false));
            for (int index = 1; index <= ChapterThreeMechanismPuzzle.MaximumHintStage; index++)
            {
                Assert.IsTrue(puzzle.TryRevealHint(true, true));
                Assert.AreEqual(index, puzzle.HintStage);
                Assert.IsFalse(puzzle.IsVerified);
            }
            Assert.IsFalse(puzzle.TryRevealHint(true, true));
            Assert.AreEqual(0, puzzle.Attempts);
            puzzle.Reset();
            Assert.AreEqual(0, puzzle.HintStage);
            Assert.AreEqual(0, puzzle.Attempts);
            Assert.AreEqual(-1, puzzle.LastChoice);
            Assert.IsFalse(puzzle.IsVerified);
        }
    }
}
