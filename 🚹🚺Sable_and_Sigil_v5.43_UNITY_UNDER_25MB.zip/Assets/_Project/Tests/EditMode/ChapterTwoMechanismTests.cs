using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterTwoMechanismTests
    {
        [Test]
        public void CatalogContracts_FourLocationsMatchAuthoritativeDossiers()
        {
            Assert.IsTrue(ChapterTwoMechanismPuzzle.Validate(out string error), error);
            Assert.IsFalse(ChapterTwoVisualCatalog.TryGet(2, out _));
            Assert.IsFalse(ChapterTwoVisualCatalog.TryGet(7, out _));
            Assert.Throws<ArgumentOutOfRangeException>(() => new ChapterTwoMechanismPuzzle(2));
            Assert.Throws<ArgumentOutOfRangeException>(() => new ChapterTwoMechanismPuzzle(7));
            for (int number = 3; number <= 6; number++)
            {
                var puzzle = new ChapterTwoMechanismPuzzle(number);
                Assert.AreEqual(number, puzzle.LocationNumber);
                Assert.AreEqual(2, ChapterStoryGraph.GetLocation(number).Chapter);
                Assert.AreEqual(4, puzzle.Case.Choices.Count);
                Assert.AreEqual(3, puzzle.Hints.Count);
                Assert.IsFalse(puzzle.IsVerified);
                Assert.IsNotEmpty(ChapterTwoVisualCatalog.Get(number).UnsolvedMark);
            }
        }

        [TestCase(3, 0)]
        [TestCase(4, 1)]
        [TestCase(5, 3)]
        [TestCase(6, 1)]
        public void MechanismRequiresBothInspectedCluesAndCorrectSelection(int location, int solution)
        {
            var puzzle = new ChapterTwoMechanismPuzzle(location);
            Assert.AreEqual(ChapterTwoSelection.Invalid, puzzle.Select(-1, true, true));
            Assert.AreEqual(ChapterTwoSelection.Invalid, puzzle.Select(4, true, true));
            Assert.AreEqual(ChapterTwoSelection.EvidenceRequired, puzzle.Select(solution, true, false));
            Assert.AreEqual(ChapterTwoSelection.EvidenceRequired, puzzle.Select(solution, false, true));
            Assert.IsFalse(puzzle.TryRevealHint(true, false));
            Assert.IsFalse(puzzle.IsVerified);
            Assert.AreEqual(0, puzzle.Attempts);
            int wrong = (solution + 1) % 4;
            Assert.AreEqual(ChapterTwoSelection.Incorrect, puzzle.Select(wrong, true, true));
            Assert.AreEqual(1, puzzle.Attempts);
            Assert.AreEqual(wrong, puzzle.LastChoice);
            Assert.IsFalse(puzzle.IsVerified);
            Assert.AreEqual(ChapterTwoSelection.Verified, puzzle.Select(solution, true, true));
            Assert.IsTrue(puzzle.IsVerified);
            Assert.AreEqual(2, puzzle.Attempts);
            Assert.AreEqual(ChapterTwoSelection.AlreadyVerified, puzzle.Select(wrong, true, true));
            Assert.AreEqual(2, puzzle.Attempts);
            Assert.IsFalse(puzzle.TryRevealHint(true, true));
        }

        [Test]
        public void HintBudgetIsFiniteAndNeverVerifiesMechanism()
        {
            var puzzle = new ChapterTwoMechanismPuzzle(5);
            for (int stage = 1; stage <= ChapterTwoMechanismPuzzle.MaximumHintStage; stage++)
            {
                Assert.IsTrue(puzzle.TryRevealHint(true, true));
                Assert.AreEqual(stage, puzzle.HintStage);
                Assert.IsFalse(puzzle.IsVerified);
                Assert.AreEqual(0, puzzle.Attempts);
            }
            Assert.IsFalse(puzzle.TryRevealHint(true, true));
            Assert.AreEqual(3, puzzle.HintStage);
            puzzle.Reset();
            Assert.AreEqual(0, puzzle.HintStage);
            Assert.AreEqual(0, puzzle.Attempts);
            Assert.AreEqual(-1, puzzle.LastChoice);
            Assert.IsFalse(puzzle.IsVerified);
            Assert.IsTrue(puzzle.TryRevealHint(true, true));
        }

        [Test]
        public void SolvingOneLocationNeverAdvancesAnotherLocation()
        {
            for (int location = 3; location <= 6; location++)
            {
                var puzzle = new ChapterTwoMechanismPuzzle(location);
                int solution = -1;
                for (int choice = 0; choice < puzzle.Case.Choices.Count; choice++)
                    if (puzzle.Case.IsCorrect(choice)) solution = choice;
                Assert.AreEqual(ChapterTwoSelection.Verified, puzzle.Select(solution, true, true));
                for (int otherLocation = 3; otherLocation <= 6; otherLocation++)
                {
                    if (otherLocation == location) continue;
                    var other = new ChapterTwoMechanismPuzzle(otherLocation);
                    Assert.IsFalse(other.IsVerified);
                    Assert.AreEqual(0, other.Attempts);
                }
            }
        }
    }
}
