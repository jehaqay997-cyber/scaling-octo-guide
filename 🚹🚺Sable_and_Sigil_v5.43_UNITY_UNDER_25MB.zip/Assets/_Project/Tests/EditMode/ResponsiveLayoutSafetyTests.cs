using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ResponsiveLayoutSafetyTests
    {
        [Test]
        public void DisableRestoresCompleteCanvasScalerConfiguration()
        {
            var root = new GameObject("LayoutTestRoot");
            try
            {
                var camera = new GameObject("LayoutCamera").AddComponent<Camera>();
                camera.transform.SetParent(root.transform, false);
                var canvasObject = new GameObject("LayoutCanvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
                canvasObject.transform.SetParent(root.transform, false);
                var scaler = canvasObject.GetComponent<CanvasScaler>();
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ConstantPixelSize;
                scaler.referenceResolution = new Vector2(913f, 617f);
                scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
                scaler.matchWidthOrHeight = .73f;
                var layout = root.AddComponent<OrderScreenLayout>();
                layout.Configure(camera, canvasObject.GetComponent<RectTransform>(), scaler);
                scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scaler.referenceResolution = new Vector2(1280f, 720f);
                scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
                scaler.matchWidthOrHeight = .2f;
                layout.enabled = false;
                Assert.AreEqual(CanvasScaler.ScaleMode.ConstantPixelSize, scaler.uiScaleMode);
                Assert.AreEqual(new Vector2(913f, 617f), scaler.referenceResolution);
                Assert.AreEqual(CanvasScaler.ScreenMatchMode.MatchWidthOrHeight, scaler.screenMatchMode);
                Assert.AreEqual(.73f, scaler.matchWidthOrHeight, .00001f);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void ActionSlotWidthIsBoundedByAvailableLayoutWidth()
        {
            var root = new GameObject("SlotTestRoot");
            try
            {
                var camera = new GameObject("LayoutCamera").AddComponent<Camera>();
                camera.transform.SetParent(root.transform, false);
                var canvasObject = new GameObject("LayoutCanvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
                canvasObject.transform.SetParent(root.transform, false);
                var content = new GameObject("Content", typeof(RectTransform));
                content.transform.SetParent(canvasObject.transform, false);
                var button = new GameObject("UNDO", typeof(RectTransform), typeof(Image), typeof(Button));
                button.transform.SetParent(content.transform, false);
                var layout = root.AddComponent<OrderScreenLayout>();
                layout.Configure(camera, content.GetComponent<RectTransform>(), canvasObject.GetComponent<CanvasScaler>());
                var width = typeof(OrderScreenLayout).GetField("availableLayoutWidth", BindingFlags.Instance | BindingFlags.NonPublic);
                var place = typeof(OrderScreenLayout).GetMethod("PlaceInSlots", BindingFlags.Instance | BindingFlags.NonPublic);
                Assert.IsNotNull(width);
                Assert.IsNotNull(place);
                width.SetValue(layout, 600f);
                place.Invoke(layout, new object[] { "UNDO", .375f, .045f, 180f, 58f, 4 });
                Assert.LessOrEqual(button.GetComponent<RectTransform>().sizeDelta.x, 600f / 4f * .86f + .001f);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void RebindingLayoutRestoresThePreviousCanvasBeforeCapturingNewOne()
        {
            var root = new GameObject("RebindTestRoot");
            try
            {
                var camera = new GameObject("LayoutCamera").AddComponent<Camera>();
                camera.transform.SetParent(root.transform, false);
                var first = new GameObject("FirstCanvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
                first.transform.SetParent(root.transform, false);
                var second = new GameObject("SecondCanvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
                second.transform.SetParent(root.transform, false);
                var firstScaler = first.GetComponent<CanvasScaler>();
                firstScaler.matchWidthOrHeight = .61f;
                var layout = root.AddComponent<OrderScreenLayout>();
                layout.Configure(camera, first.GetComponent<RectTransform>(), firstScaler);
                firstScaler.matchWidthOrHeight = .11f;
                layout.Configure(camera, second.GetComponent<RectTransform>(), second.GetComponent<CanvasScaler>());
                Assert.AreEqual(.61f, firstScaler.matchWidthOrHeight, .00001f);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }
    }
}
