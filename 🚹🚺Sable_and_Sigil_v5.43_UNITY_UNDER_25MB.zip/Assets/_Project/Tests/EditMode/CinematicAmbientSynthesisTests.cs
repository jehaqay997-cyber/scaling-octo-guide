using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class CinematicAmbientSynthesisTests
    {
        [TestCase(1)]
        [TestCase(2)]
        [TestCase(3)]
        [TestCase(4)]
        public void AmbientLoop_IsDeterministicFinitePeriodicAndBounded(int chapter)
        {
            float[] first = CinematicAmbientSynthesis.Create(chapter);
            float[] second = CinematicAmbientSynthesis.Create(chapter);
            Assert.AreEqual(CinematicAmbientSynthesis.SampleCount, first.Length);
            CollectionAssert.AreEqual(first, second);
            float maximum = 0f;
            foreach (float sample in first)
            {
                Assert.IsFalse(float.IsNaN(sample) || float.IsInfinity(sample));
                maximum = Math.Max(maximum, Math.Abs(sample));
            }
            Assert.Greater(maximum, .05f);
            Assert.LessOrEqual(maximum, CinematicAmbientSynthesis.PeakLimit);
            Assert.Less(Math.Abs(first[0] - first[first.Length - 1]), .03f);
        }

        [Test]
        public void AmbientLoop_RejectsInvalidChapter()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => CinematicAmbientSynthesis.Create(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => CinematicAmbientSynthesis.Create(5));
            Assert.Throws<ArgumentOutOfRangeException>(() => CinematicAmbientSynthesis.Create(-1));
        }
    }
}
