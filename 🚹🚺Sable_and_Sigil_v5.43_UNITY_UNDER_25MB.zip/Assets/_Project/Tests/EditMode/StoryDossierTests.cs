using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class StoryDossierTests
    {
        private static readonly int[] CorrectAnswers = { 2, 3, 0, 1, 3, 1, 0, 2, 1, 2 };

        private sealed class FakeStorage : IStoryDossierStorage
        {
            public readonly Dictionary<string, string> Values = new Dictionary<string, string>(StringComparer.Ordinal);
            public bool FailWrite;
            public bool FailFlush;
            public int FlushCount;
            public bool Contains(string key) => Values.ContainsKey(key);
            public string Read(string key) => Values.TryGetValue(key, out string value) ? value : string.Empty;
            public void Write(string key, string value)
            {
                if (FailWrite) throw new InvalidOperationException("Injected write failure.");
                Values[key] = value;
            }
            public void Flush()
            {
                if (FailFlush) throw new InvalidOperationException("Injected flush failure.");
                FlushCount++;
            }
        }

        [Test]
        public void Catalog_ContainsTenUniqueSolvableCases()
        {
            Assert.That(StoryDossierCatalog.Validate(out string error), Is.True, error);
            Assert.That(StoryDossierCatalog.All.Count, Is.EqualTo(ChapterStoryGraph.LocationCount));
            for (int scene = 1; scene <= ChapterStoryGraph.LocationCount; scene++)
            {
                StoryDossierCase dossier = StoryDossierCatalog.Get(scene);
                Assert.That(dossier.Number, Is.EqualTo(scene));
                Assert.That(dossier.Choices.Count, Is.EqualTo(4));
                Assert.That(dossier.Choices.Distinct(StringComparer.OrdinalIgnoreCase).Count(), Is.EqualTo(4));
                for (int choice = 0; choice < 4; choice++)
                    Assert.That(dossier.IsCorrect(choice), Is.EqualTo(choice == CorrectAnswers[scene - 1]));
                Assert.That(dossier.IsCorrect(-1), Is.False);
                Assert.That(dossier.IsCorrect(4), Is.False);
            }
            Assert.Throws<ArgumentOutOfRangeException>(() => StoryDossierCatalog.Get(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => StoryDossierCatalog.Get(11));
        }

        [Test]
        public void CheckpointCodec_RoundTripsEveryReachablePrefix()
        {
            for (int count = 0; count <= 10; count++)
            {
                int[] ids = Enumerable.Range(1, count).ToArray();
                string saved = StoryDossierCheckpointCodec.Encode(count, ids);
                Assert.That(StoryDossierCheckpointCodec.TryDecode(saved, out long revision, out int[] restored), Is.True);
                Assert.That(revision, Is.EqualTo(count));
                CollectionAssert.AreEqual(ids, restored);
                Assert.That(saved.Length, Is.LessThan(512));
            }
        }

        [Test]
        public void CheckpointCodec_RejectsTamperingAndInvalidOrdering()
        {
            string valid = StoryDossierCheckpointCodec.Encode(2, new[] { 1, 2 });
            string[] bad =
            {
                null, string.Empty, valid + "x", "v2|2|1,2|" + new string('0', 64),
                valid.Replace("1,2", "1,3"), valid.Replace("v1|2", "v1|3"),
                valid.ToUpperInvariant(), new string('x', 600)
            };
            foreach (string snapshot in bad)
                Assert.That(StoryDossierCheckpointCodec.TryDecode(snapshot, out _, out _), Is.False);
            Assert.Throws<ArgumentException>(() => StoryDossierCheckpointCodec.Encode(1, new[] { 2 }));
            Assert.Throws<ArgumentException>(() => StoryDossierCheckpointCodec.Encode(2, new[] { 2, 1 }));
            Assert.Throws<ArgumentException>(() => StoryDossierCheckpointCodec.Encode(1, new[] { 1, 1 }));
            Assert.Throws<ArgumentException>(() => StoryDossierCheckpointCodec.Encode(-1, Array.Empty<int>()));
            Assert.Throws<ArgumentException>(() => StoryDossierCheckpointCodec.Encode(2, new[] { 1 }));
            Assert.Throws<ArgumentException>(() => StoryDossierCheckpointCodec.Encode(long.MaxValue, Array.Empty<int>()));
            Assert.Throws<ArgumentException>(() => StoryDossierCheckpointCodec.Encode(0, null));
        }

        [Test]
        public void AllTenInvestigations_CommitOnceAndRestoreInOrder()
        {
            var disk = new FakeStorage();
            var session = new StoryDossierSession(disk);
            Assert.That(session.IsReady, Is.True);
            Assert.That(session.CanInvestigate(1), Is.True);
            Assert.That(session.CanInvestigate(2), Is.False);
            for (int scene = 1; scene <= 10; scene++)
            {
                int wrong = (CorrectAnswers[scene - 1] + 1) % 4;
                long before = session.Revision;
                Assert.That(session.TrySubmit(scene, wrong, before, out _), Is.False);
                Assert.That(session.Revision, Is.EqualTo(before));
                Assert.That(session.TrySubmit(scene, CorrectAnswers[scene - 1], before, out string explanation), Is.True, explanation);
                Assert.That(session.CompletedCount, Is.EqualTo(scene));
                Assert.That(session.IsCompleted(scene), Is.True);
                Assert.That(session.TrySubmit(scene, CorrectAnswers[scene - 1], session.Revision, out _), Is.False);
                Assert.That(session.TrySubmit(scene, CorrectAnswers[scene - 1], before, out _), Is.False);
                session = new StoryDossierSession(disk);
                Assert.That(session.IsReady, Is.True, session.Error);
                Assert.That(session.Revision, Is.EqualTo(scene));
                for (int resolved = 1; resolved <= scene; resolved++)
                    Assert.That(session.IsCompleted(resolved), Is.True);
            }
            Assert.That(session.CanInvestigate(10), Is.True);
            Assert.That(disk.FlushCount, Is.EqualTo(10));
        }

        [Test]
        public void OutOfOrderSubmission_AndInvalidChoices_NeverWrite()
        {
            var disk = new FakeStorage();
            var session = new StoryDossierSession(disk);
            Assert.That(session.TrySubmit(2, 3, 0, out _), Is.False);
            Assert.That(session.TrySubmit(1, -1, 0, out _), Is.False);
            Assert.That(session.TrySubmit(1, 4, 0, out _), Is.False);
            Assert.That(session.TrySubmit(0, 0, 0, out _), Is.False);
            Assert.That(session.TrySubmit(11, 0, 0, out _), Is.False);
            Assert.That(disk.FlushCount, Is.Zero);
            Assert.That(disk.Values.Count, Is.Zero);
        }

        [Test]
        public void WriteFailure_DoesNotCommitOrDamageOriginalSlot()
        {
            var disk = new FakeStorage();
            var session = new StoryDossierSession(disk);
            Assert.That(session.TrySubmit(1, 2, 0, out _), Is.True);
            string original = disk.Read(StoryDossierRepository.KeyA);
            disk.FailWrite = true;
            Assert.That(session.TrySubmit(2, 3, 1, out _), Is.False);
            Assert.That(session.Revision, Is.EqualTo(1));
            Assert.That(disk.Read(StoryDossierRepository.KeyA), Is.EqualTo(original));
            disk.FailWrite = false;
            Assert.That(new StoryDossierSession(disk).CompletedCount, Is.EqualTo(1));
        }

        [Test]
        public void FlushFailure_DoesNotAdvanceLiveSession()
        {
            var disk = new FakeStorage { FailFlush = true };
            var session = new StoryDossierSession(disk);
            Assert.That(session.TrySubmit(1, 2, 0, out _), Is.False);
            Assert.That(session.Revision, Is.Zero);
            Assert.That(session.CompletedCount, Is.Zero);
        }

        [Test]
        public void FailedFlush_LocksSessionUntilExplicitReconciliation()
        {
            var disk = new FakeStorage { FailFlush = true };
            var session = new StoryDossierSession(disk);
            Assert.That(session.TrySubmit(1, 2, 0, out _), Is.False);
            Assert.That(session.IsReady, Is.False);
            Assert.That(session.TrySubmit(1, 2, 0, out _), Is.False);
            Assert.That(session.Revision, Is.Zero);
            disk.FailFlush = false;
            Assert.That(session.TryReload(out string error), Is.True, error);
            Assert.That(session.IsReady, Is.True);
            Assert.That(session.Revision, Is.EqualTo(1));
            Assert.That(session.IsCompleted(1), Is.True);
        }

        [Test]
        public void NonAdjacentValidSlots_AreRejectedAsInconsistentHistory()
        {
            var disk = new FakeStorage();
            disk.Values[StoryDossierRepository.KeyA] = StoryDossierCheckpointCodec.Encode(1, new[] { 1 });
            disk.Values[StoryDossierRepository.KeyB] = StoryDossierCheckpointCodec.Encode(4, new[] { 1, 2, 3, 4 });
            var session = new StoryDossierSession(disk);
            Assert.That(session.IsReady, Is.False);
            Assert.That(session.Error, Does.Contain("Nonconsecutive"));
            Assert.That(disk.Values.Count, Is.EqualTo(2));
        }

        [Test]
        public void CorruptNewerSlot_FallsBackToValidOlderCopy()
        {
            var disk = new FakeStorage();
            var session = new StoryDossierSession(disk);
            Assert.That(session.TrySubmit(1, 2, 0, out _), Is.True);
            Assert.That(session.TrySubmit(2, 3, 1, out _), Is.True);
            disk.Values[StoryDossierRepository.KeyB] = "corrupt";
            var recovered = new StoryDossierSession(disk);
            Assert.That(recovered.IsReady, Is.True, recovered.Error);
            Assert.That(recovered.CompletedCount, Is.EqualTo(1));
            Assert.That(recovered.TrySubmit(2, 3, 1, out _), Is.True);
            Assert.That(new StoryDossierSession(disk).CompletedCount, Is.EqualTo(2));
        }

        [Test]
        public void BothCorruptSlots_FailClosedWithoutDeletingData()
        {
            var disk = new FakeStorage();
            disk.Values[StoryDossierRepository.KeyA] = "broken A";
            disk.Values[StoryDossierRepository.KeyB] = "broken B";
            var session = new StoryDossierSession(disk);
            Assert.That(session.IsReady, Is.False);
            Assert.That(session.CanInvestigate(1), Is.False);
            Assert.That(session.TrySubmit(1, 2, 0, out _), Is.False);
            Assert.That(disk.Values[StoryDossierRepository.KeyA], Is.EqualTo("broken A"));
            Assert.That(disk.Values[StoryDossierRepository.KeyB], Is.EqualTo("broken B"));
        }

        [Test]
        public void FutureVersion_ProtectsBothSlotsFromOverwrite()
        {
            var disk = new FakeStorage();
            disk.Values[StoryDossierRepository.KeyA] = StoryDossierCheckpointCodec.Encode(1, new[] { 1 });
            disk.Values[StoryDossierRepository.KeyB] = "v2|2|1,2|futuredata";
            var session = new StoryDossierSession(disk);
            Assert.That(session.IsReady, Is.False);
            Assert.That(session.Error, Does.Contain("future"));
            Assert.That(session.TrySubmit(2, 3, 1, out _), Is.False);
            Assert.That(disk.Values[StoryDossierRepository.KeyB], Does.StartWith("v2|"));
        }

        [Test]
        public void DivergentSameRevision_IsRejectedBeforeStorage()
        {
            Assert.Throws<ArgumentException>(() =>
                StoryDossierCheckpointCodec.Encode(3, new[] { 1, 2 }));
            Assert.Throws<ArgumentException>(() =>
                StoryDossierCheckpointCodec.Encode(3, new[] { 1 }));
            var disk = new FakeStorage();
            disk.Values[StoryDossierRepository.KeyA] = StoryDossierCheckpointCodec.Encode(2, new[] { 1, 2 });
            disk.Values[StoryDossierRepository.KeyB] = "v1|3|1|" + new string('0', 64);
            var session = new StoryDossierSession(disk);
            Assert.That(session.IsReady, Is.True);
            Assert.That(session.CompletedCount, Is.EqualTo(2));
            Assert.That(disk.Values.Count, Is.EqualTo(2));
        }

        [Test]
        public void IndependentSessions_RejectStaleConcurrentWrites()
        {
            var disk = new FakeStorage();
            var first = new StoryDossierSession(disk);
            var second = new StoryDossierSession(disk);
            Assert.That(first.TrySubmit(1, 2, 0, out _), Is.True);
            Assert.That(second.TrySubmit(1, 2, 0, out _), Is.False);
            Assert.That(second.Revision, Is.Zero);
            Assert.That(new StoryDossierSession(disk).Revision, Is.EqualTo(1));
        }
    }
}
