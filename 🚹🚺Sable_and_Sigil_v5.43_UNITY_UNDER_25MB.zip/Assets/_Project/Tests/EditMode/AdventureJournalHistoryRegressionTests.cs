using System;
using System.IO;
using System.Security.Cryptography;
using NUnit.Framework;
using TheOrderRoom.AppCore;
using TheOrderRoom.Domain;
using TheOrderRoom.Infrastructure;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class AdventureJournalHistoryRegressionTests
    {
        private string directory;
        private AdventureJournalStore store;

        [SetUp]
        public void SetUp()
        {
            directory = Path.Combine(Path.GetTempPath(), "tor-journal-chain-" + Guid.NewGuid().ToString("N"));
            store = new AdventureJournalStore(directory);
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(directory)) Directory.Delete(directory, true);
        }

        private void BuildTwoRevisions()
        {
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot genesis));
            Assert.IsTrue(AdventureChapter.TryAct(genesis, AdventureAction.TakeKey, 0,
                out AdventureSnapshot first, out string firstError), firstError);
            Assert.AreEqual(AdventureCommitResult.Committed, store.Commit(0, first));
            Assert.IsTrue(AdventureChapter.TryAct(first, AdventureAction.OpenArchive, 1,
                out AdventureSnapshot second, out string secondError), secondError);
            Assert.AreEqual(AdventureCommitResult.Committed, store.Commit(1, second));
        }

        private string RecordPath(long revision) => Path.Combine(directory,
            "adventure.r" + revision.ToString("D20", System.Globalization.CultureInfo.InvariantCulture) + ".bin");

        [Test]
        public void HistoricalRecordCorruptionRejectsReadAndLaterCommits()
        {
            BuildTwoRevisions();
            byte[] first = File.ReadAllBytes(RecordPath(1));
            first[20] ^= 0x01;
            File.WriteAllBytes(RecordPath(1), first);
            Assert.IsFalse(store.TryRead(out _));
            Assert.IsFalse(store.TryInitialize(out _));
            Assert.IsTrue(AdventureChapter.TryTravel(
                new AdventureSnapshot(1, 2, AdventureLocation.Courtyard,
                    AdventureFacts.KeyTaken | AdventureFacts.ArchiveOpened),
                AdventureLocation.Archive, 2, out AdventureSnapshot third, out _));
            Assert.AreEqual(AdventureCommitResult.Rejected, store.Commit(2, third));
        }

        [Test]
        public void ValidChecksumCannotMakeAnIllegalHistoricalTransitionLegal()
        {
            BuildTwoRevisions();
            byte[] first = File.ReadAllBytes(RecordPath(1));
            // A well-formed but impossible transition: revision 1 remains at the genesis state.
            Array.Clear(first, 20, 4);
            using (var sha = SHA256.Create())
            {
                byte[] digest = sha.ComputeHash(first, 0, first.Length - 32);
                Buffer.BlockCopy(digest, 0, first, first.Length - 32, 32);
            }
            File.WriteAllBytes(RecordPath(1), first);
            Assert.IsFalse(store.TryRead(out _));
        }

        [Test]
        public void CorruptedGenesisWithIntactLaterRecordIsRejected()
        {
            BuildTwoRevisions();
            byte[] genesis = File.ReadAllBytes(RecordPath(0));
            genesis[0] ^= 0x01;
            File.WriteAllBytes(RecordPath(0), genesis);
            Assert.IsFalse(store.TryRead(out _));
        }

        [Test]
        public void CompleteValidChainCanBeReadAfterRestart()
        {
            BuildTwoRevisions();
            Assert.IsTrue(new AdventureJournalStore(directory).TryRead(out AdventureSnapshot snapshot));
            Assert.AreEqual(2L, snapshot.Revision);
            Assert.IsTrue(snapshot.Has(AdventureFacts.ArchiveOpened));
        }
    }
}
