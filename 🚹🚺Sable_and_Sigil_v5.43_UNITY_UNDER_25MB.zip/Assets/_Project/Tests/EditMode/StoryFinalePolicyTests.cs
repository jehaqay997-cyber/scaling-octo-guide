using System;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class StoryFinalePolicyTests
    {
        [Test]
        public void FinaleIsLockedAcrossAllIncompletePrefixes()
        {
            var ledger = new StoryEvidenceLedger();
            Assert.IsFalse(StoryFinalePolicy.IsUnlocked(ledger.Revision, ledger.Snapshot()));
            for (int caseNumber = 1; caseNumber <= 10; caseNumber++)
            {
                Assert.IsTrue(ledger.TryResolve(caseNumber, ledger.Revision, out _));
                Assert.AreEqual(caseNumber == 10,
                    StoryFinalePolicy.IsUnlocked(ledger.Revision, ledger.Snapshot()));
            }
        }

        [Test]
        public void TamperedAndDuplicatedEvidenceNeverUnlocksTheFinale()
        {
            int[] all = Enumerable.Range(1, 10).ToArray();
            Assert.IsTrue(StoryFinalePolicy.IsUnlocked(10, all));
            Assert.IsFalse(StoryFinalePolicy.IsUnlocked(9, all));
            Assert.IsFalse(StoryFinalePolicy.IsUnlocked(11, all));
            Assert.IsFalse(StoryFinalePolicy.IsUnlocked(10, all.Take(9).ToArray()));
            Assert.IsFalse(StoryFinalePolicy.IsUnlocked(10, new[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 9 }));
            Assert.IsFalse(StoryFinalePolicy.IsUnlocked(10, null));
        }

        [Test]
        public void FinalPagesHaveBoundedNavigationWithoutWraparound()
        {
            for (int page = 0; page < StoryFinalePolicy.PageCount; page++)
            {
                Assert.AreEqual(Math.Min(page + 1, StoryFinalePolicy.PageCount - 1),
                    StoryFinalePolicy.NextPage(page));
                Assert.AreEqual(Math.Max(page - 1, 0), StoryFinalePolicy.PreviousPage(page));
            }
            Assert.Throws<ArgumentOutOfRangeException>(() => StoryFinalePolicy.NextPage(-1));
            Assert.Throws<ArgumentOutOfRangeException>(() => StoryFinalePolicy.PreviousPage(4));
        }

        [Test]
        public void RevisionCannotExceedTheNumberOfCommittedDeductions()
        {
            var ledger = new StoryEvidenceLedger();
            Assert.IsFalse(ledger.Restore(4, new[] { 1, 2 }));
            Assert.IsFalse(ledger.Restore(long.MaxValue, Array.Empty<int>()));
            Assert.IsTrue(ledger.Restore(2, new[] { 1, 2 }));
            Assert.AreEqual(2, ledger.Revision);
        }
    }
}
