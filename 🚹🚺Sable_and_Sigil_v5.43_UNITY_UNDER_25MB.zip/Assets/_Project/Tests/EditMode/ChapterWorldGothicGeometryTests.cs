using System;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterWorldGothicGeometryTests
    {
        [TestCase(4)]
        [TestCase(12)]
        [TestCase(16)]
        [TestCase(48)]
        public void PointedArch_HasFiniteSymmetricBoundsAndValidTriangleIndices(int segments)
        {
            const float halfSpan = 2f;
            const float spring = 1.25f;
            Mesh mesh = ChapterWorldGothicGeometry.CreatePointedArch(
                halfSpan, .25f, .36f, spring, segments);
            try
            {
                Assert.AreEqual(2 * (segments + 1) * 4, mesh.vertexCount);
                Assert.AreEqual(2 * (8 * segments + 4) * 3, mesh.triangles.Length);
                Assert.That(mesh.bounds.min.x, Is.EqualTo(-halfSpan).Within(.0002f));
                Assert.That(mesh.bounds.max.x, Is.EqualTo(halfSpan).Within(.0002f));
                Assert.That(mesh.bounds.min.y, Is.EqualTo(spring).Within(.0002f));
                Assert.That(mesh.bounds.max.y,
                    Is.EqualTo(spring + Mathf.Sqrt(3f) * halfSpan).Within(.0002f));
                Assert.That(mesh.bounds.min.z, Is.EqualTo(-.18f).Within(.0001f));
                Assert.That(mesh.bounds.max.z, Is.EqualTo(.18f).Within(.0001f));
                Vector3[] vertices = mesh.vertices;
                foreach (Vector3 vertex in vertices)
                {
                    Assert.IsFalse(float.IsNaN(vertex.x) || float.IsNaN(vertex.y) || float.IsNaN(vertex.z));
                    Assert.IsFalse(float.IsInfinity(vertex.x) || float.IsInfinity(vertex.y) ||
                        float.IsInfinity(vertex.z));
                }
                foreach (int triangleIndex in mesh.triangles)
                    Assert.That(triangleIndex, Is.InRange(0, vertices.Length - 1));
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void SpiralBalusterMesh_IsFrontFacingFiniteAndBounded()
        {
            Mesh mesh = ChapterWorldSpiralGlyphGeometry.Create();
            try
            {
                Assert.AreEqual("Owned Spiral Baluster Motifs", mesh.name);
                Assert.AreEqual(71, mesh.vertexCount);
                Assert.AreEqual(174, mesh.triangles.Length);
                foreach (int triangleIndex in mesh.triangles)
                    Assert.That(triangleIndex, Is.InRange(0, mesh.vertexCount - 1));
                foreach (Vector3 normal in mesh.normals)
                    Assert.Less(normal.z, -.99f,
                        "The stair ornaments must face the camera at negative Z.");
                foreach (Vector3 vertex in mesh.vertices)
                {
                    Assert.IsFalse(float.IsNaN(vertex.x) || float.IsNaN(vertex.y) || float.IsNaN(vertex.z));
                    Assert.That(vertex.x, Is.InRange(-3f, 3f));
                    Assert.That(vertex.y, Is.InRange(1f, 3f));
                }
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void SpiralBalusterRepair_ReusesOwnedMeshAndFacesCamera()
        {
            Mesh mesh = ChapterWorldSpiralGlyphGeometry.Create();
            try
            {
                Assert.AreEqual(71, mesh.vertexCount);
                ChapterWorldSpiralGlyphGeometry.Repair(mesh);
                Assert.AreEqual(66, mesh.vertexCount,
                    "The empty square must be replaced with the final star geometry.");
                Assert.AreEqual(180, mesh.triangles.Length);
                foreach (Vector3 normal in mesh.normals)
                    Assert.Less(normal.z, -.99f);
                ChapterWorldSpiralGlyphGeometry.Repair(mesh);
                Assert.AreEqual(66, mesh.vertexCount,
                    "Repeated repair must not accumulate geometry.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void RejectsDegenerateOrNonFiniteArchitecturalDimensions()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(0f, .2f, .4f, 1f, 16));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(2f, 2f, .4f, 1f, 16));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(2f, -.2f, .4f, 1f, 16));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(2f, .2f, 0f, 1f, 16));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(float.NaN, .2f, .4f, 1f, 16));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(2f, .2f, float.PositiveInfinity, 1f, 16));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(2f, .2f, .4f, float.NegativeInfinity, 16));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(2f, .2f, .4f, 1f, 3));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(2f, .2f, .4f, 1f, 49));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(21f, .2f, .4f, 1f, 16));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(2f, .2f, 4.1f, 1f, 16));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldGothicGeometry.CreatePointedArch(2f, .2f, .4f, -21f, 16));
        }
        [Test]
        public void EvidencePedestalInlays_AreBoundedUpwardFacingAndMotifAccurate()
        {
            for (int count = 1; count <= 8; count++)
            {
                Mesh mesh = ChapterWorldPedestalInlayGeometry.Create(count);
                try
                {
                    Assert.AreEqual("Owned Evidence Pedestal Inlay", mesh.name);
                    Assert.AreEqual(count * 4, mesh.vertexCount);
                    Assert.AreEqual(count * 6, mesh.triangles.Length);
                    Assert.LessOrEqual(mesh.vertexCount, ChapterWorldPedestalInlayGeometry.MaximumVertices);
                    Assert.LessOrEqual(mesh.triangles.Length / 3,
                        ChapterWorldPedestalInlayGeometry.MaximumTriangles);
                    foreach (Vector3 normal in mesh.normals)
                        Assert.Greater(normal.y, .99f);
                    foreach (Vector3 vertex in mesh.vertices)
                    {
                        Assert.That(vertex.y, Is.EqualTo(0f).Within(.000001f));
                        Assert.That(new Vector2(vertex.x, vertex.z).magnitude,
                            Is.InRange(.45f, .63f));
                    }
                    foreach (int index in mesh.triangles)
                        Assert.That(index, Is.InRange(0, mesh.vertexCount - 1));
                }
                finally
                {
                    UnityEngine.Object.DestroyImmediate(mesh);
                }
            }
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldPedestalInlayGeometry.Create(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldPedestalInlayGeometry.Create(9));
        }

        [TestCase(12)]
        [TestCase(48)]
        [TestCase(96)]
        public void FirstChapterCrestRelief_IsBoundedFacesPlayerAndHasClosedRing(int segments)
        {
            Mesh mesh = ChapterOneCrestReliefMesh.CreateRing(.88f, .825f, segments);
            try
            {
                Assert.AreEqual("Owned First Chapter Crest Relief", mesh.name);
                Assert.AreEqual(segments * 2, mesh.vertexCount);
                Assert.AreEqual(segments * 6, mesh.triangles.Length);
                Assert.That(mesh.bounds.min.x, Is.LessThan(-.8f));
                Assert.That(mesh.bounds.max.x, Is.GreaterThan(.8f));
                foreach (Vector3 normal in mesh.normals)
                    Assert.That(normal.z, Is.LessThan(-.99f));
                foreach (int index in mesh.triangles)
                    Assert.That(index, Is.InRange(0, mesh.vertexCount - 1));
                foreach (Vector3 vertex in mesh.vertices)
                {
                    Assert.That(vertex.z, Is.EqualTo(0f));
                    Assert.That(new Vector2(vertex.x, vertex.y).magnitude,
                        Is.InRange(.8249f, .8801f));
                }
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void ChapterOneRayStuds_AreBatchedBoundedAndFrontFacing()
        {
            Vector2[] centers = {
                new Vector2(-2f, 2.8f), new Vector2(-1.5f, 2.5f),
                new Vector2(0f, 2.8f), new Vector2(.5f, 3.3f)
            };
            Mesh mesh = ChapterOneCrestReliefMesh.CreateStuds(centers, .042f);
            try
            {
                Assert.AreEqual("Owned First Chapter Crest Ray Studs", mesh.name);
                Assert.AreEqual(16, mesh.vertexCount);
                Assert.AreEqual(24, mesh.triangles.Length);
                foreach (Vector3 normal in mesh.normals)
                    Assert.That(normal.z, Is.LessThan(-.99f));
                foreach (int index in mesh.triangles)
                    Assert.That(index, Is.InRange(0, mesh.vertexCount - 1));
                for (int index = 0; index < 4; index++)
                {
                    Vector3 a = mesh.vertices[index * 4];
                    Vector3 b = mesh.vertices[index * 4 + 1];
                    Vector3 c = mesh.vertices[index * 4 + 2];
                    Assert.Less(Vector3.Cross(b - a, c - a).z, -.0001f);
                }
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateStuds(null, .04f));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateStuds(new Vector2[0], .04f));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateStuds(centers, float.NaN));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateStuds(centers, .10f));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateStuds(new[] {
                    new Vector2(float.PositiveInfinity, 2f) }, .04f));
        }

        [Test]
        public void FirstChapterCrestRelief_RejectsInvalidAndNonFiniteInputs()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateRing(0f, .2f, 48));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateRing(1f, 1f, 48));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateRing(1f, -1f, 48));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateRing(float.NaN, .2f, 48));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateRing(1f, float.PositiveInfinity, 48));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateRing(1f, .8f, 11));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateRing(1f, .8f, 97));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneCrestReliefMesh.CreateRing(9f, .8f, 48));
        }
    }
}
