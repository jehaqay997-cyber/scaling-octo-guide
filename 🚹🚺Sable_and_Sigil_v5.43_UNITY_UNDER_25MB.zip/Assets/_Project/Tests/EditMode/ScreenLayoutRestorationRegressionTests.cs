using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ScreenLayoutRestorationRegressionTests
    {
        [Test]
        public void DisablingLayoutRestoresModifiedButtonAndTextRectangles()
        {
            var root = new GameObject("LayoutFixture");
            var cameraObject = new GameObject("Camera");
            try
            {
                cameraObject.transform.SetParent(root.transform, false);
                var camera = cameraObject.AddComponent<Camera>();
                var canvas = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
                canvas.transform.SetParent(root.transform, false);
                var content = new GameObject("Content", typeof(RectTransform));
                content.transform.SetParent(canvas.transform, false);
                var buttonObject = new GameObject("UNDO", typeof(RectTransform), typeof(Image), typeof(Button));
                buttonObject.transform.SetParent(content.transform, false);
                var labelObject = new GameObject("Label", typeof(RectTransform), typeof(Text));
                labelObject.transform.SetParent(buttonObject.transform, false);
                var buttonRect = buttonObject.GetComponent<RectTransform>();
                var labelRect = labelObject.GetComponent<RectTransform>();
                var label = labelObject.GetComponent<Text>();
                buttonRect.anchorMin = new Vector2(.15f, .3f);
                buttonRect.anchorMax = new Vector2(.35f, .5f);
                buttonRect.anchoredPosition = new Vector2(21, 34);
                buttonRect.sizeDelta = new Vector2(185, 59);
                labelRect.anchorMin = new Vector2(.1f, .2f);
                labelRect.anchorMax = new Vector2(.8f, .9f);
                labelRect.offsetMin = new Vector2(2, 3);
                labelRect.offsetMax = new Vector2(-4, -5);
                label.resizeTextForBestFit = false;
                label.resizeTextMinSize = 7;
                label.resizeTextMaxSize = 37;
                var expectedAnchorMin = buttonRect.anchorMin;
                var expectedAnchorMax = buttonRect.anchorMax;
                var expectedPosition = buttonRect.anchoredPosition;
                var expectedSize = buttonRect.sizeDelta;
                var expectedLabelMin = labelRect.anchorMin;
                var expectedLabelMax = labelRect.anchorMax;
                var expectedLabelOffsetMin = labelRect.offsetMin;
                var expectedLabelOffsetMax = labelRect.offsetMax;
                var layout = root.AddComponent<OrderScreenLayout>();
                layout.Configure(camera, content.GetComponent<RectTransform>(), canvas.GetComponent<CanvasScaler>());
                var method = typeof(OrderScreenLayout).GetMethod("Place", BindingFlags.Instance | BindingFlags.NonPublic);
                Assert.IsNotNull(method);
                method.Invoke(layout, new object[] { "UNDO", .5f, .05f, 180f, 58f });
                Assert.AreNotEqual(expectedAnchorMin, buttonRect.anchorMin);
                layout.enabled = false;
                Assert.AreEqual(expectedAnchorMin, buttonRect.anchorMin);
                Assert.AreEqual(expectedAnchorMax, buttonRect.anchorMax);
                Assert.AreEqual(expectedPosition, buttonRect.anchoredPosition);
                Assert.AreEqual(expectedSize, buttonRect.sizeDelta);
                Assert.AreEqual(expectedLabelMin, labelRect.anchorMin);
                Assert.AreEqual(expectedLabelMax, labelRect.anchorMax);
                Assert.AreEqual(expectedLabelOffsetMin, labelRect.offsetMin);
                Assert.AreEqual(expectedLabelOffsetMax, labelRect.offsetMax);
                Assert.IsFalse(label.resizeTextForBestFit);
                Assert.AreEqual(7, label.resizeTextMinSize);
                Assert.AreEqual(37, label.resizeTextMaxSize);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }
    }
}
