using System;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterWorldRingGeometryTests
    {
        [TestCase(12, 6)]
        [TestCase(40, 10)]
        [TestCase(96, 24)]
        public void Torus_IsClosedAndUsesOutwardWinding(int major, int tube)
        {
            Mesh mesh = ChapterWorldRingGeometry.Create(.8f, .045f, major, tube);
            try
            {
                Assert.AreEqual((major + 1) * (tube + 1), mesh.vertexCount);
                Assert.AreEqual(major * tube * 6, mesh.triangles.Length);
                Assert.AreEqual(mesh.vertexCount, mesh.normals.Length);
                Assert.AreEqual(mesh.vertexCount, mesh.uv.Length);
                Assert.That(mesh.vertices[0].x, Is.EqualTo(.845f).Within(.00001f));
                Assert.That(mesh.vertices[0].y, Is.EqualTo(0f).Within(.00001f));
                Assert.That(mesh.vertices[0].z, Is.EqualTo(0f).Within(.00001f));
                Assert.That(Vector3.Dot(mesh.normals[0], Vector3.right), Is.GreaterThan(.999f));
                int[] triangle = mesh.triangles;
                Vector3[] vertices = mesh.vertices;
                Vector3 outward = Vector3.Cross(vertices[triangle[1]] - vertices[triangle[0]],
                    vertices[triangle[2]] - vertices[triangle[0]]);
                Assert.Greater(Vector3.Dot(outward, mesh.normals[triangle[0]]), 0f);
                for (int i = 0; i < triangle.Length; i++)
                    Assert.That(triangle[i], Is.InRange(0, mesh.vertexCount - 1));
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void Torus_RejectsNonFiniteAndOversizedDimensions()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldRingGeometry.Create(float.NaN, .03f));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldRingGeometry.Create(float.PositiveInfinity, .03f));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldRingGeometry.Create(.8f, 0f));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldRingGeometry.Create(.8f, .4f));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldRingGeometry.Create(3.1f, .03f));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldRingGeometry.Create(.8f, .03f, 11, 10));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldRingGeometry.Create(.8f, .03f, 40, 25));
        }
    }
}
