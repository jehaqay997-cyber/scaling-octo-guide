using System;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterWorldVaultGeometryTests
    {
        [TestCase(4, 2)]
        [TestCase(20, 8)]
        [TestCase(48, 24)]
        public void PointedVault_HasBoundedSymmetricDoubleSidedGeometry(int width, int length)
        {
            Mesh mesh = ChapterWorldVaultGeometry.CreateVault(
                5f, 5.75f, 1.25f, -2.5f, 3f, width, length);
            try
            {
                Assert.AreEqual(2 * (width + 1) * (length + 1), mesh.vertexCount);
                Assert.AreEqual(width * length * 12, mesh.triangles.Length);
                Assert.AreEqual(mesh.vertexCount, mesh.uv.Length);
                Assert.That(mesh.bounds.min.x, Is.EqualTo(-5f).Within(.0002f));
                Assert.That(mesh.bounds.max.x, Is.EqualTo(5f).Within(.0002f));
                Assert.That(mesh.bounds.min.z, Is.EqualTo(-2.5f).Within(.0002f));
                Assert.That(mesh.bounds.max.z, Is.EqualTo(3f).Within(.0002f));
                Assert.That(mesh.bounds.min.y, Is.EqualTo(5.75f).Within(.0002f));
                Assert.That(mesh.bounds.max.y, Is.EqualTo(7f).Within(.0002f));
                var vertices = mesh.vertices;
                foreach (Vector3 vertex in vertices)
                {
                    Assert.IsFalse(float.IsNaN(vertex.x) || float.IsNaN(vertex.y) || float.IsNaN(vertex.z));
                    Assert.IsFalse(float.IsInfinity(vertex.x) || float.IsInfinity(vertex.y) ||
                        float.IsInfinity(vertex.z));
                }
                foreach (int index in mesh.triangles)
                    Assert.That(index, Is.InRange(0, vertices.Length - 1));
                Vector3[] normals = mesh.normals;
                Assert.Less(normals[width + 1].y, 0f);
                Assert.Greater(normals[width + 1 + (width + 1) * (length + 1)].y, 0f);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void EveryAuthoredLocation_GeneratesAStableBoundedTwoEvidenceFloorSigil()
        {
            for (int location = 1; location <= ChapterWorldSceneCatalog.PrototypeCount; location++)
            {
                ChapterEvidenceVisualSpec a = ChapterEvidenceVisualCatalog.Get(location, 0);
                ChapterEvidenceVisualSpec b = ChapterEvidenceVisualCatalog.Get(location, 1);
                Mesh mesh = ChapterWorldFloorSigilGeometry.Create(location);
                Mesh second = ChapterWorldFloorSigilGeometry.Create(location);
                try
                {
                    int quads = ChapterWorldFloorSigilGeometry.OuterRingSegments +
                        ChapterWorldFloorSigilGeometry.InnerRingSegments +
                        a.MotifCount + b.MotifCount;
                    Assert.AreEqual(quads * 4, mesh.vertexCount);
                    Assert.AreEqual(quads * 6, mesh.triangles.Length);
                    Assert.LessOrEqual(mesh.vertexCount, ChapterWorldFloorSigilGeometry.MaximumVertices);
                    Assert.LessOrEqual(mesh.triangles.Length / 3,
                        ChapterWorldFloorSigilGeometry.MaximumTriangles);
                    Assert.AreEqual(mesh.vertexCount, mesh.uv.Length);
                    CollectionAssert.AreEqual(mesh.vertices, second.vertices);
                    CollectionAssert.AreEqual(mesh.triangles, second.triangles);
                    foreach (Vector3 normal in mesh.normals)
                        Assert.Greater(normal.y, .999f);
                    foreach (Vector2 uv in mesh.uv)
                    {
                        Assert.That(uv.x, Is.InRange(0f, 1f));
                        Assert.That(uv.y, Is.InRange(0f, 1f));
                    }
                    Assert.Greater(mesh.bounds.size.x, 2f);
                    Assert.Greater(mesh.bounds.size.z, 2f);
                    Assert.AreEqual("Owned Investigation Floor Sigil", mesh.name);
                }
                finally
                {
                    UnityEngine.Object.DestroyImmediate(mesh);
                    UnityEngine.Object.DestroyImmediate(second);
                }
            }
        }

        [Test]
        public void InvestigationFloorSigil_RejectsOutOfRangeLocationWithoutAllocatingMesh()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldFloorSigilGeometry.Create(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldFloorSigilGeometry.Create(11));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldFloorSigilGeometry.Create(-1));
        }

        [Test]
        public void PointedVault_RejectsMalformedAndNonFiniteDimensions()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldVaultGeometry.CreateVault(0f, 5f, 1f, -1f, 1f, 20, 8));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldVaultGeometry.CreateVault(5f, 5f, 0f, -1f, 1f, 20, 8));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldVaultGeometry.CreateVault(5f, float.NaN, 1f, -1f, 1f, 20, 8));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldVaultGeometry.CreateVault(5f, 5f, 1f, 2f, -2f, 20, 8));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldVaultGeometry.CreateVault(5f, 5f, 1f, float.PositiveInfinity, 1f, 20, 8));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldVaultGeometry.CreateVault(13f, 5f, 1f, -1f, 1f, 20, 8));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldVaultGeometry.CreateVault(5f, 5f, 1f, -1f, 1f, 3, 8));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterWorldVaultGeometry.CreateVault(5f, 5f, 1f, -1f, 1f, 20, 25));
        }
    }
}
