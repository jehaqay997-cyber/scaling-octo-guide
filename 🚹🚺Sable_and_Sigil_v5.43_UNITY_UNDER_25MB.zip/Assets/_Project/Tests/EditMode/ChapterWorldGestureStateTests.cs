using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterWorldGestureStateTests
    {
        [Test]
        public void ShortPointerMovement_ProducesOnlyOneTap()
        {
            var gesture = new ChapterWorldGestureState();
            gesture.Begin(new Vector2(100f, 200f));
            Assert.AreEqual(0f, gesture.Move(new Vector2(105f, 204f)));
            Assert.IsTrue(gesture.End(new Vector2(107f, 205f)));
            Assert.IsFalse(gesture.End(new Vector2(107f, 205f)));
            Assert.IsFalse(gesture.IsActive);
        }

        [Test]
        public void DraggedPointer_CannotInspectEvenIfItReturnsNearOrigin()
        {
            var gesture = new ChapterWorldGestureState();
            gesture.Begin(new Vector2(100f, 100f));
            Assert.AreEqual(0f, gesture.Move(new Vector2(105f, 100f)));
            Assert.AreEqual(17f, gesture.Move(new Vector2(122f, 100f)));
            Assert.IsTrue(gesture.IsDragging);
            Assert.AreEqual(-18f, gesture.Move(new Vector2(104f, 100f)));
            Assert.IsFalse(gesture.End(new Vector2(101f, 100f)));
        }

        [Test]
        public void VerticalDrag_DoesNotRotateOrInspect()
        {
            var gesture = new ChapterWorldGestureState();
            gesture.Begin(Vector2.zero);
            Assert.AreEqual(0f, gesture.Move(new Vector2(0f, 40f)));
            Assert.IsTrue(gesture.IsDragging);
            Assert.IsFalse(gesture.End(new Vector2(0f, 40f)));
        }

        [Test]
        public void CancelledOrNonFiniteGesture_NeverInspects()
        {
            var gesture = new ChapterWorldGestureState();
            gesture.Begin(Vector2.zero);
            gesture.Cancel();
            Assert.IsFalse(gesture.End(Vector2.zero));
            gesture.Begin(new Vector2(float.NaN, 0f));
            Assert.IsFalse(gesture.IsActive);
            gesture.Begin(Vector2.one);
            Assert.AreEqual(0f, gesture.Move(new Vector2(float.PositiveInfinity, 0f)));
            Assert.IsFalse(gesture.End(Vector2.one));
        }

        [Test]
        public void RepeatedSessions_DoNotSharePointerState()
        {
            var gesture = new ChapterWorldGestureState();
            gesture.Begin(Vector2.zero);
            gesture.Move(new Vector2(100f, 0f));
            gesture.Cancel();
            gesture.Begin(new Vector2(200f, 200f));
            Assert.IsFalse(gesture.IsDragging);
            Assert.IsTrue(gesture.End(new Vector2(200f, 200f)));
        }
    }
}
