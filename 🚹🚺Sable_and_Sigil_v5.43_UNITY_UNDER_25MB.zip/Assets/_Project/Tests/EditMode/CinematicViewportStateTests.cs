using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class CinematicViewportStateTests
    {
        [Test]
        public void ZoomAndPanRemainBoundedInEveryDirection()
        {
            var view = new CinematicViewportState();
            Assert.IsFalse(view.TryPan(99f, 10f));
            Assert.IsTrue(view.TryZoom(.2f));
            Assert.IsTrue(view.TryPan(9999f, -9999f));
            Assert.AreEqual(160f, view.PanX, .001f);
            Assert.AreEqual(-90f, view.PanY, .001f);
            Assert.IsTrue(view.TryZoom(-.2f));
            Assert.AreEqual(0f, view.PanX);
            Assert.AreEqual(0f, view.PanY);
            Assert.AreEqual(1f, view.Zoom);
        }

        [Test]
        public void InvalidNumbersCannotPoisonViewportState()
        {
            var view = new CinematicViewportState();
            Assert.IsFalse(view.TryZoom(float.NaN));
            Assert.IsFalse(view.TryZoom(float.PositiveInfinity));
            Assert.IsFalse(view.TryPan(1f, float.NegativeInfinity));
            Assert.AreEqual(1f, view.Zoom);
            Assert.AreEqual(0f, view.PanX);
            Assert.AreEqual(0f, view.PanY);
        }

        [Test]
        public void ZoomCeilingIsStrictAndResetIsIdempotent()
        {
            var view = new CinematicViewportState();
            Assert.IsTrue(view.TryZoom(100f));
            Assert.AreEqual(CinematicViewportState.MaximumZoom, view.Zoom);
            Assert.IsFalse(view.TryZoom(1f));
            view.Reset();
            view.Reset();
            Assert.AreEqual(CinematicViewportState.MinimumZoom, view.Zoom);
        }
    }
}
