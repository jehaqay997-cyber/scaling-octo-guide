using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterCheckpointCodecTests
    {
        [Test]
        public void RoundTripValidCheckpointPreservesState()
        {
            const int flags = ChapterOneProgress.KeyFlag | ChapterOneProgress.LetterFlag;
            string value = ChapterCheckpointCodec.Encode(22, flags, 0);
            long revision;
            int decodedFlags;
            int dial;
            Assert.That(ChapterCheckpointCodec.TryDecode(value, out revision, out decodedFlags, out dial), Is.True);
            Assert.That(revision, Is.EqualTo(22));
            Assert.That(decodedFlags, Is.EqualTo(flags));
            Assert.That(dial, Is.Zero);
        }

        [Test]
        public void InvalidOrTruncatedSnapshotsAreRejected()
        {
            string valid = ChapterCheckpointCodec.Encode(1, ChapterOneProgress.KeyFlag, 0);
            long revision;
            int flags;
            int dial;
            Assert.That(ChapterCheckpointCodec.TryDecode(valid.Substring(0, valid.Length - 1),
                out revision, out flags, out dial), Is.False);
            Assert.That(ChapterCheckpointCodec.TryDecode(valid.Replace("|1|", "|2|"),
                out revision, out flags, out dial), Is.False);
            Assert.That(ChapterCheckpointCodec.TryDecode("1|9|32|314|00000000",
                out revision, out flags, out dial), Is.False);
            Assert.That(ChapterCheckpointCodec.TryDecode(null, out revision, out flags, out dial), Is.False);
        }

        [Test]
        public void InvalidProgressCannotBeWritten()
        {
            Assert.Throws<System.ArgumentOutOfRangeException>(() =>
                ChapterCheckpointCodec.Encode(1, ChapterOneProgress.ObservatoryFlag, 314));
            Assert.Throws<System.ArgumentOutOfRangeException>(() =>
                ChapterCheckpointCodec.Encode(0, 0, 0));
        }
    }
}
