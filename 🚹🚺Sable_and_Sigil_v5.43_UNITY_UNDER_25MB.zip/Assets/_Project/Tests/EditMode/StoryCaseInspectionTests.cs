using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class StoryCaseInspectionTests
    {
        [Test]
        public void EveryCaseRequiresTwoDistinctInspectionsBeforeDeduction()
        {
            Assert.IsTrue(StoryDossierCatalog.Validate(out string error), error);
            for (int number = 1; number <= ChapterStoryGraph.LocationCount; number++)
            {
                var inspection = new StoryCaseInspection(number);
                Assert.AreEqual(2, inspection.EvidenceCount);
                Assert.IsFalse(inspection.CanDeduce);
                Assert.AreEqual(-1, inspection.SelectedEvidenceIndex);
                Assert.IsFalse(inspection.TryInspect(-1, out _));
                Assert.IsFalse(inspection.TryInspect(2, out _));
                Assert.AreEqual(0, inspection.InspectedCount);
                Assert.IsTrue(inspection.TryInspect(1, out string second));
                Assert.IsNotEmpty(second);
                Assert.IsTrue(inspection.TryInspect(1, out string repeated));
                Assert.AreEqual(second, repeated);
                Assert.AreEqual(1, inspection.InspectedCount);
                Assert.IsFalse(inspection.CanDeduce);
                Assert.IsTrue(inspection.TryInspect(0, out string first));
                Assert.AreNotEqual(first, second);
                Assert.AreEqual(2, inspection.InspectedCount);
                Assert.IsTrue(inspection.CanDeduce);
                Assert.IsTrue(inspection.HasInspected(0));
                Assert.IsTrue(inspection.HasInspected(1));
            }
        }

        [Test]
        public void ReopeningCaseStartsFreshInspectionWithoutChangingDurableProgress()
        {
            var first = new StoryCaseInspection(1);
            Assert.IsTrue(first.TryInspect(0, out _));
            Assert.IsTrue(first.TryInspect(1, out _));
            var reopened = new StoryCaseInspection(1);
            Assert.IsFalse(reopened.CanDeduce);
            Assert.AreEqual(0, reopened.InspectedCount);
            Assert.AreEqual(1, reopened.CaseNumber);
            Assert.Throws<System.ArgumentOutOfRangeException>(() => new StoryCaseInspection(0));
        }
    }
}
