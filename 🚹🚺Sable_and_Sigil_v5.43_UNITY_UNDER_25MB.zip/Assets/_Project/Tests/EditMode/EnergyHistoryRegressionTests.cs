#if UNITY_INCLUDE_TESTS
using System;
using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests
{
    public sealed class EnergyHistoryRegressionTests
    {
        [Test]
        public void RotationsOverCapacityRetainNewest128Snapshots()
        {
            var puzzle = new EnergyPuzzle(0);
            var reference = new List<int[]>();
            for (int turn = 0; turn < 170; turn++)
            {
                var snapshot = new int[9];
                for (int i = 0; i < 9; i++) snapshot[i] = puzzle.Ports(i);
                Assert.IsTrue(puzzle.Rotate(0, puzzle.Revision));
                if (reference.Count == 128) reference.RemoveAt(0);
                reference.Add(snapshot);
            }
            for (int i = reference.Count - 1; i >= 0; i--)
            {
                Assert.IsTrue(puzzle.Undo());
                for (int cell = 0; cell < 9; cell++)
                    Assert.AreEqual(reference[i][cell], puzzle.Ports(cell), "Undo snapshot mismatch at cell " + cell);
            }
            Assert.IsFalse(puzzle.Undo());
        }

        [Test]
        public void ResetDiscardsAllHistoricalSnapshots()
        {
            var puzzle = new EnergyPuzzle(1);
            var baseline = new int[9];
            for (int i = 0; i < 9; i++) baseline[i] = puzzle.Ports(i);
            Assert.IsTrue(puzzle.Rotate(0, puzzle.Revision));
            Assert.IsTrue(puzzle.Rotate(0, puzzle.Revision));
            Assert.IsTrue(puzzle.Reset());
            for (int i = 0; i < 9; i++) Assert.AreEqual(baseline[i], puzzle.Ports(i));
            Assert.IsFalse(puzzle.Undo());
        }

        [Test]
        public void FailedRotationsDoNotAddUndoSnapshots()
        {
            var puzzle = new EnergyPuzzle(2);
            long before = puzzle.Revision;
            Assert.IsFalse(puzzle.Rotate(-1, before));
            Assert.IsFalse(puzzle.Rotate(0, before + 1));
            Assert.IsFalse(puzzle.Rotate(9, before));
            Assert.IsFalse(puzzle.Undo());
            Assert.AreEqual(before, puzzle.Revision);
        }
    }
}
#endif
