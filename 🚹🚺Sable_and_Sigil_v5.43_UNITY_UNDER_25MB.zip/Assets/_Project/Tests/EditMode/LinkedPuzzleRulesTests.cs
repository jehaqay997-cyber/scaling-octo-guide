using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class LinkedPuzzleRulesTests
    {
        private static OrderBoard Board(params PuzzleRule[] rules) => new OrderBoard(
            new[] { new Item("key", "X", 1), new Item("dependent", "X", 1) },
            new[] { new Compartment("A", "X", 2, 2), new Compartment("B", "X", 2, 2) }, null, rules);
        [Test]
        public void KeyRequiresExactDrawerAndRejectsRemovalWithoutMutation()
        {
            var board = Board(new DestinationKeyRule("dependent", "key", "A"));
            Assert.IsTrue(board.Move("key", "B", out _));
            long revision = board.Revision;
            Assert.IsFalse(board.Move("dependent", "A", out _));
            Assert.AreEqual(revision, board.Revision);
            Assert.IsTrue(board.Move("key", "A", out _));
            Assert.IsTrue(board.Move("dependent", "B", out _));
            revision = board.Revision;
            Assert.IsFalse(board.Move("key", OrderBoard.Tray, out _));
            Assert.AreEqual(revision, board.Revision);
            Assert.IsTrue(board.Move("dependent", OrderBoard.Tray, out _));
            Assert.IsTrue(board.Move("key", OrderBoard.Tray, out _));
        }
        [Test]
        public void LinkedPairRejectsSplitRestoreAndAllowsTrayRecovery()
        {
            var board = Board(new LinkedPairRule("key", "dependent"));
            Assert.IsFalse(board.Restore(new Dictionary<string, string> { { "key", "A" }, { "dependent", "B" } }));
            Assert.IsTrue(board.Move("key", "A", out _));
            Assert.IsFalse(board.Move("dependent", "B", out _));
            Assert.IsTrue(board.Move("dependent", "A", out _));
            Assert.IsTrue(board.Solved);
            Assert.IsTrue(board.Move("key", OrderBoard.Tray, out _));
        }
        [Test]
        public void InvalidReferencesFailBeforePlay()
        {
            Assert.Throws<ArgumentException>(() => Board(new DestinationKeyRule("dependent", "missing", "A")));
            Assert.Throws<ArgumentException>(() => Board(new DestinationKeyRule("dependent", "key", "missing")));
            Assert.Throws<ArgumentException>(() => new LinkedPairRule("key", "key"));
        }
        [TestCase(5)] [TestCase(8)] [TestCase(11)]
        public void NewMechanicsAreIntegratedAndLegacyDefinitionsStayUnchanged(int level)
        {
            var current = CampaignPuzzles.Get(level, 2);
            Assert.IsTrue(current.Rules.OfType<LinkedPairRule>().Any());
            Assert.IsTrue(current.Rules.OfType<DestinationKeyRule>().Any());
            Assert.IsFalse(CampaignPuzzles.Get(level, 1).Rules.OfType<LinkedPairRule>().Any());
            Assert.IsFalse(OrderLevels.Create(level, 1).Rules.OfType<DestinationKeyRule>().Any());
            var board = current.CreateBoard();
            for (int i = 0; i < current.Items.Count; i++)
            {
                Assert.IsTrue(PuzzleHint.TrySuggest(current, board, out string item, out string destination));
                Assert.IsTrue(board.Move(item, destination, out string error), error);
            }
            Assert.IsTrue(board.Solved);
        }
    }
}
