using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterStoryGraphTests
    {
        [Test]
        public void FourChapters_TenLocations_ThreeTierHints_AreValidated()
        {
            Assert.IsTrue(ChapterStoryGraph.Validate(out string error), error);
            Assert.AreEqual(4, ChapterStoryGraph.ChapterCount);
            Assert.AreEqual(10, ChapterStoryGraph.AllLocations.Count);
            foreach (var location in ChapterStoryGraph.AllLocations)
            {
                Assert.AreEqual(3, location.HintTiers.Count);
                Assert.IsFalse(location.HasPlayableScene);
                Assert.AreEqual("LocationArt/Scene_" + location.Number.ToString("00"), location.ArtResource);
                Assert.IsTrue(location.Prerequisites.All(number => number < location.Number));
            }
            Assert.IsTrue(ChapterGalleryView.ValidateContentCatalog(out error), error);
        }

        [Test]
        public void EvidenceGraph_ResolvesAllScenesInAcyclicOrder()
        {
            var resolved = new HashSet<int>();
            for (int step = 1; step <= ChapterStoryGraph.LocationCount; step++)
            {
                Assert.IsTrue(ChapterStoryGraph.TrySuggestNext(resolved, out var scene));
                Assert.AreEqual(step, scene.Number);
                Assert.IsTrue(ChapterStoryGraph.IsAvailable(scene.Number, resolved));
                Assert.IsTrue(resolved.Add(scene.Number));
            }
            Assert.IsFalse(ChapterStoryGraph.TrySuggestNext(resolved, out _));
        }

        [Test]
        public void EvidenceLedger_PreventsOutOfOrderAndDuplicateClaims()
        {
            var ledger = new StoryEvidenceLedger();
            Assert.IsFalse(ledger.TryResolve(2, 0, out _));
            Assert.AreEqual(0, ledger.Revision);
            Assert.IsTrue(ledger.TryResolve(1, 0, out _));
            Assert.IsFalse(ledger.TryResolve(1, 1, out _));
            Assert.IsFalse(ledger.TryResolve(2, 0, out _));
            Assert.IsTrue(ledger.TryResolve(2, 1, out _));
            CollectionAssert.AreEqual(new[] { 1, 2 }, ledger.Snapshot());
            Assert.AreEqual(2, ledger.Revision);
        }

        [Test]
        public void EvidenceLedger_RejectsMalformedRestoreWithoutMutation()
        {
            var ledger = new StoryEvidenceLedger();
            Assert.IsTrue(ledger.TryResolve(1, 0, out _));
            foreach (var bad in new[] { new[] { 2 }, new[] { 1, 1 }, new[] { 0 }, new[] { 11 } })
            {
                Assert.IsFalse(ledger.Restore(50, bad));
                CollectionAssert.AreEqual(new[] { 1 }, ledger.Snapshot());
                Assert.AreEqual(1, ledger.Revision);
            }
            Assert.IsFalse(ledger.Restore(-1, new[] { 1 }));
            Assert.IsFalse(ledger.Restore(0, new[] { 1 }));
            Assert.IsFalse(ledger.Restore(1, null));
            Assert.IsFalse(ledger.Restore(5, new[] { 1, 2 }));
            Assert.IsTrue(ledger.Restore(2, new[] { 1, 2 }));
            Assert.AreEqual(2, ledger.Revision);
            Assert.IsFalse(ledger.TryResolve(3, 1, out _));
            Assert.IsTrue(ledger.TryResolve(3, 2, out _));
        }

        [Test]
        public void EvidenceLedger_SnapshotsAreDetachedAndSorted()
        {
            var ledger = new StoryEvidenceLedger();
            Assert.IsTrue(ledger.Restore(10, Enumerable.Range(1, 10).Reverse().ToArray()));
            var snapshot = ledger.Snapshot();
            CollectionAssert.AreEqual(Enumerable.Range(1, 10).ToArray(), snapshot);
            snapshot[0] = 999;
            Assert.IsTrue(ledger.Has(1));
            CollectionAssert.AreEqual(Enumerable.Range(1, 10).ToArray(), ledger.Snapshot());
        }

        [Test]
        public void EvidenceLedger_FailsClosedAtRevisionOverflow()
        {
            var ledger = new StoryEvidenceLedger();
            Assert.IsFalse(ledger.Restore(long.MaxValue, Array.Empty<int>()));
            Assert.AreEqual(0, ledger.Revision);
            Assert.AreEqual(0, ledger.Count);
            Assert.IsTrue(ledger.TryResolve(1, 0, out _));
            Assert.AreEqual(1, ledger.Revision);
        }

        [Test]
        public void EvidenceGraph_RejectsInvalidIdsAndNullCollections()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterStoryGraph.GetLocation(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterStoryGraph.GetLocation(11));
            Assert.Throws<ArgumentNullException>(() => ChapterStoryGraph.TrySuggestNext(null, out _));
            Assert.IsFalse(ChapterStoryGraph.TrySuggestNext(new[] { -1 }, out _));
            Assert.IsFalse(ChapterStoryGraph.TrySuggestNext(new[] { 11 }, out _));
        }
    }
}
