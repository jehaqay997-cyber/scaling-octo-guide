using System;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterWorldSceneCatalogTests
    {
        [Test]
        public void Every3DLocationResolvesToAuthoredCaseAndArtwork()
        {
            Assert.IsTrue(ChapterWorldSceneCatalog.Validate(out string error), error);
            Assert.AreEqual(10, ChapterWorldSceneCatalog.All.Count);
            Assert.AreEqual(10, ChapterWorldSceneCatalog.All.Select(s => s.SetType).Distinct().Count());
            var expectedChapters = new[] { 1, 1, 2, 2, 2, 2, 3, 3, 3, 4 };
            for (int number = 1; number <= 10; number++)
            {
                ChapterWorldSceneSpec spec = ChapterWorldSceneCatalog.Get(number);
                StoryDossierCase dossier = StoryDossierCatalog.Get(number);
                StoryLocation location = ChapterStoryGraph.GetLocation(number);
                Assert.AreEqual(number, spec.LocationNumber);
                Assert.AreEqual(expectedChapters[number - 1], spec.ChapterNumber);
                Assert.AreEqual(location.ArtResource, spec.ArtResource);
                Assert.AreEqual(location.Title, spec.Title);
                Assert.AreEqual(2, dossier.EvidenceFragments.Count);
                Assert.IsFalse(string.IsNullOrWhiteSpace(spec.EvidenceALabel));
                Assert.IsFalse(string.IsNullOrWhiteSpace(spec.EvidenceBLabel));
                Assert.IsFalse(location.HasPlayableScene,
                    "A procedural prototype must not be mistaken for a production scene.");
            }
        }

        [Test]
        public void AllTwentyEvidenceRelicsMatchAuthoredInvestigationFragments()
        {
            Assert.IsTrue(ChapterEvidenceVisualCatalog.Validate(out string error), error);
            Assert.AreEqual(20, ChapterEvidenceVisualCatalog.TotalEvidence);
            for (int location = 1; location <= ChapterWorldSceneCatalog.PrototypeCount; location++)
            {
                ChapterWorldSceneSpec world = ChapterWorldSceneCatalog.Get(location);
                ChapterEvidenceVisualSpec a = ChapterEvidenceVisualCatalog.Get(location, 0);
                ChapterEvidenceVisualSpec b = ChapterEvidenceVisualCatalog.Get(location, 1);
                Assert.AreEqual(world.EvidenceALabel, a.Label);
                Assert.AreEqual(world.EvidenceBLabel, b.Label);
                Assert.AreNotEqual(a.Silhouette, b.Silhouette);
                Assert.That(a.MotifCount, Is.InRange(1, 8));
                Assert.That(b.MotifCount, Is.InRange(1, 8));
                Assert.AreEqual(0, a.EvidenceIndex);
                Assert.AreEqual(1, b.EvidenceIndex);
            }
            Assert.AreEqual(5, ChapterEvidenceVisualCatalog.Get(1, 0).MotifCount);
            Assert.AreEqual(6, ChapterEvidenceVisualCatalog.Get(1, 1).MotifCount);
            Assert.AreEqual(4, ChapterEvidenceVisualCatalog.Get(10, 0).MotifCount);
        }

        [Test]
        public void EvidenceRelicsRejectMissingOrInvalidAuthoredReferences()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterEvidenceVisualCatalog.Get(0, 0));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterEvidenceVisualCatalog.Get(11, 1));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterEvidenceVisualCatalog.Get(1, -1));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterEvidenceVisualCatalog.Get(1, 2));
        }

        [Test]
        public void RejectsOutOfRangeCaseReferences()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldSceneCatalog.Get(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldSceneCatalog.Get(11));
        }
        [Test]
        public void StairPatternRequiresTwoCluesAndCannotBeSolvedByIncorrectSymbols()
        {
            Assert.IsTrue(SpiralBalusterPuzzle.ValidatePattern());
            Assert.AreEqual(6, SpiralBalusterPuzzle.VisibleSequence.Count);
            Assert.AreEqual(BalusterSymbol.Missing,
                SpiralBalusterPuzzle.VisibleSequence[SpiralBalusterPuzzle.MissingIndex]);
            Assert.AreEqual(BalusterSymbol.Star, SpiralBalusterPuzzle.RequiredSymbol);
            var puzzle = new SpiralBalusterPuzzle();
            Assert.AreEqual(BalusterSelection.Invalid,
                puzzle.Select((BalusterSymbol)42, true, true));
            Assert.AreEqual(BalusterSelection.EvidenceRequired,
                puzzle.Select(BalusterSymbol.Star, false, true));
            Assert.AreEqual(BalusterSelection.EvidenceRequired,
                puzzle.Select(BalusterSymbol.Star, true, false));
            Assert.AreEqual(BalusterSelection.Incorrect,
                puzzle.Select(BalusterSymbol.Circle, true, true));
            Assert.AreEqual(BalusterSelection.Incorrect,
                puzzle.Select(BalusterSymbol.Diamond, true, true));
            Assert.AreEqual(BalusterSelection.Incorrect,
                puzzle.Select(BalusterSymbol.Crescent, true, true));
            Assert.AreEqual(3, puzzle.Attempts);
            Assert.IsFalse(puzzle.IsVerified);
            Assert.AreEqual(BalusterSelection.Verified,
                puzzle.Select(BalusterSymbol.Star, true, true));
            Assert.IsTrue(puzzle.IsVerified);
            Assert.AreEqual(BalusterSelection.AlreadyVerified,
                puzzle.Select(BalusterSymbol.Circle, true, true));
            Assert.AreEqual(4, puzzle.Attempts);
            puzzle.Reset();
            Assert.IsFalse(puzzle.IsVerified);
            Assert.AreEqual(0, puzzle.Attempts);
        }

        [Test]
        public void SpiralSymbolAtlas_UsesDistinctBoundedShapesAndUvCoordinates()
        {
            Assert.AreEqual(96, ChapterOneSymbolAtlas.IconSize);
            Assert.AreEqual(4, ChapterOneSymbolAtlas.IconCount);
            Assert.IsTrue(ChapterOneSymbolAtlas.Contains(BalusterSymbol.Star, 0f, 0f));
            Assert.IsFalse(ChapterOneSymbolAtlas.Contains(BalusterSymbol.Circle, 0f, 0f));
            Assert.IsFalse(ChapterOneSymbolAtlas.Contains(BalusterSymbol.Diamond, 0f, 0f));
            Assert.IsTrue(ChapterOneSymbolAtlas.Contains(BalusterSymbol.Crescent, -.6f, 0f));
            Assert.IsFalse(ChapterOneSymbolAtlas.Contains(BalusterSymbol.Crescent, .6f, 0f));
            Assert.IsFalse(ChapterOneSymbolAtlas.Contains(BalusterSymbol.Star, float.NaN, 0f));
            Assert.IsFalse(ChapterOneSymbolAtlas.Contains(BalusterSymbol.Missing, 0f, 0f));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterOneSymbolAtlas.GetUv(BalusterSymbol.Missing));
            var seen = new System.Collections.Generic.HashSet<float>();
            foreach (BalusterSymbol symbol in new[] { BalusterSymbol.Circle,
                BalusterSymbol.Diamond, BalusterSymbol.Star, BalusterSymbol.Crescent })
            {
                Rect uv = ChapterOneSymbolAtlas.GetUv(symbol);
                Assert.That(uv.y, Is.EqualTo(0f));
                Assert.That(uv.height, Is.EqualTo(1f));
                Assert.That(uv.width, Is.EqualTo(.25f));
                Assert.IsTrue(uv.x >= 0f && uv.xMax <= 1f);
                Assert.IsTrue(seen.Add(uv.x));
            }
            Texture2D atlas = ChapterOneSymbolAtlas.Create();
            try
            {
                Assert.AreEqual(384, atlas.width);
                Assert.AreEqual(96, atlas.height);
                Assert.AreEqual(TextureWrapMode.Clamp, atlas.wrapMode);
                Assert.IsFalse(atlas.isReadable,
                    "Uploaded symbol atlas must discard its transient CPU-side pixel buffer.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(atlas);
            }
        }

        [Test]
        public void FiveOriginalRaysHaveOneUnmatchedSealRay()
        {
            Assert.IsTrue(ThresholdCrestPuzzle.ValidateGeometryContract());
            Assert.AreEqual(5, ThresholdCrestPuzzle.LetterRayAngles.Count);
            Assert.AreEqual(6, ThresholdCrestPuzzle.SealRayAngles.Count);
            Assert.AreEqual(252, ThresholdCrestPuzzle.SealRayAngles[ThresholdCrestPuzzle.AddedRayIndex]);
        }

        [Test]
        public void InspectedEvidenceIsRequiredBeforeAnyAttempt()
        {
            var puzzle = new ThresholdCrestPuzzle();
            int altered = ThresholdCrestPuzzle.AddedRayIndex;
            Assert.AreEqual(ThresholdRaySelection.EvidenceRequired, puzzle.Select(altered, false, false));
            Assert.AreEqual(ThresholdRaySelection.EvidenceRequired, puzzle.Select(altered, true, false));
            Assert.AreEqual(ThresholdRaySelection.EvidenceRequired, puzzle.Select(altered, false, true));
            Assert.AreEqual(0, puzzle.Attempts);
            Assert.IsFalse(puzzle.IsVerified);
        }

        [Test]
        public void InvalidIndicesNeverMutateMechanism()
        {
            var puzzle = new ThresholdCrestPuzzle();
            Assert.AreEqual(ThresholdRaySelection.Invalid, puzzle.Select(-1, true, true));
            Assert.AreEqual(ThresholdRaySelection.Invalid, puzzle.Select(6, true, true));
            Assert.IsFalse(puzzle.IsVerified);
            Assert.AreEqual(0, puzzle.Attempts);
        }

        [Test]
        public void EveryMatchingRayIsRejectedUntilInsertedRayIsSelected()
        {
            var puzzle = new ThresholdCrestPuzzle();
            for (int index = 0; index < ThresholdCrestPuzzle.SealRayAngles.Count; index++)
            {
                if (index == ThresholdCrestPuzzle.AddedRayIndex) continue;
                Assert.AreEqual(ThresholdRaySelection.Incorrect, puzzle.Select(index, true, true));
                Assert.IsFalse(puzzle.IsVerified);
            }
            Assert.AreEqual(5, puzzle.Attempts);
            Assert.AreEqual(ThresholdRaySelection.Verified,
                puzzle.Select(ThresholdCrestPuzzle.AddedRayIndex, true, true));
            Assert.IsTrue(puzzle.IsVerified);
            Assert.AreEqual(6, puzzle.Attempts);
        }

        [Test]
        public void VerificationIsIdempotentAndResetsForNewSession()
        {
            var puzzle = new ThresholdCrestPuzzle();
            int correct = ThresholdCrestPuzzle.AddedRayIndex;
            Assert.AreEqual(ThresholdRaySelection.Verified, puzzle.Select(correct, true, true));
            Assert.AreEqual(ThresholdRaySelection.AlreadyVerified, puzzle.Select(correct, true, true));
            Assert.AreEqual(1, puzzle.Attempts);
            puzzle.Reset();
            Assert.IsFalse(puzzle.IsVerified);
            Assert.AreEqual(0, puzzle.Attempts);
            Assert.AreEqual(ThresholdRaySelection.EvidenceRequired, puzzle.Select(correct, false, false));
        }
    }
}
