using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Editor;
using UnityEditor;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ThreeChapterSceneIntegrationTests
    {
        [Test]
        public void CanonicalChaptersAreDistinctAndLegacyIsExcluded()
        {
            string[] expected = SableChapterBuildRoute.ChapterScenes;
            Assert.That(expected.Length, Is.EqualTo(4));
            Assert.That(expected.Distinct().Count(), Is.EqualTo(4));
            Assert.That(expected, Does.Not.Contain(OrderSceneValidator.MainScene));
        }

        [Test]
        public void PreparedChaptersAreTheOnlyEnabledBuildScenes()
        {
            var scenes = EditorBuildSettings.scenes;
            var enabled = scenes.Where(scene => scene.enabled).Select(scene => scene.path).ToArray();
            CollectionAssert.AreEqual(SableChapterBuildRoute.ChapterScenes, enabled);
            Assert.That(SableChapterBuildRoute.Validate(), Is.Empty);
        }

        [Test]
        public void ConfigurePreservesButDisablesNonNarrativeScenes()
        {
            EditorBuildSettingsScene[] previous = EditorBuildSettings.scenes;
            try
            {
                EditorBuildSettings.scenes = new[]
                {
                    new EditorBuildSettingsScene(OrderSceneValidator.MainScene, true),
                    new EditorBuildSettingsScene(ChapterCaseSceneBuilder.ChapterThreeScene, true)
                };
                SableChapterBuildRoute.Configure();
                SableChapterBuildRoute.Configure();
                var configured = EditorBuildSettings.scenes;
                CollectionAssert.AreEqual(SableChapterBuildRoute.ChapterScenes,
                    configured.Where(scene => scene.enabled).Select(scene => scene.path));
                Assert.That(configured.Any(scene =>
                    scene.path == OrderSceneValidator.MainScene && !scene.enabled), Is.True);
                Assert.That(SableChapterBuildRoute.Validate(), Is.Empty);
            }
            finally
            {
                EditorBuildSettings.scenes = previous;
            }
        }
    }
}
