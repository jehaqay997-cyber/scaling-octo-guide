using System;
using System.IO;
using NUnit.Framework;
using TheOrderRoom.AppCore;
using TheOrderRoom.Domain;
using TheOrderRoom.Infrastructure;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class AdventureJournalStoreTests
    {
        private string directory;
        private AdventureJournalStore store;

        [SetUp]
        public void SetUp()
        {
            directory = Path.Combine(Path.GetTempPath(), "tor-adventure-" + Guid.NewGuid().ToString("N"));
            store = new AdventureJournalStore(directory);
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(directory)) Directory.Delete(directory, true);
        }

        [Test]
        public void GenesisIsIdempotentAndNeverResetsProgress()
        {
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot initial));
            Assert.AreEqual(0L, initial.Revision);
            Assert.IsTrue(AdventureChapter.TryAct(initial, AdventureAction.TakeKey, 0, out AdventureSnapshot candidate, out _));
            Assert.AreEqual(AdventureCommitResult.Committed, store.Commit(0, candidate));
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot reopened));
            Assert.AreEqual(1L, reopened.Revision);
            Assert.AreEqual(AdventureFacts.KeyTaken, reopened.Facts);
        }

        [Test]
        public void DuplicateCommitMustRejectWithoutModifyingPersistedState()
        {
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot initial));
            Assert.IsTrue(AdventureChapter.TryAct(initial, AdventureAction.TakeKey, 0, out AdventureSnapshot next, out _));
            Assert.AreEqual(AdventureCommitResult.Committed, store.Commit(0, next));
            Assert.AreEqual(AdventureCommitResult.Rejected, store.Commit(0, next));
            Assert.IsTrue(store.TryRead(out AdventureSnapshot persisted));
            Assert.AreEqual(1L, persisted.Revision);
        }

        [Test]
        public void ForgedRevisionOrIllegalMutationCannotBeCommitted()
        {
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot initial));
            var invalid = new AdventureSnapshot(1, 1, AdventureLocation.Courtyard,
                AdventureFacts.KeyTaken | AdventureFacts.ArchiveOpened);
            Assert.AreEqual(AdventureCommitResult.Rejected, store.Commit(0, invalid));
            Assert.AreEqual(AdventureCommitResult.Rejected, store.Commit(1, initial));
            Assert.IsTrue(store.TryRead(out AdventureSnapshot persisted));
            Assert.AreEqual(0L, persisted.Revision);
        }

        [Test]
        public void DamagedLatestRecordFailsClosed()
        {
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot initial));
            Assert.IsTrue(AdventureChapter.TryAct(initial, AdventureAction.TakeKey, 0, out AdventureSnapshot next, out _));
            Assert.AreEqual(AdventureCommitResult.Committed, store.Commit(0, next));
            string path = Path.Combine(directory, "adventure.r00000000000000000001.bin");
            byte[] bytes = File.ReadAllBytes(path);
            bytes[12] ^= 0x40;
            File.WriteAllBytes(path, bytes);
            Assert.IsFalse(store.TryRead(out _));
            Assert.AreEqual(AdventureCommitResult.Rejected, store.Commit(0, next));
        }

        [Test]
        public void SessionCanReconcileFromRealJournalAfterCompetingWriter()
        {
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot initial));
            var first = new AdventureSession(initial, store);
            var second = new AdventureSession(initial, new AdventureJournalStore(directory));
            Assert.IsTrue(first.Act(AdventureAction.TakeKey, 0, out _));
            Assert.IsFalse(second.Act(AdventureAction.TakeKey, 0, out _));
            Assert.IsTrue(second.ReloadRequired);
            Assert.IsTrue(second.TryReload(out string error), error);
            Assert.IsTrue(second.Act(AdventureAction.OpenArchive, 1, out error), error);
            Assert.IsTrue(store.TryRead(out AdventureSnapshot result));
            Assert.AreEqual(2L, result.Revision);
        }

        [Test]
        public void MissingIntermediateRecordFailsClosed()
        {
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot initial));
            Assert.IsTrue(AdventureChapter.TryAct(initial, AdventureAction.TakeKey, 0, out AdventureSnapshot first, out _));
            Assert.AreEqual(AdventureCommitResult.Committed, store.Commit(0, first));
            Assert.IsTrue(AdventureChapter.TryAct(first, AdventureAction.OpenArchive, 1, out AdventureSnapshot second, out _));
            Assert.AreEqual(AdventureCommitResult.Committed, store.Commit(1, second));
            File.Delete(Path.Combine(directory, "adventure.r00000000000000000001.bin"));
            Assert.IsFalse(store.TryRead(out _));
            Assert.AreEqual(AdventureCommitResult.Rejected, store.Commit(1, second));
        }

        [Test]
        public void OversizedRecordCannotForceUnboundedRead()
        {
            Assert.IsTrue(store.TryInitialize(out AdventureSnapshot initial));
            Assert.IsTrue(AdventureChapter.TryAct(initial, AdventureAction.TakeKey, 0, out AdventureSnapshot next, out _));
            Assert.AreEqual(AdventureCommitResult.Committed, store.Commit(0, next));
            using (var stream = new FileStream(Path.Combine(directory, "adventure.r00000000000000000001.bin"), FileMode.Open, FileAccess.Write))
                stream.SetLength(1024 * 1024 * 4);
            Assert.IsFalse(store.TryRead(out _));
        }

        [Test]
        public void InvalidPrefixIsRejected()
        {
            Assert.Throws<ArgumentException>(() => new AdventureJournalStore(directory, "../escape"));
            Assert.Throws<ArgumentException>(() => new AdventureJournalStore(directory, "a/b"));
        }
    }
}
