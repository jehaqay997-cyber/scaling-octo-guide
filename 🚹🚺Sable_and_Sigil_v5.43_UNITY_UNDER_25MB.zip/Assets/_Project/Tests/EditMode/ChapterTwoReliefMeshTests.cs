using System;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterTwoReliefMeshTests
    {
        [TestCase(3)]
        [TestCase(4)]
        [TestCase(5)]
        [TestCase(6)]
        public void EachChapterTwoLocationHasBoundedFrontFacingGeometry(int location)
        {
            Mesh mesh = ChapterTwoReliefMesh.Create(location, false);
            try
            {
                Assert.That(mesh.vertexCount, Is.GreaterThan(0));
                Assert.That(mesh.triangles.Length / 3,
                    Is.InRange(1, ChapterTwoReliefMesh.MaximumTriangles));
                Assert.AreEqual(mesh.vertexCount, mesh.normals.Length);
                foreach (Vector3 vertex in mesh.vertices)
                {
                    Assert.IsFalse(float.IsNaN(vertex.x) || float.IsInfinity(vertex.x));
                    Assert.IsFalse(float.IsNaN(vertex.y) || float.IsInfinity(vertex.y));
                    Assert.That(Mathf.Abs(vertex.x), Is.LessThan(2f));
                    Assert.That(Mathf.Abs(vertex.y), Is.LessThan(.4f));
                    Assert.That(vertex.z, Is.EqualTo(0f).Within(.00001f));
                }
                for (int index = 0; index < mesh.triangles.Length; index += 3)
                {
                    Vector3 a = mesh.vertices[mesh.triangles[index]];
                    Vector3 b = mesh.vertices[mesh.triangles[index + 1]];
                    Vector3 c = mesh.vertices[mesh.triangles[index + 2]];
                    Assert.Less(Vector3.Cross(b - a, c - a).z, -.0000001f,
                        "Every ornamental triangle must face the investigating camera.");
                }
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [TestCase(3)]
        [TestCase(4)]
        [TestCase(5)]
        [TestCase(6)]
        public void RestoringTheReliefReusesMeshIdentity(int location)
        {
            Mesh mesh = ChapterTwoReliefMesh.Create(location, false);
            try
            {
                int before = mesh.triangles.Length;
                ChapterTwoReliefMesh.Rebuild(mesh, location, true);
                Assert.That(mesh.triangles.Length, Is.Not.EqualTo(before),
                    "A restored mechanism must change its authored geometry.");
                Assert.That(mesh.triangles.Length / 3,
                    Is.LessThanOrEqualTo(ChapterTwoReliefMesh.MaximumTriangles));
                int restored = mesh.triangles.Length;
                ChapterTwoReliefMesh.Rebuild(mesh, location, false);
                Assert.AreEqual(before, mesh.triangles.Length,
                    "A fresh investigation must restore the unsolved appearance.");
                ChapterTwoReliefMesh.Rebuild(mesh, location, true);
                Assert.AreEqual(restored, mesh.triangles.Length);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void InvalidLocationsAndNullMeshCannotBeAccepted()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterTwoReliefMesh.Create(2, false));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterTwoReliefMesh.Create(7, true));
            Assert.Throws<ArgumentNullException>(() => ChapterTwoReliefMesh.Rebuild(null, 3, true));
            Mesh valid = ChapterTwoReliefMesh.Create(3, false);
            try
            {
                int before = valid.vertexCount;
                Assert.Throws<ArgumentOutOfRangeException>(() => ChapterTwoReliefMesh.Rebuild(valid, 7, true));
                Assert.AreEqual(before, valid.vertexCount,
                    "Invalid input must not clear or corrupt the existing mesh.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(valid);
            }
        }

        [Test]
        public void AllFourMechanismsHaveDifferentGeometricSignatures()
        {
            var signatures = new System.Collections.Generic.HashSet<int>();
            for (int location = 3; location <= 6; location++)
            {
                Mesh mesh = ChapterTwoReliefMesh.Create(location, true);
                try
                {
                    int signature = mesh.triangles.Length;
                    Assert.IsTrue(signatures.Add(signature),
                        "The four investigations must not reuse a generic four-seal motif.");
                }
                finally
                {
                    UnityEngine.Object.DestroyImmediate(mesh);
                }
            }
        }
    }
}
