using System;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterThreeReliefMeshTests
    {
        [TestCase(7)]
        [TestCase(8)]
        [TestCase(9)]
        public void EachSiteHasFiniteFrontFacingAndBoundedGeometry(int location)
        {
            Mesh mesh = ChapterThreeReliefMesh.Create(location, false);
            try
            {
                Assert.That(mesh.triangles.Length / 3,
                    Is.InRange(1, ChapterThreeReliefMesh.MaximumTriangles));
                Assert.AreEqual(mesh.vertexCount, mesh.normals.Length);
                foreach (Vector3 vertex in mesh.vertices)
                {
                    Assert.IsFalse(float.IsNaN(vertex.x) || float.IsInfinity(vertex.x));
                    Assert.IsFalse(float.IsNaN(vertex.y) || float.IsInfinity(vertex.y));
                    Assert.That(Mathf.Abs(vertex.x), Is.LessThan(2f));
                    Assert.That(Mathf.Abs(vertex.y), Is.LessThan(1f));
                    Assert.AreEqual(0f, vertex.z, .00001f);
                }
                int[] indices = mesh.triangles;
                Vector3[] vertices = mesh.vertices;
                for (int index = 0; index < indices.Length; index += 3)
                {
                    Vector3 a = vertices[indices[index]];
                    Vector3 b = vertices[indices[index + 1]];
                    Vector3 c = vertices[indices[index + 2]];
                    Assert.Less(Vector3.Cross(b - a, c - a).z, -.0000001f);
                }
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [TestCase(7)]
        [TestCase(8)]
        [TestCase(9)]
        public void SolvedAndUnsolvedStatesReuseTheSameOwnedMesh(int location)
        {
            Mesh mesh = ChapterThreeReliefMesh.Create(location, false);
            try
            {
                int unsolvedTriangles = mesh.triangles.Length;
                ChapterThreeReliefMesh.Rebuild(mesh, location, true);
                int solvedTriangles = mesh.triangles.Length;
                Assert.AreNotEqual(unsolvedTriangles, solvedTriangles);
                Assert.That(solvedTriangles / 3,
                    Is.LessThanOrEqualTo(ChapterThreeReliefMesh.MaximumTriangles));
                ChapterThreeReliefMesh.Rebuild(mesh, location, false);
                Assert.AreEqual(unsolvedTriangles, mesh.triangles.Length);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [TestCase(7)]
        [TestCase(8)]
        [TestCase(9)]
        public void EvidenceDisclosureUsesThreeDistinctStatesAndOneOwnedMesh(int location)
        {
            Mesh mesh = ChapterThreeReliefMesh.Create(location, ChapterThreeReliefStage.Locked);
            try
            {
                int lockedTriangles = mesh.triangles.Length;
                int lockedVertices = mesh.vertexCount;
                Assert.That(lockedTriangles / 3, Is.InRange(1, ChapterThreeReliefMesh.MaximumTriangles));
                ChapterThreeReliefMesh.Rebuild(mesh, location, ChapterThreeReliefStage.Investigating);
                int investigatingTriangles = mesh.triangles.Length;
                Assert.AreNotEqual(lockedTriangles, investigatingTriangles);
                ChapterThreeReliefMesh.Rebuild(mesh, location, ChapterThreeReliefStage.Restored);
                int restoredTriangles = mesh.triangles.Length;
                Assert.AreNotEqual(investigatingTriangles, restoredTriangles);
                Assert.That(restoredTriangles / 3, Is.LessThanOrEqualTo(ChapterThreeReliefMesh.MaximumTriangles));
                ChapterThreeReliefMesh.Rebuild(mesh, location, ChapterThreeReliefStage.Locked);
                Assert.AreEqual(lockedTriangles, mesh.triangles.Length);
                Assert.AreEqual(lockedVertices, mesh.vertexCount);
                Assert.IsFalse(mesh == null);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void InvalidDisclosureStageCannotCorruptOwnedMesh()
        {
            Mesh mesh = ChapterThreeReliefMesh.Create(8, ChapterThreeReliefStage.Locked);
            try
            {
                Vector3[] before = mesh.vertices;
                int[] beforeTriangles = mesh.triangles;
                Assert.Throws<ArgumentOutOfRangeException>(() =>
                    ChapterThreeReliefMesh.Rebuild(mesh, 8, (ChapterThreeReliefStage)99));
                CollectionAssert.AreEqual(before, mesh.vertices);
                CollectionAssert.AreEqual(beforeTriangles, mesh.triangles);
                Assert.Throws<ArgumentOutOfRangeException>(() =>
                    ChapterThreeReliefMesh.Create(8, (ChapterThreeReliefStage)(-1)));
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void InvalidRequestsDoNotMutateAnExistingMesh()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterThreeReliefMesh.Create(6, false));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterThreeReliefMesh.Create(10, false));
            Assert.Throws<ArgumentNullException>(() => ChapterThreeReliefMesh.Rebuild(null, 7, false));
            Mesh mesh = ChapterThreeReliefMesh.Create(7, false);
            try
            {
                int initial = mesh.vertexCount;
                Assert.Throws<ArgumentOutOfRangeException>(() => ChapterThreeReliefMesh.Rebuild(mesh, 6, true));
                Assert.AreEqual(initial, mesh.vertexCount);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(mesh);
            }
        }
    }
}
