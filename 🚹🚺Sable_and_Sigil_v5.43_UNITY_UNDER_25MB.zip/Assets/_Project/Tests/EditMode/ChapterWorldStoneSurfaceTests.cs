using System;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterWorldStoneSurfaceTests
    {
        [Test]
        public void LocationLightingProfiles_AreAuthoredBoundedAndDifferent()
        {
            Assert.IsTrue(ChapterWorldLightingRig.Validate(out string error), error);
            Assert.AreEqual(10, ChapterWorldLightingRig.AuthoredLocationCount);
            Assert.AreEqual(3, ChapterWorldLightingRig.MaximumLights);
            var keyColors = new System.Collections.Generic.HashSet<Color>();
            for (int number = 1; number <= 10; number++)
            {
                ChapterWorldLightingProfile profile = ChapterWorldLightingRig.Get(number);
                Assert.IsTrue(keyColors.Add(profile.KeyColor),
                    "Each location must have an independently authored illumination palette.");
                Assert.That(profile.KeyIntensity, Is.InRange(2f, 3f));
                Assert.That(profile.FillIntensity, Is.InRange(.5f, 1f));
                foreach (Color color in new[] { profile.KeyColor, profile.LeftFillColor,
                    profile.RightFillColor })
                {
                    Assert.That(color.r, Is.InRange(0f, 1f));
                    Assert.That(color.g, Is.InRange(0f, 1f));
                    Assert.That(color.b, Is.InRange(0f, 1f));
                }
            }
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldLightingRig.Get(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldLightingRig.Get(11));
        }

        [Test]
        public void LocationLightingRig_ValidatesLayersAndOwnsExactlyThreeShadowFreeLights()
        {
            GameObject host = new GameObject("Lighting Rig EditMode Test Host");
            try
            {
                Assert.Throws<ArgumentNullException>(() =>
                    ChapterWorldLightingRig.Create(null, 1, 26, 27));
                Assert.Throws<ArgumentOutOfRangeException>(() =>
                    ChapterWorldLightingRig.Create(host.transform, 1, 26, 26));
                Assert.Throws<ArgumentOutOfRangeException>(() =>
                    ChapterWorldLightingRig.Create(host.transform, 1, -1, 27));
                Assert.Throws<ArgumentOutOfRangeException>(() =>
                    ChapterWorldLightingRig.Create(host.transform, 1, 26, 32));
                Assert.Throws<ArgumentOutOfRangeException>(() =>
                    ChapterWorldLightingRig.Create(host.transform, 11, 26, 27));
                Assert.AreEqual(0, host.transform.childCount,
                    "Invalid profiles or layers must be rejected before scene mutation.");

                Transform rig = ChapterWorldLightingRig.Create(host.transform, 7, 26, 27);
                Assert.AreEqual("Location Lighting Rig", rig.name);
                Assert.AreSame(host.transform, rig.parent);
                Light[] lights = rig.GetComponentsInChildren<Light>();
                Assert.AreEqual(ChapterWorldLightingRig.MaximumLights, lights.Length);
                ChapterWorldLightingProfile profile = ChapterWorldLightingRig.Get(7);
                Light key = rig.Find("Gallery Key Light").GetComponent<Light>();
                Assert.AreEqual(profile.KeyColor, key.color);
                Assert.AreEqual(profile.KeyIntensity, key.intensity);
                Assert.AreEqual(ChapterWorldLightingRig.KeyRange, key.range);
                Assert.AreEqual(LightRenderMode.Auto, key.renderMode);
                Assert.AreEqual(LightRenderMode.ForceVertex,
                    rig.Find("Left Evidence Fill").GetComponent<Light>().renderMode);
                Assert.AreEqual(LightRenderMode.ForceVertex,
                    rig.Find("Right Evidence Fill").GetComponent<Light>().renderMode);
                foreach (Light light in lights)
                {
                    Assert.AreEqual(LightType.Point, light.type);
                    Assert.AreEqual(LightShadows.None, light.shadows);
                    Assert.AreEqual((1 << 26) | (1 << 27), light.cullingMask);
                    Assert.IsNull(light.GetComponent<Collider>());
                }
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(host);
            }
        }

        [Test]
        public void AuthoredChapters_GenerateRepeatableNonUniformStonePixels()
        {
            for (int chapter = 1; chapter <= 4; chapter++)
            {
                Color32[] first = ChapterWorldStoneSurface.BuildPixels(chapter);
                Color32[] second = ChapterWorldStoneSurface.BuildPixels(chapter);
                Assert.AreEqual(128 * 128, first.Length);
                CollectionAssert.AreEqual(first, second);
                Assert.Less(first[0].r, first[5 + 5 * 128].r);
                Assert.AreNotEqual(first[5 + 5 * 128], first[6 + 5 * 128]);
            }
        }

        [Test]
        public void GeneratedTexture_IsMipmappedAndDiscardsCpuPixelCopy()
        {
            Texture2D stone = ChapterWorldStoneSurface.Create(2);
            try
            {
                Assert.AreEqual(128, stone.width);
                Assert.AreEqual(128, stone.height);
                Assert.Greater(stone.mipmapCount, 1);
                Assert.IsFalse(stone.isReadable);
                Assert.AreEqual(TextureWrapMode.Repeat, stone.wrapMode);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(stone);
            }
        }

        [Test]
        public void InvalidChapterNumbers_AreRejectedWithoutAllocatingTexture()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldStoneSurface.BuildPixels(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterWorldStoneSurface.Create(5));
        }
        [Test]
        public void ArtworkViewport_ZoomPanAndResetStayWithinTheOriginalTexture()
        {
            var viewport = new ChapterArtworkViewport();
            Assert.AreEqual(1f, viewport.Zoom);
            Assert.AreEqual(0f, viewport.X);
            Assert.AreEqual(0f, viewport.Y);
            Assert.IsFalse(viewport.TryPan(.2f, -.1f));
            for (int index = 0; index < 20; index++) viewport.TryZoom(.5f);
            Assert.AreEqual(3f, viewport.Zoom);
            Assert.That(viewport.Extent, Is.EqualTo(1f / 3f).Within(.000001f));
            Assert.IsTrue(viewport.TryPan(5f, -5f));
            Assert.That(viewport.X + viewport.Extent, Is.EqualTo(1f).Within(.000001f));
            Assert.That(viewport.Y, Is.EqualTo(0f).Within(.000001f));
            Assert.IsFalse(viewport.TryPan(5f, -5f));
            Assert.IsTrue(viewport.TryPan(-10f, 10f));
            Assert.That(viewport.X, Is.EqualTo(0f).Within(.000001f));
            Assert.That(viewport.Y + viewport.Extent, Is.EqualTo(1f).Within(.000001f));
            viewport.Reset();
            Assert.AreEqual(1f, viewport.Zoom);
            Assert.AreEqual(0f, viewport.X);
            Assert.AreEqual(0f, viewport.Y);
            Assert.AreEqual(1f, viewport.Extent);
        }

        [Test]
        public void ArtworkViewport_RejectsInvalidInputAndPreservesVisibleBounds()
        {
            var viewport = new ChapterArtworkViewport();
            Assert.IsFalse(viewport.TryZoom(float.NaN));
            Assert.IsFalse(viewport.TryZoom(float.NegativeInfinity));
            Assert.IsFalse(viewport.TryZoom(-10f));
            Assert.IsTrue(viewport.TryZoom(1f));
            Assert.IsFalse(viewport.TryPan(float.NaN, 0f));
            Assert.IsFalse(viewport.TryPan(0f, float.PositiveInfinity));
            Assert.IsFalse(viewport.TryPan(0f, 0f));
            Assert.IsTrue(viewport.TryPan(.2f, .2f));
            for (int index = 0; index < 40; index++)
            {
                viewport.TryZoom(index % 2 == 0 ? -.3f : .4f);
                viewport.TryPan(index % 3 == 0 ? -1f : .15f, index % 4 == 0 ? 1f : -.18f);
                Assert.That(viewport.X, Is.InRange(0f, 1f - viewport.Extent));
                Assert.That(viewport.Y, Is.InRange(0f, 1f - viewport.Extent));
                Assert.That(viewport.Zoom, Is.InRange(1f, 3f));
            }
        }

    }
}
