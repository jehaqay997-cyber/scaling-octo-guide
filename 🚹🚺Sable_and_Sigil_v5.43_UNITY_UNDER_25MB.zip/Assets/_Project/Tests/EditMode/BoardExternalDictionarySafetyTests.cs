#if UNITY_INCLUDE_TESTS
using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class BoardExternalDictionarySafetyTests
    {
        private sealed class ThrowingDictionary : IDictionary<string, string>
        {
            public string this[string key] { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
            public ICollection<string> Keys => throw new NotSupportedException();
            public ICollection<string> Values => throw new NotSupportedException();
            public int Count => 1;
            public bool IsReadOnly => true;
            public void Add(string key, string value) => throw new NotSupportedException();
            public void Add(KeyValuePair<string, string> item) => throw new NotSupportedException();
            public void Clear() => throw new NotSupportedException();
            public bool Contains(KeyValuePair<string, string> item) => false;
            public bool ContainsKey(string key) => false;
            public void CopyTo(KeyValuePair<string, string>[] array, int arrayIndex) => throw new NotSupportedException();
            public IEnumerator<KeyValuePair<string, string>> GetEnumerator() => new ThrowingEnumerator();
            public bool Remove(string key) => throw new NotSupportedException();
            public bool Remove(KeyValuePair<string, string> item) => throw new NotSupportedException();
            public bool TryGetValue(string key, out string value) { value = null; return false; }
            IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        }

        private sealed class ThrowingEnumerator : IEnumerator<KeyValuePair<string, string>>
        {
            public KeyValuePair<string, string> Current => throw new NotSupportedException();
            object IEnumerator.Current => Current;
            public bool MoveNext() => throw new NotSupportedException("Enumeration is not supported.");
            public void Reset() => throw new NotSupportedException();
            public void Dispose() { }
        }

        [Test]
        public void UnsupportedExternalEnumerationIsRejectedWithoutChangingBoardOrTicket()
        {
            var board = new OrderBoard(
                new[] { new Item("A", "S", 1) },
                new[] { new Compartment("B", "S", 1, 2) });
            Assert.IsTrue(board.Prepare("A", "B", board.Revision, out Guid ticket, out _));
            long revision = board.Revision;
            Assert.IsFalse(board.Restore(new ThrowingDictionary()));
            Assert.AreEqual(revision, board.Revision);
            Assert.AreEqual(OrderBoard.Tray, board.Location("A"));
            Assert.IsTrue(board.Commit(ticket, out _));
            Assert.AreEqual("B", board.Location("A"));
        }
    }
}
#endif
