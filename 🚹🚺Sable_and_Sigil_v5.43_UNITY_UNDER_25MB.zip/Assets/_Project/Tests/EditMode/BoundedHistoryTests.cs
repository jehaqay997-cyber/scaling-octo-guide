using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class BoundedHistoryTests
    {
        [Test]
        public void RejectsNonPositiveCapacity()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => new BoundedHistory<int>(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => new BoundedHistory<int>(-3));
        }

        [Test]
        public void EmptyHistoryCannotBeReadOrPopped()
        {
            var history = new BoundedHistory<int>(2);
            Assert.Throws<InvalidOperationException>(() => history.Peek());
            Assert.Throws<InvalidOperationException>(() => history.Pop());
        }

        [Test]
        public void OverflowEvictsOnlyOldestEntry()
        {
            var history = new BoundedHistory<int>(3);
            for (int i = 1; i <= 4; i++) history.Push(i);
            Assert.AreEqual(3, history.Count);
            Assert.AreEqual(4, history.Pop());
            Assert.AreEqual(3, history.Pop());
            Assert.AreEqual(2, history.Pop());
            Assert.AreEqual(0, history.Count);
        }

        [Test]
        public void WrapAroundPreservesChronologicalOrder()
        {
            var history = new BoundedHistory<int>(2);
            history.Push(10);
            history.Push(20);
            Assert.AreEqual(20, history.Pop());
            history.Push(30);
            history.Push(40);
            Assert.AreEqual(40, history.Pop());
            Assert.AreEqual(30, history.Pop());
            history.Push(50);
            Assert.AreEqual(50, history.Peek());
        }

        [Test]
        public void ClearReleasesReferencesAndResetsCapacity()
        {
            var history = new BoundedHistory<object>(2);
            history.Push(new object());
            history.Push(new object());
            history.Clear();
            Assert.AreEqual(0, history.Count);
            Assert.AreEqual(2, history.Capacity);
            history.Push(new object());
            Assert.AreEqual(1, history.Count);
        }

        [Test]
        public void BoundaryAtSixtyFourKeepsSixtyFourMostRecentStates()
        {
            var history = new BoundedHistory<int>(64);
            for (int i = 0; i < 1000; i++) history.Push(i);
            Assert.AreEqual(64, history.Count);
            for (int i = 999; i >= 936; i--)
                Assert.AreEqual(i, history.Pop());
            Assert.AreEqual(0, history.Count);
        }

        [Test]
        public void RepeatedPushPopCyclesRemainConsistent()
        {
            var history = new BoundedHistory<int>(1);
            for (int i = 0; i < 2000; i++)
            {
                history.Push(i);
                Assert.AreEqual(i, history.Peek());
                Assert.AreEqual(i, history.Pop());
            }
        }
    }
}
