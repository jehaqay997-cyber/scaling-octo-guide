using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class BoardMalformedRestoreTests
    {
        private sealed class BadDictionary : IDictionary<string, string>
        {
            public string this[string key] { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
            public ICollection<string> Keys => throw new NotSupportedException();
            public ICollection<string> Values => throw new NotSupportedException();
            public int Count => 1;
            public bool IsReadOnly => true;
            public void Add(string key, string value) => throw new NotSupportedException();
            public void Add(KeyValuePair<string, string> item) => throw new NotSupportedException();
            public void Clear() => throw new NotSupportedException();
            public bool Contains(KeyValuePair<string, string> item) => false;
            public bool ContainsKey(string key) => false;
            public void CopyTo(KeyValuePair<string, string>[] array, int arrayIndex) => throw new NotSupportedException();
            public IEnumerator<KeyValuePair<string, string>> GetEnumerator()
            {
                yield return new KeyValuePair<string, string>(null, "TRAY");
            }
            public bool Remove(string key) => throw new NotSupportedException();
            public bool Remove(KeyValuePair<string, string> item) => throw new NotSupportedException();
            public bool TryGetValue(string key, out string value) { value = null; return false; }
            IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
        }

        [Test]
        public void InvalidExternalDictionaryIsRejectedWithoutMutation()
        {
            var board = new OrderBoard(new[] { new Item("A", "S", 1) },
                new[] { new Compartment("B", "S", 1, 2) });
            long beforeRevision = board.Revision;
            var before = board.Location("A");
            Assert.IsFalse(board.Restore(new BadDictionary()));
            Assert.AreEqual(beforeRevision, board.Revision);
            Assert.AreEqual(before, board.Location("A"));
        }
    }
}
