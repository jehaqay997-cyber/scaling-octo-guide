using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class AdventureSolvabilityVerifierTests
    {
        [Test]
        public void EveryReachableAdventureStateCanReachVictory()
        {
            var report = AdventureSolvabilityVerifier.Verify();
            Assert.Greater(report.ReachableStates, 0);
            Assert.Greater(report.WinningStates, 0);
            Assert.Greater(report.Transitions, 0);
            Assert.AreEqual(0, report.SoftlockedStates);
            Assert.AreEqual(report.ReachableStates, report.StatesWithPathToVictory);
            Assert.IsTrue(report.IsSolvableFromEveryReachableState);
        }

        [Test]
        public void VerifierIsDeterministic()
        {
            var a = AdventureSolvabilityVerifier.Verify();
            var b = AdventureSolvabilityVerifier.Verify();
            Assert.AreEqual(a.ReachableStates, b.ReachableStates);
            Assert.AreEqual(a.WinningStates, b.WinningStates);
            Assert.AreEqual(a.Transitions, b.Transitions);
            Assert.AreEqual(a.SoftlockedStates, b.SoftlockedStates);
        }
    }
}
