using System;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class WorldInvestigationGrantTests
    {
        private static WorldInvestigationGrant Create(int location)
        {
            var constructor = typeof(WorldInvestigationGrant).GetConstructor(
                BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { typeof(int) }, null);
            Assert.IsNotNull(constructor);
            return (WorldInvestigationGrant)constructor.Invoke(new object[] { location });
        }

        private static bool Consume(WorldInvestigationGrant grant, int location)
        {
            var method = typeof(WorldInvestigationGrant).GetMethod("TryConsume",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(method);
            return (bool)method.Invoke(grant, new object[] { location });
        }

        [Test]
        public void LocationMismatchNeverConsumesTheGrant()
        {
            var grant = Create(7);
            Assert.IsFalse(Consume(grant, 8));
            Assert.IsTrue(Consume(grant, 7));
        }

        [Test]
        public void GrantCanOnlyBeConsumedOnce()
        {
            var grant = Create(3);
            Assert.IsTrue(Consume(grant, 3));
            Assert.IsFalse(Consume(grant, 3));
        }

        [Test]
        public void FailedModalInitializationCanReleaseItsReservation()
        {
            var grant = Create(7);
            var reserve = typeof(WorldInvestigationGrant).GetMethod("TryReserve",
                BindingFlags.Instance | BindingFlags.NonPublic);
            var release = typeof(WorldInvestigationGrant).GetMethod("ReleaseReservation",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsNotNull(reserve);
            Assert.IsNotNull(release);
            Assert.IsFalse((bool)reserve.Invoke(grant, new object[] { 8 }));
            Assert.IsTrue((bool)reserve.Invoke(grant, new object[] { 7 }));
            Assert.IsFalse(Consume(grant, 7));
            release.Invoke(grant, new object[] { 8 });
            Assert.IsFalse(Consume(grant, 7));
            release.Invoke(grant, new object[] { 7 });
            Assert.IsTrue(Consume(grant, 7));
            Assert.IsFalse(Consume(grant, 7));
        }

        [Test]
        public void CommittedReservationCannotBeReused()
        {
            var grant = Create(3);
            var reserve = typeof(WorldInvestigationGrant).GetMethod("TryReserve",
                BindingFlags.Instance | BindingFlags.NonPublic);
            var commit = typeof(WorldInvestigationGrant).GetMethod("CommitReservation",
                BindingFlags.Instance | BindingFlags.NonPublic);
            var release = typeof(WorldInvestigationGrant).GetMethod("ReleaseReservation",
                BindingFlags.Instance | BindingFlags.NonPublic);
            Assert.IsTrue((bool)reserve.Invoke(grant, new object[] { 3 }));
            commit.Invoke(grant, new object[] { 3 });
            release.Invoke(grant, new object[] { 3 });
            Assert.IsFalse(Consume(grant, 3));
            Assert.IsFalse((bool)reserve.Invoke(grant, new object[] { 3 }));
        }

        [Test]
        public void InvalidLocationCannotBeAuthorized()
        {
            var constructor = typeof(WorldInvestigationGrant).GetConstructor(
                BindingFlags.Instance | BindingFlags.NonPublic, null, new[] { typeof(int) }, null);
            Assert.IsNotNull(constructor);
            var exception = Assert.Throws<TargetInvocationException>(() =>
                constructor.Invoke(new object[] { 0 }));
            Assert.IsInstanceOf<ArgumentOutOfRangeException>(exception.InnerException);
        }
    }
}
