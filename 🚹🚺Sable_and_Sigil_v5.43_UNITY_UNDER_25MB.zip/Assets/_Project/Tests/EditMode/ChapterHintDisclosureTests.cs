using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterHintDisclosureTests
    {
        [Test]
        public void EveryLocationRequiresExplicitAndAuthorizedHintDisclosure()
        {
            for (int number = 1; number <= ChapterStoryGraph.LocationCount; number++)
            {
                StoryLocation location = ChapterStoryGraph.GetLocation(number);
                int tier = 0;
                Assert.That(ChapterHintDisclosure.TryGetVisibleHint(location, tier, true, out _), Is.False);
                Assert.That(ChapterHintDisclosure.CanRevealNext(tier, false), Is.False);
                Assert.That(ChapterHintDisclosure.RevealNext(tier, false), Is.Zero);
                for (int expected = 1; expected <= ChapterHintDisclosure.MaximumTier; expected++)
                {
                    Assert.That(ChapterHintDisclosure.CanRevealNext(tier, true), Is.True);
                    tier = ChapterHintDisclosure.RevealNext(tier, true);
                    Assert.That(tier, Is.EqualTo(expected));
                    Assert.That(ChapterHintDisclosure.TryGetVisibleHint(location, tier, true, out string hint), Is.True);
                    Assert.That(hint, Is.EqualTo(location.HintTiers[expected - 1]));
                    Assert.That(ChapterHintDisclosure.TryGetVisibleHint(location, tier, false, out _), Is.False);
                }
                Assert.That(ChapterHintDisclosure.CanRevealNext(tier, true), Is.False);
                Assert.That(ChapterHintDisclosure.RevealNext(tier, true), Is.EqualTo(3));
            }
        }

        [Test]
        public void InvalidTierAndMissingLocationFailClosed()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterHintDisclosure.RevealNext(-1, true));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterHintDisclosure.RevealNext(4, false));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterHintDisclosure.CanRevealNext(4, true));
            Assert.Throws<ArgumentNullException>(() =>
                ChapterHintDisclosure.TryGetVisibleHint(null, 0, true, out _));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                ChapterHintDisclosure.TryGetVisibleHint(ChapterStoryGraph.GetLocation(1), 5, true, out _));
        }
    }
}
