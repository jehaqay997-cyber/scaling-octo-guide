using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterFourMeridianReliefTests
    {
        [Test]
        public void ThreeStagesAreFiniteFrontFacingAndReuseSameNativeMesh()
        {
            var puzzle = new ChapterFourMeridianPuzzle();
            Mesh mesh = ChapterFourMeridianRelief.Create(MeridianReliefStage.Locked, puzzle.Order);
            try
            {
                Mesh originalMesh = mesh;
                int lockedTriangles = mesh.triangles.Length;
                Assert.AreEqual(160, lockedTriangles / 3);
                Assert.AreEqual(mesh.vertexCount, mesh.normals.Length);
                Assert.AreSame(originalMesh, mesh);
                ChapterFourMeridianRelief.Rebuild(mesh, MeridianReliefStage.Investigating, puzzle.Order);
                Assert.AreSame(originalMesh, mesh);
                Assert.Greater(mesh.triangles.Length, lockedTriangles);
                int[] ids = mesh.triangles;
                Vector3[] points = mesh.vertices;
                for (int index = 0; index < ids.Length; index += 3)
                {
                    Vector3 cross = Vector3.Cross(points[ids[index + 1]] - points[ids[index]],
                        points[ids[index + 2]] - points[ids[index]]);
                    Assert.Less(cross.z, -.0000001f);
                }
                puzzle.SelectPosition(0, true, true);
                puzzle.SelectPosition(1, true, true);
                puzzle.SelectPosition(2, true, true);
                puzzle.SelectPosition(3, true, true);
                Assert.IsTrue(puzzle.IsVerified);
                ChapterFourMeridianRelief.Rebuild(mesh, MeridianReliefStage.Restored, puzzle.Order);
                Assert.That(mesh.triangles.Length / 3,
                    Is.InRange(1, ChapterFourMeridianRelief.MaximumTriangles));
                Assert.AreEqual(4, puzzle.Order.Count);
            }
            finally
            {
                Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void InvalidRebuildLeavesExistingMeshUntouched()
        {
            var puzzle = new ChapterFourMeridianPuzzle();
            Mesh mesh = ChapterFourMeridianRelief.Create(MeridianReliefStage.Locked, puzzle.Order);
            try
            {
                int previousTriangles = mesh.triangles.Length;
                Assert.Throws<System.ArgumentOutOfRangeException>(() =>
                    ChapterFourMeridianRelief.Rebuild(mesh, (MeridianReliefStage)99, puzzle.Order));
                Assert.Throws<System.ArgumentException>(() =>
                    ChapterFourMeridianRelief.Rebuild(mesh, MeridianReliefStage.Investigating,
                        new[] { 'A', 'A', 'B', 'C' }));
                Assert.Throws<System.ArgumentException>(() =>
                    ChapterFourMeridianRelief.Rebuild(mesh, MeridianReliefStage.Restored, puzzle.Order));
                Assert.AreEqual(previousTriangles, mesh.triangles.Length);
            }
            finally
            {
                Object.DestroyImmediate(mesh);
            }
        }
    }
}
