using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class CinematicSceneMapTests
    {
        [Test]
        public void EveryAuthoredLocationHasFiniteNonoverlappingPhotographicTargets()
        {
            Assert.IsTrue(CinematicSceneMap.Validate(out string error), error);
            Assert.AreEqual(10, CinematicSceneMap.LocationCount);
            for (int location = 1; location <= CinematicSceneMap.LocationCount; location++)
            {
                ScenicLocation scene = CinematicSceneMap.Get(location);
                Assert.AreEqual(location, scene.LocationNumber);
                string atmosphere = CinematicSceneMap.GetAtmosphere(location);
                Assert.IsNotEmpty(atmosphere);
                Assert.That(atmosphere.Length, Is.LessThanOrEqualTo(160));
                AssertBounds(scene.EvidenceA);
                AssertBounds(scene.EvidenceB);
                AssertBounds(scene.Mechanism);
                AssertSeparation(scene.EvidenceA, scene.EvidenceB);
                AssertSeparation(scene.EvidenceA, scene.Mechanism);
                AssertSeparation(scene.EvidenceB, scene.Mechanism);
            }
        }

        [Test]
        public void FeaturedEnvironmentsMatchCanonicalEvidenceAndStoryContracts()
        {
            Assert.IsTrue(CinematicEnvironmentCatalog.Validate(out string error), error);
            foreach (int location in new[] { 2, 4, 5, 7, 10 })
            {
                Assert.IsTrue(CinematicEnvironmentCatalog.TryGetFeatured(location,
                    out CinematicEnvironmentSpec environment));
                Assert.AreEqual(location, environment.LocationNumber);
                Assert.AreEqual("CinematicLocations/Location_" + location.ToString("00"),
                    environment.ResourcePath);
                Assert.IsNotEmpty(environment.InspectionA);
                Assert.IsNotEmpty(environment.InspectionB);
                Assert.AreNotEqual(environment.InspectionA, environment.InspectionB);
                Assert.IsNotEmpty(environment.MechanismSubject);
                Assert.AreEqual(2, StoryDossierCatalog.Get(location).EvidenceFragments.Count);
            }
            Assert.IsFalse(CinematicEnvironmentCatalog.TryGetFeatured(3, out _));
        }

        [Test]
        public void InvalidLocationsAndNonfiniteTargetsAreRejected()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => CinematicSceneMap.Get(0));
            Assert.Throws<ArgumentOutOfRangeException>(() => CinematicSceneMap.Get(11));
            Assert.Throws<ArgumentOutOfRangeException>(() => new ScenicPoint(float.NaN, 0f));
            Assert.Throws<ArgumentOutOfRangeException>(() => new ScenicPoint(0f, float.PositiveInfinity));
        }

        private static void AssertBounds(ScenicPoint point)
        {
            Assert.That(Math.Abs(point.X), Is.LessThanOrEqualTo(CinematicSceneMap.MaximumXOffset));
            Assert.That(Math.Abs(point.Y), Is.LessThanOrEqualTo(CinematicSceneMap.MaximumYOffset));
        }

        private static void AssertSeparation(ScenicPoint a, ScenicPoint b)
        {
            float x = a.X - b.X;
            float y = a.Y - b.Y;
            Assert.That(x * x + y * y, Is.GreaterThanOrEqualTo(.01f));
            Assert.IsTrue(Math.Abs(x) * CinematicSceneMap.CanvasWidth >= 112f ||
                          Math.Abs(y) * CinematicSceneMap.CanvasHeight >= 76f,
                "Authored touch targets must not overlap on the reference canvas.");
        }
    }
}
