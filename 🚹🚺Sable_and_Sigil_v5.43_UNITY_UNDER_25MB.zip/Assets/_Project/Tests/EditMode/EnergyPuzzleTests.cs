using NUnit.Framework;
using TheOrderRoom.Domain;
namespace TheOrderRoom.Tests.EditMode
{
    public sealed class EnergyPuzzleTests
    {
        [TestCase(0)] [TestCase(1)] [TestCase(2)] [TestCase(3)]
        [TestCase(4)] [TestCase(5)] [TestCase(6)] [TestCase(7)]
        [TestCase(8)] [TestCase(9)] [TestCase(10)] [TestCase(11)]
        public void EveryRoomHasAnExecutablePowerSolution(int level)
        {
            var puzzle = new EnergyPuzzle(level);
            Assert.IsFalse(puzzle.IsSolved);
            for (int step = 0; step < 16 && !puzzle.IsSolved; step++)
                Assert.IsTrue(puzzle.Rotate(puzzle.Hint(), puzzle.Revision));
            Assert.IsTrue(puzzle.IsSolved);
            Assert.IsTrue(puzzle.Undo());
            Assert.IsFalse(puzzle.IsSolved);
            Assert.IsTrue(puzzle.Reset());
            Assert.IsFalse(puzzle.IsSolved);
        }
        [Test]
        public void RejectedCommandsDoNotMutateRevisionOrCells()
        {
            var puzzle = new EnergyPuzzle(0);
            Assert.IsFalse(puzzle.Rotate(-1, 0));
            Assert.IsFalse(puzzle.Rotate(9, 0));
            Assert.IsFalse(puzzle.Rotate(2, 0));
            Assert.IsFalse(puzzle.Rotate(0, 1));
            Assert.AreEqual(0, puzzle.Revision);
            Assert.AreEqual(5, puzzle.Ports(0));
        }
        [Test]
        public void PoweredResultCannotMutatePuzzleAndHistoryIsBounded()
        {
            var puzzle = new EnergyPuzzle(0);
            for (int i = 0; i < 200; i++) Assert.IsTrue(puzzle.Rotate(0, puzzle.Revision));
            var powered = puzzle.Powered(); powered[8] = true;
            Assert.IsFalse(puzzle.IsSolved);
            int count = 0; while (puzzle.Undo()) count++;
            Assert.AreEqual(128, count);
        }
        [Test]
        public void FocusIsBoundedAndRequiresTheCorrectSeal()
        {
            var focus = new OpticalFocus();
            Assert.IsTrue(focus.IsFocused(0));
            Assert.IsFalse(focus.Adjust(-1));
            Assert.IsFalse(focus.Adjust(2));
            Assert.IsTrue(focus.Adjust(1));
            Assert.IsTrue(focus.IsFocused(1));
            Assert.IsTrue(focus.Adjust(1));
            Assert.IsTrue(focus.IsFocused(2));
            Assert.IsFalse(focus.IsFocused(3));
            Assert.IsFalse(focus.Adjust(1));
            focus.Reset(); Assert.AreEqual(100, focus.Magnification);
        }
    }
}
