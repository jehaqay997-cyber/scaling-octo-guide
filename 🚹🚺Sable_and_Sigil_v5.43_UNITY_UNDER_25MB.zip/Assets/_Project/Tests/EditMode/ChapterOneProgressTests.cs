using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterOneProgressTests
    {
        [Test]
        public void ChapterSequence_RequiresEveryClueAndOpensNextLocation()
        {
            var progress = new ChapterOneProgress();
            Assert.That(progress.UnlockWritingDesk(), Is.False);
            Assert.That(progress.SearchPortrait(), Is.False);
            Assert.That(progress.DecodeLens(2, 2), Is.False);
            Assert.That(progress.OpenSecretPanel(), Is.False);
            Assert.That(progress.EnterObservatory(), Is.False);
            Assert.That(progress.SearchShelf(), Is.True);
            Assert.That(progress.SearchShelf(), Is.False);
            Assert.That(progress.UnlockWritingDesk(), Is.True);
            Assert.That(progress.SearchPortrait(), Is.True);
            Assert.That(progress.DecodeLens(1, 3), Is.False);
            Assert.That(progress.DecodeLens(2, 1), Is.False);
            Assert.That(progress.DecodeLens(2, 2), Is.True);
            Assert.That(progress.SetDigit(0, 3), Is.True);
            Assert.That(progress.SetDigit(1, 1), Is.True);
            Assert.That(progress.SetDigit(2, 4), Is.True);
            Assert.That(progress.OpenSecretPanel(), Is.True);
            Assert.That(progress.EnterObservatory(), Is.True);
            Assert.That(progress.ObservatoryUnlocked, Is.True);
            Assert.That(progress.EnterObservatory(), Is.False);
        }

        [Test]
        public void CorruptOrImpossibleSave_CannotMutateLiveState()
        {
            var progress = new ChapterOneProgress();
            Assert.That(progress.SearchShelf(), Is.True);
            Assert.That(progress.Restore(ChapterOneProgress.ObservatoryFlag, 314), Is.False);
            Assert.That(progress.Restore(ChapterOneProgress.KeyFlag | ChapterOneProgress.LensFlag, 0), Is.False);
            Assert.That(progress.Restore(-1, 0), Is.False);
            Assert.That(progress.Restore(ChapterOneProgress.KeyFlag, 1000), Is.False);
            Assert.That(progress.Restore(ChapterOneProgress.KeyFlag, 0), Is.True);
            Assert.That(progress.HasKey, Is.True);
            Assert.That(progress.HasLens, Is.False);
        }

        [Test]
        public void CipherDial_RejectsInvalidInputAndAllowsZeroDigit()
        {
            var progress = new ChapterOneProgress();
            Assert.That(progress.SetDigit(0, 3), Is.False);
            progress.SearchShelf(); progress.UnlockWritingDesk(); progress.SearchPortrait();
            progress.DecodeLens(2, 2);
            Assert.That(progress.SetDigit(-1, 2), Is.False);
            Assert.That(progress.SetDigit(3, 2), Is.False);
            Assert.That(progress.SetDigit(0, 10), Is.False);
            Assert.That(progress.SetDigit(0, 3), Is.True);
            Assert.That(progress.SetDigit(1, 0), Is.False, "An unchanged digit must not cause a checkpoint write.");
            Assert.That(progress.SetDigit(2, 4), Is.True);
            Assert.That(progress.DialValue, Is.EqualTo(304));
            Assert.That(progress.OpenSecretPanel(), Is.False);
        }

        [Test]
        public void RestoreRejectsImpossibleConsecutiveStages()
        {
            for (int flags = 0; flags <= ChapterOneProgress.AllFlags; flags++)
            {
                var progress = new ChapterOneProgress();
                bool expected = ChapterOneProgress.IsValid(flags, 0);
                Assert.That(progress.Restore(flags, 0), Is.EqualTo(expected), "flags=" + flags);
            }
        }

        [Test]
        public void CipherDial_NoOpDoesNotMutateOrReportProgress()
        {
            var progress = new ChapterOneProgress();
            progress.SearchShelf();
            progress.UnlockWritingDesk();
            progress.SearchPortrait();
            Assert.That(progress.DecodeLens(2, 2), Is.True);
            Assert.That(progress.SetDigit(0, 0), Is.False);
            Assert.That(progress.DialValue, Is.Zero);
            Assert.That(progress.SetDigit(0, 3), Is.True);
            Assert.That(progress.SetDigit(0, 3), Is.False);
            Assert.That(progress.DialValue, Is.EqualTo(300));
            Assert.That(progress.SetDigit(0, 0), Is.True);
            Assert.That(progress.DialValue, Is.Zero);
        }

        [Test]
        public void LensRotation_HandlesSignedIntegerBoundaryWithoutOverflow()
        {
            var progress = new ChapterOneProgress();
            progress.SearchShelf();
            progress.UnlockWritingDesk();
            progress.SearchPortrait();
            Assert.That(progress.DecodeLens(int.MinValue, 2), Is.False);
            Assert.That(progress.DecodeLens(-2, 2), Is.True);
            Assert.That(progress.KnowsCipher, Is.True);
        }
    }
}
