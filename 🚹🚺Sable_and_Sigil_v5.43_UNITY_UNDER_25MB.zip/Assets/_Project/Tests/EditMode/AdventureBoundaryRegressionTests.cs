using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class AdventureBoundaryRegressionTests
    {
        [Test]
        public void StaleTravelDoesNotProduceCandidate()
        {
            var start = AdventureChapter.NewGame();
            AdventureSnapshot candidate;
            string error;
            Assert.IsFalse(AdventureChapter.TryTravel(start, AdventureLocation.Archive, 99, out candidate, out error));
            Assert.IsNull(candidate);
            Assert.AreEqual(AdventureFacts.None, start.Facts);
            Assert.AreEqual(0, start.Revision);
        }

        [Test]
        public void StaleActionDoesNotProduceCandidate()
        {
            var start = AdventureChapter.NewGame();
            AdventureSnapshot candidate;
            string error;
            Assert.IsFalse(AdventureChapter.TryAct(start, AdventureAction.TakeKey, 1, out candidate, out error));
            Assert.IsNull(candidate);
            Assert.AreEqual(AdventureFacts.None, start.Facts);
        }

        [Test]
        public void RevisionExhaustionRejectsMutationWithoutOverflow()
        {
            var state = new AdventureSnapshot(AdventureSnapshot.CurrentSchema, long.MaxValue,
                AdventureLocation.Courtyard, AdventureFacts.None);
            AdventureSnapshot candidate;
            string error;
            Assert.IsFalse(AdventureChapter.TryAct(state, AdventureAction.TakeKey, long.MaxValue, out candidate, out error));
            Assert.IsNull(candidate);
            Assert.IsFalse(AdventureChapter.TryTravel(state, AdventureLocation.Archive, long.MaxValue, out candidate, out error));
            Assert.IsNull(candidate);
        }

        [Test]
        public void InvalidLocationAndFactsCannotBeLoaded()
        {
            Assert.Throws<ArgumentException>(() => new AdventureSnapshot(1, 0,
                (AdventureLocation)999, AdventureFacts.None));
            Assert.Throws<ArgumentException>(() => new AdventureSnapshot(1, 0,
                AdventureLocation.Courtyard, (AdventureFacts)128));
            Assert.Throws<ArgumentException>(() => new AdventureSnapshot(1, 0,
                AdventureLocation.Courtyard, AdventureFacts.LensInstalled));
            Assert.Throws<ArgumentException>(() => new AdventureSnapshot(2, 0,
                AdventureLocation.Courtyard, AdventureFacts.None));
        }

        [Test]
        public void InvalidActionAndNullStateAreRejected()
        {
            AdventureSnapshot candidate;
            string error;
            Assert.IsFalse(AdventureChapter.TryAct(null, AdventureAction.TakeKey, 0, out candidate, out error));
            Assert.IsNull(candidate);
            var start = AdventureChapter.NewGame();
            Assert.IsFalse(AdventureChapter.TryAct(start, (AdventureAction)999, 0, out candidate, out error));
            Assert.IsNull(candidate);
            Assert.AreEqual(AdventureFacts.None, start.Facts);
        }

        [Test]
        public void DuplicateKeyAcquisitionIsRejectedWithoutStateMutation()
        {
            var initial = AdventureChapter.NewGame();
            AdventureSnapshot withKey;
            string error;
            Assert.IsTrue(AdventureChapter.TryAct(initial, AdventureAction.TakeKey, 0, out withKey, out error));
            AdventureSnapshot duplicate;
            Assert.IsFalse(AdventureChapter.TryAct(withKey, AdventureAction.TakeKey, withKey.Revision, out duplicate, out error));
            Assert.IsNull(duplicate);
            Assert.AreEqual(AdventureFacts.KeyTaken, withKey.Facts);
            Assert.AreEqual(1, withKey.Revision);
        }
    }
}
