using System;
using System.Collections.Generic;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterInvestigationProgressionTests
    {
        private sealed class MemoryStorage : IStoryDossierStorage
        {
            private readonly Dictionary<string, string> values =
                new Dictionary<string, string>(StringComparer.Ordinal);
            public bool Contains(string key) => values.ContainsKey(key);
            public string Read(string key) => values.TryGetValue(key, out string value) ? value : string.Empty;
            public void Write(string key, string value) => values[key] = value;
            public void Flush() { }
            public void SetRaw(string key, string value) => values[key] = value;
        }

        [Test]
        public void ChapterCountsAndUnlockTransitionsFollowEvidenceGraph()
        {
            var ledger = new StoryEvidenceLedger();
            int[] first = { 1, 3, 7, 10 };
            int[] last = { 2, 6, 9, 10 };
            for (int chapter = 1; chapter <= 4; chapter++)
            {
                ChapterInvestigationProgress summary = ChapterInvestigationProgression.Get(chapter, ledger);
                Assert.AreEqual(first[chapter - 1], summary.FirstLocation);
                Assert.AreEqual(last[chapter - 1], summary.LastLocation);
                Assert.AreEqual(last[chapter - 1] - first[chapter - 1] + 1, summary.TotalCount);
                Assert.AreEqual(0, summary.CompletedCount);
                Assert.AreEqual(chapter == 1, summary.IsUnlocked);
                Assert.AreEqual(chapter == 1 ? 1 : 0, summary.NextAvailableLocation);
            }
            for (int scene = 1; scene <= ChapterStoryGraph.LocationCount; scene++)
            {
                Assert.IsTrue(ledger.TryResolve(scene, ledger.Revision, out string error), error);
                int currentChapter = ChapterStoryGraph.GetLocation(scene).Chapter;
                ChapterInvestigationProgress current = ChapterInvestigationProgression.Get(currentChapter, ledger);
                Assert.IsTrue(current.IsUnlocked);
                Assert.AreEqual(scene == current.LastLocation, current.IsComplete);
                if (scene == current.LastLocation && currentChapter < 4)
                {
                    ChapterInvestigationProgress upcoming = ChapterInvestigationProgression.Get(currentChapter + 1, ledger);
                    Assert.IsTrue(upcoming.IsUnlocked);
                    Assert.AreEqual(upcoming.FirstLocation, upcoming.NextAvailableLocation);
                }
            }
            Assert.IsTrue(ChapterInvestigationProgression.Get(4, ledger).IsComplete);
            Assert.AreEqual(0, ChapterInvestigationProgression.Get(4, ledger).NextAvailableLocation);
        }

        [Test]
        public void DerivedSummaryDoesNotMutateOwnerAndValidatesInput()
        {
            var ledger = new StoryEvidenceLedger();
            Assert.IsTrue(ledger.TryResolve(1, 0, out _));
            long before = ledger.Revision;
            var chapter = ChapterInvestigationProgression.Get(1, ledger);
            Assert.AreEqual(1, chapter.CompletedCount);
            Assert.AreEqual(2, chapter.NextAvailableLocation);
            Assert.AreEqual(before, ledger.Revision);
            CollectionAssert.AreEqual(new[] { 1 }, ledger.Snapshot());
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterInvestigationProgression.Get(0, ledger));
            Assert.Throws<ArgumentOutOfRangeException>(() => ChapterInvestigationProgression.Get(5, ledger));
            Assert.Throws<ArgumentNullException>(() => ChapterInvestigationProgression.Get(1, null));
        }

        [Test]
        public void ReloadReconcilesStaleSessionWithoutDuplicatingRewards()
        {
            var storage = new MemoryStorage();
            var first = new StoryDossierSession(storage);
            var second = new StoryDossierSession(storage);
            Assert.IsTrue(first.TrySubmit(1, 2, 0, out _));
            Assert.IsFalse(second.TrySubmit(1, 2, 0, out _));
            Assert.AreEqual(0, second.CompletedCount);
            Assert.IsTrue(second.TryReload(out string error), error);
            Assert.AreEqual(1, second.CompletedCount);
            Assert.IsTrue(second.TryGetChapterProgress(1, out ChapterInvestigationProgress chapter));
            Assert.AreEqual(1, chapter.CompletedCount);
            Assert.IsFalse(second.TrySubmit(1, 2, second.Revision, out _));
            Assert.IsTrue(second.TrySubmit(2, 3, second.Revision, out _));
            Assert.AreEqual(2, new StoryDossierSession(storage).CompletedCount);
        }

        [Test]
        public void LiveSessionRefusesSilentRollbackAfterNewestCheckpointCorruption()
        {
            var storage = new MemoryStorage();
            var session = new StoryDossierSession(storage);
            Assert.IsTrue(session.TrySubmit(1, 2, 0, out _));
            Assert.IsTrue(session.TrySubmit(2, 3, 1, out _));
            storage.SetRaw(StoryDossierRepository.KeyB, "corrupted newest snapshot");
            Assert.IsFalse(session.TryReload(out string error));
            StringAssert.Contains("regressed", error);
            Assert.IsFalse(session.IsReady);
            Assert.AreEqual(2, session.Revision);
            Assert.IsFalse(session.TrySubmit(3, 0, 2, out _));
            var recoveryAfterRestart = new StoryDossierSession(storage);
            Assert.IsTrue(recoveryAfterRestart.IsReady);
            Assert.AreEqual(1, recoveryAfterRestart.CompletedCount);
        }

        [Test]
        public void ReloadFromFutureSchemaFailsClosedWithoutOverwriting()
        {
            var storage = new MemoryStorage();
            var session = new StoryDossierSession(storage);
            Assert.IsTrue(session.TrySubmit(1, 2, 0, out _));
            storage.SetRaw(StoryDossierRepository.KeyB, "v900|2|future");
            Assert.IsFalse(session.TryReload(out string error));
            StringAssert.Contains("future", error);
            Assert.IsFalse(session.IsReady);
            Assert.IsFalse(session.TryGetChapterProgress(1, out ChapterInvestigationProgress locked));
            Assert.IsNull(locked);
            Assert.IsFalse(session.TrySubmit(2, 3, 1, out _));
            Assert.AreEqual("v900|2|future", storage.Read(StoryDossierRepository.KeyB));
        }
    }
}
