using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class CinematicHudClearanceTests
    {
        [Test]
        public void AllTenScenicLocationsAreAccessibleAtDefaultViewport()
        {
            Assert.IsTrue(CinematicHudClearance.Validate(out string error), error);
            Assert.IsTrue(CinematicSceneMap.Validate(out error), error);
            Assert.AreEqual(-368f, CinematicHudClearance.CameraY);
            for (int location = 1; location <= CinematicSceneMap.LocationCount; location++)
            {
                ScenicLocation scene = CinematicSceneMap.Get(location);
                foreach (ScenicPoint point in new[] { scene.EvidenceA, scene.EvidenceB, scene.Mechanism })
                {
                    float x = point.X * CinematicSceneMap.CanvasWidth;
                    float y = point.Y * CinematicSceneMap.CanvasHeight;
                    foreach (float cameraX in new[]
                    {
                        CinematicHudClearance.CameraZoomInX,
                        CinematicHudClearance.CameraZoomOutX,
                        CinematicHudClearance.CameraResetX
                    })
                        Assert.IsFalse(CinematicHudClearance.IntersectsHotspot(x, y,
                            cameraX, CinematicHudClearance.CameraY,
                            CinematicHudClearance.CameraButtonWidth,
                            CinematicHudClearance.CameraButtonHeight));
                    Assert.IsFalse(CinematicHudClearance.IntersectsHotspot(x, y,
                        CinematicHudClearance.ScenicToggleX, CinematicHudClearance.ScenicToggleY,
                        CinematicHudClearance.ScenicToggleWidth,
                        CinematicHudClearance.ScenicToggleHeight));
                }
            }
        }

        [Test]
        public void LegacyUpperRightControlsBlockSeventhCaseMechanism()
        {
            ScenicPoint mechanism = CinematicSceneMap.Get(7).Mechanism;
            Assert.IsTrue(CinematicHudClearance.IntersectsHotspot(
                mechanism.X * CinematicSceneMap.CanvasWidth,
                mechanism.Y * CinematicSceneMap.CanvasHeight,
                570f, 108f, 106f, 60f));
            Assert.IsFalse(CinematicHudClearance.IntersectsHotspot(
                mechanism.X * CinematicSceneMap.CanvasWidth,
                mechanism.Y * CinematicSceneMap.CanvasHeight,
                CinematicHudClearance.CameraZoomInX, CinematicHudClearance.CameraY,
                CinematicHudClearance.CameraButtonWidth,
                CinematicHudClearance.CameraButtonHeight));
        }

        [Test]
        public void InvalidRectanglesFailConservatively()
        {
            Assert.IsTrue(CinematicHudClearance.IntersectsHotspot(0f, 0f,
                float.NaN, 0f, 106f, 60f));
            Assert.IsTrue(CinematicHudClearance.IntersectsHotspot(0f, 0f,
                0f, 0f, 0f, 60f));
            Assert.IsFalse(CinematicHudClearance.IntersectsHotspot(0f, 0f,
                -700f, -370f, 106f, 60f));
        }
    }
}
