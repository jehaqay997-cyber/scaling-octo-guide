using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class WorldPointerResumeGateTests
    {
        [Test]
        public void UnsuspendedWorldAcceptsNewInput()
        {
            var gate = new WorldPointerResumeGate();
            Assert.IsFalse(gate.IsAwaitingRelease);
            Assert.IsTrue(gate.MayProcessFrame(true));
            Assert.IsTrue(gate.MayProcessFrame(false));
        }

        [Test]
        public void FocusLossRejectsHeldPointerAndItsReleaseFrame()
        {
            var gate = new WorldPointerResumeGate();
            gate.Suspend();
            Assert.IsTrue(gate.IsAwaitingRelease);
            Assert.IsFalse(gate.MayProcessFrame(true));
            Assert.IsFalse(gate.MayProcessFrame(true));
            Assert.IsFalse(gate.MayProcessFrame(false));
            Assert.IsFalse(gate.IsAwaitingRelease);
            Assert.IsTrue(gate.MayProcessFrame(true));
        }

        [Test]
        public void RepeatedSuspensionsCannotAccidentallyUnblockInput()
        {
            var gate = new WorldPointerResumeGate();
            gate.Suspend();
            Assert.IsFalse(gate.MayProcessFrame(true));
            gate.Suspend();
            Assert.IsFalse(gate.MayProcessFrame(true));
            Assert.IsFalse(gate.MayProcessFrame(false));
            Assert.IsTrue(gate.MayProcessFrame(true));
        }

        [Test]
        public void SceneCloseClearsTransientSuspensionWithoutPersistentState()
        {
            var gate = new WorldPointerResumeGate();
            gate.Suspend();
            gate.Reset();
            Assert.IsFalse(gate.IsAwaitingRelease);
            Assert.IsTrue(gate.MayProcessFrame(true));
        }
    }
}
