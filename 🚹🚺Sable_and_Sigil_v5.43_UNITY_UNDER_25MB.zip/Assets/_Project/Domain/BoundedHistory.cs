using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// A fixed-capacity last-in-first-out history. When full, only the oldest entry
    /// is evicted. Push, Pop, and Peek are O(1) and require no resize allocation.
    /// This container does not clone T: callers own snapshot immutability.
    /// </summary>
    public sealed class BoundedHistory<T>
    {
        private readonly T[] entries;
        private int oldest;
        private int count;

        public BoundedHistory(int capacity)
        {
            if (capacity <= 0) throw new ArgumentOutOfRangeException(nameof(capacity));
            entries = new T[capacity];
        }

        public int Capacity => entries.Length;
        public int Count => count;

        public void Push(T value)
        {
            if (count < entries.Length)
            {
                int index = (int)(((long)oldest + count) % entries.Length);
                entries[index] = value;
                count++;
                return;
            }

            entries[oldest] = value;
            oldest++;
            if (oldest == entries.Length) oldest = 0;
        }

        public T Peek()
        {
            if (count == 0) throw new InvalidOperationException("History is empty.");
            return entries[(int)(((long)oldest + count - 1) % entries.Length)];
        }

        public T Pop()
        {
            if (count == 0) throw new InvalidOperationException("History is empty.");
            int index = (int)(((long)oldest + count - 1) % entries.Length);
            T result = entries[index];
            entries[index] = default(T);
            count--;
            if (count == 0) oldest = 0;
            return result;
        }

        public void Clear()
        {
            Array.Clear(entries, 0, entries.Length);
            oldest = 0;
            count = 0;
        }
    }
}
