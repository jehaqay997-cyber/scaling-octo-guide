using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Pure, read-only access control for the final narrative. Neither hints nor visual
    /// previews can mark evidence complete. All ten durable case resolutions are required.
    /// The ledger's revision equals its number of accepted, monotonic commits.
    /// </summary>
    public static class StoryFinalePolicy
    {
        public const int RequiredEvidenceCount = 10;
        public const int PageCount = 4;

        public static bool IsUnlocked(long revision, IReadOnlyCollection<int> resolved)
        {
            if (resolved == null || revision != RequiredEvidenceCount ||
                resolved.Count != RequiredEvidenceCount ||
                RequiredEvidenceCount != ChapterStoryGraph.LocationCount) return false;

            var distinct = new HashSet<int>();
            foreach (int number in resolved)
            {
                if (number < 1 || number > RequiredEvidenceCount || !distinct.Add(number))
                    return false;
            }
            for (int number = 1; number <= RequiredEvidenceCount; number++)
            {
                if (!distinct.Contains(number)) return false;
                foreach (int prerequisite in ChapterStoryGraph.GetLocation(number).Prerequisites)
                    if (!distinct.Contains(prerequisite)) return false;
            }
            return true;
        }

        public static int NextPage(int currentPage)
        {
            ValidatePage(currentPage);
            return Math.Min(currentPage + 1, PageCount - 1);
        }

        public static int PreviousPage(int currentPage)
        {
            ValidatePage(currentPage);
            return Math.Max(currentPage - 1, 0);
        }

        public static void ValidatePage(int page)
        {
            if (page < 0 || page >= PageCount)
                throw new ArgumentOutOfRangeException(nameof(page));
        }
    }
}
