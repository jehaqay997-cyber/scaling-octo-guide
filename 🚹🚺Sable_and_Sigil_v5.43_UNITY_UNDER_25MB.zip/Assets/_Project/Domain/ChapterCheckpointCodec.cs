using System;
using System.Globalization;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Versioned checkpoint encoding. The checksum detects accidental corruption; it is not
    /// cryptographic authentication and must not be used for anti-cheat or trust decisions.
    /// </summary>
    public static class ChapterCheckpointCodec
    {
        private const string Version = "1";

        public static string Encode(long revision, int flags, int dial)
        {
            if (revision <= 0 || !ChapterOneProgress.IsValid(flags, dial))
                throw new ArgumentOutOfRangeException(nameof(revision), "Checkpoint state is invalid.");
            string payload = Version + "|" + revision.ToString(CultureInfo.InvariantCulture) + "|" +
                flags.ToString(CultureInfo.InvariantCulture) + "|" + dial.ToString(CultureInfo.InvariantCulture);
            return payload + "|" + Checksum(payload).ToString("X8", CultureInfo.InvariantCulture);
        }

        public static bool TryDecode(string data, out long revision, out int flags, out int dial)
        {
            revision = 0;
            flags = 0;
            dial = 0;
            if (string.IsNullOrEmpty(data) || data.Length > 128) return false;
            string[] parts = data.Split('|');
            if (parts.Length != 5 || parts[0] != Version || parts[4].Length != 8) return false;
            long parsedRevision;
            int parsedFlags;
            int parsedDial;
            uint expectedChecksum;
            if (!long.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out parsedRevision) ||
                !int.TryParse(parts[2], NumberStyles.None, CultureInfo.InvariantCulture, out parsedFlags) ||
                !int.TryParse(parts[3], NumberStyles.None, CultureInfo.InvariantCulture, out parsedDial) ||
                !uint.TryParse(parts[4], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out expectedChecksum))
                return false;
            if (parsedRevision <= 0 || !ChapterOneProgress.IsValid(parsedFlags, parsedDial)) return false;
            string canonical = Version + "|" + parsedRevision.ToString(CultureInfo.InvariantCulture) + "|" +
                parsedFlags.ToString(CultureInfo.InvariantCulture) + "|" + parsedDial.ToString(CultureInfo.InvariantCulture);
            if (data != canonical + "|" + expectedChecksum.ToString("X8", CultureInfo.InvariantCulture) ||
                Checksum(canonical) != expectedChecksum) return false;
            revision = parsedRevision;
            flags = parsedFlags;
            dial = parsedDial;
            return true;
        }

        private static uint Checksum(string value)
        {
            unchecked
            {
                uint hash = 2166136261u;
                for (int i = 0; i < value.Length; i++)
                {
                    hash ^= value[i];
                    hash *= 16777619u;
                }
                return hash;
            }
        }
    }
}
