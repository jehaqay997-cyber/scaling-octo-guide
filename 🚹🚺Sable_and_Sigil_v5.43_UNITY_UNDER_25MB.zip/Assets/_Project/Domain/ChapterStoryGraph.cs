using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public sealed class StoryLocation
    {
        public int Number { get; }
        public int Chapter { get; }
        public string Id { get; }
        public string Title { get; }
        public string Mechanism { get; }
        public string ClueSource { get; }
        public string EvidenceId { get; }
        public string ArtResource { get; }
        public IReadOnlyList<int> Prerequisites { get; }
        public IReadOnlyList<string> HintTiers { get; }
        public bool HasPlayableScene => false;

        internal StoryLocation(int number, int chapter, string id, string title, string mechanism,
            string clueSource, string evidenceId, int[] dependencies, string[] hints)
        {
            Number = number;
            Chapter = chapter;
            Id = id;
            Title = title;
            Mechanism = mechanism;
            ClueSource = clueSource;
            EvidenceId = evidenceId;
            ArtResource = "LocationArt/Scene_" + number.ToString("00");
            Prerequisites = Array.AsReadOnly((int[])dependencies.Clone());
            HintTiers = Array.AsReadOnly((string[])hints.Clone());
        }
    }

    /// <summary>Authored evidence dependencies. Reference images never grant gameplay progress.</summary>
    public static class ChapterStoryGraph
    {
        public const int ChapterCount = 4;
        public const int LocationCount = 10;
        private static readonly StoryLocation[] Locations = CreateLocations();
        private static readonly IReadOnlyList<StoryLocation> ReadOnlyLocations = Array.AsReadOnly(Locations);
        public static IReadOnlyList<StoryLocation> AllLocations => ReadOnlyLocations;

        private static StoryLocation[] CreateLocations()
        {
            return new[]
            {
                new StoryLocation(1, 1, "scene_01", "The Threshold of Vey", "seal-comparison", "lady_vey_letter", "scene_01_evidence",
                    new int[] {  }, new[] { "Compare the lost-star crest on the threshold with the mark in Lady Vey's final letter.", "Notice which details appear on the sealed arch but are absent from the letter.", "Record the matching and mismatched marks before attempting a seal comparison." }),
                new StoryLocation(2, 1, "scene_02", "The Spiral of Testimony", "pattern-anomaly", "altered_baluster", "scene_02_evidence",
                    new int[] { 1 }, new[] { "Inspect the ceremonial stair for one baluster that breaks the repeated design.", "Compare the spacing on both sides of the replacement rather than its color.", "Infer the missing pattern position from its neighboring steps before testing it." }),
                new StoryLocation(3, 2, "scene_03", "The Lantern Ascent", "lantern-time", "lunar_calendar", "scene_03_evidence",
                    new int[] { 2 }, new[] { "The lantern burns at an hour that contradicts the garden's lunar calendar.", "Read the calendar as a cycle; compare its marked phase with the lantern dial.", "Choose the phase implied by the calendar evidence, not the apparent time of day." }),
                new StoryLocation(4, 2, "scene_04", "The Rose Pavilion", "floral-sequence", "basin_engraving", "scene_04_evidence",
                    new int[] { 3 }, new[] { "Read the four petal counts carved around the pavilion basin.", "The inscription says that each count combines the two preceding counts.", "Apply the additive rule to the last two counts before selecting a number." }),
                new StoryLocation(5, 2, "scene_05", "The Fountain of Echoes", "fountain-order", "gardener_notation", "scene_05_evidence",
                    new int[] { 4 }, new[] { "Inspect the four numbered fountain spouts and the gardener's written sequence.", "The inscription fixes the first and last spouts and one adjacent pair.", "Position spout 3 immediately after spout 1, then satisfy the remaining order constraints." }),
                new StoryLocation(6, 2, "scene_06", "The Silent Crossing", "statue-direction", "statue_gestures", "scene_06_evidence",
                    new int[] { 5 }, new[] { "Study the orientation of the three statues before approaching the boat.", "Treat the statues' gestures as directional evidence, not decorative poses.", "Combine the three directions in order to infer the route to the hidden shore." }),
                new StoryLocation(7, 3, "scene_07", "The Glass Testament", "light-sequence", "window_symbols", "scene_07_evidence",
                    new int[] { 6 }, new[] { "Record the three stained-glass symbols in their original vertical order.", "The silvered mirror carriage exchanges the upper and lower panes while the middle stays fixed.", "Apply the outer-pane exchange: keep the ring centered, then read the new top-to-bottom sequence." }),
                new StoryLocation(8, 3, "scene_08", "The Hall of False Light", "memorial-contradiction", "family_memorial", "scene_08_evidence",
                    new int[] { 7 }, new[] { "Compare the gallery memorial text with the painted figures above it.", "Compare the recorded death year with the portrait sitting year.", "Identify the assertion that a deceased witness was alive for a later sitting." }),
                new StoryLocation(9, 3, "scene_09", "The Weeping Witness", "epitaph-restoration", "damaged_epitaph", "scene_09_evidence",
                    new int[] { 8 }, new[] { "Inspect the broken epitaph beneath the witness statue for repeated letter forms.", "Compare its missing word length with the surviving testimony fragments.", "Reconstruct the word from confirmed fragments before restoring the inscription." }),
                new StoryLocation(10, 4, "scene_10", "The Meridian Rotunda", "meridian-synthesis", "missing_star_chart", "scene_10_evidence",
                    new int[] { 9 }, new[] { "Read the archive constraints for the four meridian rings A, B, C and D.", "The note fixes D last, B immediately after A, and A before C.", "Solve the ordering constraints together; preserve the adjacent A-B pair and D in the final position." }),
            };
        }

        public static StoryLocation GetLocation(int number)
        {
            if (number < 1 || number > LocationCount)
                throw new ArgumentOutOfRangeException(nameof(number));
            return Locations[number - 1];
        }

        private static bool Contains(IReadOnlyCollection<int> values, int number)
        {
            foreach (int value in values)
                if (value == number) return true;
            return false;
        }

        public static bool IsAvailable(int number, IReadOnlyCollection<int> resolved)
        {
            if (resolved == null) throw new ArgumentNullException(nameof(resolved));
            StoryLocation scene = GetLocation(number);
            if (Contains(resolved, number)) return false;
            foreach (int dependency in scene.Prerequisites)
                if (!Contains(resolved, dependency)) return false;
            return true;
        }

        public static bool TrySuggestNext(IReadOnlyCollection<int> resolved, out StoryLocation next)
        {
            if (resolved == null) throw new ArgumentNullException(nameof(resolved));
            next = null;
            foreach (int number in resolved)
                if (number < 1 || number > LocationCount) return false;
            foreach (StoryLocation location in Locations)
                if (IsAvailable(location.Number, resolved))
                {
                    next = location;
                    return true;
                }
            return false;
        }

        public static bool Validate(out string error)
        {
            error = null;
            if (Locations.Length != LocationCount)
            { error = "Catalog length mismatch."; return false; }
            var seenIds = new HashSet<string>(StringComparer.Ordinal);
            var seenEvidence = new HashSet<string>(StringComparer.Ordinal);
            var mappedChapters = new bool[ChapterCount];
            int lastChapter = 1;
            for (int index = 0; index < Locations.Length; index++)
            {
                var scene = Locations[index];
                if (scene.Number != index + 1 || scene.Chapter < lastChapter ||
                    scene.Chapter > ChapterCount || string.IsNullOrWhiteSpace(scene.Title) ||
                    string.IsNullOrWhiteSpace(scene.Mechanism) || string.IsNullOrWhiteSpace(scene.ClueSource) ||
                    !seenIds.Add(scene.Id) || !seenEvidence.Add(scene.EvidenceId) ||
                    scene.HintTiers.Count != 3 || scene.HasPlayableScene)
                { error = "Invalid location metadata: " + (index + 1); return false; }
                foreach (string hint in scene.HintTiers)
                    if (string.IsNullOrWhiteSpace(hint))
                    { error = "Missing hint at scene " + scene.Number; return false; }
                var distinct = new HashSet<int>();
                foreach (int dependency in scene.Prerequisites)
                    if (dependency < 1 || dependency >= scene.Number ||
                        !distinct.Add(dependency) || Locations[dependency - 1].Chapter > scene.Chapter)
                    { error = "Invalid prerequisite at scene " + scene.Number; return false; }
                mappedChapters[scene.Chapter - 1] = true;
                lastChapter = scene.Chapter;
            }
            foreach (bool mapped in mappedChapters)
                if (!mapped) { error = "Chapter missing scene."; return false; }
            var resolved = new HashSet<int>();
            while (TrySuggestNext(resolved, out StoryLocation candidate))
                if (!resolved.Add(candidate.Number))
                { error = "Repeated scene in graph."; return false; }
            if (resolved.Count != LocationCount)
            { error = "Unreachable scene."; return false; }
            return true;
        }
    }

    /// <summary>Revision-bound monotonic evidence ledger. Not connected to save data yet.</summary>
    public sealed class StoryEvidenceLedger
    {
        private readonly HashSet<int> resolved = new HashSet<int>();
        public long Revision { get; private set; }
        public int Count => resolved.Count;

        public bool Has(int number)
        {
            ChapterStoryGraph.GetLocation(number);
            return resolved.Contains(number);
        }

        public int[] Snapshot()
        {
            var result = new int[resolved.Count];
            resolved.CopyTo(result);
            Array.Sort(result);
            return result;
        }

        public bool TryResolve(int number, long expectedRevision, out string error)
        {
            error = null;
            if (number < 1 || number > ChapterStoryGraph.LocationCount)
            { error = "Unknown scene."; return false; }
            if (expectedRevision != Revision)
            { error = "Stale evidence command."; return false; }
            if (Revision == long.MaxValue)
            { error = "Revision exhausted."; return false; }
            if (!ChapterStoryGraph.IsAvailable(number, resolved))
            { error = "Scene prerequisites are incomplete or already resolved."; return false; }
            resolved.Add(number);
            Revision++;
            return true;
        }

        public bool Restore(long revision, IEnumerable<int> evidence)
        {
            if (revision < 0 || evidence == null) return false;
            var proposed = new HashSet<int>();
            foreach (int number in evidence)
                if (number < 1 || number > ChapterStoryGraph.LocationCount || !proposed.Add(number)) return false;
            if (revision != proposed.Count) return false;
            foreach (int number in proposed)
                foreach (int required in ChapterStoryGraph.GetLocation(number).Prerequisites)
                    if (!proposed.Contains(required)) return false;
            resolved.Clear();
            resolved.UnionWith(proposed);
            Revision = revision;
            return true;
        }
    }
}
