using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Transient, case-scoped evidence inspection. Durable completion remains exclusively
    /// owned by StoryDossierSession. Switching cases creates a fresh inspection state.
    /// </summary>
    public sealed class StoryCaseInspection
    {
        private readonly StoryDossierCase dossier;
        private readonly bool[] inspected;

        public int CaseNumber => dossier.Number;
        public int EvidenceCount => dossier.EvidenceFragments.Count;
        public int InspectedCount { get; private set; }
        public int SelectedEvidenceIndex { get; private set; } = -1;
        public bool CanDeduce => InspectedCount == EvidenceCount;

        public StoryCaseInspection(int caseNumber)
        {
            dossier = StoryDossierCatalog.Get(caseNumber);
            inspected = new bool[dossier.EvidenceFragments.Count];
            if (inspected.Length != 2)
                throw new InvalidOperationException("A case must have exactly two evidence fragments.");
        }

        public bool HasInspected(int evidenceIndex)
        {
            return evidenceIndex >= 0 && evidenceIndex < inspected.Length && inspected[evidenceIndex];
        }

        public bool TryInspect(int evidenceIndex, out string transcript)
        {
            transcript = null;
            if (evidenceIndex < 0 || evidenceIndex >= inspected.Length)
                return false;
            if (!inspected[evidenceIndex])
            {
                inspected[evidenceIndex] = true;
                InspectedCount++;
            }
            SelectedEvidenceIndex = evidenceIndex;
            transcript = dossier.EvidenceFragments[evidenceIndex];
            return true;
        }
    }
}
