using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Canonical, authored panorama HUD geometry on the 1600x900 design canvas.
    /// The camera controls and the photo/3D toggle reside in the bottom gutter,
    /// outside every evidence and mechanism target at the default viewport.
    /// This model is purely presentational and never authorizes a deduction.
    /// </summary>
    public static class CinematicHudClearance
    {
        public const float CameraY = -368f;
        public const float CameraZoomInX = -665f;
        public const float CameraZoomOutX = -535f;
        public const float CameraResetX = -405f;
        public const float CameraButtonWidth = 106f;
        public const float CameraButtonHeight = 60f;
        public const float ScenicToggleX = 0f;
        public const float ScenicToggleY = -368f;
        public const float ScenicToggleWidth = 278f;
        public const float ScenicToggleHeight = 60f;
        public const float EvidenceWidth = 112f;
        public const float EvidenceHeight = 76f;

        public static bool Validate(out string error)
        {
            float[] xs = { CameraZoomInX, CameraZoomOutX, CameraResetX, ScenicToggleX };
            float[] widths = { CameraButtonWidth, CameraButtonWidth,
                CameraButtonWidth, ScenicToggleWidth };
            for (int control = 0; control < xs.Length; control++)
            {
                if (!InsideCanvas(xs[control], CameraY, widths[control], CameraButtonHeight))
                {
                    error = "A panoramic HUD control protrudes outside the design canvas.";
                    return false;
                }
                // The shared bottom-right deduction control must remain clickable
                // while a completed mechanism is awaiting journal submission.
                if (Overlap(xs[control], CameraY, widths[control], CameraButtonHeight,
                    620f, -370f, 315f, 66f))
                {
                    error = "Panoramic HUD covers the deduction action.";
                    return false;
                }
                for (int other = control + 1; other < xs.Length; other++)
                {
                    if (!Overlap(xs[control], CameraY, widths[control], CameraButtonHeight,
                        xs[other], CameraY, widths[other], CameraButtonHeight)) continue;
                    error = "Panoramic HUD controls overlap one another.";
                    return false;
                }
            }
            for (int location = 1; location <= CinematicSceneMap.LocationCount; location++)
            {
                ScenicLocation scene = CinematicSceneMap.Get(location);
                ScenicPoint[] points = { scene.EvidenceA, scene.EvidenceB, scene.Mechanism };
                foreach (ScenicPoint point in points)
                {
                    float x = point.X * CinematicSceneMap.CanvasWidth;
                    float y = point.Y * CinematicSceneMap.CanvasHeight;
                    for (int control = 0; control < xs.Length; control++)
                    {
                        if (!Overlap(x, y, EvidenceWidth, EvidenceHeight,
                            xs[control], CameraY, widths[control], CameraButtonHeight)) continue;
                        error = "Photo HUD obscures a case hotspot at location " + location;
                        return false;
                    }
                }
            }
            error = null;
            return true;
        }

        public static bool IntersectsHotspot(float x, float y, float controlX,
            float controlY, float controlWidth, float controlHeight)
        {
            if (!Finite(x) || !Finite(y) || !Finite(controlX) || !Finite(controlY) ||
                !Finite(controlWidth) || !Finite(controlHeight) ||
                controlWidth <= 0f || controlHeight <= 0f) return true;
            return Overlap(x, y, EvidenceWidth, EvidenceHeight,
                controlX, controlY, controlWidth, controlHeight);
        }

        private static bool InsideCanvas(float x, float y, float width, float height)
        {
            return Math.Abs(x) + width * .5f <= CinematicSceneMap.CanvasWidth * .5f &&
                Math.Abs(y) + height * .5f <= CinematicSceneMap.CanvasHeight * .5f;
        }

        private static bool Overlap(float ax, float ay, float aw, float ah,
            float bx, float by, float bw, float bh)
        {
            return Math.Abs(ax - bx) < (aw + bw) * .5f &&
                Math.Abs(ay - by) < (ah + bh) * .5f;
        }

        private static bool Finite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }
    }
}
