using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// The unique scene identifiers for the four authored story chapters.
    /// No UnityEngine dependency is permitted in the campaign route policy.
    /// </summary>
    public static class NarrativeSceneRoute
    {
        public const int ChapterCount = 4;

        public static string SceneName(int chapter)
        {
            switch (chapter)
            {
                case 1: return "ChapterOne";
                case 2: return "ChapterTwo";
                case 3: return "ChapterThree";
                case 4: return "ChapterFour";
                default: throw new ArgumentOutOfRangeException(nameof(chapter),
                    "A narrative chapter must be between one and four.");
            }
        }

        public static string ScenePath(int chapter)
        {
            return "Assets/_Project/Scenes/" + SceneName(chapter) + ".unity";
        }

        public static bool IsCanonicalScene(string sceneName)
        {
            if (string.IsNullOrEmpty(sceneName)) return false;
            for (int chapter = 1; chapter <= ChapterCount; chapter++)
            {
                if (string.Equals(sceneName, SceneName(chapter), StringComparison.Ordinal))
                    return true;
            }
            return false;
        }

        public static bool RequiresSceneTransition(string currentSceneName, int selectedChapter)
        {
            string destination = SceneName(selectedChapter);
            return !string.Equals(currentSceneName, destination, StringComparison.Ordinal);
        }
    }
}
