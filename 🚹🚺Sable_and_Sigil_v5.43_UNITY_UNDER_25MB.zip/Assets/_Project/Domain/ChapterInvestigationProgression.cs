using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    /// <summary>An immutable, derived chapter view. This is not a second owner of progress.</summary>
    public sealed class ChapterInvestigationProgress
    {
        internal ChapterInvestigationProgress(int chapter, int firstLocation, int lastLocation,
            int completedCount, bool isUnlocked, int nextAvailableLocation)
        {
            Chapter = chapter;
            FirstLocation = firstLocation;
            LastLocation = lastLocation;
            CompletedCount = completedCount;
            IsUnlocked = isUnlocked;
            NextAvailableLocation = nextAvailableLocation;
        }

        public int Chapter { get; }
        public int FirstLocation { get; }
        public int LastLocation { get; }
        public int TotalCount => LastLocation - FirstLocation + 1;
        public int CompletedCount { get; }
        public bool IsUnlocked { get; }
        public bool IsComplete => CompletedCount == TotalCount;
        public int NextAvailableLocation { get; }
    }

    /// <summary>Read-only chapter summaries derived from the evidence graph and a validated ledger.</summary>
    public static class ChapterInvestigationProgression
    {
        public static ChapterInvestigationProgress Get(int chapter, StoryEvidenceLedger ledger)
        {
            if (chapter < 1 || chapter > ChapterStoryGraph.ChapterCount)
                throw new ArgumentOutOfRangeException(nameof(chapter));
            if (ledger == null) throw new ArgumentNullException(nameof(ledger));

            int first = 0;
            int last = 0;
            int completed = 0;
            bool unlocked = chapter == 1;
            int next = 0;
            int[] snapshot = ledger.Snapshot();
            var resolved = new HashSet<int>(snapshot);

            foreach (StoryLocation location in ChapterStoryGraph.AllLocations)
            {
                if (location.Chapter < chapter)
                {
                    if (!resolved.Contains(location.Number)) unlocked = false;
                    continue;
                }
                if (location.Chapter > chapter) break;
                if (first == 0) first = location.Number;
                last = location.Number;
                if (resolved.Contains(location.Number)) completed++;
                else if (next == 0 && ChapterStoryGraph.IsAvailable(location.Number, resolved))
                    next = location.Number;
            }

            if (first == 0 || last < first)
                throw new InvalidOperationException("The requested chapter has no authored locations.");
            if (!unlocked) next = 0;
            return new ChapterInvestigationProgress(chapter, first, last, completed, unlocked, next);
        }
    }
}
