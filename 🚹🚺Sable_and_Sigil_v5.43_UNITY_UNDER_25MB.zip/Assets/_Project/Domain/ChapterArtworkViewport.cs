using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// A transient, Unity-independent UV viewport for examining existing chapter artwork.
    /// It neither owns image data nor modifies investigation or persistence state.
    /// </summary>
    public sealed class ChapterArtworkViewport
    {
        public const float MinimumZoom = 1f;
        public const float MaximumZoom = 3f;

        private float zoom = MinimumZoom;
        private float centerX = .5f;
        private float centerY = .5f;

        public float Zoom => zoom;
        public float X => centerX - .5f / zoom;
        public float Y => centerY - .5f / zoom;
        public float Extent => 1f / zoom;

        public void Reset()
        {
            zoom = MinimumZoom;
            centerX = .5f;
            centerY = .5f;
        }

        public bool TryZoom(float change)
        {
            if (!Finite(change) || change == 0f) return false;
            float next = Clamp(zoom + change, MinimumZoom, MaximumZoom);
            if (next == zoom) return false;
            zoom = next;
            ClampCenter();
            return true;
        }

        /// <summary>Moves the texture window in normalized UV units without exposing empty space.</summary>
        public bool TryPan(float deltaU, float deltaV)
        {
            if (!Finite(deltaU) || !Finite(deltaV) ||
                (deltaU == 0f && deltaV == 0f) || zoom <= MinimumZoom)
                return false;
            float half = .5f / zoom;
            float nextX = Clamp(centerX + deltaU, half, 1f - half);
            float nextY = Clamp(centerY + deltaV, half, 1f - half);
            if (nextX == centerX && nextY == centerY) return false;
            centerX = nextX;
            centerY = nextY;
            return true;
        }

        private void ClampCenter()
        {
            float half = .5f / zoom;
            centerX = Clamp(centerX, half, 1f - half);
            centerY = Clamp(centerY, half, 1f - half);
        }

        private static bool Finite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private static float Clamp(float value, float minimum, float maximum)
        {
            return Math.Min(maximum, Math.Max(minimum, value));
        }
    }
}
