using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Authored environment roles. The decorative background is never a puzzle oracle:
    /// the existing evidence fragments and mechanism validators remain authoritative.
    /// These descriptions describe inspection targets, not correct responses.
    /// </summary>
    public sealed class CinematicEnvironmentSpec
    {
        public int LocationNumber { get; }
        public string ResourcePath { get; }
        public string InspectionA { get; }
        public string InspectionB { get; }
        public string MechanismSubject { get; }

        internal CinematicEnvironmentSpec(int location, string resource, string a, string b, string mechanism)
        {
            LocationNumber = location;
            ResourcePath = resource;
            InspectionA = a;
            InspectionB = b;
            MechanismSubject = mechanism;
        }
    }

    public static class CinematicEnvironmentCatalog
    {
        private static readonly CinematicEnvironmentSpec[] Featured =
        {
            New(2, "Repeated carved stair rail", "The altered baluster", "Restoration of the three-symbol rhythm"),
            New(4, "Petal clusters on the stone basin", "The additive inscription", "Restore the engraved floral sequence"),
            New(5, "Four numbered fountain spouts", "The gardener's marginal notation", "Align the constrained spout order"),
            New(7, "Vertical colors in the upper glazing", "The silvered pane-changing carriage", "Reconstruct the reordered testament"),
            New(10, "Four meridian rings on the instrument", "The archivist's ordering note", "Align the original meridian"),
        };

        private static CinematicEnvironmentSpec New(int number, string a, string b, string mechanism)
        {
            return new CinematicEnvironmentSpec(number,
                "CinematicLocations/Location_" + number.ToString("00"), a, b, mechanism);
        }

        public static bool TryGetFeatured(int locationNumber, out CinematicEnvironmentSpec spec)
        {
            ChapterStoryGraph.GetLocation(locationNumber);
            foreach (CinematicEnvironmentSpec candidate in Featured)
            {
                if (candidate.LocationNumber == locationNumber)
                {
                    spec = candidate;
                    return true;
                }
            }
            spec = null;
            return false;
        }

        public static bool Validate(out string error)
        {
            var unique = new HashSet<int>();
            foreach (CinematicEnvironmentSpec spec in Featured)
            {
                ChapterWorldSceneSpec world = ChapterWorldSceneCatalog.Get(spec.LocationNumber);
                StoryDossierCase dossier = StoryDossierCatalog.Get(spec.LocationNumber);
                ScenicLocation scenic = CinematicSceneMap.Get(spec.LocationNumber);
                if (!unique.Add(spec.LocationNumber) || scenic.LocationNumber != spec.LocationNumber ||
                    world.LocationNumber != spec.LocationNumber || dossier.Number != spec.LocationNumber ||
                    dossier.EvidenceFragments.Count != 2 || string.IsNullOrWhiteSpace(spec.ResourcePath) ||
                    string.IsNullOrWhiteSpace(spec.InspectionA) ||
                    string.IsNullOrWhiteSpace(spec.InspectionB) ||
                    string.IsNullOrWhiteSpace(spec.MechanismSubject) ||
                    string.Equals(spec.InspectionA, spec.InspectionB, StringComparison.OrdinalIgnoreCase))
                {
                    error = "Featured environment and puzzle evidence catalog diverge.";
                    return false;
                }
            }
            if (unique.Count != 5)
            {
                error = "The original five featured cinematic environments are incomplete.";
                return false;
            }
            error = null;
            return true;
        }
    }
}
