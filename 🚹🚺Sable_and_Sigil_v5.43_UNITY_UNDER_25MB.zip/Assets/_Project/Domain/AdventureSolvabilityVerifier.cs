using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Exhaustively checks the finite adventure transition graph, using the actual
    /// production transition functions rather than a separately invented rule set.
    /// Revisions are excluded from state identity because they are concurrency metadata.
    /// </summary>
    public static class AdventureSolvabilityVerifier
    {
        public sealed class Report
        {
            public int ReachableStates { get; }
            public int WinningStates { get; }
            public int StatesWithPathToVictory { get; }
            public int SoftlockedStates { get; }
            public int Transitions { get; }
            public bool IsSolvableFromEveryReachableState =>
                WinningStates > 0 && SoftlockedStates == 0 && StatesWithPathToVictory == ReachableStates;

            internal Report(int reachable, int winning, int solvable, int transitions)
            {
                ReachableStates = reachable;
                WinningStates = winning;
                StatesWithPathToVictory = solvable;
                SoftlockedStates = reachable - solvable;
                Transitions = transitions;
            }
        }

        private static int Key(AdventureSnapshot state)
        {
            return ((int)state.Location << 6) | (int)state.Facts;
        }

        public static Report Verify()
        {
            var initial = AdventureChapter.NewGame();
            var visited = new Dictionary<int, AdventureSnapshot>();
            var reverseEdges = new Dictionary<int, HashSet<int>>();
            var frontier = new Queue<AdventureSnapshot>();
            int initialKey = Key(initial);
            visited.Add(initialKey, initial);
            reverseEdges.Add(initialKey, new HashSet<int>());
            frontier.Enqueue(initial);
            int transitions = 0;

            while (frontier.Count > 0)
            {
                var state = frontier.Dequeue();
                int fromKey = Key(state);
                foreach (AdventureLocation destination in Enum.GetValues(typeof(AdventureLocation)))
                {
                    AdventureSnapshot next;
                    string error;
                    if (AdventureChapter.TryTravel(state, destination, state.Revision, out next, out error))
                        Register(next, fromKey, visited, reverseEdges, frontier, ref transitions);
                }
                foreach (AdventureAction action in Enum.GetValues(typeof(AdventureAction)))
                {
                    AdventureSnapshot next;
                    string error;
                    if (AdventureChapter.TryAct(state, action, state.Revision, out next, out error))
                        Register(next, fromKey, visited, reverseEdges, frontier, ref transitions);
                }
            }

            var canWin = new HashSet<int>();
            var backward = new Queue<int>();
            int winning = 0;
            foreach (var entry in visited)
            {
                if (!entry.Value.Has(AdventureFacts.LensInstalled)) continue;
                winning++;
                if (canWin.Add(entry.Key)) backward.Enqueue(entry.Key);
            }
            while (backward.Count > 0)
            {
                int key = backward.Dequeue();
                foreach (int predecessor in reverseEdges[key])
                    if (canWin.Add(predecessor)) backward.Enqueue(predecessor);
            }
            return new Report(visited.Count, winning, canWin.Count, transitions);
        }

        private static void Register(AdventureSnapshot next, int fromKey,
            Dictionary<int, AdventureSnapshot> visited,
            Dictionary<int, HashSet<int>> reverseEdges,
            Queue<AdventureSnapshot> frontier,
            ref int transitions)
        {
            if (next == null) throw new InvalidOperationException("Successful transition returned null.");
            if (next.Revision < 0) throw new InvalidOperationException("Invalid revision.");
            int nextKey = Key(next);
            transitions++;
            if (!visited.ContainsKey(nextKey))
            {
                visited.Add(nextKey, next);
                reverseEdges.Add(nextKey, new HashSet<int>());
                frontier.Enqueue(next);
            }
            reverseEdges[nextKey].Add(fromKey);
        }
    }
}
