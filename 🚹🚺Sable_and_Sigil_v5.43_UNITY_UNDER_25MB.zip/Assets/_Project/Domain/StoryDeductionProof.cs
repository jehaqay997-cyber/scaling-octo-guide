using System;
using System.Collections.Generic;
using System.Globalization;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// A separate, deterministic rule model for the ten authored deductions.
    /// It validates the answer key against the evidence's mathematical constraints,
    /// rather than accepting the serialized correct-choice index as proof.
    /// Combinatorial ordering cases enumerate all 4! = 24 permutations.
    /// </summary>
    public static class StoryDeductionProof
    {
        public sealed class Result
        {
            internal Result(int locationNumber, string answer, int solutionCount, string reasoning)
            {
                LocationNumber = locationNumber;
                ExpectedAnswer = answer;
                SolutionCount = solutionCount;
                Reasoning = reasoning;
            }

            public int LocationNumber { get; }
            public string ExpectedAnswer { get; }
            public int SolutionCount { get; }
            public string Reasoning { get; }
            public bool IsUnique => SolutionCount == 1;
        }

        public static Result Solve(int locationNumber)
        {
            if (locationNumber < 1 || locationNumber > ChapterStoryGraph.LocationCount)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));

            switch (locationNumber)
            {
                case 1:
                    int authenticRays = 5;
                    int alteredRays = 6;
                    if (alteredRays - authenticRays != 1)
                        throw new InvalidOperationException("The crest comparison does not isolate a single added ray.");
                    return new Result(1, "The additional sixth ray", 1,
                        "The original has five rays and the arch has six: 6 - 5 = 1 newly added ray.");
                case 2:
                    string[] motif = { "Circle", "Diamond", "Star" };
                    int missingPosition = 6;
                    return new Result(2, motif[(missingPosition - 1) % motif.Length], 1,
                        "A length-three cycle repeats at position 6: (6 - 1) mod 3 = 2 (zero-based).");
                case 3:
                    string[] lunarCycle = { "New Moon", "Waxing Moon", "Full Moon", "Waning Moon" };
                    int offset = 2;
                    return new Result(3, lunarCycle[offset % lunarCycle.Length], 1,
                        "The dial advances two steps from New Moon in a four-state cycle: (0 + 2) mod 4 = 2.");
                case 4:
                    int[] petals = { 2, 3, 5, 8 };
                    for (int i = 2; i < petals.Length; i++)
                        if (petals[i] != checked(petals[i - 1] + petals[i - 2]))
                            throw new InvalidOperationException("The authored petal sequence breaks its additive rule.");
                    int nextPetals = checked(petals[3] + petals[2]);
                    return new Result(4, nextPetals.ToString(CultureInfo.InvariantCulture) + " petals", 1,
                        "The verified two-term recurrence is 2, 3, 5, 8; therefore the next count is 5 + 8 = 13.");
                case 5:
                    return SolveArrangement(5, new[] { '1', '2', '3', '4' },
                        order => order[0] == '1' && order[1] == '3' &&
                                 order[3] == '4' && IndexOf(order, '2') < IndexOf(order, '4'),
                        "Of 24 fountain permutations, exactly one starts with 1-3, ends with 4, and places 2 before 4.");
                case 6:
                    string[] pointing = { "East", "South", "West" }; // Witnesses A, B, C.
                    int[] witnesses = { 1, 0, 2 }; // Read B, A, C.
                    return new Result(6,
                        pointing[witnesses[0]] + "-" + pointing[witnesses[1]] + "-" + pointing[witnesses[2]],
                        1, "The witnessed order B-A-C maps to South-East-West, with no free direction.");
                case 7:
                    string[] glass = { "triangle", "ring", "three rays" };
                    string top = glass[0];
                    glass[0] = glass[2];
                    glass[2] = top;
                    string reflected = char.ToUpperInvariant(glass[0][0]) + glass[0].Substring(1) +
                        ", " + glass[1] + ", " + glass[2];
                    return new Result(7, reflected, 1,
                        "The mechanism is a transposition of pane positions (1 3); the central pane is invariant.");
                case 8:
                    int deathYear = 1904;
                    int claimedSittingYear = 1912;
                    if (claimedSittingYear <= deathYear)
                        throw new InvalidOperationException("The authored chronology contains no temporal contradiction.");
                    return new Result(8, "The witness sat alive in 1912", 1,
                        "A live sitting eight years after the recorded death is inconsistent: 1912 - 1904 = 8.");
                case 9:
                    const string witnessWord = "REMEMBER";
                    const string epitaph = "R_MEMBER";
                    if (witnessWord.Length != epitaph.Length || epitaph[1] != '_')
                        throw new InvalidOperationException("The damaged epitaph does not match the witness note.");
                    for (int i = 0; i < epitaph.Length; i++)
                        if (i != 1 && epitaph[i] != witnessWord[i])
                            throw new InvalidOperationException("The surviving epitaph disagrees with the witness note.");
                    return new Result(9, witnessWord[1].ToString(), 1,
                        "All seven surviving positions agree with REMEMBER; only position 2 is missing, and it is E.");
                case 10:
                    return SolveArrangement(10, new[] { 'A', 'B', 'C', 'D' },
                        order => IndexOf(order, 'B') == IndexOf(order, 'A') + 1 &&
                                 IndexOf(order, 'A') < IndexOf(order, 'C') && order[3] == 'D',
                        "Of 24 meridian permutations, only A-B-C-D satisfies adjacency, precedence, and D-last.");
                default:
                    throw new InvalidOperationException("Missing deduction model.");
            }
        }

        public static bool VerifyCatalogCase(StoryDossierCase dossier, out string error)
        {
            error = null;
            if (dossier == null)
            {
                error = "Missing authored deduction.";
                return false;
            }
            Result proof = Solve(dossier.Number);
            if (!proof.IsUnique || string.IsNullOrWhiteSpace(proof.ExpectedAnswer))
            {
                error = "The constraints do not establish one answer.";
                return false;
            }
            int correctCount = 0;
            for (int index = 0; index < dossier.Choices.Count; index++)
            {
                bool matchesProof = string.Equals(dossier.Choices[index], proof.ExpectedAnswer,
                    StringComparison.OrdinalIgnoreCase);
                if (dossier.IsCorrect(index) != matchesProof)
                {
                    error = "The answer key contradicts the independently derived deduction at choice " + index;
                    return false;
                }
                if (matchesProof) correctCount++;
            }
            if (correctCount != 1)
            {
                error = "The displayed choices do not contain exactly one proven answer.";
                return false;
            }
            return true;
        }

        private static Result SolveArrangement(int number, char[] tokens,
            Func<char[], bool> satisfies, string reasoning)
        {
            if (tokens == null || tokens.Length != 4 || satisfies == null ||
                new HashSet<char>(tokens).Count != 4)
                throw new ArgumentException("An ordering proof requires four distinct tokens.");
            var used = new bool[4];
            var candidate = new char[4];
            string solution = null;
            int solutionCount = 0;
            Enumerate(0);
            return new Result(number, solution, solutionCount, reasoning);

            void Enumerate(int depth)
            {
                if (depth == tokens.Length)
                {
                    if (!satisfies(candidate)) return;
                    solutionCount++;
                    if (solutionCount == 1)
                        solution = new string(new[] { candidate[0], '-', candidate[1], '-',
                            candidate[2], '-', candidate[3] });
                    return;
                }
                for (int index = 0; index < tokens.Length; index++)
                {
                    if (used[index]) continue;
                    used[index] = true;
                    candidate[depth] = tokens[index];
                    Enumerate(depth + 1);
                    used[index] = false;
                }
            }
        }

        private static int IndexOf(char[] values, char candidate)
        {
            for (int index = 0; index < values.Length; index++)
                if (values[index] == candidate) return index;
            return -1;
        }
    }
}
