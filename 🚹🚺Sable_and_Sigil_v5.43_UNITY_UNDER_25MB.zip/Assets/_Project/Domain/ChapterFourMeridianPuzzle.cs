using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public enum MeridianMoveResult
    {
        Invalid = 0,
        EvidenceRequired = 1,
        Selected = 2,
        SelectionCancelled = 3,
        Swapped = 4,
        Verified = 5,
        AlreadyVerified = 6
    }

    /// <summary>
    /// Transient four-ring meridian mechanism. Two independent evidence fragments
    /// are required before a physical move. It never changes saved progression.
    /// Only the dossier session may commit the case's durable conclusion.
    /// </summary>
    public sealed class ChapterFourMeridianPuzzle
    {
        public const int LocationNumber = 10;
        public const int RingCount = 4;
        public const int MaximumHintStage = 3;
        private static readonly char[] InitialOrder = { 'B', 'A', 'D', 'C' };
        private readonly char[] ringOrder = new char[RingCount];
        private readonly IReadOnlyList<char> readOnlyOrder;
        private int selectedIndex;
        private int attempts;
        private int hintStage;
        private bool verified;

        public ChapterFourMeridianPuzzle()
        {
            readOnlyOrder = Array.AsReadOnly(ringOrder);
            Reset();
        }

        public bool IsVerified => verified;
        public int SelectedIndex => selectedIndex;
        public int Attempts => attempts;
        public int HintStage => hintStage;
        public IReadOnlyList<char> Order => readOnlyOrder;
        public IReadOnlyList<string> Hints => ChapterStoryGraph.GetLocation(LocationNumber).HintTiers;
        public StoryDossierCase Case => StoryDossierCatalog.Get(LocationNumber);

        public MeridianMoveResult SelectPosition(int index, bool evidenceA, bool evidenceB)
        {
            if (index < 0 || index >= RingCount) return MeridianMoveResult.Invalid;
            if (!evidenceA || !evidenceB) return MeridianMoveResult.EvidenceRequired;
            if (verified) return MeridianMoveResult.AlreadyVerified;
            if (selectedIndex < 0)
            {
                selectedIndex = index;
                return MeridianMoveResult.Selected;
            }
            if (selectedIndex == index)
            {
                selectedIndex = -1;
                return MeridianMoveResult.SelectionCancelled;
            }
            char saved = ringOrder[selectedIndex];
            ringOrder[selectedIndex] = ringOrder[index];
            ringOrder[index] = saved;
            selectedIndex = -1;
            if (attempts < int.MaxValue) attempts++;
            if (!SatisfiesClues(ringOrder)) return MeridianMoveResult.Swapped;
            verified = true;
            return MeridianMoveResult.Verified;
        }

        public bool TryRevealHint(bool evidenceA, bool evidenceB)
        {
            if (!evidenceA || !evidenceB || verified || hintStage >= MaximumHintStage)
                return false;
            hintStage++;
            return true;
        }

        public void Reset()
        {
            Array.Copy(InitialOrder, ringOrder, RingCount);
            selectedIndex = -1;
            attempts = 0;
            hintStage = 0;
            verified = false;
        }

        public static bool SatisfiesClues(IReadOnlyList<char> ringPositions)
        {
            if (!HasUniqueRings(ringPositions)) return false;
            int a = -1;
            int b = -1;
            int c = -1;
            int d = -1;
            for (int index = 0; index < RingCount; index++)
            {
                switch (ringPositions[index])
                {
                    case 'A': a = index; break;
                    case 'B': b = index; break;
                    case 'C': c = index; break;
                    case 'D': d = index; break;
                }
            }
            return a < c && b == a + 1 && d == RingCount - 1;
        }

        public static bool HasUniqueRings(IReadOnlyList<char> ringPositions)
        {
            if (ringPositions == null || ringPositions.Count != RingCount) return false;
            int mask = 0;
            for (int index = 0; index < RingCount; index++)
            {
                int bit = ringPositions[index] - 'A';
                if (bit < 0 || bit >= RingCount || (mask & (1 << bit)) != 0) return false;
                mask |= 1 << bit;
            }
            return mask == (1 << RingCount) - 1;
        }

        /// <summary>
        /// Exhaustively verifies the 4! permutation space and checks agreement with
        /// the authored case. The sole solution is A-B-C-D; no heuristic is used.
        /// </summary>
        public static bool Validate(out string error)
        {
            StoryLocation location = ChapterStoryGraph.GetLocation(LocationNumber);
            StoryDossierCase dossier = StoryDossierCatalog.Get(LocationNumber);
            if (location.Chapter != 4 || dossier.Choices.Count != 4 ||
                location.HintTiers.Count != MaximumHintStage ||
                dossier.EvidenceFragments.Count != 2 ||
                !dossier.IsCorrect(2) || !string.Equals(dossier.Choices[2], "A-B-C-D", StringComparison.Ordinal))
            {
                error = "Chapter Four authored dossier and meridian constraints disagree.";
                return false;
            }
            int solutionCount = 0;
            char[] trial = new char[RingCount];
            for (int a = 0; a < RingCount; a++)
            for (int b = 0; b < RingCount; b++)
            for (int c = 0; c < RingCount; c++)
            for (int d = 0; d < RingCount; d++)
            {
                trial[0] = (char)('A' + a);
                trial[1] = (char)('A' + b);
                trial[2] = (char)('A' + c);
                trial[3] = (char)('A' + d);
                if (!SatisfiesClues(trial)) continue;
                solutionCount++;
                if (trial[0] != 'A' || trial[1] != 'B' ||
                    trial[2] != 'C' || trial[3] != 'D')
                {
                    error = "Chapter Four constraints accept an unexpected ring order.";
                    return false;
                }
            }
            if (solutionCount != 1 || SatisfiesClues(InitialOrder))
            {
                error = "Meridian ring constraints are not uniquely solvable from the start.";
                return false;
            }
            error = null;
            return true;
        }
    }
}
