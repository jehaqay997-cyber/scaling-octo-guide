using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public enum BalusterSymbol
    {
        Missing = -1,
        Circle = 0,
        Diamond = 1,
        Star = 2,
        Crescent = 3
    }

    public enum BalusterSelection
    {
        Invalid = 0,
        EvidenceRequired = 1,
        Incorrect = 2,
        Verified = 3,
        AlreadyVerified = 4
    }

    /// <summary>
    /// A transient evidence-gated cycle puzzle for Chapter One's second location.
    /// Progress is never saved by this mechanism and cannot award dossier evidence.
    /// </summary>
    public sealed class SpiralBalusterPuzzle
    {
        public const int LocationNumber = 2;
        public const int CycleLength = 3;
        public const int MissingIndex = 5;

        private static readonly IReadOnlyList<BalusterSymbol> Sequence = Array.AsReadOnly(
            new[] { BalusterSymbol.Circle, BalusterSymbol.Diamond, BalusterSymbol.Star,
                BalusterSymbol.Circle, BalusterSymbol.Diamond, BalusterSymbol.Missing });

        private bool verified;
        private int attempts;

        public static IReadOnlyList<BalusterSymbol> VisibleSequence => Sequence;
        public static BalusterSymbol RequiredSymbol => Sequence[MissingIndex % CycleLength];
        public bool IsVerified => verified;
        public int Attempts => attempts;

        public BalusterSelection Select(BalusterSymbol symbol, bool evidenceA, bool evidenceB)
        {
            if (symbol != BalusterSymbol.Circle && symbol != BalusterSymbol.Diamond &&
                symbol != BalusterSymbol.Star && symbol != BalusterSymbol.Crescent)
                return BalusterSelection.Invalid;
            if (!evidenceA || !evidenceB) return BalusterSelection.EvidenceRequired;
            if (verified) return BalusterSelection.AlreadyVerified;
            if (attempts < int.MaxValue) attempts++;
            if (symbol != RequiredSymbol) return BalusterSelection.Incorrect;
            verified = true;
            return BalusterSelection.Verified;
        }

        public void Reset()
        {
            verified = false;
            attempts = 0;
        }

        public static bool ValidatePattern()
        {
            if (Sequence.Count != MissingIndex + 1 || CycleLength <= 0 ||
                MissingIndex < CycleLength || Sequence[MissingIndex] != BalusterSymbol.Missing)
                return false;
            for (int index = 0; index < MissingIndex; index++)
                if (Sequence[index] != Sequence[index % CycleLength]) return false;
            return RequiredSymbol == BalusterSymbol.Star;
        }
    }
}
