using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public enum ChapterThreeSelection
    {
        Invalid = 0,
        EvidenceRequired = 1,
        Incorrect = 2,
        Verified = 3,
        AlreadyVerified = 4
    }

    /// <summary>
    /// A transient, evidence-gated 3D mechanism for locations 7 through 9.
    /// Authoritative answers remain in StoryDossierCatalog. No save state or
    /// campaign progression can be committed through this mechanism.
    /// </summary>
    public sealed class ChapterThreeMechanismPuzzle
    {
        public const int FirstLocation = 7;
        public const int LastLocation = 9;
        public const int MaximumHintStage = 3;
        private bool verified;
        private int attempts;
        private int hintStage;
        private int lastChoice = -1;

        public int LocationNumber { get; }
        public bool IsVerified => verified;
        public int Attempts => attempts;
        public int HintStage => hintStage;
        public int LastChoice => lastChoice;
        public StoryDossierCase Case => StoryDossierCatalog.Get(LocationNumber);
        public IReadOnlyList<string> Hints => ChapterStoryGraph.GetLocation(LocationNumber).HintTiers;

        public ChapterThreeMechanismPuzzle(int locationNumber)
        {
            if (locationNumber < FirstLocation || locationNumber > LastLocation ||
                ChapterStoryGraph.GetLocation(locationNumber).Chapter != 3)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            LocationNumber = locationNumber;
        }

        public ChapterThreeSelection Select(int choiceIndex, bool evidenceA, bool evidenceB)
        {
            if (choiceIndex < 0 || choiceIndex >= Case.Choices.Count)
                return ChapterThreeSelection.Invalid;
            if (!evidenceA || !evidenceB)
                return ChapterThreeSelection.EvidenceRequired;
            if (verified) return ChapterThreeSelection.AlreadyVerified;
            if (attempts < int.MaxValue) attempts++;
            lastChoice = choiceIndex;
            if (!Case.IsCorrect(choiceIndex)) return ChapterThreeSelection.Incorrect;
            verified = true;
            return ChapterThreeSelection.Verified;
        }

        public bool TryRevealHint(bool evidenceA, bool evidenceB)
        {
            if (!evidenceA || !evidenceB || verified || hintStage >= MaximumHintStage)
                return false;
            hintStage++;
            return true;
        }

        public void Reset()
        {
            verified = false;
            attempts = 0;
            hintStage = 0;
            lastChoice = -1;
        }

        public static bool Validate(out string error)
        {
            for (int number = FirstLocation; number <= LastLocation; number++)
            {
                StoryLocation location = ChapterStoryGraph.GetLocation(number);
                StoryDossierCase dossier = StoryDossierCatalog.Get(number);
                if (location.Chapter != 3 || dossier.Choices.Count != 4 ||
                    location.HintTiers.Count != MaximumHintStage ||
                    dossier.EvidenceFragments.Count != 2 ||
                    !ChapterThreeVisualCatalog.TryGet(number, out ChapterThreeVisualSpec visual) ||
                    string.IsNullOrWhiteSpace(visual.LockedMark) ||
                    string.Equals(visual.LockedMark, visual.UnsolvedMark, StringComparison.Ordinal) ||
                    string.IsNullOrWhiteSpace(visual.UnsolvedMark) ||
                    string.IsNullOrWhiteSpace(visual.SolvedMark))
                {
                    error = "Chapter Three location contract mismatch: " + number;
                    return false;
                }
                int correctCount = 0;
                for (int choice = 0; choice < dossier.Choices.Count; choice++)
                    if (dossier.IsCorrect(choice)) correctCount++;
                if (correctCount != 1)
                {
                    error = "Chapter Three case has no unique solution: " + number;
                    return false;
                }
            }
            error = null;
            return true;
        }
    }

    public sealed class ChapterThreeVisualSpec
    {
        public int LocationNumber { get; }
        public string MechanismTitle { get; }
        public string LockedMark { get; }
        public string UnsolvedMark { get; }
        public string SolvedMark { get; }
        public string Inscription { get; }

        internal ChapterThreeVisualSpec(int location, string title, string locked,
            string unsolved, string solved, string inscription)
        {
            LocationNumber = location;
            MechanismTitle = title;
            LockedMark = locked;
            UnsolvedMark = unsolved;
            SolvedMark = solved;
            Inscription = inscription;
        }

        // Reveal clue-specific text only after both independent fragments are inspected.
        // Even a corrupted solved flag cannot disclose the answer prematurely.
        public string GetVisibleMark(bool inspectedA, bool inspectedB, bool verified)
        {
            if (!inspectedA || !inspectedB) return LockedMark;
            return verified ? SolvedMark : UnsolvedMark;
        }
    }

    /// <summary>
    /// Art metadata only: revealed solutions are never shown before verification.
    /// Coordinates and geometry remain owned by the 3D presentation layer.
    /// </summary>
    public static class ChapterThreeVisualCatalog
    {
        private static readonly ChapterThreeVisualSpec[] Specs =
        {
            new ChapterThreeVisualSpec(7, "THE GLASS TESTAMENT",
                "GLASS / MIRROR  |  INSPECT BOTH FRAGMENTS",
                "TOP: TRIANGLE / RING / THREE RAYS  |  MIRROR: ?",
                "MIRROR: THREE RAYS / RING / TRIANGLE",
                "TWO TESTIMONIES ARE HELD IN GLASS"),
            new ChapterThreeVisualSpec(8, "THE HALL OF FALSE LIGHT",
                "MEMORIAL / PORTRAIT  |  INSPECT BOTH RECORDS",
                "MEMORIAL: 1904  |  LIVE PORTRAIT: 1912  |  TRUTH: ?",
                "A LIVE SITTING IN 1912 IS IMPOSSIBLE",
                "COMPARE THE DEATH RECORD WITH THE SIGNED SITTING"),
            new ChapterThreeVisualSpec(9, "THE WEEPING WITNESS",
                "DAMAGED EPITAPH  |  INSPECT BOTH RECORDS",
                "R _ M E M B E R  |  MISSING GLYPH: ?",
                "R E M E M B E R  |  RESTORED",
                "CROSS-CHECK THE EPITAPH WITH THE PRESERVED LETTER")
        };

        public static bool TryGet(int location, out ChapterThreeVisualSpec spec)
        {
            spec = location >= ChapterThreeMechanismPuzzle.FirstLocation &&
                location <= ChapterThreeMechanismPuzzle.LastLocation ?
                Specs[location - ChapterThreeMechanismPuzzle.FirstLocation] : null;
            return spec != null && spec.LocationNumber == location;
        }

        public static ChapterThreeVisualSpec Get(int location)
        {
            if (!TryGet(location, out ChapterThreeVisualSpec result))
                throw new ArgumentOutOfRangeException(nameof(location));
            return result;
        }
    }
}
