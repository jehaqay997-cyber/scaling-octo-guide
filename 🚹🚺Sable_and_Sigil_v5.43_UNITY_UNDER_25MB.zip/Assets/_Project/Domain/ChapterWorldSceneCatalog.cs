using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public enum ChapterWorldSetType
    {
        Threshold = 1,
        Staircase = 2,
        LanternPath = 3,
        RosePavilion = 4,
        Fountain = 5,
        SilentCrossing = 6,
        GlassTestament = 7,
        PortraitGallery = 8,
        WitnessStatue = 9,
        MeridianRotunda = 10
    }

    /// <summary>
    /// Immutable authored contract for a bounded, procedural 3D investigation prototype.
    /// It does not grant progress or indicate that a production chapter scene has been accepted.
    /// </summary>
    public sealed class ChapterWorldSceneSpec
    {
        public int LocationNumber { get; }
        public int ChapterNumber => ChapterStoryGraph.GetLocation(LocationNumber).Chapter;
        public string Title => ChapterStoryGraph.GetLocation(LocationNumber).Title;
        public string ArtResource => ChapterStoryGraph.GetLocation(LocationNumber).ArtResource;
        public ChapterWorldSetType SetType { get; }
        public string EvidenceALabel { get; }
        public string EvidenceBLabel { get; }

        internal ChapterWorldSceneSpec(int locationNumber, ChapterWorldSetType setType,
            string evidenceALabel, string evidenceBLabel)
        {
            LocationNumber = locationNumber;
            SetType = setType;
            EvidenceALabel = evidenceALabel;
            EvidenceBLabel = evidenceBLabel;
        }
    }

    public static class ChapterWorldSceneCatalog
    {
        public const int PrototypeCount = 10;
        private static readonly ChapterWorldSceneSpec[] Specs =
        {
            new ChapterWorldSceneSpec(1, ChapterWorldSetType.Threshold, "Lady Vey's Letter", "Altered Arch Crest"),
            new ChapterWorldSceneSpec(2, ChapterWorldSetType.Staircase, "Repeated Stair Motif", "Missing Baluster"),
            new ChapterWorldSceneSpec(3, ChapterWorldSetType.LanternPath, "Lunar Calendar", "Lantern Calibration"),
            new ChapterWorldSceneSpec(4, ChapterWorldSetType.RosePavilion, "Basin Petal Counts", "Additive Inscription"),
            new ChapterWorldSceneSpec(5, ChapterWorldSetType.Fountain, "Spout Numbers", "Gardener's Order"),
            new ChapterWorldSceneSpec(6, ChapterWorldSetType.SilentCrossing, "Statue Directions", "Boat Inscription"),
            new ChapterWorldSceneSpec(7, ChapterWorldSetType.GlassTestament, "Vertical Window Symbols", "Mirror Reversal"),
            new ChapterWorldSceneSpec(8, ChapterWorldSetType.PortraitGallery, "Family Memorial", "Signed Portrait"),
            new ChapterWorldSceneSpec(9, ChapterWorldSetType.WitnessStatue, "Damaged Epitaph", "Preserved Letter"),
            new ChapterWorldSceneSpec(10, ChapterWorldSetType.MeridianRotunda, "Meridian Ring Order", "Archive Constraints")
        };
        private static readonly IReadOnlyList<ChapterWorldSceneSpec> ReadOnlySpecs = Array.AsReadOnly(Specs);

        public static IReadOnlyList<ChapterWorldSceneSpec> All => ReadOnlySpecs;

        public static ChapterWorldSceneSpec Get(int locationNumber)
        {
            if (locationNumber < 1 || locationNumber > PrototypeCount)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            return Specs[locationNumber - 1];
        }

        public static bool Validate(out string error)
        {
            if (!StoryDossierCatalog.Validate(out error)) return false;
            if (Specs.Length != PrototypeCount || PrototypeCount != ChapterStoryGraph.LocationCount)
            {
                error = "3D prototype count does not match authored location graph.";
                return false;
            }
            var types = new HashSet<ChapterWorldSetType>();
            var chapters = new HashSet<int>();
            for (int index = 0; index < Specs.Length; index++)
            {
                ChapterWorldSceneSpec spec = Specs[index];
                StoryLocation location = ChapterStoryGraph.GetLocation(index + 1);
                StoryDossierCase dossier = StoryDossierCatalog.Get(index + 1);
                if (spec.LocationNumber != index + 1 || !Enum.IsDefined(typeof(ChapterWorldSetType), spec.SetType) ||
                    !types.Add(spec.SetType) || string.IsNullOrWhiteSpace(spec.EvidenceALabel) ||
                    string.IsNullOrWhiteSpace(spec.EvidenceBLabel) ||
                    string.Equals(spec.EvidenceALabel, spec.EvidenceBLabel, StringComparison.OrdinalIgnoreCase) ||
                    dossier.EvidenceFragments.Count != 2 || !string.Equals(spec.ArtResource, location.ArtResource, StringComparison.Ordinal) ||
                    spec.ChapterNumber != location.Chapter)
                {
                    error = "Invalid or divergent 3D scene spec at location " + (index + 1);
                    return false;
                }
                chapters.Add(spec.ChapterNumber);
            }
            if (chapters.Count != ChapterStoryGraph.ChapterCount)
            {
                error = "One or more chapters have no 3D scene prototype.";
                return false;
            }
            error = null;
            return true;
        }
    }
}
