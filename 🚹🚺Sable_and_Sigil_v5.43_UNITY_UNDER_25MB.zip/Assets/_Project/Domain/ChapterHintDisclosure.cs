using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Pure disclosure policy. A chapter hint is not visible until the player explicitly
    /// reveals it and the authoritative progression allows the location to be investigated.
    /// No hint operation can mutate an evidence ledger, solve a puzzle, or grant progress.
    /// </summary>
    public static class ChapterHintDisclosure
    {
        public const int MaximumTier = 3;

        public static int RevealNext(int revealedTier, bool canInvestigate)
        {
            ValidateTier(revealedTier);
            return canInvestigate && revealedTier < MaximumTier ? revealedTier + 1 : revealedTier;
        }

        public static bool CanRevealNext(int revealedTier, bool canInvestigate)
        {
            ValidateTier(revealedTier);
            return canInvestigate && revealedTier < MaximumTier;
        }

        public static bool TryGetVisibleHint(StoryLocation location, int revealedTier,
            bool canInvestigate, out string hint)
        {
            if (location == null) throw new ArgumentNullException(nameof(location));
            ValidateTier(revealedTier);
            hint = null;
            if (!canInvestigate || revealedTier == 0 ||
                location.HintTiers.Count != MaximumTier) return false;
            string candidate = location.HintTiers[revealedTier - 1];
            if (string.IsNullOrWhiteSpace(candidate)) return false;
            hint = candidate;
            return true;
        }

        private static void ValidateTier(int revealedTier)
        {
            if (revealedTier < 0 || revealedTier > MaximumTier)
                throw new ArgumentOutOfRangeException(nameof(revealedTier));
        }
    }
}
