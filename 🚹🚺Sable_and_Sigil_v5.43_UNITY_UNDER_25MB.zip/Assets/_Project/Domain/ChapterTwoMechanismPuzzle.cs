using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public enum ChapterTwoSelection
    {
        Invalid = 0,
        EvidenceRequired = 1,
        Incorrect = 2,
        Verified = 3,
        AlreadyVerified = 4
    }

    /// <summary>
    /// A transient, evidence-gated 3D mechanism for locations 3 through 6.
    /// Authoritative answers remain in StoryDossierCatalog. No save state or
    /// campaign progression can be committed through this mechanism.
    /// </summary>
    public sealed class ChapterTwoMechanismPuzzle
    {
        public const int FirstLocation = 3;
        public const int LastLocation = 6;
        public const int MaximumHintStage = 3;
        private bool verified;
        private int attempts;
        private int hintStage;
        private int lastChoice = -1;

        public int LocationNumber { get; }
        public bool IsVerified => verified;
        public int Attempts => attempts;
        public int HintStage => hintStage;
        public int LastChoice => lastChoice;
        public StoryDossierCase Case => StoryDossierCatalog.Get(LocationNumber);
        public IReadOnlyList<string> Hints => ChapterStoryGraph.GetLocation(LocationNumber).HintTiers;

        public ChapterTwoMechanismPuzzle(int locationNumber)
        {
            if (locationNumber < FirstLocation || locationNumber > LastLocation ||
                ChapterStoryGraph.GetLocation(locationNumber).Chapter != 2)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            LocationNumber = locationNumber;
        }

        public ChapterTwoSelection Select(int choiceIndex, bool evidenceA, bool evidenceB)
        {
            if (choiceIndex < 0 || choiceIndex >= Case.Choices.Count)
                return ChapterTwoSelection.Invalid;
            if (!evidenceA || !evidenceB)
                return ChapterTwoSelection.EvidenceRequired;
            if (verified) return ChapterTwoSelection.AlreadyVerified;
            if (attempts < int.MaxValue) attempts++;
            lastChoice = choiceIndex;
            if (!Case.IsCorrect(choiceIndex)) return ChapterTwoSelection.Incorrect;
            verified = true;
            return ChapterTwoSelection.Verified;
        }

        public bool TryRevealHint(bool evidenceA, bool evidenceB)
        {
            if (!evidenceA || !evidenceB || verified || hintStage >= MaximumHintStage)
                return false;
            hintStage++;
            return true;
        }

        public void Reset()
        {
            verified = false;
            attempts = 0;
            hintStage = 0;
            lastChoice = -1;
        }

        public static bool Validate(out string error)
        {
            for (int number = FirstLocation; number <= LastLocation; number++)
            {
                StoryLocation location = ChapterStoryGraph.GetLocation(number);
                StoryDossierCase dossier = StoryDossierCatalog.Get(number);
                if (location.Chapter != 2 || dossier.Choices.Count != 4 ||
                    location.HintTiers.Count != MaximumHintStage ||
                    dossier.EvidenceFragments.Count != 2 ||
                    !ChapterTwoVisualCatalog.TryGet(number, out ChapterTwoVisualSpec visual) ||
                    string.IsNullOrWhiteSpace(visual.UnsolvedMark) ||
                    string.IsNullOrWhiteSpace(visual.SolvedMark))
                {
                    error = "Chapter Two location contract mismatch: " + number;
                    return false;
                }
                int correctCount = 0;
                for (int choice = 0; choice < dossier.Choices.Count; choice++)
                    if (dossier.IsCorrect(choice)) correctCount++;
                if (correctCount != 1)
                {
                    error = "Chapter Two case has no unique solution: " + number;
                    return false;
                }
            }
            error = null;
            return true;
        }
    }

    public sealed class ChapterTwoVisualSpec
    {
        public int LocationNumber { get; }
        public string MechanismTitle { get; }
        public string UnsolvedMark { get; }
        public string SolvedMark { get; }
        public string Inscription { get; }

        internal ChapterTwoVisualSpec(int location, string title, string unsolved,
            string solved, string inscription)
        {
            LocationNumber = location;
            MechanismTitle = title;
            UnsolvedMark = unsolved;
            SolvedMark = solved;
            Inscription = inscription;
        }
    }

    /// <summary>
    /// Art metadata only: revealed solutions are never shown before verification.
    /// Coordinates and geometry remain owned by the 3D presentation layer.
    /// </summary>
    public static class ChapterTwoVisualCatalog
    {
        private static readonly ChapterTwoVisualSpec[] Specs =
        {
            new ChapterTwoVisualSpec(3, "LUNAR CALIBRATION", "NEW / WAXING / ? / WANING",
                "FULL MOON - SECOND PHASE AFTER NEW", "FOUR PHASES / TWO STEPS AFTER NEW"),
            new ChapterTwoVisualSpec(4, "ROSE BASIN", "2  +  3  +  5  +  8  =  ?",
                "2  /  3  /  5  /  8  /  13", "EACH COUNT ADDS THE PREVIOUS TWO"),
            new ChapterTwoVisualSpec(5, "FOUNTAIN CHIMES", "1  >  ?  >  ?  >  4",
                "1  >  3  >  2  >  4", "3 FOLLOWS 1 / 4 ENDS THE SEQUENCE"),
            new ChapterTwoVisualSpec(6, "SILENT CROSSING", "A: E  /  B: S  /  C: W  /  ROUTE: ?",
                "B  >  A  >  C  =  S  >  E  >  W", "FOLLOW THE WITNESSES B / A / C")
        };

        public static bool TryGet(int location, out ChapterTwoVisualSpec spec)
        {
            spec = location >= ChapterTwoMechanismPuzzle.FirstLocation &&
                location <= ChapterTwoMechanismPuzzle.LastLocation ?
                Specs[location - ChapterTwoMechanismPuzzle.FirstLocation] : null;
            return spec != null && spec.LocationNumber == location;
        }

        public static ChapterTwoVisualSpec Get(int location)
        {
            if (!TryGet(location, out ChapterTwoVisualSpec result))
                throw new ArgumentOutOfRangeException(nameof(location));
            return result;
        }
    }
}
