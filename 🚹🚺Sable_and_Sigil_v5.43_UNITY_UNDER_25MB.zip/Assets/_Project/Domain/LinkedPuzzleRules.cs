using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public sealed class LinkedPairRule : PuzzleRule
    {
        public string First { get; }
        public string Second { get; }
        public LinkedPairRule(string first, string second)
        {
            First = Identifier(first); Second = Identifier(second);
            if (First == Second) throw new ArgumentException("Linked items must be distinct.");
        }
        public override string Description => First + " and " + Second + " must share a drawer when both are placed.";
        public override void ValidateDefinition(IReadOnlyDictionary<string, Item> items, IReadOnlyDictionary<string, Compartment> bins)
        {
            if (!items.ContainsKey(First) || !items.ContainsKey(Second)) throw new ArgumentException("Unknown linked item.");
            if (items[First].Tag != items[Second].Tag) throw new ArgumentException("Linked items require compatible tags.");
        }
        public override bool Accepts(IReadOnlyDictionary<string, string> positions, IReadOnlyDictionary<string, Item> items, bool completion, out string error)
        {
            bool accepted = positions[First] == OrderBoard.Tray || positions[Second] == OrderBoard.Tray || positions[First] == positions[Second];
            error = accepted ? null : Description;
            return accepted;
        }
    }

    public sealed class DestinationKeyRule : PuzzleRule
    {
        public string Dependent { get; }
        public string Key { get; }
        public string KeyBin { get; }
        public DestinationKeyRule(string dependent, string key, string keyBin)
        {
            Dependent = Identifier(dependent); Key = Identifier(key); KeyBin = Identifier(keyBin);
            if (Dependent == Key) throw new ArgumentException("A key cannot depend on itself.");
        }
        public override string Description => "Place " + Key + " in " + KeyBin + " to unlock " + Dependent + "; return the dependent to the tray before moving its key.";
        public override void ValidateDefinition(IReadOnlyDictionary<string, Item> items, IReadOnlyDictionary<string, Compartment> bins)
        {
            if (!items.ContainsKey(Dependent) || !items.ContainsKey(Key) || !bins.ContainsKey(KeyBin))
                throw new ArgumentException("Unknown destination key reference.");
            if (items[Key].Tag != bins[KeyBin].Tag || items[Key].Weight > bins[KeyBin].MaxWeight)
                throw new ArgumentException("The key cannot enter its required drawer.");
        }
        public override bool Accepts(IReadOnlyDictionary<string, string> positions, IReadOnlyDictionary<string, Item> items, bool completion, out string error)
        {
            bool accepted = positions[Dependent] == OrderBoard.Tray || positions[Key] == KeyBin;
            error = accepted ? null : Description;
            return accepted;
        }
    }
}
