using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    /// <summary>Visual silhouettes are display-only; neither identity nor puzzle correctness depends on them.</summary>
    public enum ChapterEvidenceSilhouette
    {
        Scroll = 1,
        StarCrest = 2,
        PatternTile = 3,
        Baluster = 4,
        LunarDial = 5,
        Lantern = 6,
        FloralRelief = 7,
        Tablet = 8,
        FountainSpout = 9,
        DirectionCompass = 10,
        Boat = 11,
        StainedGlass = 12,
        Mirror = 13,
        Memorial = 14,
        Portrait = 15,
        Epitaph = 16,
        MeridianRings = 17
    }

    /// <summary>Read-only evidence presentation contract for a single location and fragment.</summary>
    public sealed class ChapterEvidenceVisualSpec
    {
        public int LocationNumber { get; }
        public int EvidenceIndex { get; }
        public ChapterEvidenceSilhouette Silhouette { get; }
        public int MotifCount { get; }
        public string Label { get; }

        internal ChapterEvidenceVisualSpec(int locationNumber, int evidenceIndex,
            ChapterEvidenceSilhouette silhouette, int motifCount, string label)
        {
            LocationNumber = locationNumber;
            EvidenceIndex = evidenceIndex;
            Silhouette = silhouette;
            MotifCount = motifCount;
            Label = label;
        }
    }

    /// <summary>
    /// Maps all twenty authored case fragments to bounded physical relic representations.
    /// This catalog must not be used as a solver, hint source or persistence authority.
    /// </summary>
    public static class ChapterEvidenceVisualCatalog
    {
        private static readonly ChapterEvidenceVisualSpec[,] Specs =
        {
            { New(1, 0, ChapterEvidenceSilhouette.Scroll, 5, "Lady Vey's Letter"), New(1, 1, ChapterEvidenceSilhouette.StarCrest, 6, "Altered Arch Crest") },
            { New(2, 0, ChapterEvidenceSilhouette.PatternTile, 3, "Repeated Stair Motif"), New(2, 1, ChapterEvidenceSilhouette.Baluster, 2, "Missing Baluster") },
            { New(3, 0, ChapterEvidenceSilhouette.LunarDial, 4, "Lunar Calendar"), New(3, 1, ChapterEvidenceSilhouette.Lantern, 2, "Lantern Calibration") },
            { New(4, 0, ChapterEvidenceSilhouette.FloralRelief, 8, "Basin Petal Counts"), New(4, 1, ChapterEvidenceSilhouette.Tablet, 2, "Additive Inscription") },
            { New(5, 0, ChapterEvidenceSilhouette.FountainSpout, 4, "Spout Numbers"), New(5, 1, ChapterEvidenceSilhouette.Tablet, 4, "Gardener's Order") },
            { New(6, 0, ChapterEvidenceSilhouette.DirectionCompass, 3, "Statue Directions"), New(6, 1, ChapterEvidenceSilhouette.Boat, 3, "Boat Inscription") },
            { New(7, 0, ChapterEvidenceSilhouette.StainedGlass, 3, "Vertical Window Symbols"), New(7, 1, ChapterEvidenceSilhouette.Mirror, 3, "Mirror Reversal") },
            { New(8, 0, ChapterEvidenceSilhouette.Memorial, 2, "Family Memorial"), New(8, 1, ChapterEvidenceSilhouette.Portrait, 2, "Signed Portrait") },
            { New(9, 0, ChapterEvidenceSilhouette.Epitaph, 8, "Damaged Epitaph"), New(9, 1, ChapterEvidenceSilhouette.Scroll, 8, "Preserved Letter") },
            { New(10, 0, ChapterEvidenceSilhouette.MeridianRings, 4, "Meridian Ring Order"), New(10, 1, ChapterEvidenceSilhouette.Tablet, 3, "Archive Constraints") }
        };

        private static ChapterEvidenceVisualSpec New(int location, int index,
            ChapterEvidenceSilhouette silhouette, int motifs, string label)
        {
            return new ChapterEvidenceVisualSpec(location, index, silhouette, motifs, label);
        }

        public const int EvidencePerLocation = 2;
        public const int TotalEvidence = ChapterWorldSceneCatalog.PrototypeCount * EvidencePerLocation;

        public static ChapterEvidenceVisualSpec Get(int locationNumber, int evidenceIndex)
        {
            if (locationNumber < 1 || locationNumber > ChapterWorldSceneCatalog.PrototypeCount)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            if (evidenceIndex < 0 || evidenceIndex >= EvidencePerLocation)
                throw new ArgumentOutOfRangeException(nameof(evidenceIndex));
            return Specs[locationNumber - 1, evidenceIndex];
        }

        public static bool Validate(out string error)
        {
            error = null;
            if (Specs.GetLength(0) != ChapterWorldSceneCatalog.PrototypeCount ||
                Specs.GetLength(1) != EvidencePerLocation)
            {
                error = "Evidence visualization inventory does not match chapter locations.";
                return false;
            }
            for (int location = 1; location <= ChapterWorldSceneCatalog.PrototypeCount; location++)
            {
                ChapterWorldSceneSpec world = ChapterWorldSceneCatalog.Get(location);
                StoryDossierCase dossier = StoryDossierCatalog.Get(location);
                if (dossier.EvidenceFragments.Count != EvidencePerLocation)
                {
                    error = "An evidence visualization requires exactly two authored fragments.";
                    return false;
                }
                var silhouettes = new HashSet<ChapterEvidenceSilhouette>();
                for (int index = 0; index < EvidencePerLocation; index++)
                {
                    ChapterEvidenceVisualSpec spec = Get(location, index);
                    string expected = index == 0 ? world.EvidenceALabel : world.EvidenceBLabel;
                    if (spec.LocationNumber != location || spec.EvidenceIndex != index ||
                        !Enum.IsDefined(typeof(ChapterEvidenceSilhouette), spec.Silhouette) ||
                        !silhouettes.Add(spec.Silhouette) ||
                        spec.MotifCount < 1 || spec.MotifCount > 8 ||
                        !string.Equals(spec.Label, expected, StringComparison.Ordinal))
                    {
                        error = "Unmatched evidence visual specification for location " + location;
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
