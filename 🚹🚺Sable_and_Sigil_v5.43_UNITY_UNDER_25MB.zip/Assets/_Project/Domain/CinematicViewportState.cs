using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Finite, deterministic viewport state for all panoramic investigations.
    /// Both the photograph and evidence hotspots share this transform.
    /// No Unity dependency, persistent storage or puzzle-state mutation.
    /// </summary>
    public sealed class CinematicViewportState
    {
        public const float MinimumZoom = 1f;
        public const float MaximumZoom = 1.4f;
        public const float ReferenceWidth = CinematicSceneMap.CanvasWidth;
        public const float ReferenceHeight = CinematicSceneMap.CanvasHeight;
        private float zoom = MinimumZoom;
        private float panX;
        private float panY;

        public float Zoom => zoom;
        public float PanX => panX;
        public float PanY => panY;

        public void Reset()
        {
            zoom = MinimumZoom;
            panX = 0f;
            panY = 0f;
        }

        public bool TryZoom(float delta)
        {
            if (!Finite(delta)) return false;
            float next = Clamp(zoom + delta, MinimumZoom, MaximumZoom);
            if (next == zoom) return false;
            zoom = next;
            ClampPan();
            return true;
        }

        public bool TryPan(float deltaX, float deltaY)
        {
            if (!Finite(deltaX) || !Finite(deltaY)) return false;
            float priorX = panX;
            float priorY = panY;
            panX += deltaX;
            panY += deltaY;
            ClampPan();
            return panX != priorX || panY != priorY;
        }

        private void ClampPan()
        {
            float boundX = ReferenceWidth * (zoom - MinimumZoom) * .5f;
            float boundY = ReferenceHeight * (zoom - MinimumZoom) * .5f;
            panX = Clamp(panX, -boundX, boundX);
            panY = Clamp(panY, -boundY, boundY);
        }

        private static bool Finite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private static float Clamp(float value, float minimum, float maximum)
        {
            return value < minimum ? minimum : value > maximum ? maximum : value;
        }
    }
}
