using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Deterministic, Unity-independent state machine for the first adventure chapter.
    /// Every action is monotonic, checked against prerequisites, and safe to repeat.
    /// </summary>
    public sealed class ChapterOneProgress
    {
        public const int KeyFlag = 1;
        public const int LetterFlag = 2;
        public const int LensFlag = 4;
        public const int CipherFlag = 8;
        public const int PassageFlag = 16;
        public const int ObservatoryFlag = 32;
        public const int AllFlags = KeyFlag | LetterFlag | LensFlag | CipherFlag | PassageFlag | ObservatoryFlag;
        public const int CipherSolution = 314;

        public int Flags { get; private set; }
        public int DialValue { get; private set; }
        public bool HasKey => (Flags & KeyFlag) != 0;
        public bool HasLetter => (Flags & LetterFlag) != 0;
        public bool HasLens => (Flags & LensFlag) != 0;
        public bool KnowsCipher => (Flags & CipherFlag) != 0;
        public bool PassageOpen => (Flags & PassageFlag) != 0;
        public bool ObservatoryUnlocked => (Flags & ObservatoryFlag) != 0;

        public bool SearchShelf() => Grant(KeyFlag);
        public bool UnlockWritingDesk() => HasKey && Grant(LetterFlag);
        public bool SearchPortrait() => HasLetter && Grant(LensFlag);
        public bool DecodeLens(int rotationQuarterTurns, int focusLevel)
            => HasLens && (rotationQuarterTurns % 4 == 2 || rotationQuarterTurns % 4 == -2) && focusLevel >= 2 && Grant(CipherFlag);
        public bool OpenSecretPanel() => KnowsCipher && DialValue == CipherSolution && Grant(PassageFlag);
        public bool EnterObservatory() => PassageOpen && Grant(ObservatoryFlag);

        public bool SetDigit(int index, int digit)
        {
            if (!KnowsCipher || PassageOpen || index < 0 || index > 2 || digit < 0 || digit > 9) return false;
            var place = index == 0 ? 100 : index == 1 ? 10 : 1;
            int currentDigit = DialValue / place % 10;
            if (currentDigit == digit) return false;
            DialValue = DialValue - currentDigit * place + digit * place;
            return true;
        }

        public bool Restore(int flags, int dial)
        {
            if (!IsValid(flags, dial)) return false;
            Flags = flags;
            DialValue = dial;
            return true;
        }

        public void Restart()
        {
            Flags = 0;
            DialValue = 0;
        }

        public static bool IsValid(int flags, int dial)
        {
            if (flags < 0 || (flags & ~AllFlags) != 0 || dial < 0 || dial > 999) return false;
            if ((flags & LetterFlag) != 0 && (flags & KeyFlag) == 0) return false;
            if ((flags & LensFlag) != 0 && (flags & LetterFlag) == 0) return false;
            if ((flags & CipherFlag) != 0 && (flags & LensFlag) == 0) return false;
            if ((flags & PassageFlag) != 0 && ((flags & CipherFlag) == 0 || dial != CipherSolution)) return false;
            if ((flags & ObservatoryFlag) != 0 && (flags & PassageFlag) == 0) return false;
            if ((flags & CipherFlag) == 0 && dial != 0) return false;
            return true;
        }

        private bool Grant(int flag)
        {
            if ((Flags & flag) != 0) return false;
            Flags |= flag;
            return true;
        }
    }
}
