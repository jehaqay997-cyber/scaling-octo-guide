using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Pure, deterministic and bounded synthesis of an original three-second
    /// ambient texture. Its integer-cycle partials are periodic at loop boundaries.
    /// No recording, downloaded sound, random state or external asset is used.
    /// </summary>
    public static class CinematicAmbientSynthesis
    {
        public const int SampleRate = 22050;
        public const int LoopSeconds = 3;
        public const int SampleCount = SampleRate * LoopSeconds;
        public const float PeakLimit = .201f;
        private static readonly int[] BaseCycles = { 228, 246, 270, 291 };

        public static float[] Create(int chapterNumber)
        {
            if (chapterNumber < 1 || chapterNumber > BaseCycles.Length)
                throw new ArgumentOutOfRangeException(nameof(chapterNumber));

            var samples = new float[SampleCount];
            int cycles = BaseCycles[chapterNumber - 1];
            for (int sample = 0; sample < SampleCount; sample++)
            {
                double theta = 2.0 * Math.PI * sample / SampleCount;
                double baseTone = .50 * Math.Sin(theta * cycles);
                double harmonic = .24 * Math.Sin(theta * (cycles + 3) + .2);
                double overtone = .14 * Math.Sin(theta * (cycles * 2) + .7);
                double air = .12 * Math.Sin(theta * 3);
                samples[sample] = (float)((baseTone + harmonic + overtone + air) * .2);
            }
            return samples;
        }
    }
}
