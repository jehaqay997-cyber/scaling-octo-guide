using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    public enum ThresholdRaySelection
    {
        Invalid = 0,
        EvidenceRequired = 1,
        Incorrect = 2,
        Verified = 3,
        AlreadyVerified = 4
    }

    /// <summary>
    /// Transient mechanical verification for the first investigation's altered crest.
    /// The letter contains five evenly spaced rays; the arch contains an additional
    /// ray inserted between the fourth and fifth originals. This state never persists
    /// or changes the authored dossier's answer authority.
    /// </summary>
    public sealed class ThresholdCrestPuzzle
    {
        private static readonly IReadOnlyList<int> Letter =
            Array.AsReadOnly(new[] { 0, 72, 144, 216, 288 });
        private static readonly IReadOnlyList<int> Seal =
            Array.AsReadOnly(new[] { 0, 72, 144, 216, 252, 288 });
        private const int InsertedRayIndex = 4;
        private bool verified;
        private int attempts;

        public static IReadOnlyList<int> LetterRayAngles => Letter;
        public static IReadOnlyList<int> SealRayAngles => Seal;
        public static int AddedRayIndex => InsertedRayIndex;
        public bool IsVerified => verified;
        public int Attempts => attempts;

        public ThresholdRaySelection Select(int rayIndex, bool evidenceAInspected,
            bool evidenceBInspected)
        {
            if (rayIndex < 0 || rayIndex >= Seal.Count)
                return ThresholdRaySelection.Invalid;
            if (!evidenceAInspected || !evidenceBInspected)
                return ThresholdRaySelection.EvidenceRequired;
            if (verified)
                return ThresholdRaySelection.AlreadyVerified;
            if (attempts < int.MaxValue) attempts++;
            if (rayIndex != InsertedRayIndex)
                return ThresholdRaySelection.Incorrect;
            verified = true;
            return ThresholdRaySelection.Verified;
        }

        public void Reset()
        {
            verified = false;
            attempts = 0;
        }

        public static bool ValidateGeometryContract()
        {
            if (Letter.Count != 5 || Seal.Count != 6 ||
                InsertedRayIndex < 0 || InsertedRayIndex >= Seal.Count)
                return false;
            var original = new HashSet<int>(Letter);
            var seen = new HashSet<int>();
            int extraneous = 0;
            for (int index = 0; index < Seal.Count; index++)
            {
                int angle = Seal[index];
                if (angle < 0 || angle >= 360 || !seen.Add(angle)) return false;
                if (!original.Contains(angle))
                {
                    if (index != InsertedRayIndex) return false;
                    extraneous++;
                }
            }
            return extraneous == 1 && seen.IsSupersetOf(original);
        }
    }
}
