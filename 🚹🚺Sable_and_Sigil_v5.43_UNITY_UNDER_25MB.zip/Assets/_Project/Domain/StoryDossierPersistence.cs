using System;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace TheOrderRoom.Domain
{
    public interface IStoryDossierStorage
    {
        bool Contains(string key);
        string Read(string key);
        void Write(string key, string value);
        void Flush();
    }

    /// <summary>Canonical, bounded save format with a corruption checksum, not an anti-cheat signature.</summary>
    public static class StoryDossierCheckpointCodec
    {
        private const string Prefix = "v1|";
        private const string DigestContext = "SABLE_SIGIL_STORY_DOSSIER_V1|";
        private const int MaximumLength = 512;

        public static string Encode(long revision, int[] resolved)
        {
            if (revision < 0 || resolved == null || !ValidateEvidence(revision, resolved))
                throw new ArgumentException("Invalid story dossier snapshot.");
            var joined = new StringBuilder();
            for (int index = 0; index < resolved.Length; index++)
            {
                if (index != 0) joined.Append(',');
                joined.Append(resolved[index].ToString(CultureInfo.InvariantCulture));
            }
            string payload = Prefix + revision.ToString(CultureInfo.InvariantCulture) + "|" + joined;
            string result = payload + "|" + Digest(payload);
            if (result.Length > MaximumLength)
                throw new InvalidOperationException("Story dossier checkpoint exceeds its maximum size.");
            return result;
        }

        public static bool TryDecode(string encoded, out long revision, out int[] resolved)
        {
            revision = 0;
            resolved = Array.Empty<int>();
            if (string.IsNullOrEmpty(encoded) || encoded.Length > MaximumLength ||
                !encoded.StartsWith(Prefix, StringComparison.Ordinal)) return false;
            int delimiter = encoded.LastIndexOf('|');
            if (delimiter <= Prefix.Length || delimiter == encoded.Length - 1) return false;
            string payload = encoded.Substring(0, delimiter);
            string suppliedDigest = encoded.Substring(delimiter + 1);
            if (suppliedDigest.Length != 64 || !DigestEquals(suppliedDigest, Digest(payload))) return false;
            int secondDelimiter = payload.IndexOf('|', Prefix.Length);
            if (secondDelimiter < 0 || payload.IndexOf('|', secondDelimiter + 1) >= 0) return false;
            string revisionText = payload.Substring(Prefix.Length, secondDelimiter - Prefix.Length);
            if (!long.TryParse(revisionText, NumberStyles.None, CultureInfo.InvariantCulture, out long candidateRevision) ||
                candidateRevision.ToString(CultureInfo.InvariantCulture) != revisionText) return false;
            string evidenceText = payload.Substring(secondDelimiter + 1);
            string[] elements = evidenceText.Length == 0 ? Array.Empty<string>() : evidenceText.Split(',');
            if (elements.Length > ChapterStoryGraph.LocationCount) return false;
            var candidate = new int[elements.Length];
            for (int index = 0; index < elements.Length; index++)
            {
                if (!int.TryParse(elements[index], NumberStyles.None, CultureInfo.InvariantCulture, out int parsed) ||
                    parsed.ToString(CultureInfo.InvariantCulture) != elements[index]) return false;
                candidate[index] = parsed;
            }
            if (!ValidateEvidence(candidateRevision, candidate)) return false;
            revision = candidateRevision;
            resolved = candidate;
            return true;
        }

        private static bool ValidateEvidence(long revision, int[] resolved)
        {
            if (revision != resolved.Length || resolved.Length > ChapterStoryGraph.LocationCount) return false;
            int previous = 0;
            var present = new HashSet<int>();
            foreach (int number in resolved)
            {
                if (number <= previous || number > ChapterStoryGraph.LocationCount || !present.Add(number))
                    return false;
                previous = number;
            }
            foreach (int number in resolved)
                foreach (int required in ChapterStoryGraph.GetLocation(number).Prerequisites)
                    if (!present.Contains(required)) return false;
            return true;
        }

        private static string Digest(string payload)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(DigestContext + payload));
                var result = new StringBuilder(64);
                for (int index = 0; index < bytes.Length; index++)
                    result.Append(bytes[index].ToString("x2", CultureInfo.InvariantCulture));
                return result.ToString();
            }
        }

        private static bool DigestEquals(string actual, string expected)
        {
            int difference = 0;
            for (int index = 0; index < expected.Length; index++)
                difference |= actual[index] ^ expected[index];
            return difference == 0;
        }
    }

    /// <summary>Two-slot monotonic repository: never overwrites the last accepted slot.</summary>
    public sealed class StoryDossierRepository
    {
        public const string KeyA = "SableAndSigil.StoryDossier.v1.CheckpointA";
        public const string KeyB = "SableAndSigil.StoryDossier.v1.CheckpointB";
        private static readonly object Synchronization = new object();
        private readonly IStoryDossierStorage storage;

        public StoryDossierRepository(IStoryDossierStorage storage)
        {
            this.storage = storage ?? throw new ArgumentNullException(nameof(storage));
        }

        public bool TryLoad(out StoryEvidenceLedger progress, out string error)
        {
            lock (Synchronization)
                return TryLoadInternal(out progress, out _, out error);
        }

        private bool TryLoadInternal(out StoryEvidenceLedger progress, out int activeSlot, out string error)
        {
            progress = null;
            activeSlot = -1;
            error = null;
            try
            {
                bool existsA = storage.Contains(KeyA);
                bool existsB = storage.Contains(KeyB);
                if (!existsA && !existsB)
                {
                    progress = new StoryEvidenceLedger();
                    return true;
                }
                string checkpointA = existsA ? storage.Read(KeyA) : null;
                string checkpointB = existsB ? storage.Read(KeyB) : null;
                if (IsFutureSchema(checkpointA) || IsFutureSchema(checkpointB))
                {
                    error = "A future story save version was detected; existing slots will not be overwritten.";
                    return false;
                }
                long revisionA = 0, revisionB = 0;
                int[] resolvedA = Array.Empty<int>(), resolvedB = Array.Empty<int>();
                bool validA = existsA && StoryDossierCheckpointCodec.TryDecode(checkpointA, out revisionA, out resolvedA);
                bool validB = existsB && StoryDossierCheckpointCodec.TryDecode(checkpointB, out revisionB, out resolvedB);
                if (!validA && !validB)
                {
                    error = "Both story dossier checkpoints are damaged. Original saves were preserved.";
                    return false;
                }
                if (validA && validB)
                {
                    // Each durable commit alternates slots. Two valid slots separated
                    // by multiple revisions indicate a fork or an externally altered
                    // checkpoint, not ordinary one-step progress.
                    if ((revisionA > revisionB && revisionA - revisionB > 1) ||
                        (revisionB > revisionA && revisionB - revisionA > 1))
                    {
                        error = "Nonconsecutive story checkpoints require manual recovery.";
                        return false;
                    }
                    if (revisionA == revisionB && !Same(resolvedA, resolvedB))
                    {
                        error = "Conflicting story checkpoints at the same revision.";
                        return false;
                    }
                    int[] earlier = revisionA <= revisionB ? resolvedA : resolvedB;
                    int[] later = revisionA <= revisionB ? resolvedB : resolvedA;
                    if (!IsSubset(earlier, later))
                    {
                        error = "Story checkpoint history is not monotonic.";
                        return false;
                    }
                }
                activeSlot = validA && (!validB || revisionA >= revisionB) ? 0 : 1;
                long revision = activeSlot == 0 ? revisionA : revisionB;
                int[] resolved = activeSlot == 0 ? resolvedA : resolvedB;
                var restored = new StoryEvidenceLedger();
                if (!restored.Restore(revision, resolved))
                {
                    error = "Story checkpoint violated the evidence graph.";
                    return false;
                }
                progress = restored;
                return true;
            }
            catch (Exception exception)
            {
                error = "Story checkpoint read failed: " + exception.GetType().Name;
                return false;
            }
        }

        public bool TryStore(StoryEvidenceLedger previous, StoryEvidenceLedger next, out string error)
        {
            lock (Synchronization)
                return TryStoreInternal(previous, next, out error);
        }

        private bool TryStoreInternal(StoryEvidenceLedger previous, StoryEvidenceLedger next, out string error)
        {
            error = null;
            if (previous == null || next == null)
            {
                error = "A save transaction requires both states.";
                return false;
            }
            if (previous.Revision == long.MaxValue || next.Revision != previous.Revision + 1 ||
                next.Count != previous.Count + 1 || !IsSubset(previous.Snapshot(), next.Snapshot()))
            {
                error = "Invalid monotonic story transaction.";
                return false;
            }
            if (!TryLoadInternal(out StoryEvidenceLedger stored, out int slot, out error)) return false;
            if (stored.Revision != previous.Revision || !Same(stored.Snapshot(), previous.Snapshot()))
            {
                error = "Story checkpoint changed externally; stale transaction rejected.";
                return false;
            }
            try
            {
                string checkpoint = StoryDossierCheckpointCodec.Encode(next.Revision, next.Snapshot());
                string destination = slot == 0 ? KeyB : KeyA;
                storage.Write(destination, checkpoint);
                storage.Flush();
                if (!string.Equals(storage.Read(destination), checkpoint, StringComparison.Ordinal))
                {
                    error = "Story checkpoint write could not be verified.";
                    return false;
                }
                return true;
            }
            catch (Exception exception)
            {
                error = "Story checkpoint write failed: " + exception.GetType().Name;
                return false;
            }
        }

        private static bool IsFutureSchema(string checkpoint)
        {
            if (string.IsNullOrEmpty(checkpoint) || checkpoint[0] != 'v') return false;
            int delimiter = checkpoint.IndexOf('|');
            // Preserve any recognizable but unsupported version, including versions
            // whose number is too large to fit in a CLR integer.
            return delimiter > 1 && !string.Equals(
                checkpoint.Substring(0, delimiter), "v1", StringComparison.Ordinal);
        }

        private static bool Same(int[] left, int[] right)
        {
            if (left.Length != right.Length) return false;
            for (int index = 0; index < left.Length; index++)
                if (left[index] != right[index]) return false;
            return true;
        }

        private static bool IsSubset(int[] earlier, int[] later)
        {
            var recent = new HashSet<int>(later);
            foreach (int number in earlier)
                if (!recent.Contains(number)) return false;
            return true;
        }
    }

    /// <summary>Single owner for live investigation state and durable completion commits.</summary>
    public sealed class StoryDossierSession
    {
        private readonly StoryDossierRepository repository;
        private StoryEvidenceLedger progress;
        public bool IsReady { get; private set; }
        public string Error { get; private set; }
        public long Revision => progress == null ? 0 : progress.Revision;
        public int CompletedCount => progress == null ? 0 : progress.Count;
        public bool IsFinaleUnlocked => IsReady && progress != null &&
            StoryFinalePolicy.IsUnlocked(progress.Revision, progress.Snapshot());

        public StoryDossierSession(IStoryDossierStorage storage)
        {
            repository = new StoryDossierRepository(storage);
            IsReady = repository.TryLoad(out progress, out string error);
            Error = error;
        }

        /// <summary>Reconcile with storage after a pause, failed flush or external update.</summary>
        public bool TryReload(out string error)
        {
            if (!repository.TryLoad(out StoryEvidenceLedger restored, out error))
            {
                IsReady = false;
                Error = error;
                return false;
            }
            // A live session must never silently lose a previously confirmed result.
            // A fresh process may recover an older valid checkpoint, but an existing
            // session fails closed if storage has regressed or forked its history.
            if (progress != null &&
                (restored.Revision < progress.Revision ||
                 !ContainsAll(restored.Snapshot(), progress.Snapshot())))
            {
                error = "Stored story progress regressed or diverged; investigation is locked.";
                IsReady = false;
                Error = error;
                return false;
            }
            progress = restored;
            IsReady = true;
            Error = null;
            return true;
        }

        private static bool ContainsAll(int[] available, int[] required)
        {
            var indexed = new HashSet<int>(available);
            for (int index = 0; index < required.Length; index++)
                if (!indexed.Contains(required[index])) return false;
            return true;
        }

        public bool TryGetChapterProgress(int chapter, out ChapterInvestigationProgress summary)
        {
            if (chapter < 1 || chapter > ChapterStoryGraph.ChapterCount)
                throw new ArgumentOutOfRangeException(nameof(chapter));
            summary = IsReady ? ChapterInvestigationProgression.Get(chapter, progress) : null;
            return summary != null;
        }

        public bool IsCompleted(int number)
        {
            ChapterStoryGraph.GetLocation(number);
            return IsReady && progress.Has(number);
        }

        public bool CanInvestigate(int number)
        {
            ChapterStoryGraph.GetLocation(number);
            return IsReady && (progress.Has(number) ||
                ChapterStoryGraph.IsAvailable(number, progress.Snapshot()));
        }

        public bool TrySubmit(int number, int choiceIndex, long expectedRevision, out string message)
        {
            message = null;
            if (!IsReady)
            {
                message = Error ?? "Story progress is not available.";
                return false;
            }
            if (number < 1 || number > ChapterStoryGraph.LocationCount)
            {
                message = "Unknown investigation.";
                return false;
            }
            if (expectedRevision != progress.Revision)
            {
                message = "The investigation changed. Refresh your case file.";
                return false;
            }
            if (progress.Has(number))
            {
                message = "This evidence is already recorded.";
                return false;
            }
            if (!ChapterStoryGraph.IsAvailable(number, progress.Snapshot()))
            {
                message = "Complete the prerequisite investigation first.";
                return false;
            }
            StoryDossierCase dossier = StoryDossierCatalog.Get(number);
            if (choiceIndex < 0 || choiceIndex >= dossier.Choices.Count)
            {
                message = "Invalid deduction option.";
                return false;
            }
            if (!dossier.IsCorrect(choiceIndex))
            {
                message = "The evidence does not support that deduction. Examine the case details again.";
                return false;
            }
            var next = new StoryEvidenceLedger();
            if (!next.Restore(progress.Revision, progress.Snapshot()) ||
                !next.TryResolve(number, progress.Revision, out message)) return false;
            if (!repository.TryStore(progress, next, out message))
            {
                // A failed flush can occur after bytes were written. The old live
                // revision is intentionally retained until explicit reconciliation.
                // Do not permit further deductions against an ambiguous disk state.
                IsReady = false;
                Error = "Save commit status is uncertain. Reopen the case file to reconcile progress. " + message;
                message = Error;
                return false;
            }
            progress = next;
            message = dossier.Explanation;
            return true;
        }
    }
}
