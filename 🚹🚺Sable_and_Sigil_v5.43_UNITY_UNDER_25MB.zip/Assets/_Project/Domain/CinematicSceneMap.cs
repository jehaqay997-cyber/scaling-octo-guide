using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Photo-first, location-specific investigation hit targets. Coordinates are
    /// normalized relative to the original authored 16:9 photographs, never to
    /// the physical screen resolution. These are exploratory hints, not answers.
    /// </summary>
    public readonly struct ScenicPoint
    {
        public float X { get; }
        public float Y { get; }

        public ScenicPoint(float x, float y)
        {
            if (float.IsNaN(x) || float.IsInfinity(x) ||
                float.IsNaN(y) || float.IsInfinity(y))
                throw new ArgumentOutOfRangeException(nameof(x), "A scenic point must be finite.");
            X = x;
            Y = y;
        }
    }

    public sealed class ScenicLocation
    {
        public int LocationNumber { get; }
        public ScenicPoint EvidenceA { get; }
        public ScenicPoint EvidenceB { get; }
        public ScenicPoint Mechanism { get; }

        internal ScenicLocation(int location, ScenicPoint evidenceA,
            ScenicPoint evidenceB, ScenicPoint mechanism)
        {
            LocationNumber = location;
            EvidenceA = evidenceA;
            EvidenceB = evidenceB;
            Mechanism = mechanism;
        }
    }

    public static class CinematicSceneMap
    {
        public const int LocationCount = 10;
        public const float CanvasWidth = 1600f;
        public const float CanvasHeight = 900f;
        public const float MaximumXOffset = .40f;
        public const float MaximumYOffset = .26f;
        private const float MinimumSpacingSquared = .0100f;
        private static readonly string[] Atmosphere =
        {
            "The sealed threshold holds traces of a name removed from the estate records.",
            "A ceremonial staircase keeps one more secret in its worn brass details.",
            "The garden lantern burns beyond the hour recorded in the old almanac.",
            "The conservatory roses have outgrown an inscription beside the stone basin.",
            "The fountain is silent, but its four carved spouts still tell a story.",
            "The empty crossing has been watched by three statues for generations.",
            "The window remembers a testament written in fractured light.",
            "Every portrait appears familiar until the family memorial is read.",
            "The weathered witness guards an epitaph that someone tried to erase.",
            "Beneath the rotunda, the lost meridian awaits one final interpretation."
        };

        private static readonly ScenicLocation[] Scenes =
        {
            New(1, -.10f, .14f, .11f, -.13f, -.01f, -.06f),
            New(2, -.20f, .18f, -.08f, -.13f, -.32f, -.17f),
            New(3, -.12f, -.08f, .10f, .15f, .00f, -.19f),
            New(4, -.20f, -.15f, .18f, .06f, .05f, -.13f),
            New(5, .17f, -.08f, -.32f, .16f, .20f, -.20f),
            New(6, -.10f, -.13f, .11f, .16f, .00f, .00f),
            New(7, -.28f, .20f, .05f, .00f, .36f, .13f),
            New(8, -.11f, -.09f, .12f, .16f, .00f, .00f),
            New(9, -.10f, .17f, .11f, -.14f, .00f, .00f),
            New(10, -.17f, -.09f, .35f, -.18f, .05f, -.16f)
        };

        public static ScenicLocation Get(int locationNumber)
        {
            if (locationNumber < 1 || locationNumber > LocationCount)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            return Scenes[locationNumber - 1];
        }

        public static string GetAtmosphere(int locationNumber)
        {
            Get(locationNumber);
            return Atmosphere[locationNumber - 1];
        }

        public static bool Validate(out string error)
        {
            if (Scenes.Length != LocationCount || Atmosphere.Length != LocationCount ||
                LocationCount != ChapterWorldSceneCatalog.PrototypeCount)
            {
                error = "The photographic location inventory is incomplete.";
                return false;
            }
            for (int index = 0; index < Scenes.Length; index++)
            {
                ScenicLocation location = Scenes[index];
                if (location == null || location.LocationNumber != index + 1 ||
                    string.IsNullOrWhiteSpace(Atmosphere[index]) || Atmosphere[index].Length > 160 ||
                    !WithinFrame(location.EvidenceA) || !WithinFrame(location.EvidenceB) ||
                    !WithinFrame(location.Mechanism) ||
                    !Separated(location.EvidenceA, location.EvidenceB) ||
                    !Separated(location.EvidenceA, location.Mechanism) ||
                    !Separated(location.EvidenceB, location.Mechanism))
                {
                    error = "Invalid or overlapping scenic hotspots at location " + (index + 1);
                    return false;
                }
            }
            if (!CinematicHudClearance.Validate(out error)) return false;
            error = null;
            return true;
        }

        private static bool WithinFrame(ScenicPoint point)
        {
            return Math.Abs(point.X) <= MaximumXOffset &&
                Math.Abs(point.Y) <= MaximumYOffset;
        }

        private static bool Separated(ScenicPoint a, ScenicPoint b)
        {
            float dx = a.X - b.X;
            float dy = a.Y - b.Y;
            // Every touch marker is 112 by 76 pixels on the 1600x900 canvas.
            // Euclidean spacing alone would still allow overlapping touch rectangles.
            bool touchRectsSeparated = Math.Abs(dx) * CanvasWidth >= 112f ||
                Math.Abs(dy) * CanvasHeight >= 76f;
            return dx * dx + dy * dy >= MinimumSpacingSquared && touchRectsSeparated;
        }

        private static ScenicLocation New(int number, float ax, float ay, float bx,
            float by, float mx, float my)
        {
            return new ScenicLocation(number, new ScenicPoint(ax, ay),
                new ScenicPoint(bx, by), new ScenicPoint(mx, my));
        }
    }
}
