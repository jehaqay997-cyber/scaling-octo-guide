# Sable & Sigil v5.38 — Cinematic Story and Puzzle Fusion

**Compatibility target:** Unity 2022.3.62f3. **Verification status:** offline source candidate only; Unity compile, Unity NUnit/PlayMode, visual rendering and Android performance have NOT been executed.

## Actual integrated changes

The supplied original creative inspiration was interpreted as design direction, not copied directly. Five newly authored, photorealistic 1672 x 941 art plates were compressed into Unity runtime JPEG assets and coupled to **existing canonical investigations and mechanisms**. Original full-resolution PNG masters are stored OUTSIDE Unity's Assets tree under `ArtSource/CinematicMasters`, preserving fidelity without importing duplicate textures at runtime.

| Existing story location | Unity runtime plate | New environmental role | Original puzzle remains authoritative |
|---|---|---|---|
| 02 — The Spiral of Testimony | `Location_02.jpg` | Stair rhythm / altered baluster / staircase lock | Three-symbol cycle, sixth entry |
| 04 — The Rose Pavilion | `Location_04.jpg` | Autumn cloister, flowering basin and inscription | Additive petal sequence |
| 05 — The Fountain of Echoes | `Location_05.jpg` | Grand vaulted fountain and archived sequence | Unique order of four spouts |
| 07 — The Glass Testament | `Location_07.jpg` | Conservatory glazing, mirror, and concealed mechanism | Outer-pane exchange in three-symbol reading |
| 10 — The Meridian Rotunda | `Location_10.jpg` | Celestial tables, floor sigil, and archive notes | Unique constrained order of four rings |

Total full-bleed landscape plates present: **six of ten**, including the previously integrated Location 01. Existing Location 03, 06, 08, and 09 continue to use legacy photographs. The game still has **four chapters and ten authored investigations**: no fifth chapter or new ending has been falsely counted as complete.

### Real interactive change

- `CinematicSceneMap` now contains image-specific inspection positions for the five new environments.
- The world uses the exact existing `Resources.Load<Texture2D>("CinematicLocations/Location_XX")` pipeline, falling back to original artwork if the cinematic plate is absent; Unity Editor preflight rejects missing featured plates on release verification.
- Evidence marker taps open an in-game inspection panel with the **canonical original evidence fragment**, not the decorative glyphs shown in AI-authored scenery. The player must choose `RECORD IN JOURNAL` to commit the discovery; `KEEP EXPLORING` or Android Back discards the preview without awarding progress.
- The investigation, authored puzzle, SaveData structure, chapter progression, and finale gates are unchanged. Both evidence records must exist before the mechanic can be opened.
- A preview is modal: it blocks scene camera mode switching, pan/zoom, chapter navigation and direct programmatic clue grants until closed.
- The 112 x 76 UI touch rectangles must not overlap. Both center-to-center spacing and AABB separation are checked on the reference 1600 x 900 canvas. All 10 scenes satisfy the current contract.
- The five new JPEGs have their own `.meta` identities and deterministic SHA-256 inventory. All old Unity `.meta` GUIDs and legacy case photo bytes remain unchanged.

### Asset performance and privacy

The art importer accepts PNG and JPEG; it disables CPU-readable texture copies and mipmaps for UI-only location plates. Platform GPU compression/performance, thermal behavior and memory use are NOT measured; compressed GPU assets can still use considerable device memory. The change does not add tracking, networking or personal information to the scene logic. The preexisting PlayerPrefs-based save/preferences remain local but are not encrypted and must not store secrets.

## Verification evidence

- Python tests: **984/984 passed**, including adversarial mutation checks for scene image hashes, story-to-image crosswalk, modal bypass, missing confirmation, coordinate bounds and overlapping targets.
- Independent offline static gates: **92/92 passed**, including assembly references, source integrity, story/finale mathematical invariants, references, and artwork contract.
- All source is UTF-8, code identifiers/comments/logs are English.
- The final ZIP is independently re-extracted and checked for: full previous archive file retention, CRC, all file sizes and SHA-256 inventory, preserved Unity GUIDs, valid decoded images, source gates and Python tests.
- **NOT verified:** C# compilation inside Unity; NUnit EditMode/PlayMode execution; touch UI on actual devices; graphical parity with the generated art; correct graphical hotspot placement after Unity canvas scaling; GPU memory/FPS; Android publishing compliance.

## Priority next steps

**P0:** Open in Unity 2022.3.62f3 and run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`; resolve any actual compile/Safe Mode exceptions. Execute both Unity test suites and visually inspect Locations 02, 04, 05, 07 and 10 at landscape and portrait device sizes. Check modal click order and Android Back.

**P1:** Reconcile **decorative image markings with mechanically truthful close-up puzzle overlays**, polish each interactive hotspot against Unity screenshots and make sure every environmental glyph encodes the authored puzzle instead of relying on text-only explanations.

**P2:** Model properly explorable, lit 3D architecture and detailed puzzle props for all chapter locations, with authored collision and navigation, physically coherent PBR materials and LOD/occlusion. The current realistic backdrops are **2.5D** and do NOT meet the claim of complete premium photorealistic 3D environments.

**P3:** Complete new full-bleed artwork for four remaining old locations, performance profiling and Android device validation.

**Release decision:** v5.38 is a stronger integrated Unity source candidate. It must NOT be labeled play-tested, 3D-finished, safe for distribution or commercial release until engine and device evidence exists.
