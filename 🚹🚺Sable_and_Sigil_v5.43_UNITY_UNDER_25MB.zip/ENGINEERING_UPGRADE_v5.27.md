# Sable & Sigil v5.27 — Source Integrity and Cross-File Hardening

**Baseline:** v5.26. **Target:** Unity 2022.3.62f3. **Status:** Offline-audited source candidate.

## Corrective work

- `Assets/_Project/Editor/ChapterCaseSceneBuilder.cs`: validate pre-existing chapter scenes before acceptance, preserve loaded and edited scenes, inspect the expected bootstrap and gallery pairing, and reject missing scripts or wrong chapter identifiers. No original scene is overwritten.
- `Assets/_Project/Runtime/ChapterGalleryView.cs`: reject malformed world callback numbers and contain failed dossier handoff exceptions with a recovery message, without changing saved progression.
- `Assets/_Project/Runtime/StoryDossierView.cs`: ensure a failed dossier initialization hides and releases the partially displayed modal; preserve prerequisite, revision and single-use grant checks.
- `Assets/_Project/Runtime/ChapterWorldExplorer.cs`: block further physical input, hints and deduction when the Chapter Four relief cannot reflect a committed domain move. Never roll back the domain after a successful swap. The player may exit and reopen to restore a clean transient state.
- `Assets/_Project/Tests/PlayMode/ChapterFourWorldPlayModeTests.cs`: introduce an adversarial missing-relief scenario that confirms failure-closed behavior and recovery after reopening. It is authored source, not an executed Unity test.
- `Assets/_Project/Tests/EditMode/ChapterFourMeridianReliefTests.cs`: replace a redundant self-identity check with a persistent mesh identity check across rebuilds.
- `Verification/verify_cross_file_hardening_v527.py` and `Verification/test_cross_file_hardening_v527.py`: validate source ownership, fail-closed transitions, source language, scene identity checks, the release runner, and mutation resistance. All legacy gates remain active.

## Architecture constraints

Domain/AppCore remain independent of Unity. The story dossier session alone commits persistent case completion. 3D mechanisms maintain transient states and pass ephemeral one-use grants. Scene ownership and native meshes remain scoped to the world component. Saved checkpoint encoding and existing asset GUIDs are unchanged. Chapter Four mathematical solvability retains exactly one admissible order among 24 permutations.

## Verification scope

The complete nonempty source archive, every C# file, Unity meta identities, package manifest, NUnit source inventory, and edited reference contracts undergo offline checks. C# lexical scanning detects tokenization errors only, not compiler/CLR behavior. Unity scene import, compilation, NUnit execution, actual 3D visual quality and Android device tests are not performed by these checks.

**No measured percentage of final runtime completion is asserted.**
