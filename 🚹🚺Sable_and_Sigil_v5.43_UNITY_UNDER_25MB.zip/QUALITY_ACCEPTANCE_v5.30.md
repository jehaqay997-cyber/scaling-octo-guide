# Sable & Sigil v5.30 - Evidence-Gated Quality Acceptance

This document maps engineering work to internationally recognized quality and security frameworks. It does not claim ISO certification, NIST certification, or release readiness. All results are source-level unless linked to actual Unity/Android run evidence.

## Framework mapping

- **ISO/IEC 25010:2023 (product quality model):** evaluate functional suitability, performance efficiency, compatibility, interaction capability, reliability, security, maintainability, flexibility, and safety. The complete standard is maintained by ISO; project checks below are an engineering mapping rather than a conformity assessment.
- **NIST SP 800-218 SSDF v1.1:** retain change provenance, protect source and saves, analyze third-party dependencies, verify changes with reproducible evidence, and prevent unreviewed release promotion.
- **Unity 2022.3 official documentation:** acceptance must use Unity Editor 2022.3.62f3, its assembly definition/Test Framework setup, verified Editor import and scene serialization, and device profiling; Python static gates are not Unity compiler results.

Primary references:
- https://www.iso.org/standard/78176.html
- https://csrc.nist.gov/pubs/sp/800/218/final
- https://docs.unity.cn/2022.3/Documentation/Manual/cus-tests.html
- https://docs.unity.cn/2022.3/Documentation/ScriptReference/Application-targetFrameRate.html
- https://unity.com/how-to/use-memory-profiling-unity

## Acceptance matrix

| Quality attribute | Source control or change | Required runtime evidence | Current state |
| --- | --- | --- | --- |
| Functional suitability | Four named chapters and ten evidence cases; puzzle dependency graph; existing save identifiers retained | Ten case walkthroughs including wrong answer, success, reload, restart, and chapter transition | Source reviewed; runtime pending |
| Performance efficiency | Bounded frame pacing, optional short synthesized audio, transient input gate, explicit resource cleanup | On-device frame timings, GC allocations, texture/mesh/material resident memory, battery draw versus baseline | Source reviewed; runtime pending |
| Compatibility | Fixed Unity 2022.3.62f3, assembly definition and package checks | Unity import and Android build for target SDK/ABI | Pending |
| Interaction capability | Safe-area layout and touch-release barrier across focus transitions | Landscape/portrait and display cutout touch tests on representative hardware | Pending |
| Reliability | Two-slot dossier recovery, journal save contracts, fail-closed handoff | Fault injection in Unity Test Runner, crash/restart and interrupted-write device tests | Source tests authored; runtime pending |
| Security | Versioned save decoding, non-reusable one-shot investigation grants, archived source hashes | Adversarial save tampering, malicious/unsupported version and race simulations on target runtime | Source tests authored; runtime pending |
| Maintainability | Seven assembly definitions, source audit, source-to-test fixture SHA inventory | Zero compiler errors and all mandatory NUnit XML results | Source checked; runtime pending |
| Flexibility | Separation of domain, application, infrastructure, runtime and Editor modules | Platform input backend and device configuration matrix | Partially assessed |
| Safety | Fail-closed save corruption handling, no forced scene overwrite, no untrusted asset fallback | Verified recovery of user progress after failed saves and concurrent editing | Source checked; runtime pending |

## Required Unity acceptance order

1. Extract the full ZIP into a writable local folder outside synchronized/cloud-placeholder paths. Keep an immutable backup of the older project and saves.
2. Open the project with exactly Unity 2022.3.62f3; do not regenerate existing `.meta` GUIDs or mix different Unity editor revisions.
3. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`; retain the preflight Console log, generated scene files, Editor log and complete NUnit EditMode/PlayMode XML evidence.
4. Confirm `WorldPointerResumeGateTests`, `AudioFeedbackIsolationPlayModeTests`, chapter audio/power fixtures, all chapter mechanism tests and save-fault tests are discovered and pass. A missing, ignored or timed-out mandatory fixture blocks release.
5. Interactively verify all ten location cases, deduction gating and chapter title continuity. Inspect the native geometry, camera orbit, lighting, artwork, cutouts, touch targets, audio effects, and menu transitions.
6. Profile at least ten cycles of open/close, pause/resume and checkpoint reload using Unity Profiler and Memory Profiler on Android. Record per-cycle managed heap, native memory, texture allocations, GC.Alloc, FPS and thermal/battery measurements; compare steady-state and trend, not merely one end sample.
7. Build and install APK/AAB only after source import and NUnit tests pass. Record device/Android version, renderer, orientation, logs, package name, and build artifact SHA-256. Refuse commercial release if any gate lacks evidence.

## Explicit verification state

`SOURCE_INTEGRITY`: static gate results and archive manifest, if independently verified.
`DESIGN_VERIFIED`: partial; story/architecture source reviewed, visual gameplay not observed.
`COMPILE_VERIFIED`: NOT EXECUTED.
`TEST_VERIFIED`: Unity EditMode/PlayMode NOT EXECUTED.
`DEVICE_VERIFIED`: NOT EXECUTED.
`ENERGY_DRAIN_MEASURED`: NOT EXECUTED.
`RELEASE_APPROVED`: NO.
