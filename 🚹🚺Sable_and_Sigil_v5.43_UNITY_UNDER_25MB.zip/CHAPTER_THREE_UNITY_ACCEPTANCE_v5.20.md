# Chapter Three Unity Acceptance — v5.20

**Unity:** 2022.3.62f3. **Baseline:** v5.19. **Candidate:** v5.20. **Locations:** 07–09.

## Execution

1. Extract the complete v5.20 ZIP to a writable local Windows directory outside any cloud-placeholder or sync-evicted path.
2. Open the project folder through Unity Hub using the required Editor. Confirm Asset Database import and Package Manager resolve successfully and Console has no C# errors.
3. Close the Editor, then run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the extracted project root. Preserve the editor log, EditMode NUnit XML, PlayMode NUnit XML, test fixture identity proof and acceptance JSON.
4. In Unity, execute all Chapter Three tests: `ChapterThreeMechanismTests`, `ChapterThreeReliefMeshTests`, and `ChapterThreeWorldPlayModeTests`. The last fixture now includes `MechanismModalBlocksQueuedCameraAndAtlasCommands` and `ArtworkAndComparisonModalPreventCameraMutation`.
5. Run the full previous NUnit regression inventory. Do not approve the release if any test or compiler error is missing evidence or is unsuccessful.

## Gameplay and scene acceptance for each of locations 07–09

| Site | Expected authoritative solution | Visual state |
|---|---|---|
| 07 — The Glass Testament | Choice index 0; reversed mirror order | Original stained-glass symbols remain, reconstructed mirror engraving appears only after verification |
| 08 — The Hall of False Light | Choice index 2; 1912 live sitting contradicts 1904 memorial | Memorial/portrait timeline inlay changes on verification |
| 09 — The Weeping Witness | Choice index 1; missing E | Epitaph engraving is restored in place |

- Do not permit any answer before both distinct evidence fragments are inspected. Wrong answers must not satisfy deduction; a correct answer must unlock it once only.
- Repeat opening/closing a case and switching between the three sites. The mechanism, hints and attempts must reset across sessions; there must be no bleed into other chapters.
- Open the mechanism modal, then attempt rotation, zoom, focus evidence, return to overview and direct atlas exit. The modal must remain visible, camera unchanged, no extra meshes, no new evidence, no answer, and no atlas callback. Back/Escape must close the modal first.
- Open the original artwork and clue comparison modals. Rotation, zoom and direct atlas exit must be ignored while either is active; Back closes one modal layer. Afterwards, camera controls and exit should work normally.
- Call nonfinite camera rotation through the PlayMode regression and confirm camera yaw remains finite.
- Verify nearest-hit foreground occlusion, physical backplate tap after both clues, safe-area layout at 16:9, readability of text and 4 choices at mobile aspect ratios, UI hit targets, lighting, mesh facing, and zero unintended tapping behind modals.
- Profile memory/GC/frame rate on an actual Android device; collect stable screenshots and profiler data for locations 07, 08 and 09.

## Evidence matrix

| Gate | Required proof | Status |
|---|---|---|
| SOURCE | Python source regressions, static gates, full zip SHA-256 and source manifest | Must be reported separately |
| UNITY_COMPILE | 2022.3.62f3 Editor log, no compile errors | NOT EXECUTED HERE |
| UNITY_EDITMODE | NUnit EditMode XML, zero failures | NOT EXECUTED HERE |
| UNITY_PLAYMODE | NUnit PlayMode XML, zero failures | NOT EXECUTED HERE |
| ANDROID_DEVICE | Build log, recorded device, framerate/memory trace and complete site playthrough | NOT EXECUTED HERE |

**Do not claim 99% completion or production verification from Python source tests alone.**
