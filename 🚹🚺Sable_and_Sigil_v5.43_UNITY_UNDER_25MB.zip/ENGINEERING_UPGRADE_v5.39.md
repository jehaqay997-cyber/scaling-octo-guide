# Sable & Sigil v5.39 — Physical Meridian and Local Chapter Atmosphere

**Target:** Unity 2022.3.62f3. **Status:** source-level candidate; Unity C# compilation, Unity NUnit, visual validation, Android, hardware sound playback, performance and commercial release remain **unverified**.

## Executed source changes

1. **Actual 3D ring geometry:** The Chapter Four meridian no longer uses four flat cylinder discs as decorative rings. `ChapterWorldRingGeometry.Create` builds a bounded toroidal mesh with a genuine central opening, UVs, analytic outward normals, a closed seam and finite input validation. Four world rings are allocated per investigation, assigned scene-owned meshes/materials, and disposed via the established world ownership lists when the location closes.
2. **State-consistent spatial puzzle:** `ChapterWorldExplorer` maps each physical ring's visible orientation to the canonical `ChapterFourMeridianPuzzle.Order` permutation. A valid swap immediately synchronizes the 3D artwork; the completed state updates the ring material as well as the existing relief. If geometry cannot be synchronized, visual integrity is marked desynchronized and deduction remains blocked until the investigation is reopened. The puzzle's unique solution, evidence requirements, save schema and story ending remain unchanged.
3. **Original procedural sound bed:** `CinematicAmbientSynthesis` is a pure-domain, deterministic synthesizer for four original chapter tones. Each loop uses three seconds of 22,050 Hz mono samples, with integer-cycle oscillators for periodic boundaries and a formal absolute sample ceiling of 0.201. Its nominal PCM buffer is **66,150 samples x 4 bytes = 264,600 bytes**. This represents a lightweight *prototype atmosphere*, **not** an artistically mastered ambient soundtrack or calibrated device audio experience.
4. **Memory, focus and privacy:** `ChapterWorldAtmosphere` creates one non-streaming AudioClip on location entry; it keeps no external media files, calls no network API, respects the previously implemented local audio-off preference, suspends on application pause/focus loss, and removes its clip when the scene closes. If optional clip initialization fails, only ambience is disabled; chapter opening continues. The source uses a 0.5-second preference poll rather than per-frame PlayerPrefs reads.
5. **Verification governance:** Two Unity EditMode fixture classes now cover geometric topology/winding/radius bounds and synthesized audio determinism/peak/loop behavior. Both are registered in the complete NUnit fingerprint inventory. A separate Python mathematical/source integrity gate and 17 adversarial regression tests guard these changes. The acceptance runner's candidate revision is v5.39 while its intentionally preserved legacy baseline remains v5.30.

## Mathematical checks

For a torus with major radius R, tube radius r, azimuth u and cross-section angle v, vertices follow
`((R + r cos v) cos u, r sin v, (R + r cos v) sin u)`.

- Each mesh uses `(M + 1) * (T + 1)` vertices and `6 * M * T` triangle indices; bounds are `12 <= M <= 96`, `6 <= T <= 24`, `0 < r < 0.4 R`, `0 < R <= 3`.
- For production `M=40`, `T=10`, each ring contains 451 vertices and 800 triangles; the four torus meshes total **3,200 triangles** before other scene geometry.
- The winding test compares triangle cross products to the analytic outward normal, and an independent mathematical model checks both parametric seams.
- Audio loop oscillators use integer cycle counts over three seconds. The independent model confirms finite samples, maximum absolute amplitude below 0.201 and near-continuous boundary transitions for all four chapters. These are signal-level properties, not evidence of sound quality or latency on hardware.

## Art, story and puzzle scope

All authored cinematic backgrounds, original images, five enhanced location plates, 10 case solutions, four story chapters, four-page finale, chapter unlock rules, camera pan/zoom system and durable save schema are **unchanged**. This revision materially improves one genuine 3D puzzle prop and introduces local chapter ambience, but **does not** make the entire existing photo-backed prototype a fully explorable photorealistic 3D game. The user-provided reference imagery and earlier generated backgrounds remain inspiration rather than copied commercial assets.

## Evidence limits and outstanding requirements

- 1,001 Python source/contract regression tests **passed** in the working tree and independently extracted archive.
- 93/93 offline source gates **passed** in the working tree and independently extracted archive.
- Unity compiler, Unity Test Runner EditMode/PlayMode, actual camera rendering, 3D visibility/occlusion, 3D puzzle interactions, sound listening and Android thermal/FPS measurements **not executed**.
- Existing `Packages/packages-lock.json` remains absent; resolve packages using Unity Package Manager on the target machine and preserve generated dependency evidence.
- Store/preferences are device-local, but PlayerPrefs must not be treated as encrypted storage.
- Realistic environmental architecture, material authoring, professional ambience/foley/voiceover, cutscene direction, all ten full-bleed scenes, Unity PlayMode acceptance and Android device profiling remain separate production milestones.

## Practical Unity acceptance order

1. Open the project using Unity 2022.3.62f3 from a non-synchronized, writable local directory. Resolve any actual Console compilation errors; do not infer success from offline checks.
2. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`, retain its generated XML/log evidence and verify that both newly registered EditMode fixtures actually execute.
3. Open chapter-four Location 10 and switch to `INSPECT 3D RELICS`. Confirm ring holes, front-facing normals, all ring meshes visible, permutation swaps updating the spatial rings, and solved-state highlighting.
4. Toggle local sound in Privacy Settings while exploring and check pause/resume, scene close/reopen, audio clicks at loop boundaries, master volume, device playback and memory life cycle with Unity Profiler.
5. Play all four chapters, every investigation and the finale; inspect UI safe areas, artwork hot spots, puzzle fairness and failure recovery. Validate an Android build on an actual target device.

**Release verdict: NOT APPROVED.** This deliverable is a further auditable source improvement, not proof of world-class, fully 3D, commercially ready gameplay.
