# Sable & Sigil — v5.09 Chapter One Final Interaction & Hint Guard Audit

Unity Editor compatibility target: **2022.3.62f3**.
Parent version: **v5.08**. This is a **SOURCE CANDIDATE**, not a Unity-verified or device-tested release.

## Changes, deliberately limited to chapter one

1. Added a three-step on-demand crest hint inside the existing first-location comparison overlay, without changing the pure C# `ThresholdCrestPuzzle` answer authority, evidence inspection, dossier answer, journal, save data, or chapter unlock rules.
2. Hint progression is local transient UI state (0..3), available only while the first chapter's threshold modal is open and both evidence fragments have been inspected. Requests after verification or beyond the three-hint maximum fail closed.
3. Hints offer visual/comparative guidance progressively and disappear once the crest is verified. The action never calls evidence inspection, ray selection, persistence, or navigation.
4. Reset hint state on each scene Open and Close. Other nine locations have neither this button nor the new hint state exposed.
5. Extended the existing first-chapter Unity PlayMode test with checks for blocked requests, three bounded stages, attempt-count invariance, untouched deduction state, disabled button at the limit, clearing after verified, and reset on reopening. Updated the corresponding reviewed NUnit-source fingerprint.
6. Added eleven Python regression and mutation tests plus an independent static source auditor; registered that auditor as gate 63 in the existing full audit.

**Art and world geometry:** This iteration intentionally retains the existing authored photo, four-stair Gothic portal, metal crest rings and stud mesh unchanged. Render quality and exact framing require an actual Unity/GPU check and must not be inferred from static tests.

## Independent verification

- Python unittest discovery: **556 / 556 PASS**.
- Source static gates: **63 / 63 PASS**, in two independently completed batches; see `Verification/STATIC_EVIDENCE_v509.json`.
- NUnit fixture manifest signature audit: PASS, **71 EditMode + 6 PlayMode source fixtures**; this checks fingerprints and registrations, not Unity execution.
- Archive CRC, cryptographic file manifest, baseline preservation and fresh-extraction Python checks are performed by the packaging process. See the separate `*_Independent_Verification.json` and SHA-256 map.

### Explicit release gates

- DESIGN_VERIFIED: source-side invariants and test design checked; runtime presentation unverified.
- COMPILE_VERIFIED: **FALSE**. Unity Editor unavailable in the current environment.
- EDITMODE_VERIFIED: **FALSE**. No Unity/NUnit XML from an executed editor session.
- PLAYMODE_VERIFIED: **FALSE**. No live camera, input or scene test evidence.
- DEVICE_VERIFIED: **FALSE**. No Android build or physical device check.
- RELEASE_VERIFIED: **FALSE**.

## Chapter-one acceptance within Unity

1. Extract the complete project locally, preserve `.meta` GUIDs, and open in **Unity 2022.3.62f3**. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` and retain logs and test XML.
2. Launch Chapter 1 → first Threshold location → `EXPLORE 3D`; verify the photograph, four stone treads, crest relief, camera, three original lights and evidence relics are aligned on real device aspect ratios.
3. Attempt `REQUEST CREST HINT` before inspecting A and B: unavailable; confirm no progress is granted. Inspect both relics and open `EXAMINE CREST LOCK`.
4. Press `REQUEST CREST HINT` three times: readable stages 1, 2 and 3; the fourth request is disabled. Verify `ThresholdAttempts = 0`, `IsThresholdVerified = false`, `CanDeduce = false` throughout.
5. Select a wrong ray from the on-diagram targets, verify red feedback and incremented attempts; then select the extra ray, verify green feedback, hints disappear and deduction becomes available.
6. Close and reopen the investigation, verify hints reset to stage 0, the crest is locked and previously inspected evidence does not leak into the new transient session. Verify the other nine locations remain unaffected.
7. Confirm compile, EditMode, PlayMode and Android build/device results separately before calling this a final release.

## Primary references

- Unity 2022.3 Object.Destroy behavior: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Object.Destroy.html
- Unity 2022.3 camera ray geometry: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Camera.ScreenPointToRay.html
- Unity uGUI Text component implementation (owned runtime font handling): https://github.com/Unity-Technologies/uGUI/blob/main/com.unity.ugui/Runtime/UGUI/UI/Core/Text.cs
