# Sable & Sigil — Chapter Three Unity Acceptance v5.19

**Required Unity Editor:** 2022.3.62f3. **Baseline:** v5.18. **Candidate:** v5.19.
**Scope:** Chapter Three, locations 07–09. All decisions require actual Unity logs and screenshots.

## Execution

1. Extract the entire v5.19 project ZIP to an ordinary writable local Windows directory. Avoid synced/cloud-only placeholders.
2. Open that folder through Unity Hub with **2022.3.62f3**. Wait for Package Manager imports and C# compilation.
3. From the extracted project root, run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`. Preserve its console log, NUnit EditMode and PlayMode result XML, and JSON report. Do not infer success from the command starting.
4. Confirm there are no C# compiler errors, broken GUID references, missing resources or Safe Mode at scene startup.
5. Execute the Chapter Three tests by name: `ChapterThreeMechanismTests`, `ChapterThreeReliefMeshTests`, `ChapterThreeWorldPlayModeTests`. Run all pre-existing regression suites too.
6. Test every site at 16:9 landscape and Android portrait/landscape as appropriate for the configured game. Check safe-area behavior and pointer input on device.

## Required in-editor journey

| Site | Evidence and mechanism | Expected verified state |
|---|---|---|
| 07 — The Glass Testament | Inspect both independent clues; examine the stained-glass panel. Reflect top-to-bottom triangle, ring, three rays into three rays, ring, triangle. | Mirror relief is restored; correct answer is choice index 0; deduction unlocks only after verification |
| 08 — The Hall of False Light | Inspect memorial record 1904 and signed portrait 1912. Reject the claim of a living sitting eight years after the recorded death. | Timeline relief is restored; correct answer is choice index 2 |
| 09 — The Weeping Witness | Inspect broken inscription and independent letter. Restore the missing letter E in R _ M E M B E R. | Epitaph relief is restored; correct answer is choice index 1 |

## Blocker tests

- Attempt selecting a solution before either clue, after only the first clue, after both clues, and after verification. Only the correctly evidenced answer may verify the puzzle. Repeat selection must not duplicate credit.
- Ensure hints require two inspected clues, are limited to three stages, and never solve the mechanism or write campaign progress.
- Attempt deduction before evidence, after evidence but before repair, while the modal is open, and after verified repair. Only the last case permits deduction.
- Physically tap the backplate. It must obey the same gate as the UI button and use the nearest non-trigger collider; verify a temporary foreground blocker prevents world interaction.
- Verify the geometry faces the camera and the selected site has a unique relief. Compare before/after triangle counts to the test's independent oracle. Verify no additional owned mesh appears on restoration.
- Rotate, zoom, focus and inspect without modifying clue completion. Test Back/Escape through modal, artwork, comparison, camera focus and atlas. Exit never opens deduction.
- Close and reopen each investigation. Hint stages, attempts and solution state must reset. Confirm each site's state is independent of the other sites, and Chapter One/Two tests remain unchanged.
- Verify mobile safe areas, UI touch target visibility, zero unintended background clicks, appearance of shadows/materials and frame time under real device profiling.

## Release evidence, not yet acquired

| Gate | Required evidence | Current status |
|---|---|---|
| DESIGN_SOURCE | Source static gates, SHA-256 manifest, preserved assets | Offline checks can be reported separately |
| UNITY_COMPILE | Editor log ending with zero compiler errors | NOT RUN |
| UNITY_EDITMODE | NUnit XML with zero failures | NOT RUN |
| UNITY_PLAYMODE | NUnit XML and scene screenshots | NOT RUN |
| ANDROID_DEVICE | Build logs, device name, FPS/memory trace and a full playthrough | NOT RUN |

**Acceptance rule:** Source-only tests never count as Unity verification. A 99% completion estimate or production certification is not established without the above runtime evidence.

## Primary API references

- Unity 2022.3 Physics.Raycast: https://docs.unity3d.com/kr/2022.3/ScriptReference/Physics.Raycast.html
- Unity 2022.3 Mesh.SetVertices: https://docs.unity3d.com/kr/2022.3/ScriptReference/Mesh.SetVertices.html
