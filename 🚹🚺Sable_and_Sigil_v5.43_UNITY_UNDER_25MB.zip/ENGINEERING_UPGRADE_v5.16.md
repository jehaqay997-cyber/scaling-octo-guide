# Sable & Sigil v5.16 — Chapter Two Physical Relief and World Interaction

Unity target: **2022.3.62f3**. Base: **v5.15**. This is a source-only candidate pending Unity validation.

## Scope

Chapter Two locations 03–06. No changes to the artwork image files, authored story answers, case progression, Chapter One logic, serialized scenes or original asset GUIDs.

## Actual implementation

- `ChapterTwoReliefMesh`: four deterministic, site-specific 3D ornamental motifs built with one bounded mesh per active site. Lunar phases, rose petal counts, fountain heights and witness arrows are visually different and conceal the missing solution until verification.
- The relief uses rear-facing-to-camera geometry normals (`Vector3.back`), validates location and triangle bounds (maximum **512 triangles**), and is owned by the same world scene as the other procedural assets.
- The former four separate decorative primitive cylinder objects were removed. No collider is attached to the decorative relief, eliminating their repeated renderers and primitive meshes. The existing stone backplate is now the one interactive world target on the evidence layer.
- Clicking the physical backplate opens the existing evidence-gated puzzle viewer; attempts before both clues have been inspected remain blocked. Other colliders may occlude the backplate and still retain nearest-ray hit precedence.
- After the single correct choice, the existing relief `Mesh` is rebuilt in place and switched to the existing verified material, with no additional mesh instance or material allocation. Incorrect answers never rebuild it. The transient state is erased on closing the world.
- Updated PlayMode and EditMode fixtures, fixture source SHA-256 inventory, Unity acceptance baseline, static contracts, a geometric triangle-count oracle and mutation tests. Existing Chapter One tests were updated only to distinguish the expected Chapter Two mesh count.

## Geometry budget (independent structural oracle)

| Site | Unsolved triangles | Restored triangles |
|---|---:|---:|
| 03 | 184 | 208 |
| 04 | 210 | 231 |
| 05 | 80 | 24 |
| 06 | 137 | 146 |

The numbers come from the authored mesh generator's triangle formulas; **they are not rendered Unity GPU measurements**.

## Validation boundary

Source verification cannot confirm C# compilation, visual quality, graphics frame rate, interaction timing or Android behavior. `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` and `CHAPTER_TWO_UNITY_ACCEPTANCE_v5.16.md` specify the required real editor and device acceptance. This candidate is not approved for release without those results.
