# TheOrderRoom v4.40 — PlayMode Acceptance Gate

## Source of truth

Built from `TheOrderRoom_v4.39_UI_EVENT_DELIVERY_CANDIDATE.zip`. The authored project version remains `Unity 2022.3.62f3`. This review does not certify compatibility with another Unity editor version.

## Confirmed release-process gap

The preceding `Verification/Run-UnityVerification.ps1` executed scene bootstrap and EditMode tests. Its success state did not require any PlayMode tests. An EditMode-only acceptance gate cannot establish that a serialized scene starts and that its runtime UI and input services initialize.

## Implemented changes

1. `Verification/Run-UnityVerification.ps1` now invokes a separate Unity batch process with `-runTests -testPlatform PlayMode` and requests `playmode-results.xml`.
2. PlayMode acceptance fails when NUnit XML is absent, malformed, empty, has no successful tests, reports failed tests, returns a nonzero process exit code, or reports an overall result other than `Passed`.
3. `Assets/_Project/Tests/PlayMode/IntegratedSceneSmokeTests.cs` loads the generated Main scene and checks active camera, one game controller, one bound pointer provider, active EventSystem/input module, active raycasting Canvas, 13 UI buttons, screen layout, and performance governor.
4. `Assets/_Project/Tests/PlayMode/TheOrderRoom.Tests.PlayMode.asmdef` provides an isolated Unity Test Framework assembly with Editor-only tests and an explicit runtime dependency.
5. The fail-closed `Verification/release_source_gate_v435.py` assembly allowlist was updated to declare the new assembly and exact approved dependencies rather than weakening assembly inventory checks.
6. A new independent static contract plus mutation tests were added: `playmode_release_gate_v440.py`, `test_playmode_release_gate_v440.py`.

## Evidence (offline only)

- Python unittest discovery: **68 tests passed**.
- Python static gates: **15 of 15 returned status code 0**, including the new PlayMode source contract.
- Unity Editor executable: **not available in this environment**. Neither the new smoke test nor previous C# EditMode tests have been executed here.
- No Android, battery, thermal, memory, FPS, or production build execution was performed.
- SHA-256 manifest and file inventory are included in `Verification/RELEASE_EVIDENCE_v4.40.json` and `Verification/SHA256_MANIFEST_v4.40.json`.

## Release governance — mandatory blocking conditions

**SOURCE_VERIFIED** means only the offline gates passed. **COMPILE_VERIFIED** requires a real Unity compilation log from exactly the editor version pinned in `ProjectVersion.txt`. **EDITMODE_VERIFIED** and **PLAYMODE_VERIFIED** require distinct Unity Test Framework XML outputs, test counts greater than zero, no failed tests, a passing overall result and zero command process exit codes. **DEVICE_VERIFIED** requires on-device Android testing and recorded build/artifact hashes. All four execution categories remain **NOT_VERIFIED** for this deliverable.

## Next action with an installed Unity editor

From Windows PowerShell, launch `Verification/Run-UnityVerification.ps1` using the exact Unity editor path. Inspect `Verification/LocalResults/verification.json`, `bootstrap.log`, `editmode-results.xml`, and `playmode-results.xml`.

**Never** promote the candidate based on Python/static success alone. The PlayMode smoke test checks scene wiring, not full gameplay, multi-touch stress, storage power-failure recovery, mobile thermal stability, or release signing.

## Primary references

- Unity Editor command line arguments: https://docs.unity3d.com/2022.3/Documentation/Manual/EditorCommandLineArguments.html
- Unity Test Framework command-line execution: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html
- PowerShell try/catch/finally: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_try_catch_finally
