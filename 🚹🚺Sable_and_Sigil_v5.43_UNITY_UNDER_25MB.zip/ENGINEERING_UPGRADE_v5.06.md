# Sable & Sigil v5.06 — First-Chapter Visual Crest Comparison

**Unity target:** 2022.3.62f3. **Parent source:** v5.05.  
**Classification:** STATIC-SOURCE CANDIDATE. Unity Editor, PlayMode, Android and device checks are NOT VERIFIED.

## Implemented

- The first investigation's crest modal now draws side-by-side **five-ray original letter** and **six-ray altered arch** diagrams using `UnityEngine.UI.Image` objects. Both diagrams derive each ray angle from `ThresholdCrestPuzzle` rather than a duplicated list.
- The altered diagram displays numbered marks corresponding exactly to the existing six touch-accessible selection buttons. Decorative images set `raycastTarget=false` so they do not consume touch input. The modal backdrop continues to block world input.
- A wrong choice marks only the rejected ray red. Verified success marks only the added ray green, resets previously rejected ray coloring, and preserves the original evidence gate and dossier authority. All diagram references and prior attempts are cleared on world close/re-entry.
- Added assertions to the existing `ChapterWorldExplorerPlayModeTests` fixture to verify the 5/6 diagram counts, passive input surfaces, numbered rays and feedback colors. The total authored NUnit fixture identities remain **71 EditMode and 6 PlayMode**; these are authored tests, not executed results.
- Added `verify_crest_diagram_v506.py`, eleven mutation regression tests, and registered the new fail-closed gate in the full static audit runner. Refreshed the reviewed NUnit source SHA-256 fingerprint and version-specific acceptance guards to v5.06.

## Ownership and boundaries

- No original photo, art resource, Unity `.meta`, `.asmdef`, `ProjectSettings`, `Packages`, or scene source has been modified.
- The diagrams are owned and destroyed by `ChapterWorldExplorer`; no `PlayerPrefs` or permanent quest state changes were introduced.
- The mechanism still requires inspection of both evidence fragments and correct selection of the inserted arch ray. The existing story-dossier deduction remains authoritative.
- The 3D geometry is still primitive/procedural. No production 3D model, PBR texture set, or pre-authored Unity scene has been added in this iteration.

## Acceptance restrictions

The ZIP is a complete source candidate, not a compiled game. On a Windows workstation, extract to a local, non-synced folder and run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` using Unity **2022.3.62f3**. Preserve logs and NUnit XML. Confirm the first case's diagrams, UI hit areas, wrong/correct selection feedback, the dossier gate, and scene re-entry. Run Android build and on-device profiling separately.
