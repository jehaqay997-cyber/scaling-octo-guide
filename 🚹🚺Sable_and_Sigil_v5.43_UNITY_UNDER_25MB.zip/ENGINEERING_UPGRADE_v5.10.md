# Sable & Sigil — v5.10 Chapter One Close-Up and Art Composition

**Compatibility target:** Unity 2022.3.62f3. **Parent:** v5.09. **Status:** source candidate; editor and Android runtime not verified.

## Scoped implementation

1. A dedicated chapter-one crest inspection orbit begins at 4.8 world units instead of 6.7. Within this orbit, camera zoom clamps to 3.8–8.2, separately from the room's 6.6–11 range. This removes the prior zoom-in discontinuity. Returning to the overview restores the original 8.7-unit distance. Evidence focus remains 7.2.
2. Reject NaN and infinity camera zoom deltas before applying any position change.
3. The first-location reference art (1280×720 with blurred outer side extensions) is now shown in the 3D stage through its central 432×720 source-pixel region, preserving a 0.6 aspect ratio and reframing the stage border accordingly. A texture-dimension guard automatically falls back to full-extent rendering for assets of other sizes.
4. The original imported JPEG stays byte-for-byte unchanged. The original-art inspection viewer still presents that exact, full texture; the crop only adjusts the stage material's UV transform. All other nine locations retain full-extent image rendering.
5. Block evidence inspection while the artwork, comparison, or threshold-crest modal overlays are active, so programmatic UI callbacks cannot inspect clues behind an open modal.
6. Extend the existing PlayMode fixture with close-up zoom bounds, non-interfering modal inspection, world-photo UV/aspect checks, unmodified original-image identity and non-first-location fallback. Refresh only the changed PlayMode fixture fingerprint.
7. Add an independent source/numeric gate plus 11 Python mutation/regression tests. The new static gate is appended to the existing audit schedule.

## Measured source geometry (not a Unity screenshot)

- Authored Scene_01.jpg source image: 1280×720 pixels, central doorway crop x=424..855 inclusive (432 pixels wide).
- In-game stage photo panel: 4.95 units high, 2.97 units wide. Aspect ratio 432/720 = 0.600.
- At crest focus (4.8 units), effective straight-line camera offset is sqrt(4.8² + 2.0²) = 5.2 units. Using 53-degree vertical FOV and a 16:9 illustrative aspect ratio, the nominal viewport horizontal width at focus depth is about 9.22 units. This is a numeric proxy, not a rendered framing validation.
- The photograph, its .meta, original scenes, other chapter images, and domain puzzle answer geometry remain unmodified.

## Source and static evidence

- 567 of 567 Python unittest cases passed after modifications.
- 64 of 64 offline static gates passed, each executed independently; see Verification/STATIC_EVIDENCE_v510.json.
- The existing EditMode/PlayMode fixture inventory and its source hashes pass source-level checks. No Unity NUnit tests were run.
- Archive files are SHA-256 indexed in MANIFEST_v5.10.json and MANIFEST_v5.10.sha256. The separate independent verification JSON records fresh-extraction results.

## Release gates

| Check | Status |
| --- | --- |
| Source-side design invariants | Checked by offline tests and numerical assertions |
| C# compilation in target Unity | NOT VERIFIED |
| Unity EditMode NUnit execution | NOT VERIFIED |
| Unity PlayMode, actual camera/UI and 3D rendering | NOT VERIFIED |
| Android build and physical device | NOT VERIFIED |
| Release approval | BLOCKED |

## Target Editor acceptance

1. Extract the entire ZIP on a local non-synchronized drive. Use Unity 2022.3.62f3. Run RUN_SABLE_EDITOR_ACCEPTANCE.cmd and preserve the actual Unity logs and NUnit XML.
2. Open Chapter One, first Threshold location, then EXPLORE 3D. The central Gothic doorway must show no horizontal distortion or blank texture; VIEW ORIGINAL ART must still present the full original 1280×720 JPEG.
3. Focus the crest: camera distance 4.8. ZOOM+ moves to 3.8 and remains clamped after repeated taps; ZOOM− remains <= 8.2; RETURN TO OVERVIEW restores 8.7. Test wheel and pinch on an Android aspect ratio as well.
4. Open an artwork, comparison or crest modal and attempt a programmatic/underlying evidence inspection; all should fail closed while it is open. Close it and inspect normally.
5. Verify neither crest focus nor viewing the artwork or requesting hints alters inspected evidence, attempts, completion or durable save state. Test the wrong/correct ray paths and dossier gating.
6. Measure frame time, memory and touch safe-area alignment using Unity Profiler and a physical Android device. Do not mark release verified without the logs and screenshots.

## Primary Unity API documentation

- Unity 2022.3 Material.SetTextureScale: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Material.SetTextureScale.html
- Unity 2022.3 Material.SetTextureOffset: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Material.SetTextureOffset.html
- Unity 2022.3 Camera.ScreenPointToRay: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Camera.ScreenPointToRay.html
