# Sable & Sigil v4.99 — Build Gate and Imported Scene Dependency Integrity

Unity compatibility target: **2022.3.62f3**. Source baseline: **v4.98**.

## P0 fixes shipped

1. `Assets/_Project/Editor/OrderBuildPreflight.cs`: `IPreprocessBuildWithReport.OnPreprocessBuild` invokes the complete imported-source, generated-scene, resource and UI acceptance routine. Build validation fails closed with a `BuildFailedException` if the Editor acceptance routine rejects the project. The original Main-scene Build Settings requirement remains.
2. `Assets/_Project/Editor/OrderAndroidBuildBatch.cs`: before `BuildPipeline.BuildPlayer`, the Android entrypoint explicitly invokes the same comprehensive Editor acceptance routine after generating the Chapter One scene. Errors are collected and block APK creation.
3. `Assets/_Project/Editor/SableAssetReferenceValidator.cs`: `ValidateImportedSceneDependencies` verifies both generated scene imports, enumerates `AssetDatabase.GetDependencies(scenePath, true)`, checks project-owned imported dependencies are loadable using `AssetDatabase.LoadMainAssetAtPath`, and validates asset GUID round-trips. Built-in and package-managed dependencies are deliberately excluded from project-owned GUID checks.
4. `Verification/verify_build_integrity_v499.py`: offline acceptance gate checks these call paths, scene lists, dependency checks and UI/missing-script validation contracts.
5. `Verification/test_build_integrity_v499.py`: 12 tests, including mutations of call ordering, missing scene coverage, GUID verification and UI binding checks.
6. Updated all version-pinned acceptance runners and regression tests to accurately label source baseline `v4.99`, and registered the new static gate in `Verification/run_full_static_audit_v443.py`.

## What the audit established

- Python regressions: **413 of 413 passed** in the working source.
- Maintained static gates: **54 of 54 passed**, executed independently in three process batches.
- Reference graph: **149 C# source files, 7 asmdef files, 207 unique Unity GUIDs, 13 persistent Main UI callback contracts, 15 required Resources, 17 runtime MonoBehaviour identities**; no failures detected inside these static audit contracts.
- All **890 v4.98 source files preserved**, including all original images, Unity `.meta` files, existing `asmdef` definitions, save systems, puzzle rules, and artwork.
- Scene assets `Main.unity` and `ChapterOne.unity` remain Editor-generated. The ZIP does **not** pretend to contain Editor-imported scenes.

## Important verification limits

All work above is source-level evidence, not an Editor compilation. There is no Unity Editor binary in this execution environment, so `COMPILE_VERIFIED`, `TEST_VERIFIED` and `DEVICE_VERIFIED` remain **false**. The scene-dependency routine is compiled and executed only when Unity runs it. Package Manager resolution, runtime MonoScript binding, scene callback invocation, Android build and on-device performance require actual Unity logs and NUnit/Android outputs. Do not claim missing references are fully repaired unless an Editor log proves they have been resolved.

## Execution

Extract the full ZIP into a stable local directory on Windows. With Unity 2022.3.62f3 installed and the Editor closed, execute `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`; retain the generated Editor, NUnit and Android logs. The updated fail-closed prebuild gate also applies to ordinary Unity player builds.

## Verified API documentation

- Unity 2022.3 assembly definitions: https://docs.unity3d.com/ja/2022.3/Manual/ScriptCompilationAssemblyDefinitionFiles.html
- Unity 2022.3 asset import APIs: https://docs.unity3d.com/cn/2022.3/ScriptReference/AssetDatabase.html
- Unity 2022.3 project manifest: https://docs.unity3d.com/ja/2022.3/Manual/upm-manifestPrj.html
