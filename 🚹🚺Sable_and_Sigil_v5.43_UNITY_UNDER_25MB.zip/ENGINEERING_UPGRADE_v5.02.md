# Sable & Sigil v5.02 — Relic manipulation and evidence comparison

## Contract and compatibility

- Base: v5.01; target Editor: Unity 2022.3.62f3.
- Keep all artwork, Unity asset GUIDs, assembly definitions, authored solution data, persistence and puzzle progression unchanged.
- This is a complete **source candidate**, not a Unity-compiled or device-verified build.

## Runtime additions

1. `Assets/_Project/Runtime/ChapterWorldExplorer.cs` now tracks both evidence GameObject transforms, authored rest quaternions, and independent yaw angles per open location.
2. A focused relic can be rotated 22.5 degrees using `TURN RELIC LEFT` and `TURN RELIC RIGHT` and restored with `RESET RELIC`. Invalid requests, nonfinite angles, increments exceeding 45 degrees, inactive cases, and modal overlays are rejected without mutation. Rotation wraps through a full turn while preserving the original quaternion and ornament/collider relationship.
3. `COMPARE CLUES` is disabled before inspection and allows side-by-side viewing of *only* the examined evidence transcript(s), independently of the authored reference image. Unknown evidence stays hidden. A dedicated `CLOSE COMPARISON` action restores the stage; comparisons never collect clues or submit a deduction.
4. The existing original-art modal, camera focus, collision layers, case-completion semantics, resource cleanup, asset references and saved data contracts remain unchanged.

## Verification

- Added a PlayMode NUnit regression inside the existing `ChapterWorldExplorerPlayModeTests` fixture, covering locations 1, 3, 7 and 10; camera focus, rotation, invalid inputs, inspection gating, hidden clues, both modal types, scene teardown and reopened-case isolation.
- Updated the SHA-256 fingerprint of that reviewed PlayMode fixture in `Verification/EXPECTED_NUNIT_FIXTURES_v494.json` without increasing fixture count.
- Added `verify_relic_interaction_v502.py` and mutation regression suite `test_relic_interaction_v502.py`; registered the new static gate with the suite runner.
- Updated acceptance baseline to v5.02 so Windows-generated Unity evidence is attributed to the correct source.

## Constraints and release blockers

- No Windows Unity Editor or Android toolchain is present in the execution environment.
- `COMPILE_VERIFIED=false`; `EDITMODE_VERIFIED=false`; `PLAYMODE_VERIFIED=false`; `ANDROID_BUILD_VERIFIED=false`; `DEVICE_VERIFIED=false`.
- Do not use the delivered source for commercial release before `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` and device verification pass on Unity 2022.3.62f3.

## Primary engine reference

- Unity 2022.3 `Quaternion.AngleAxis`: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Quaternion.AngleAxis.html
