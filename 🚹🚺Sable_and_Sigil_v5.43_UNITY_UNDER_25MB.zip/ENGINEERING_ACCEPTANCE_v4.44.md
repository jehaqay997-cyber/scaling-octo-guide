# TheOrderRoom v4.44 — Source Acceptance and Runtime Blockers

## Scope

This update is based directly on the v4.43 source archive. It is a source candidate, not a demonstrated Unity or Android release.

## Source code change

- `Assets/_Project/Runtime/OrderGame.cs`: reuse a single `PointerEventData` for UI/world hit arbitration while its `EventSystem` remains current; reset its transient data for each query; safely allocate a new instance on an event-system change; fail closed when UI input routing is absent or disabled; release cached references on destruction.
- `Verification/ui_pointer_allocation_gate_v444.py`: source regression contract.
- `Verification/test_ui_pointer_allocation_gate_v444.py`: five tests including four failure-mode mutations.
- `Verification/run_full_static_audit_v443.py`: registers the v4.44 check in the aggregate audit.

The change reduces a known per-query managed allocation in input routing. No numerical GC reduction is claimed without Unity Profiler measurements.

## Executed evidence

- 95 of 95 Python unit tests passed.
- 18 of 18 source gates passed; the aggregate includes the Python regression suite as an additional execution stage.
- Existing archive contents preserved, excluding only regenerated and temporary local verification products.
- Final ZIP archive and SHA-256 integrity manifest verified after packaging.

## Blocking verification requirements

1. Use the editor version recorded by `ProjectSettings/ProjectVersion.txt` (2022.3.62f3). Compatibility with Unity 6.3.28f1 is not established.
2. Execute `Verification/Run-UnityVerification.ps1` to prove first-import bootstrap, compilation, EditMode and PlayMode results. Do not classify unexecuted tests as passed.
3. Execute the script with `-BuildAndroid` and verify that a development APK is produced after passing the checks.
4. Install and interactively test on Android: mouse/touch gestures, UI interception, save recovery, undo/redo, focus changes, screen ratios, GC allocations and frame pacing.
5. Preserve raw Unity Editor and Android logs for audit trail and triage.

## Release decision

`SOURCE_STATIC_VERIFIED = TRUE`, `UNITY_COMPILE_VERIFIED = FALSE`, `UNITY_TEST_VERIFIED = FALSE`, `DEVICE_VERIFIED = FALSE`. Not approved for production distribution.
