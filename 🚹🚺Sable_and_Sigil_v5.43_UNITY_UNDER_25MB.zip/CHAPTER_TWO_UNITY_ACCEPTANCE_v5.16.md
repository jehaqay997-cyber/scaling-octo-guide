# Sable & Sigil — Chapter Two Unity Acceptance v5.16

## Compatibility and evidence policy

Editor: **Unity 2022.3.62f3**. Candidate: **v5.16**. This is a source candidate, **not** a successful Unity build or Android release. Run all acceptance steps in a local, non-synchronized Windows project directory. Do not confuse Python static-audit pass results with Unity compilation or NUnit execution.

## 1. Import and compile

1. Extract the complete v5.16 archive, open its root in Unity 2022.3.62f3, and resolve all package/assembly references without changing `.meta` GUIDs.
2. Confirm no C# compiler errors. Validate Runtime, Domain, NUnit EditMode and PlayMode assemblies.
3. Execute `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the project root. Preserve the generated logs and JSON evidence outside the source folder. Do not claim a test passed solely because it exists in the fixture inventory.

## 2. Play all four Chapter Two sites

| Site | Physical clue | Unsolved relief | Restored relief | Authoritative answer |
|---|---|---|---|---|
| 03 — The Lantern Ascent | Lunar phase calendar | New, waxing, missing phase, waning | Full moon occupies missing phase | Full Moon |
| 04 — The Rose Pavilion | Petal sequence | Counts 2, 3, 5, 8, empty fifth | Final flower displays 13 petals | 13 |
| 05 — The Fountain of Echoes | Spout ordering | First and fourth levels shown; middle hidden | Height order 1–3–2–4 | 1–3–2–4 |
| 06 — The Silent Crossing | Witness compass route | East, south, west; final route hidden | Route motif South–East–West | South–East–West |

For **each** site, visually confirm that the new relief faces the player, appears in the world, contains no visible missing polygons, and never intercepts the evidence pedestals. Confirm the relief does **not** gain its completed geometry after a wrong answer. Press the in-world backplate **before** inspecting both evidence fragments: the mechanism must remain locked. Inspect fragments A and B, tap the backplate again, and confirm the **same** viewer as the HUD button opens. Try an incorrect choice and three hints; then choose the correct answer. Confirm the relief changes once, the same `Mesh` instance is retained, the material changes to the restored state, and deduction becomes available only after verifying the mechanism. Reopen the site and confirm that all transient state resets.

## 3. Tests and coverage

- **EditMode:** Run `ChapterTwoMechanismTests` and `ChapterTwoReliefMeshTests`. Confirm each location has a unique, front-facing, finite, bounded mesh; invalid location/mesh inputs are rejected; rebuilding does not replace the Mesh instance; and the authored hints/answer contract remains unchanged.
- **PlayMode:** Run `ChapterTwoWorldPlayModeTests`, specifically `PhysicalMechanismCannotOpenBeforeEvidenceAndNeverBypassesUiGuard`. Verify 8 owned meshes per Chapter Two site, no collider on the decorative relief itself, no mesh/material count growth after the correct answer, and correct cleanup on Close.
- **Regression:** Run the complete Unity test suite. Chapter One, text dossiers, gallery unlock rules, save/load, pointer and modal behavior must remain unchanged.

## 4. Graphics, UI and Android

Test 16:9 landscape and taller mobile aspect ratios. Check the world plate is physically tappable without hitting the wrong UI button, including at camera yaw limits. Inspect decorative backfaces, texture quality, visible occlusion, readability of each plaque, lights, and image framing. On the target Android device, test touch, pinch, screen rotation, memory release after repeated site loads, average and worst frame time. Record actual metrics rather than target numbers.

## Required evidence

| Gate | Status before editor execution |
|---|---|
| Source static audit | See `Verification/STATIC_EVIDENCE_v516.json` |
| Unity C# Compile | NOT VERIFIED |
| Unity EditMode | NOT EXECUTED |
| Unity PlayMode | NOT EXECUTED |
| Android device | NOT EXECUTED |

A failed gate blocks release and must be corrected from the actual error logs. No Android build or editor success is implied by this document.
