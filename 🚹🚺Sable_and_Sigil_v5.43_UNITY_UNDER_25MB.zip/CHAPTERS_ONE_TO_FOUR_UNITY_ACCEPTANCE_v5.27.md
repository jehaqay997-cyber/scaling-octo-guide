# Sable & Sigil v5.27 — Four-Chapter Unity Acceptance

**Required Unity Editor:** 2022.3.62f3. This is a source candidate, not a Unity-verified release.

## Execution

1. Extract the entire ZIP to a local, writable Windows directory. Keep the project outside synchronized placeholders and backup the existing saves before opening.
2. Open the extracted directory in Unity 2022.3.62f3. Resolve Package Manager and any Safe Mode compiler errors before proceeding. Do not delete or regenerate existing `.meta` files.
3. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the extracted project, or invoke `Verification/Run-SableAcceptance.ps1` with an explicit verified Unity editor path.
4. Confirm the generator has created `Assets/_Project/Scenes/ChapterOne.unity`, `ChapterTwo.unity`, `ChapterThree.unity`, `ChapterFour.unity`, and `Main.unity` and registered them exactly once in the expected enabled build order.
5. Confirm previously existing chapter scenes are rejected if they contain the wrong bootstrap, multiple galleries, missing scripts, or unsaved edits. This check must never silently overwrite an existing scene.
6. Run EditMode and PlayMode NUnit tests and retain their complete XML reports and Editor.log. Validate in particular `ChapterFourWorldPlayModeTests.MissingReliefDuringCommittedSwapFailsClosedWithoutAwardingProgress`.
7. Manually play each of the ten location puzzles: evidence inspection, wrong and correct choice, staged disclosure, hints, camera focus, Back behavior, world-to-dossier grant, restart, and save reload. Inspect every world mesh and HUD element for occlusion, alignment, touch targets, and text truncation.
8. Verify chapter locks, case completion, cross-scene navigation, persistence monotonicity, asset unloading, and graphical appearance on supported aspect ratios.
9. Build an Android APK only after the Unity scene and test gates pass. Capture device logs, touch behavior, thermal/memory profiling, orientation and process-resume behavior.

## Failure criteria

- Any C# compile error, missing assembly/package, scene-import issue, unavailable `Resources` image or unresolved `.meta` GUID.
- Any NUnit failure, skipped mandatory fixture, unexpected Unity exception, stale scene, input bleed-through or duplicate reward/commit.
- Any mismatch between physical puzzle state and rendered relief that still permits a dossier handoff.
- Any case handoff error that leaves a partially active modal or consumes a reusable grant.
- Any asset or save regression, unexpected build order, or Android launch failure.

## Verification boundaries

The source has passed offline regressions and integrity checks, but no Unity Editor, EditMode, PlayMode, scene-generation, screenshot, frame-time, Android build or device evidence has been executed in this delivery. Do not label `COMPILE_VERIFIED`, `TEST_VERIFIED`, or `DEVICE_VERIFIED` as true until their actual signed results are available.
