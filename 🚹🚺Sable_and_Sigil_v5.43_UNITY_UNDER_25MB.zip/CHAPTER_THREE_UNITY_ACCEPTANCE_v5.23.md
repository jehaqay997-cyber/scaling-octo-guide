# Chapter Three Unity Acceptance — v5.23

**Required Editor:** Unity 2022.3.62f3
**Baseline:** v5.22
**Candidate:** v5.23
**Chapter Three cases:** 07 / The Glass Testament; 08 / The Hall of False Light; 09 / The Weeping Witness.

## 0. Source provenance and installation

- Extract all files from the v5.23 source ZIP to a local writable Windows directory. Do not omit `.meta` files or open a cloud-placeholder project.
- Verify the `MANIFEST_v5.23.json` and `MANIFEST_v5.23.sha256` source inventories, as well as the release ZIP SHA-256.
- Open with **Unity 2022.3.62f3**. Resolve required packages and preserve `packages-lock.json` and the Package Manager log created by the real Editor.
- Generate the required `Assets/_Project/Scenes/Main.unity` and `ChapterOne.unity` with the existing Editor acceptance tooling. Do not regard source-side scene generation code as proof that scene generation succeeded.

## 1. Compile and test inventory

- Require zero Unity C# compile errors. Confirm both Chapter Two and Chapter Three `TextMesh` world captions compile and display.
- Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` with Unity closed. Preserve preflight/editor logs, all NUnit XML results and verification JSON.
- Confirm **all** EditMode and PlayMode fixtures are discovered and executed, not merely hashed. Pay particular attention to `ChapterThreeMechanismTests`, `ChapterThreeReliefMeshTests`, `ChapterThreeWorldPlayModeTests`, `ChapterArtGalleryTests`, and `StoryDossierPlayModeTests`.
- Check the two added tests: `ChapterThreeAtlasGatePreservesOnlyCompletedCaseReview` and `ChapterThreeUnfinishedCaseCannotBypassPhysicalMechanismFromAtlas`.

## 2. Physical mechanism and dossier entry — each of locations 07–09

1. Prepare a valid save with all preceding case files completed and the target case unlocked, but the target case not yet completed.
2. Select the location from the atlas. `EXPLORE 3D` must be available; `OPEN CASE FILE` must be **disabled** and display **SOLVE 3D MECHANISM**.
3. Verify that invoking the underlying case-file click callback or direct dossier `Open()` cannot bypass the disabled state or write a save.
4. Open the 3D world. Inspect only one relic and attempt to open the mechanism: it must remain locked. Inspect the other relic and open the mechanism.
5. Submit an incorrect option. Verify one attempt increment, no completion, no gallery transfer, and no saved deduction.
6. Submit the authored correct option. Verify the owned 3D relief transitions from locked to investigating to restored, without changing Mesh identity or creating colliders/material leaks.
7. Select **OPEN DEDUCTION**. The gallery must open the dossier with both evidence fragments already inspected. Commit the dossier's correct deduction **once** and confirm the save ledger revision advances once.
8. Return to the atlas and revisit the completed location: the case-file button must now display **REVIEW CASE FILE** and permit read-only review. Check that reopening and closing does not advance the save revision.
9. Test both relic-inspection orders, loss of focus, Back/Escape, overlay stacking, camera pan/zoom bounds, and closing/re-entering an unfinished investigation. Each new world visit must start with transient mechanism state reset without losing durable completed cases.

## 3. Stability and regression

- Repeat the first-time path for locations 07, 08 and 09, in that order, validating the sequential case dependency graph. The dossier-first workflow for Chapters One and Two must remain unchanged.
- Check both touch input and mouse on Windows. Inspect 16:9 and Android aspect ratios, safe areas, line wrapping, art crop, lighting, GPU frame times, memory, allocations, and device-specific back behavior.
- Capture gameplay screenshots for the three mechanism states and attach actual Editor test/log evidence. Do not infer performance or visual quality from Python static tests.

## Current verification matrix

| Verification gate | Status at source delivery |
|---|---|
| Offline source regression tests and static audit | Evidence attached separately |
| SHA-256 manifest and patch replay | Evidence attached separately |
| Unity C# compile | NOT EXECUTED |
| Unity EditMode NUnit execution | NOT EXECUTED |
| Unity PlayMode NUnit execution | NOT EXECUTED |
| Scene import and visual QA | NOT EXECUTED |
| Physical Android test | NOT EXECUTED |
| Release approval | BLOCKED |
