# Sable & Sigil v4.94 — Complete NUnit Fixture Provenance and Fail-Closed Acceptance

## Baseline and scope

The immutable source baseline is `Sable & Sigil v4.93` targeting **Unity 2022.3.62f3**. This release modifies only source verification, acceptance tooling and regression tests. Chapter logic, ten location artworks, four chapter artworks, puzzle rules, persistence, C# runtime assemblies, `.asmdef`, and existing Unity `.meta` files are preserved byte-for-byte.

## P0 finding

The v4.93 Editor acceptance script required only **14 of 71** authored EditMode fixture classes and all six PlayMode fixture classes. The other **57 EditMode fixtures** could disappear from the Unity NUnit XML without failing the v4.93 mandatory-fixture test, even if the reported remaining cases were all passed. Aggregate test totals alone cannot prove discovery completeness.

## Implemented remediation

1. `Verification/EXPECTED_NUNIT_FIXTURES_v494.json` is a reviewed, complete source manifest covering 71 EditMode and six PlayMode fixture classes. Each entry includes an exact relative source path, namespace and SHA-256 of the authored `.cs` file.
2. `Read-VerifiedFixtureInventory` rejects missing or added `.cs` files, modified fixture source, duplicate class identities, malformed paths, invalid namespaces, incorrect Unity versions, and reductions below the reviewed 71/6 baseline.
3. `Assert-NUnitEvidence` checks exact namespace-qualified fixture prefixes, case-by-case pass status, the total test count, skipped and inconclusive counts, and duplicate or unnamed test-case identities. All **77** fixture classes must appear in the actual NUnit XML of the correct test stage.
4. Unity acceptance reports the fixture-inventory SHA-256, both fixture counts, and the SHA-256 of the two NUnit result XML files. The outer acceptance gate independently checks the reported hashes and counts against the local files.
5. The Unity runner removes all three previous stage logs before a new attempt so stale bootstrap or test evidence cannot be reused.
6. The original 14 EditMode and six PlayMode fixture assertions remain as backward-compatible guards, with complete-manifest validation added on top. The historical v4.93 audit contract now recognizes the new source-baseline identifier `v4.94`.
7. `Verification/verify_test_inventory_v494.py` and its negative mutation tests reject missing tests, extra tests, changed file hashes, altered namespaces, missing runner invocation, absent XML integrity checks and stale-log reuse.

## Executed verification outside Unity

- **343 / 343 Python `unittest` cases passed.**
- **49 / 49 standalone static source gates passed**, recorded by individual process exit codes and output.
- All source checks are reproducible from the delivered archive. An independent re-extraction verification is performed before delivery.
- Previous v4.93 project members remain present; only the specifically reviewed verification files are modified.

## Explicitly unverified

`COMPILE_VERIFIED = false`, `EDITMODE_VERIFIED = false`, `PLAYMODE_VERIFIED = false`, `ANDROID_BUILD_VERIFIED = false`, and `DEVICE_VERIFIED = false`.

There is no Unity Editor executable or Android toolchain in the development container. A valid external test result must originate from Unity 2022.3.62f3 itself, not from Python or a fabricated NUnit XML.

## Operating procedure on Windows

1. Extract the complete ZIP into a local non-synchronized folder; do not open the same folder from two Editor processes.
2. Install or use **Unity 2022.3.62f3** with the required modules and enable a graphics-capable context for PlayMode.
3. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the project root. Preserve all the resulting `.log`, `editmode-results.xml`, `playmode-results.xml`, `verification.json`, and `sable-acceptance.json` files under the sibling `SableSigilVerification` directory.
4. Require exactly 71 or more reviewed EditMode fixture classes, all six PlayMode fixture classes, successful full NUnit results, and valid source/fixture/result hashes before promoting compile and test status.
5. Run `RUN_SABLE_ANDROID_BUILD_GATE.cmd` only if Editor acceptance succeeds, and separately test gameplay and saved progress on a physical Android device.

## Primary technical contracts

- Unity Test Framework 1.1.33: https://docs.unity.cn/Packages/com.unity.test-framework%401.1/manual/reference-command-line.html
- Unity 2022.3 Editor CLI: https://docs.unity.cn/2022.3/Documentation/Manual/EditorCommandLineArguments.html
