# TheOrderRoom v4.50 — Verified Play-Mode Entry Contract

## Scope

This candidate incrementally hardens v4.49's automatic Unity editor launch without replacing Domain, persistence, campaign, input, or presentation systems.

## Confirmed defect addressed

Previously `OrderFirstImportSetup` set the launch-completed session flag immediately after assigning `EditorApplication.isPlaying = true`. That assignment requests a Play Mode transition; it does not prove that Unity entered Play Mode. Compilation, assembly reload, scene corruption, or a canceled transition could lead to false successful startup state.

## Implemented changes

- Subscribe to Unity's documented `EditorApplication.playModeStateChanged` event.
- Persist an explicit pending-launch flag in `SessionState` before requesting Play Mode.
- Only mark startup complete after `PlayModeStateChange.EnteredPlayMode`, an active integrated Main scene, and an existing `OrderGame` component.
- On an invalid active scene, exit Play Mode and allow bounded recovery after returning to Edit Mode.
- On a failed return to Edit Mode, clear pending status and schedule only remaining retries.
- Clear pending state on an exception or explicit manual retry.
- Strengthen the previous static gate and add mutation-focused regressions for premature success, callback removal, missing game-object validation, and missing pending state.

## Evidence and limitations

Run `python Verification/run_full_static_audit_v443.py` to reproduce source checks. All gates and tests run as subprocesses and are logged under `Verification/LocalResults/` (excluded from this release archive). The tests examine Python contract logic and static C# source, **not actual Unity C# compilation**.

A separate Windows machine with the project's pinned Unity version 2022.3.62f3 must run `OPEN_GAME.cmd` and `Verification/Run-UnityVerification.ps1 -BuildAndroid` for executable confirmation. Inspect Unity Console and result XML, then test the application on Android before any release declaration.

The Main.unity scene is still generated on first import. There is no claim that a valid serialized Unity scene or APK is present in this archive.

## Reference standards and official APIs

- Unity 2022.3 Scripting API, `PlayModeStateChange.EnteredPlayMode`: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PlayModeStateChange.EnteredPlayMode.html
- Unity 2022.3 Scripting API, `EditorApplication.playModeStateChanged`: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/EditorApplication-playModeStateChanged.html
- NIST SP 800-218 SSDF v1.1 (evidence-driven secure development): https://csrc.nist.gov/pubs/sp/800/218/final

## Independent acceptance status

| Gate | Status |
|---|---|
| ZIP integrity / individual hashes | Checked by release packaging script |
| Offline Python regression suite | Passed |
| Offline source gate suite | Passed |
| Unity compilation | NOT EXECUTED |
| Unity EditMode / PlayMode | NOT EXECUTED |
| Android build / device | NOT EXECUTED |

No 10/10 score or production-ready designation is implied by static checks.
