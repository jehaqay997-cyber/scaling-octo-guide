# Sable & Sigil — v5.08 Chapter One Interactive Crest Engineering

**Unity target:** 2022.3.62f3  
**Parent:** v5.07  
**Scope:** first Threshold location only  
**Status:** source candidate; no verified Unity compilation, PlayMode, or Android device run.

## Implemented in current source

1. Six directly clickable diagram targets with 52×52 virtual-pixel hit rectangles, one per altered crest ray. Both the diagram targets and the existing six central buttons call `TrySelectThresholdRay`; their state is derived from the original `ThresholdCrestPuzzle` in the pure C# Domain, never duplicated. Added clear visual selection feedback to the diagram targets and kept informational text for non-color-only feedback.
2. First-location-only `TryFocusCrest()` camera inspection; `IsCrestFocused` reflects transient view state and is cleared on return, switch to evidence focus, and Close. Focus does not inspect evidence, solve the seal, or write a save. Artwork/comparison/crest modals block this camera action.
3. One owned front-facing crest-stud mesh containing 11 diamond ornaments (44 vertices, 22 triangles) placed in both original and altered ray patterns. The studs are non-colliding scenery with no lights, gameplay authority, or per-frame allocation. The original two owned crest ring meshes remain intact.
4. Additional Unity EditMode geometry and PlayMode UI/camera/feedback tests, including negative-state assertions. Updated the cryptographic NUnit fixture fingerprints without altering tests for other chapters.
5. Kept the chapter-one original artwork and every existing image, Unity scene, `.meta`, assembly definition, and package file byte-identical to v5.07. Other nine locations still use their original 3D configuration.

## Evidence and limits

- Python mutation and source regression suite: 545/545 passed before packaging.
- Static gates: 62/62 PASS. Evidence is in `Verification/STATIC_EVIDENCE_v508.json`. The first 53 gates ran in one process group until the invocation deadline; the remaining nine passed in a separate invocation.
- Independent numeric oracle: 11 studs, 44 vertices, 22 non-degenerate front-facing triangles; direct target minimal center separation 67.3657047737 virtual px vs target width 52 virtual px. This is a source-side numerical check, NOT Unity rendering or Unity C# execution.
- `DESIGN_VERIFIED`: source-level design and static invariants checked, with actual rendering still pending.
- `COMPILE_VERIFIED`: FALSE. `EDITMODE_VERIFIED`: FALSE. `PLAYMODE_VERIFIED`: FALSE. `DEVICE_VERIFIED`: FALSE. The editor was not available in this container.

## Exact first-location Unity acceptance protocol

1. Extract the complete ZIP to a local NTFS directory with free space. Open the project in Unity Editor 2022.3.62f3 without changing its `.meta` GUIDs, and run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`. Capture the Unity log and EditMode/PlayMode XML; the source-level PASS statuses do not imply these tests passed.
2. Chapter atlas → first location → `EXPLORE 3D`. Verify unchanged photographic backdrop, four Gothic stair treads, two brass-edged rings, one combined 11-stud ornament mesh and three owned lights. Verify zero colliders on reliefs/studs and no new interactive scene objects beyond six existing arch ray colliders.
3. Press `FOCUS CREST`. Verify the camera frames the two crest plaques; `InspectedCount` remains zero, and the deduction button remains locked. `RETURN TO OVERVIEW` and focusing A or B must clear crest focus.
4. With no fragments inspected, selecting a physical arch ray must return `EvidenceRequired`. Inspect evidence A only; verify the deduction and seal remain locked. Inspect evidence B; open `EXAMINE CREST LOCK`.
5. Tap diagram target 4 (index 3) directly; its marker and the matching 3D ray must turn red, with one attempt. Tap diagram target 5 (index 4); the corrected marker and 3D ray must turn green and the rejected ray return to brass. A further tap must not increase attempts or replace the verified ray.
6. Ensure `OPEN DEDUCTION` is disabled before the valid seal, and enabled after it. Open the original dossier and verify it receives both inspected fragments and retains its own independent answer validator.
7. Close/reopen the chapter-one world; visual state, inspected count, selection count, focus, meshes and temporary objects must reset. Verify locations two through ten still open and unload with the preexisting seven-mesh budget. Test touch accessibility and frame pacing on physical Android hardware before release.

## Unity primary documentation used

- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Renderer-sharedMaterial.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/UI.Button-onClick.html
