# Sable & Sigil v5.24 — Three-Chapter Integration Closeout Candidate

**Source baseline:** v5.23; **required Unity Editor:** 2022.3.62f3.
**Status:** Static-source verified, editor compilation and on-device verification not executed.

## Implemented corrections

- Chapter I/II/III incomplete case files now require the verified physical 3D mechanism before first deduction. Completed cases remain reviewable. Chapter IV is unchanged.
- `ChapterGalleryView.EnterSelectedChapter` routes unlocked Chapter II and III entries to their next available 3D location. Chapter I continues to enter the authored narrative scene. A chapter-case scene's Back action loads Chapter One instead of closing onto an empty scene.
- Chapter-to-dossier transfer now uses `WorldInvestigationGrant`, an ephemeral, location-scoped, one-use capability minted only after `ChapterWorldExplorer.Finish` passes the physical mechanism and evidence gates. The world callback alone no longer conveys authorization via raw Boolean flags.
- The gallery records the dossier checkpoint revision at world entry. A changed revision at handoff blocks use of the grant, without performing a save or rolling back an already committed dossier.
- `ChapterCaseSceneBuilder` non-destructively creates and imports separate Chapter Two and Chapter Three Unity scene assets, preserving existing scenes, then installs `[ChapterOne, ChapterTwo, ChapterThree, Main]` in Build Settings.
- `ChapterCaseSceneBootstrap` initializes the chapter-specific gallery, with an active EventSystem when necessary. Scene validity is inspected in `SableLaunchAcceptance` before the success marker is emitted.
- Android build scene inclusion is sourced from the validated enabled Build Settings list, rather than Chapter One alone.
- The EditMode test assembly explicitly references `TheOrderRoom.Editor` for editor integration tests. New EditMode and PlayMode fixtures cover scene order, chapter entry, physical handoff, and single-use grants.
- Added a fail-closed static gate and mutation tests; updated historical checkers to recognize the stronger contract instead of requiring obsolete dossier-first behavior.

## Known limits

The Unity C# compiler, Editor scene serialization, NUnit runner, graphical frame rendering, and Android device tests have **not run in this environment**. New `.unity` scenes are created by Unity during acceptance; no generated scene is included or claimed to have been tested in this ZIP. The Chapter II/III scenes provide connected case-investigation entry points; this is not a claim that bespoke production-quality 3D environments or a complete art pass are finished. The original art, save codec and historical `.meta` identifiers have been preserved.

See `CHAPTERS_ONE_TO_THREE_UNITY_ACCEPTANCE_v5.24.md` for the executable acceptance protocol. The source is a candidate for Unity validation, not a release-verified product and not a measured 99% completion percentage.
