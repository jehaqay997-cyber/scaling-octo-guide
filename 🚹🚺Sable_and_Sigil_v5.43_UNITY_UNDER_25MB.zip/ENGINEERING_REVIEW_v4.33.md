# TheOrderRoom v4.33 — Restoration Atomicity Review

## Root-cause defect (P0)

In `Assets/_Project/Domain/OrderBoard.cs`, `RestoreCore` iterated through a saved dictionary but never inserted any entry into the candidate dictionary. The subsequent `ValidateSnapshot` therefore received an empty candidate and rejected every complete non-empty save snapshot. This affected load/recovery and all staged gameplay actions using `Restore`, including `Place`, `Undo`, and `Redo`. Previous source-only gates did not detect it.

## Correction

Each item is now checked for null, unknown identity, or duplicate identity, then copied into a private candidate dictionary; only after complete snapshot validation are the authoritative locations, counts and weights replaced. Failed restoration leaves board revision and outstanding transfer tickets unchanged. Successful restoration increments the revision and clears outstanding tickets.

## Regression evidence

- Added five Unity NUnit cases in `BoardRestoreAtomicityTests.cs`: valid restore, tray restore, rejected restore atomicity, ticket invalidation and item identity rejection.
- Added an offline source-order guard with three deliberate mutation checks and a current-source passing case. This guard **does not substitute for executing C# tests**.
- Previously supplied governance, architecture, camera, integration, lifecycle, layout and gesture gates were re-executed.
- This candidate preserves the original v4.32 archive files, changing one existing source file and adding documentation and tests.

## Verification boundaries

| Gate | Evidence |
| --- | --- |
| ZIP CRC and contents | Executed, passed |
| Historical code preservation | Verified by SHA-256 comparison |
| Python gates | Executed, passed |
| Python mutation tests | Executed, passed |
| C# compilation | **Not run**: Unity/.NET SDK unavailable |
| NUnit tests | **Not run** |
| Unity scene and Android device | **Not run** |

No claim is made that all vulnerabilities are closed. Do not publish this candidate before compiling with the configured Unity editor and running both EditMode and PlayMode tests, plus an actual save/restore session.

## References

- Unity Test Framework: https://docs.unity.cn/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html
- Microsoft Dictionary APIs: https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.dictionary-2.tryadd
