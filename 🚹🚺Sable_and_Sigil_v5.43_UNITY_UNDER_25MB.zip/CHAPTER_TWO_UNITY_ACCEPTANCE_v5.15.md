# Chapter Two Unity Acceptance — v5.15

Target Unity Editor: **2022.3.62f3**. Candidate: **Sable & Sigil v5.15**.

## Gate A — Import and compile

1. Extract the complete ZIP into a local, non-synced Windows folder.
2. Open its project root in Unity 2022.3.62f3.
3. Ensure all project packages resolve and Console has zero C# compiler errors.
4. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the project root and retain its output logs.
5. Confirm assembly definitions for Domain, Runtime, EditMode, and PlayMode, and NUnit discovery.

## Gate B — EditMode

Run all EditMode tests, including `ChapterTwoMechanismTests`.
Confirm four contracts, evidence gating, invalid selection, bounded hints, idempotence, and state reset.

## Gate C — PlayMode

Run all PlayMode tests, including `ChapterTwoWorldPlayModeTests`.
For **each** of locations 03, 04, 05, 06: verify correct image, procedural 3D set, evidence A/B, locked deduction, a blocked premature puzzle viewer, wrong-choice feedback, clue-only hints, correct-choice physical inlay change, and deduction unlock on viewer close.

Test atlas progression: resolve location 02, then 03 -> 04 -> 05 -> 06, and confirm location 07 unlocks only through the existing dossier session rules. Test replay and cancellation with no leaked scene objects.

## Gate D — Visual/UX and Android

Visually inspect the world diagram and original art in landscape mode, including camera orbit, readability, contrast, screen safe areas, font clipping, touch targets and overlapping HUD controls at 16:9 and taller ratios.
Measure frame time and memory on the target Android device. No verified metrics are available from this source-only review.

## Gate evidence recording

| Gate | Result | Evidence path |
|---|---|---|
| Source integrity | Pending final packaging record | See engineering report |
| Python source tests | Pending final packaging record | See independent verification JSON |
| Unity Compile | NOT EXECUTED | |
| Unity EditMode | NOT EXECUTED | |
| Unity PlayMode | NOT EXECUTED | |
| Android device | NOT EXECUTED | |
