# Sable & Sigil v4.62 — Chapter Atlas Coherence and Texture Residency

## Scope

This change is based on the complete v4.61 project archive. It does not rename assembly definitions, regenerate Unity asset GUIDs, alter the chapter checkpoint format, claim that conceptual locations are playable, or replace the user-approved environment imagery.

## Confirmed defects and corrections

1. **Cross-chapter navigation mismatch**: Choosing location 7 (Chapter III) after browsing another chapter displayed Chapter III location art but kept the previous chapter selected. `ChapterGalleryView.SelectLocation` and `NavigateLocation` now synchronize the chapter index from the single `LocationChapters` mapping. Mapping inputs are range checked by `GetChapterForLocation`.
2. **Retained hidden chapter image**: Switching to the atlas displayed a location image while the previously selected chapter texture remained held in the gallery's chapter cache. The atlas branch now attaches the incoming location texture and then releases the no-longer-displayed chapter texture. This preserves the image ownership and keeps chapter and atlas image residency mutually exclusive.

## Evidence collected

- `python -m unittest discover -s Verification -p 'test_*.py' -q`: **196 tests passed**.
- `python Verification/run_full_static_audit_v443.py`: **35/35 maintained gates passed plus the full Python regression suite** (36/36 tasks).
- New gate: `Verification/chapter_atlas_coherence_gate_v462.py`.
- New mutation tests: `Verification/test_chapter_atlas_coherence_gate_v462.py`, five checks including negative mutations.
- Two additional PlayMode tests in `Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs`: invalid location mapping and mutually exclusive chapter/location texture ownership.
- No new Unity assemblies or asset GUID changes.

## Release acceptance status

- Source integrity and offline contracts: **STATIC_PASS_ONLY**.
- Unity C# compilation: **NOT EXECUTED**.
- Unity EditMode/PlayMode tests: **NOT EXECUTED**.
- Android build, GPU memory and battery measurements: **NOT EXECUTED**.
- Main scene is editor-generated. Its actual first-import behavior has not been verified here.

## Next required executable evidence

Run the existing `Verification/Run-UnityVerification.ps1` script under the project-locked Unity `2022.3.62f3` editor with Android modules installed if Android output is requested. Preserve editor logs, NUnit EditMode/PlayMode XML, build report, on-device frame timing, memory profiler captures, and device logs. Review failed tests before release promotion. Do not infer device or battery success from the static test results.

## Source references

- Unity 2022.3 API, Resources.UnloadAsset: https://docs.unity3d.com/cn/2022.3/ScriptReference/Resources.UnloadAsset.html
- Unity 2022.3 manual, UI and safe area: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Screen-safeArea.html
- OWASP SAMM requirements-driven testing: https://owaspsamm.org/model/verification/requirements-driven-testing/
- NIST SSDF SP 800-218: https://csrc.nist.gov/pubs/sp/800/218/final
