# TheOrderRoom v4.43 — Release Artifact Integrity Engineering Review

## Scope and preserved architecture

The full Unity source is carried forward from v4.42. Domain, AppCore,
Infrastructure, Runtime, Editor, EditMode tests and PlayMode tests remain in their
existing assemblies. The project settings remain pinned to Unity 2022.3.62f3.
No C# gameplay code, save schema, generated GUID, Unity assembly definition,
or game level content was changed in this release-engineering update.

## Corrected release-publishing defect

The previous runner used the final APK filename before validating its payload
and source integrity. A partial or unsuccessful build could leave a misleading
file under the deliverable name.

The runner now:

1. Requires an empty output slot for both the staged and final APK.
2. Directs the Android Unity build to a staging filename in the output folder.
3. Checks the staged APK is nonempty and a valid ZIP containing the Android
   manifest and at least one DEX entry.
4. Requires the Unity build marker and successful upstream EditMode/PlayMode stages.
5. Verifies both authored-source and generated-output SHA-256 maps.
6. Promotes the staged APK to its final name using File.Move within one directory.
7. Re-inspects the published artifact and records its SHA-256 and size.
8. Removes the staging artifact on failure, and removes only an APK created by
   this run if a later final integrity check fails.
9. Fails the command and records a failing JSON report for rejected releases.

This is an artifact publication safeguard, not an Android application security
certificate. The validation still does not verify package signatures, DEX
semantics, device compatibility, runtime stability, or deployment readiness.

## Verification performed in this environment

- Original v4.42 ZIP integrity: PASS (495 entries, no corrupted entries).
- Current offline gate set: 17/17 PASS in isolated subprocesses.
- Current Python regression suite: 90/90 PASS, including the seven new
  release-promotion mutations and three audit-runner coverage checks.
- Offline governance source inventory: 7 assembly definitions, 104 C# files,
  143 Unity GUIDs, no reported missing metadata or assembly dependency errors.
- Independent restricted adventure model: 20 reachable states, 34 transitions,
  3 victory states, zero softlocks in its intentionally narrow scope.
- New archive and its SHA-256 manifest are verified independently.

## Verification NOT performed

- Unity Editor C# compilation: NOT_RUN.
- Unity EditMode and PlayMode NUnit execution: NOT_RUN.
- PowerShell execution (pwsh/Windows PowerShell not installed): NOT_RUN.
- Android APK build and device tests: NOT_RUN.
- Frame time, GC, memory, battery and thermal profiling: NOT_RUN.
- Production signing, store publishing and market compliance: NOT_RUN.

## Review disposition

SOURCE_STATIC_VERIFIED only. This is a complete source candidate ready to be
opened and tested with the pinned Unity editor; it is not an approved
production build. If Windows verification fails, preserve Editor.log, NUnit
XML, the runner JSON report, and Android build logs. Do not bypass a failed gate.

## Authoritative references

- Unity 2022.3 Editor command-line reference:
  https://docs.unity3d.com/2022.3/Documentation/Manual/EditorCommandLineArguments.html
- Unity Test Framework command-line reference:
  https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html
- Microsoft FileStream.Flush(Boolean) reference:
  https://learn.microsoft.com/en-us/dotnet/api/system.io.filestream.flush
- NIST Secure Software Development Framework (SP 800-218):
  https://csrc.nist.gov/pubs/sp/800/218/final
