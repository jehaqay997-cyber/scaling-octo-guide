# Sable & Sigil — Chapter One Unity Acceptance (v5.13)

**Compatibility:** Unity Editor **2022.3.62f3**. This is a complete-source *acceptance candidate*, not an approved player build. Perform the steps below on the extracted project, not inside the ZIP or a cloud-synced placeholder folder.

## Automatic acceptance

1. Close any running Unity instance that already has this project open.
2. Extract the ZIP to a short, writable local path with available disk space.
3. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the project root. It invokes `Verification/Run-SableAcceptance.ps1` and must return exit code zero.
4. Preserve the new `SableSigilVerification` directory created beside the project. Require `sable-acceptance.json`, `bootstrap.log`, `editmode-results.xml`, `playmode-results.xml`, and `verification.json` to agree on a passing result. A zero script exit without passing test results is **not** an acceptance.
5. Open this same project in Unity 2022.3.62f3. Use **Sable & Sigil > Prepare and Validate Playable Chapter**, then enter Play Mode. The actual scene and camera must be visually reviewed; passing static tests alone does not certify rendered quality.

## Chapter One end-to-end checks

| Stage | Action | Expected acceptance evidence |
|---|---|---|
| 01 | Open **The Threshold of Vey** from the atlas and enter **EXPLORE 3D** | Gothic reference image, 3D camera, both evidence relics and controls appear without Console errors |
| 02 | Attempt **OPEN DEDUCTION** immediately | Remains locked; no dossier progress or save mutation |
| 03 | Inspect evidence A and B, then open **EXAMINE CREST LOCK** | Original five rays, altered six rays; wrong choices rejected |
| 04 | Use up to three optional crest hints; select the additional sixth ray | Hint requests do not grant completion; correct ray verifies the crest and changes its 3D material |
| 05 | Test focus, zoom, touch and one physical blocker between camera and relic | No snap/teleport, tapping the blocker must not inspect the concealed relic; UI cannot rotate the world behind a modal |
| 06 | Open deduction dossier and solve the location-1 case | The progression ledger commits location 1 exactly once; location 2 becomes available |
| 07 | Enter **The Spiral of Testimony** | Both evidence relics, 3D stair balusters and the photographic location reference are visible |
| 08 | Try stair puzzle before checking both clues | Interaction is locked, no hint or bypass available |
| 09 | Inspect both clues, open stair pattern | Six visual tile slots: circle, diamond, star, circle, diamond, missing |
| 10 | Attempt circle, diamond and crescent | All rejected; dossier remains locked; the star is not displayed in the missing slot |
| 11 | Request each optional hint, then select **STAR** | Third hint is final; missing slot displays a star; the **existing** 3D mesh switches from **71 vertices / 174 indices** to **66 vertices / 180 indices** without creating another mesh or collider |
| 12 | Close the stair modal and open the dossier; submit the correct deduction | Only after the physical star repair and both inspected clues does deduction become available; second case completion unlocks chapter 2 |
| 13 | Exit/reopen location 2 | Puzzle, attempts, hint tier and original unsolved 3D stair mesh reset; durable dossier evidence remains in the approved save ledger |
| 14 | Test back, resume, orientation and safe area | Atlas returns, no hidden active cameras, no clipped buttons on the target Android aspect ratio |

## Blocking defects

Any failure to compile, missing/duplicate asset GUID, test failure, empty camera, missing image, wrong ray or star choice, premature deduction, modal input leakage, visual 3D desynchronization, save corruption, memory growth after repeated open/close, or Android input/frame-time regression prevents release approval. Capture the Unity Console, log files, screenshots, and device details for each failure.

## Verification truth table

- `DESIGN_VERIFIED`: source-oriented, static and mathematical checks completed where documented.
- `COMPILE_VERIFIED`: **NO**, requires the real Unity Editor compiler log.
- `EDITMODE_VERIFIED`: **NO**, requires passing Unity NUnit XML.
- `PLAYMODE_VERIFIED`: **NO**, requires passing Unity NUnit XML and a visual playthrough.
- `DEVICE_VERIFIED`: **NO**, requires real Android installation and device evidence.
- `RELEASE_APPROVED`: **NO**.

The request for *99% readiness* is treated as a production target, **not a measured or validated percentage**. No automated offline audit can establish this percentage or guarantee that only one Unity test will remain.
