# TheOrderRoom v4.42 — Release Engineering & Provenance Policy

## Decision

SOURCE_CANDIDATE. Not production-verified. A source archive, static verification,
unit-test sources, and an Android build script are not substitutes for Unity
compilation, executed EditMode and PlayMode tests, device validation, and a
signed production build.

## Source of truth

- The repository `ProjectSettings/ProjectVersion.txt` fixes the Unity Editor
  compatibility version. The runner checks the **actual editor binary** using
  the documented `-version` argument, before project import.
- `Packages/manifest.json` records package requirements. The lockfile is created
  by Unity's package resolution, then fingerprinted for the test stages.
- Every `.asmdef`, `.meta`, and Unity asset is treated as authored content except
  strictly enumerated bootstrap outputs. Unity-generated caches are ignored by
  version control; `.meta` and authored assets are retained.

## Release controls

1. Run source provenance, GUID, assembly graph, and contract checks.
2. Enforce exact Unity binary version **before opening the project**.
3. Bootstrap and validate scene and required event components.
4. Run all EditMode tests; require XML, positive test count, zero failures,
   zero skipped tests, and successful process exit.
5. Repeat for PlayMode in a separate process.
6. Optionally build a development Android APK only after both test stages pass.
   Inspect nonempty APK as a ZIP package containing AndroidManifest.xml and
   at least one classes*.dex file; record the SHA-256 digest.
7. Reject source changes during any of these steps. Save full logs and reports.
8. On-device testing, signed production delivery, performance budgets, and
   platform security review are independent release prerequisites.

## Constraints

- Only maintain one owner of mutable board state (`OrderBoard`).
- Invalid saved snapshots must not mutate the authoritative board.
- Failed session restoration must not create a writable fresh game silently.
- UI/world input cancellation must be explicit across focus and touch loss.
- No production claim is permitted without evidence for compiler, NUnit,
  PlayMode, Android build, and actual device checks.

## Reference standards

- Unity Editor command-line arguments, Unity 2022.3: `-version`, `-batchmode`,
  `-runTests` (Unity Test Framework), and `-buildTarget Android`.
- Unity BuildPipeline.BuildPlayer / BuildReport: require success and inspect
  its output independently.
- NIST SP 800-218 SSDF 1.1: software component provenance and security
  verification. These practices are **guidance**, not a formal compliance claim.

## Known environment gaps

Unity Editor, PowerShell, C# compiler, Android toolchain, and a device have not
been executed in this review environment. PowerShell edits are therefore not
syntax- or runtime-validated here. The APK entry checks are additional basic
structural validation, not proof of installation, signing, security, or quality.

## User execution

On Windows with the exact Editor and Android modules installed:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1 -BuildAndroid
```

The local result file is `Verification/LocalResults/verification.json`.
