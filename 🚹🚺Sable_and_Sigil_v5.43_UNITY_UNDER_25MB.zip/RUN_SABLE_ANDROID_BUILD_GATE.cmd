@echo off
setlocal
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0Verification\Run-SableAcceptance.ps1" -ProjectPath "%~dp0." -BuildAndroid
if errorlevel 1 (
    echo Android build acceptance blocked. Inspect the generated verification logs.
    exit /b 1
)
echo Android build gate passed. Physical device validation remains required.
exit /b 0
