# Sable & Sigil v5.14 — Chapter One Input Integrity

**Baseline:** v5.13. **Unity target:** 2022.3.62f3. **Scope:** chapter-one UI, its 3D explorer, interaction acceptance tests, and the active offline verification contract.

## Defects resolved in source

1. The standalone ChapterOneExperience modal backdrops did not cover the full canvas. Root HUD commands outside the modal rectangle could still receive pointer events, potentially replacing the current panel. The inspection modal explicitly overrode its own anchors and compounded this issue.
2. Several root commands could be invoked while a modal was active. Opening lens inspection or restarting the chapter during an active modal risked confusing the interaction state. All entry points now check the same modal condition.
3. World-camera drag cancellation was limited to locations 1 and 2. Later authored locations could continue a drag after crossing the interactive HUD or camera viewport boundary.
4. Two-finger pinch zoom and mouse wheel input did not share the exact same viewport-and-UI eligibility check as tap/drag input. The single predicate now gates all world pointer actions.

## Implemented changes

- `ChapterOneExperience.cs`: one null-safe `IsModalActive` condition; full-canvas raycast intercepting backgrounds for all three popups; prevent root hint, inspection, cipher, restart and chapter gallery interactions while any popup is active. World hotspot polling skips all active popups.
- `ChapterWorldExplorer.cs`: `IsWorldPointerAllowed(Vector2)` checks `sceneCamera.pixelRect` and UI raycast; used by pressed, held, released, pinch and wheel paths; cancels drag outside the world for every location. No additional world objects, colliders, materials or textures allocated.
- `ChapterOneSceneTests.cs`: new PlayMode regression for full-screen modal anchors, raycast target, hidden-command isolation and unchanged progress when blocked.
- `ChapterWorldExplorerPlayModeTests.cs`: new PlayMode regression for released and held gestures outside viewport at locations 1, 2, 3 and 10.
- `Verification`: updated previous offline contracts to the stronger common input guard; registered an additional fail-closed v5.14 source gate and mutation test suite; renewed the affected NUnit fixture fingerprints and current acceptance source baseline.

## Offline evidence (NOT Unity execution)

- 621 / 621 Python unittests passed in the working source.
- 68 / 68 offline source gates passed.
- Unity Editor compilation: **NOT VERIFIED**.
- EditMode/PlayMode execution: **NOT EXECUTED IN UNITY**.
- Rendered appearance/physical touch performance: **NOT VERIFIED**.

## Required remaining acceptance

Use `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` on a writable, fully extracted folder, then execute the linked v5.14 Unity acceptance checklist. Record actual Unity Console errors, EditMode and PlayMode NUnit XML, and the two location walkthrough results. An offline source audit cannot establish production readiness or a measured 99% completion percentage.
