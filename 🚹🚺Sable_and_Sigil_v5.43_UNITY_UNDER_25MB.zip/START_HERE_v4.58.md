# Sable & Sigil — Unity First Launch (v4.58)

1. Extract the entire ZIP to a local Windows folder with a short ASCII path.
2. Use Unity Editor **2022.3.62f3** as recorded in the project's ProjectVersion.txt.
3. Run OPEN_GAME.cmd from the project root. The script validates the version before launching Unity.
4. Allow project import and automatic ChapterOne.unity creation. Play launch is only confirmed when the chapter is enabled and ready.
5. If auto-launch fails, inspect Unity Console and use TheOrderRoom > Retry Automatic Game Launch.
6. Run Verification/Run-UnityVerification.ps1 with -BuildAndroid after installing required Android modules.

The chapter art and ten location references are 1280x720 aspect-safe JPEG assets. Locations 2–4 remain art/reference concepts, not implemented gameplay.

No Unity execution is asserted by the offline source audit. See ENGINEERING_ACCEPTANCE_v4.58.md.
