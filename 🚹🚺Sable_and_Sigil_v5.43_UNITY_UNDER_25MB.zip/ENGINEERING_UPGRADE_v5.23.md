# Sable & Sigil v5.23 — Chapter Three Case Entry Authority Closeout

**Base source:** v5.22
**Unity compatibility target:** 2022.3.62f3
**Delivery:** Complete source candidate, not an Editor-certified or Android-certified release.

## P0 fixed — The Chapter Three physical mechanism could be skipped

In v5.22, the location atlas offered `OPEN CASE FILE` for any unlocked investigation, including Chapter Three locations 07–09. The case-file interface allowed a player to inspect two textual fragments and commit the correct deduction without solving the new physical world mechanism. This bypass rendered the Chapter Three 3D investigation optional despite the explicit `ChapterWorldExplorer.CanDeduce` requirement. A disabled button alone would not be sufficient: the atlas callback and `StoryDossierView.Open()` were independently callable.

In v5.23, the access policy is enforced in three places:

1. `ChapterGalleryView.CanOpenDossierFromAtlas(location, completed)` permits Chapter Three atlas entry **only for already completed cases**. Chapter One, Chapter Two and Chapter Four retain their existing dossier-first entry policy.
2. `ChapterGalleryView.Refresh()` sets `caseFileButton.interactable` from the same policy, displaying `SOLVE 3D MECHANISM` for an unlocked but unfinished Chapter Three case.
3. `ChapterGalleryView.OpenDossier()` independently checks the policy; a direct or queued button callback cannot bypass the disabled button. `StoryDossierView.Open()` also refuses first-time Chapter Three entry; a completed case can still be reopened for review.

The intended first-time transition is unchanged: the player opens `EXPLORE 3D`, inspects both independent evidence relics, solves the Chapter Three location-specific mechanism, and chooses `OPEN DEDUCTION`. `ChapterWorldExplorer.Finish(true)` requires the authoritative `CanDeduce` predicate, which includes both evidence fragments and `chapterThreePuzzle.IsVerified`, before calling the gallery. The gallery uses the separate `StoryDossierView.OpenFromWorldEvidence` entry point to import the already inspected fragments into the dossier UI. Durable story progress is committed only via `StoryDossierSession.TrySubmit`.

No changes were made to the authored answers, evidence text, story-save schema, scene artwork, Unity `.meta` GUIDs, or Chapter One/Two world puzzle logic.

## Regression coverage

- PlayMode `ChapterThreeUnfinishedCaseCannotBypassPhysicalMechanismFromAtlas`: loads the genuine prefix checkpoint through the normal PlayerPrefs-backed repository, confirms Chapter Three is unlocked but cannot be opened from the atlas, exercises a queued button callback, verifies the `StoryDossierView.Open` fail-closed guard, exercises the valid world-evidence handoff, and confirms that a completed case can subsequently be reviewed. Original PlayerPrefs slots are restored in `finally`.
- PlayMode-independent `ChapterThreeAtlasGatePreservesOnlyCompletedCaseReview`: validates the policy at every authored location, checks both completed/incomplete cases, and rejects out-of-range location IDs.
- `verify_chapter_three_atlas_gate_v523.py` and its independent mutation tests audit the actual atlas callback, button state, `StoryDossierView` public entry, world-evidence transfer, world `CanDeduce`, and current acceptance baseline.
- The full PlayMode test fixture SHA-256 inventory is updated to cover both modified test sources. New Unity tests are **authored but not executed** in this environment.

## Scope and remaining acceptance

Source integrity, Python tests, static gates, manifest and patch replay are verified separately from Unity. **Unity compilation, NUnit EditMode and PlayMode execution, generated scene import/rendering and a physical Android device test have not been performed.** The source archive does not include an Editor-generated `packages-lock.json` or pre-generated production `.unity` scenes; their generation and successful import must be proven in Unity.
