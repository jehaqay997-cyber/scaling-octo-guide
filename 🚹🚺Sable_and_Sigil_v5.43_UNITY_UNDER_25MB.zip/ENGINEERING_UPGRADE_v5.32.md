# Sable & Sigil v5.32 — Progression, Security, Narrative and Artwork Hardening

Review date: 2026-11-22. Direct parent: v5.31. Exact Unity target: **2022.3.62f3**.

This archive contains a complete Unity source project candidate. All verification outside the Unity Editor is **source-level only**. No Unity C# compilation, NUnit EditMode/PlayMode, Android build, memory profiler, audio listening, display-device or battery test was run in this environment. No ISO, NIST, Google Play or Unity release certification is claimed.

## Implemented fixes

| Priority | File or component | Implemented change | Risk addressed |
| --- | --- | --- | --- |
| P0 | `Assets/_Project/Domain/StoryDossierPersistence.cs` | On an ambiguous checkpoint write or flush failure, the active dossier session fails closed while retaining its previous in-memory revision. Reopening via the recovery action re-reads authoritative storage. | Duplicate/stale case commits and on-screen progress differing from durable state |
| P0 | `Assets/_Project/Domain/StoryDossierPersistence.cs` | Two simultaneously valid rotating checkpoints must have identical or adjacent revisions; nonconsecutive revisions are rejected without deletion. | Conflicting or skipped history hidden by otherwise valid digests |
| P0 | `Assets/_Project/Runtime/ChapterGalleryView.cs` | Added `RETRY SAVE RECOVERY` control, visible only while the story session is unavailable. It invokes `TryReload`, logs failure types and refreshes the interface; save recovery does not fabricate achievements or reset evidence. | Permanent in-session dead end after failed save |
| P1 | `Assets/_Project/Runtime/ChapterGalleryView.cs` | Block chapter and location selection while a dossier modal retains the image reference. | Invalidation of displayed artwork by `Resources.UnloadAsset` during case review |
| P1 | `Assets/_Project/Runtime/StoryDossierView.cs` | Scales evidence, question and answer text down within bounded readable sizes; catches nonessential gallery callback failures after a successful durable commit. | Truncated clues and a presentation exception after committed progress |
| P1 | `Assets/_Project/Runtime/CampaignNarrative.cs` | Four chapter-specific closing lines, revealed only when the corresponding investigation chapter is fully complete. | Inconsistent chapter transitions or premature spoiler display |
| P1 | `Assets/_Project/Editor/SableReferenceArtworkImport.cs` | New deterministic JPEG import settings: no CPU-readable texture copy; compression; mipmaps retained for oblique 3D artwork, clamp wrap and trilinear filtering. | Avoidable CPU-side texture memory and inconsistent importing across machines |
| P1 | `Verification/verify_story_continuity_art_v532.py` | Original JPEG reference presence, bounds, format and dimensions (four chapters + ten scenes), new source contracts, and modal/recovery protections. | Missing or altered imagery and regressions in continuity |
| P1 | `Assets/_Project/Tests/EditMode/StoryDossierTests.cs` | Authored regression tests for failed-flush reconciliation and nonadjacent checkpoints; tests have **not** been executed in Unity. | Persistence bugs returning after refactoring |
| P1 | `Assets/_Project/Tests/EditMode/CampaignNarrativeTests.cs` | Authored bounds and content tests for the four narrative chapter closures; Unity execution pending. | Invalid story index or missing chapter text |

## Artwork inspection and limitations

All 14 game reference JPEGs were individually checked at 1280×720, and all 42 original image resources were decoded during package verification. Some location art contains intentional blurred side panels around a vertically composed photograph. The original artist-provided image bytes, `.meta` GUIDs and dossier answers are preserved. This version improves **import configuration and presentation memory safety**, not the artistic detail of those paintings or the generated 3D geometry. Measurements of VRAM, GPU render time or visual fidelity must use the Unity Profiler and real target devices.

## Story, puzzle and state consistency

- All ten authored cases, correct answers, prerequisite links and physical puzzle rules are unchanged; the visual editor scenes are generated at first Unity launch, as before.
- Chapter codas are derived from the existing validated `ChapterInvestigationProgression` and appear only after the chapter is complete; they are not a second mutable progression store.
- The new save-failure guard deliberately leaves the original session revision untouched. The explicit recovery button re-reads the two existing checkpoint slots, without overwriting or deleting a damaged save.
- The new pairwise revision check may reject previously altered files with an implausible multi-step gap. When rejected, the save slots remain intact for manual recovery; this is a deliberate fail-closed tradeoff.

## Verification and evidence

The prepackaged source passed **903/903 Python tests** (including **16 new** mutation tests) and **87/87 individually executed source-gate commands**. SHA-256, ZIP CRC, all archive entries and original `.meta` GUIDs are independently verified after extraction. These are static and structural results, not Unity test results.

The original verified NUnit fixture inventory remains complete. Two existing C# NUnit fixtures were edited, their SHA-256 entries updated, and the manifest is checked by the existing static validation. **New NUnit tests have only been authored, not executed.**

## Remaining release blockers

- **P0:** `COMPILE_VERIFIED = false`: open using Unity 2022.3.62f3 and capture actual successful C# import and compilation logs.
- **P0:** `TEST_VERIFIED = false`: generate Main and Chapter One–Four scenes, execute and save full EditMode and PlayMode NUnit XML. Ensure all ten investigations and durable save recovery pass on the real runtime.
- **P0:** `ANDROID_BUILD_VERIFIED = false`: confirm API 36, ARM64 IL2CPP, signed AAB, package alignment and 16 KB native library support using the official Android tools; Unity 2022.3 toolchain compatibility is not presumed.
- **P0:** `DEVICE_VERIFIED = false`: Android 15/16 hardware checks for cold start, background/resume, chapter loading, image lifetime, voice output, 4 KB/16 KB page sizes, crashes, cutouts and Google Play compatibility.
- **P1:** A genuine Unity Package Manager `packages-lock.json` must be generated by Unity; none was invented or bundled by the audit.
- **P1:** Application ID retains `com.theorderroom.game` until a deliberate app identity and save migration decision is made.
- **P1:** October 2026 Editor/package security advisories remain subject to official patched Editor and package availability; these source changes do not patch the Unity Editor.
- **P1:** Texture GPU memory, battery/thermal measurements, artistic realism, UI readability, procedurally generated 3D scenes and speaker sound remain unmeasured.

## Acceptance sequence

1. Extract to a writable local folder outside cloud-sync and open in the **exact Unity 2022.3.62f3 Editor**. Leave Package manifest pinned.
2. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`, capture Console/editor logs, verify successful import, all five generated scenes and required NUnit XML.
3. Use the Story Dossier to test case commit, reload, simulated save faults and recovery button. Verify that a failed save never grants a case or loses original checkpoint bytes.
4. Inspect all 14 reference pictures and case text at landscape resolutions, tall/cutout screens, Android 16 edge-to-edge and UI navigation.
5. Profile 10+ scene transitions on a representative Android device; record VRAM, managed heap, native allocations, audio playback and energy/thermal measurements. No performance improvement is claimed without before/after evidence.
6. For distribution, run the Google Play publication gate and official Android SDK/bundletool checks on a **real signed release AAB**. Keep the release blocked until passing evidence exists.

## Original official documentation carried forward

- Unity Android 2022 Gradle compatibility: https://docs.unity3d.com/2022.3/Documentation/Manual/android-gradle-overview.html
- Unity Android environment: https://docs.unity3d.com/2022.3/Documentation/Manual/android-sdksetup.html
- Unity October 2026 Brotli advisory: https://unity.com/security/unity-brotli-decoder-vulnerability
- Unity October 2026 certificate advisory: https://unity.com/security/unity-emudhra-compromise
- Android 16 KB page sizes: https://developer.android.com/guide/practices/page-sizes
- Google Play target API: https://support.google.com/googleplay/android-developer/answer/11926878
- NIST SSDF: https://csrc.nist.gov/pubs/sp/800/218/final

Status: `SOURCE_STATIC_TESTS = PASS`; `COMPILE_VERIFIED = NOT_EXECUTED`; `TEST_VERIFIED = NOT_EXECUTED`; `DEVICE_VERIFIED = NOT_EXECUTED`; `RELEASE_APPROVED = false`.
