# TheOrderRoom v4.46 — First-Open Game Delivery

## Objective

A player must see a playable game rather than an empty Unity default scene when opening the project. The deliverable includes a **Unity editor auto-launch fix** and a **separate immediate browser gameplay preview**.

## Source changes

- `Assets/_Project/Editor/OrderFirstImportSetup.cs`: session-once launch after import and compilation, batch isolation, error reporting, active scene validation, Game tab focus, and automatic Play Mode entry.
- `Assets/_Project/Editor/OrderProjectBootstrap.cs`: open the integrated scene even if another scene was dirty only after a non-destructive save confirmation; add `TheOrderRoom/Play Integrated Game` menu fallback.
- `PLAY_GAME_NOW.html`: standalone offline interactive browser puzzle with 12 chambers, artifact placement, tap and mouse drag, hints, Undo/Redo, reset, progress saving.
- `Verification/first_open_game_gate_v446.py`, `Verification/test_first_open_game_gate_v446.py`: static launch contracts and mutation tests.
- `Verification/run_full_static_audit_v443.py`: include the new gate.

## Verification

- JavaScript parsed using Node.js v22.
- Python offline gates succeeded; 114 Python regression tests passed.
- ZIP CRC and SHA-256 manifest verified independently.
- Unity Editor / C# compiler / Android SDK are not installed in the execution environment: Unity import, compile, real PlayMode, and Android build **NOT VERIFIED**.
- Headless Chromium rendering did not complete in this environment, so browser visuals were not independently screenshot-verified. The browser preview JavaScript is syntax-validated but not device-tested.

## Engine compatibility

The project's declared version remains `Unity 2022.3.62f3`. The first-opening hooks deliberately do not run in Unity batch mode or when the user opted out. The auto-launch does not bypass compilation errors, failed scene validation, or consent for unsaved scene changes.

## No false equivalence

The HTML game is a companion prototype intended to show an immediate playable representation. It is not a Unity scene, Android binary, or identical gameplay implementation.
