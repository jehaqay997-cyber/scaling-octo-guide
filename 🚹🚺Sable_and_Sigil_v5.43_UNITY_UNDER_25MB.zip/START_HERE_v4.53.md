# Sable & Sigil v4.53 — Opening and Reviewing the Chapter Gallery

- Project editor target: Unity `2022.3.62f3`.
- Extract the ZIP to a local folder on Windows, outside cloud-synced paths.
- Run `OPEN_GAME.cmd` (or open the extracted project folder in Unity Hub).
- The first-import bootstrap creates and opens `Assets/_Project/Scenes/ChapterOne.unity` when Unity import succeeds. This scene is not embedded in the archive.
- Enter Play Mode, then select **CHAPTERS** in the HUD to view four linked 1280x720 images.
- Chapter I is implemented as a playable prototype. Chapters II-IV are labelled concept previews; no interaction or navigation into them is implemented.
- `Verification/run_full_static_audit_v443.py` is the maintained offline audit. It now includes `chapter_art_linkage_gate_v453.py`.
- Use `Verification/Run-UnityVerification.ps1` to execute Unity compile, EditMode and PlayMode with recorded results; optional `-BuildAndroid` requires Android modules.
- Review `Design/CHAPTER_ART_DIRECTION_v4.53.md` and `Design/CHAPTER_VISUAL_CATALOG_v4.53.json` for art asset mapping.
- Do not claim Unity compile, rendered artwork, Android gameplay or device acceptance based on the offline checks alone.
