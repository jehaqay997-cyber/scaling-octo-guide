# Sable & Sigil v5.05 — First Chapter Physical Crest Puzzle

**Target:** Unity 2022.3.62f3  
**Baseline:** v5.04  
**Delivery classification:** Unity Editor compile and PlayMode candidate, **not release verified**.

## Implemented first chapter vertical-slice mechanic

The Threshold is the opening investigation (location 1). Lady Vey's five-ray letter and the arch's six-ray seal now have distinct, constructed 3D crest geometry. The reference has five rays at 0, 72, 144, 216 and 288 degrees. The arch has the same five rays plus one added at 252 degrees. This correspondence comes from the authored case and its five-versus-six evidence counts. It does not introduce an alternative answer authority.

Players can examine both original relics, compare clues, and identify the inserted ray either by clicking one of six collidable 3D rays or by opening a touch-accessible six-choice seal panel. Wrong rays produce non-punitive feedback and do not end the session. The mechanical confirmation enables the existing four-choice dossier deduction only **after both evidence fragments have been inspected**. The dossier still owns its answer evaluation and durable progress. The mechanic itself never writes a save.

The new first-room requirement does not affect deductions in locations 2–10. Restarting or leaving the room resets the physical lock with the other temporary inspection state.

## Source design and ownership

- `Assets/_Project/Domain/ThresholdCrestPuzzle.cs` — pure C# finite-state mechanism with immutable source/arch angle lists, bounded indices and attempt counter, idempotent verification and reset. No Unity dependencies.
- `Assets/_Project/Runtime/ThresholdCrestRayMarker.cs` — single-purpose `MonoBehaviour` index marker on six touchable world-ray colliders. New unique `.meta` GUID.
- `Assets/_Project/Runtime/ChapterWorldExplorer.cs` — first-location-only 3D geometry, event routing, touch-friendly overlay, evidence and modal guards, and visual feedback. Keeps existing camera, artwork, comparison and save boundaries intact.
- `Assets/_Project/Tests/EditMode/ChapterWorldSceneCatalogTests.cs` — five new authored NUnit tests for geometry identity, input rejection, wrong attempts, successful idempotence and session reset.
- `Assets/_Project/Tests/PlayMode/ChapterWorldExplorerPlayModeTests.cs` — new first-location PlayMode integration test, existing chapter navigation test updated for the physical lock, and an explicit alias for `UnityEngine.Object` to avoid `System.Object` ambiguity.
- `Verification/verify_threshold_crest_v505.py` — fail-closed static code and story linkage gate.
- `Verification/test_threshold_crest_v505.py` — seventeen mutation checks. All offline verifications remain explicitly distinct from Unity execution.
- `Verification/EXPECTED_NUNIT_FIXTURES_v494.json` — reviewed SHA-256 fingerprints for altered NUnit fixtures. Keeps **71 EditMode + 6 PlayMode source fixtures**.
- `Verification/Run-SableAcceptance.ps1` and source contract gates — source baseline updated to v5.05.

## Limitations and next verification step

This is a **source-level prototype** with authored low-poly 3D geometry. No source-created `.unity` production scene, professional art package, raster image replacement, Android build, GPU benchmark or Unity Editor test execution is claimed. `Main.unity` and `ChapterOne.unity` remain generated via the bundled Unity acceptance tool.

On Windows, extract the project outside synchronized folders and use **Unity 2022.3.62f3**, then execute `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` with the editor closed. Capture logs and XML NUnit evidence. Manually inspect selection colliders and ray legibility at target screen sizes before production approval.

Official Unity scripting references: 
- https://docs.unity3d.com/2022.3/ScriptReference/Physics.Raycast.html
- https://docs.unity3d.com/2022.3/ScriptReference/Object.Destroy.html
