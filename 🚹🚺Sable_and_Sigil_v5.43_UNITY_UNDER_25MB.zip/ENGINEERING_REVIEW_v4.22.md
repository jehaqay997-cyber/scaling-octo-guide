# TheOrderRoom v4.22 — Engineering Governance Review

## Scope and provenance

- Base: v4.21 integrated candidate; preserved the previous Unity project and source tree.
- Source changes: `AdventureJournalStore.cs` now validates the complete persisted transition chain; new `AdventureJournalHistoryRegressionTests.cs` covers four cases.
- Added deterministic source-governance gate and file hash inventory.
- This package is a **candidate**, not a compiled or device-tested release.

## Root cause: unverified historical revisions (P0 integrity)

Previously `TryReadLocked` verified that all record file names existed, but only checked the latest record payload/checksum. A damaged older record could be ignored while a later valid record was accepted. The replacement verifies the genesis record, all SHA-256 digests and legal transitions from revision zero onward, rejecting any broken chain. Source changes have not been validated by a C# compiler in this environment.

The SHA-256 checks detect corruption but are not authentication: a user with write access can recompute hashes. Full history scanning increases read cost to O(number of revisions) small fixed-size records; this is a bounded initial design with MaxEntries=10,000. Compaction/secure key management need a separate verified design before increasing that bound.

## Architecture review / outstanding release gates

- P0: Unity editor compilation, NUnit execution, scene generation and real play session remain unverified. ProjectVersion is `2022.3.62f3`; never assume Unity 6 migration passed.
- P0: Current scene is generated after import, not stored as a reproducible serialized `Main.unity` asset. Verify generated scene references and automation with Unity batch mode.
- P1: `AdventureJournalStore` is not yet the active game save store. `OrderSaveStore` is a separate runtime persistence system; integration and transaction coordination remain open.
- P1: Power profile / GPU / memory / audio / 16:9–21:9 touch safety not measured on device; static analysis cannot establish leak-free operation.
- P1: Journal digest is not tamper-proof; verified transition history protects accidental corruption and noncompliant saves, not intentional forging of a valid chain.
- P1: Legacy `UnityEngine.Input` is in use while `com.unity.inputsystem` is installed. ProjectSettings currently permits input compatibility; audit before Unity 6 migration.
- P1: Pure assembly boundaries currently isolate Domain and AppCore but gameplay and UI responsibilities are still coupled in `OrderGame` and the Editor bootstrap. Plan a migration to scene-composition root/services after M0.

## Reproduce

1. `python Verification/governance_gate.py`
2. `python Verification/verify_v4_21.py` (historical baseline checker)
3. Open Unity project in the editor version recorded in `ProjectSettings/ProjectVersion.txt` and run compilation + EditMode tests.
4. Run Android playthrough and Unity Profiler/Memory Profiler/battery thermal measurements before marking device verified.

## Verification level

Governance and independent mathematical model checks are build-independent only; `COMPILE_VERIFIED`, `TEST_VERIFIED`, `DEVICE_VERIFIED` remain false. New NUnit test methods are authored but not executed.
