# Sable & Sigil v5.18 — Chapter Two Unity Acceptance

**Target:** Unity 2022.3.62f3. **Locations:** 03–06. This is a test plan, not executed evidence.

## Source restoration and compilation

1. Extract the full project archive to a dedicated local Windows folder. Keep Unity projects out of live cloud-synchronization folders during import.
2. Launch the project in Unity 2022.3.62f3. Validate package import, unique `.meta` GUIDs and assembly dependencies. Record every console error, not just the first visible one.
3. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the project root. Preserve the raw Editor.log, EditMode and PlayMode NUnit XML, and acceptance JSON under an external output directory.
4. Confirm Unity C# compilation, valid graphics shaders, camera initialization, scene cleanup and all inventoried test fixture classes.

## Chapter Two four-site regression

For each of **03 The Lantern Ascent**, **04 The Rose Pavilion**, **05 The Fountain of Echoes** and **06 The Silent Crossing**:

1. Open with zero inspected evidence. Verify the deduction and mechanism gates are locked.
2. Test the `FOCUS MECHANISM` button, scene rotation, zoom bounds 4.3–8.8 and return to overview. Focus must not grant evidence.
3. Inspect evidence A and B, enter and exit clue comparison, inspect original artwork and verify that both textures and full art are unchanged.
4. Open the corresponding physical mechanism, try a wrong answer, reveal hints, then select the correct answer. Verify the world relief updates in place, deduction becomes available and callbacks are single-shot.
5. In the mechanism modal press Android Back or Escape: the modal closes but the puzzle result, hints and attempts persist. Repeat with original art and comparison. In focus mode the first Back restores overview; a further Back returns to the atlas without committing dossier progression.
6. Run the authored deduction independently, then reopen the site and confirm transient attempt, hint, focus and inspection state resets.

## Android Back delivery checks

- Verify the Android operating system dispatches Back to the app rather than auto-backgrounding it; inspect the platform's `backButtonLeavesApp` behavior and active input backend. The implementation does not modify global input settings.
- Verify Escape in the Editor and Android Back on a device for both legacy and Input System configurations supported by the project. The presence of the source handler does not prove device dispatch.
- Check both system navigation styles (three-button Back and gesture navigation when available). Ensure there is no duplicate callback, unintentional application exit or unintended dossier completion.
- Confirm on-screen `RETURN TO ATLAS`, `RETURN TO OVERVIEW` and modal CLOSE still work when no hardware Back event is supplied.

## Visual/performance release gates

Inspect all four relief motifs, original images, shaders and lighting in 16:9 and tall handset aspect ratios. Record draw calls, memory/GC trends over repeated load/unload, frame times, lifecycle pause/resume events and device logs. No unmeasured performance improvement should be claimed.

## Evidence flags before Unity execution

| Gate | State |
|---|---|
| Python source regressions | 692/692 PASS |
| Offline static gates | 72/72 PASS |
| Unity compile | NOT VERIFIED |
| Unity EditMode NUnit | NOT EXECUTED |
| Unity PlayMode NUnit | NOT EXECUTED |
| Android Back/device validation | NOT EXECUTED |

**Release state:** Candidate only; open defects and logs must be reconciled before production approval.
