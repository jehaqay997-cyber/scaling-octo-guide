# Sable & Sigil v4.64 — Engineering Acceptance

## Scope and source baseline
- Source: the verified v4.63 project archive (661 files).
- All v4.63 files retained. No C# class, namespace, assembly or save key renamed.
- Unity Editor target remains 2022.3.62f3. No Unity Editor or Android runtime is available in the execution environment.

## Confirmed defects and fixes
1. **Fallback main camera ownership** (`Assets/_Project/Runtime/ChapterOneExperience.cs`): When no camera exists, the generated main camera was not parented under the chapter. The camera and its AudioListener could remain after chapter object deletion. The fallback camera is now chapter-owned before its Camera component is attached. Existing scene cameras are not reparented.
2. **PlayMode test persistence contamination** (`Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs`): The lens GPU lifecycle test collected clues, producing real PlayerPrefs checkpoints without restoring them. The test now captures both checkpoint slots before scene load and restores their exact key presence and values in `finally`, including after assertions fail.
3. **Runtime lifecycle acceptance**: Added a PlayMode assertion that a generated main camera belongs to the chapter and is removed with it.
4. **Release governance**: Added an independent static contract gate with four mutation-focused tests, and registered it in the full audit runner.

## Evidence collected here
- Python unittest discovery: **206/206 passed**.
- Unified static audit runner: **38/38 steps passed** (37 static gates plus Python regression suite).
- Source ZIP integrity and per-file SHA-256 hashes: generated and independently rechecked.
- Baseline preservation: 661 previous entries retained; no empty files shipped.

## Explicit unverified stages
- UNITY_COMPILE_VERIFIED: false
- EDITMODE_VERIFIED: false
- PLAYMODE_VERIFIED: false (new PlayMode tests are authored, not executed)
- ANDROID_BUILD_VERIFIED: false
- DEVICE_PERFORMANCE_VERIFIED: false

## Acceptance actions in Unity
1. Use the project-recorded Unity Editor 2022.3.62f3.
2. Run `Verification/Run-UnityVerification.ps1` on Windows with an installed Unity Test Framework. Inspect Editor, EditMode and PlayMode logs.
3. Verify chapter starts and camera count returns to zero after chapter root destruction.
4. Test PlayerPrefs checkpoint content before/after the lens PlayMode test.
5. Run Android build, then profile memory, FPS and temperature on a real Android phone.

## References
- Unity 2022.3 PlayerPrefs reference: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PlayerPrefs.html
- Unity 2022.3 Object.Destroy reference: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Object.Destroy.html
- Unity Test Framework command line: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html
- NIST SSDF: https://csrc.nist.gov/pubs/sp/800/218/final
