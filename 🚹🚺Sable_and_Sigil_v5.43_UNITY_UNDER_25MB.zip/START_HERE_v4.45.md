# TheOrderRoom v4.45 — Inspection Candidate

Open the directory containing `Assets`, `Packages`, and `ProjectSettings` with
Unity Hub using Unity 2022.3.62f3. Allow first-import scene creation to finish.

Run the PowerShell verifier from the project root:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1
```

For optional Android build after the Unity tests:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1 -BuildAndroid
```

Do not treat the source audit as a Unity compile, device run or store-ready release.
For a full breakdown see `ENGINEERING_REVIEW_v4.45.md`.
