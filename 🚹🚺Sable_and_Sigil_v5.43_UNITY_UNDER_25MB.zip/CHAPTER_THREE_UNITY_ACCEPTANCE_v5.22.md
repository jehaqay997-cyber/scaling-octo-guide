# Chapter Three Unity Acceptance — v5.22

**Required Unity Editor:** 2022.3.62f3  
**Prior baseline:** v5.21  
**Candidate:** v5.22  
**Cases:** 07 / The Glass Testament; 08 / The Hall of False Light; 09 / The Weeping Witness

## Gate 0 — Source and package preflight

1. Extract the entire v5.22 ZIP into a writable local project directory, not a cloud-synced placeholder.
2. Verify `MANIFEST_v5.22.json` and `MANIFEST_v5.22.sha256` and preserve the original Unity `.meta` files.
3. Open the project with the specified Editor. Resolve packages, review the `Packages/manifest.json` and record the resulting `packages-lock.json` and Package Manager log. Do not claim the source archive included a resolved package lock.
4. Confirm Unity generated the required scenes, valid references and build settings. Source contains editor-authored scene generation, not pre-baked `.unity` production scene files.

## Gate 1 — Compile integrity

- Console must show zero C# compiler errors, especially no incompatible `Text`/`TextMesh` assignment, or unresolved symbols/assemblies.
- Confirm `ChapterWorldExplorer` fields `chapterTwoWorldMark` and `chapterThreeWorldMark` compile and show the authored 3D world captions.
- Capture the complete Unity Editor log and compiler messages. A static Python type scan does NOT certify Unity compilation.

## Gate 2 — Test execution

With Unity closed, run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the extracted project directory. Preserve all EditMode and PlayMode NUnit XML and the evidence JSON. Verify the NUnit fixture source inventory hash; never accept an old or incomplete XML report as a fresh pass.

Required chapter-specific EditMode classes: `ChapterThreeMechanismTests`, `ChapterThreeReliefMeshTests`. Required PlayMode class: `ChapterThreeWorldPlayModeTests`, in addition to all inherited suite fixtures.

## Gate 3 — Three-state world visual acceptance

For **each of locations 7, 8 and 9**, enter a fresh investigation using the authored original art and photograph the following:

| Stage | Required visible relief and world text | Forbidden result |
|---|---|---|
| No evidence | Site-themed blank / locked relief, locked world inscription | Displaying ordered glass symbols, dated timeline bands or missing-glyph location |
| Only A or only B | The same locked relief and text; original mesh identity | Puzzle statement or completed answer |
| Both A and B | Incomplete case-specific relief and text, stage Investigating | Unlocked deduction or restored answer |
| Wrong choice | Investigating relief remains unchanged, attempts increase exactly once | Solved material or dossier progress |
| Correct choice | Restored relief, solved caption, world status material; same owned mesh | Duplicate meshes/colliders or multiple dossier callbacks |

Verify that closing/reopening the mechanism does not reset current session attempts or hints; exiting and re-entering resets transient world-puzzle state. Both clue orders (A then B, B then A) must work. No world mechanism action alone writes persistent dossier state.

## Gate 4 — Interaction and performance

- On desktop and Android: touch/select the world backplate, test evidence modal stacking, compare clues, focus the panel, pan/orbit/zoom and safe screen-area boundaries.
- Back/Escape closes one overlay at a time, then exits focus, then atlas; no stale HUD callback bypasses a modal or awards progress.
- Examine art crop, 3D face orientation, normals, lighting, text fit, frame-time, GPU and RAM budget. Test frame rates and GC allocations on a real Android target.

## Current evidence matrix

| Gate | Status in v5.22 source archive |
|---|---|
| Python regressions / mutation tests | Run and record in external verification report |
| Maintained static gates / source SHA comparison | Run and record in external verification report |
| Unity Compile | NOT EXECUTED |
| Unity EditMode and PlayMode | NOT EXECUTED |
| Generated scene inspection | NOT EXECUTED |
| Real Android device | NOT EXECUTED |
| Release approval | BLOCKED |
