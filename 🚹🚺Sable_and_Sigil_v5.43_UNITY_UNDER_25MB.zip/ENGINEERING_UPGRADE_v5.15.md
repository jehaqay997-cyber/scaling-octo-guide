# Sable & Sigil v5.15 — Chapter Two Mechanism Integration

## Change scope

Unity compatibility target: **2022.3.62f3**. The base is the verified v5.14 source archive. This is a **source candidate**, not a Unity-validated release.

Chapter Two comprises locations 03–06:

| Location | 3D set | Mechanism | Authoritative choice |
|---|---|---|---|
| 03 The Lantern Ascent | Lantern Path | Lunar calendar calibration: two phases after New | Full Moon |
| 04 The Rose Pavilion | Rose Pavilion | Petal sum 2, 3, 5, 8, ? | 13 |
| 05 The Fountain of Echoes | Fountain | Gardener's spout ordering | 1-3-2-4 |
| 06 The Silent Crossing | Silent Crossing | Witness directions in B-A-C order | South-East-West |

### Implemented

- Introduced pure-C# `ChapterTwoMechanismPuzzle` for evidence-gated, replay-safe transient world puzzle state. Authoritative answer indexes are resolved against the existing `StoryDossierCatalog`; no competing solution table was introduced.
- Implemented four separately authored inscription and world-state visual contracts. Solutions appear in the physical world display **only after** verification.
- Added chapter-two viewer, answer selection, a three-tier hint budget, feedback, and a non-colliding 3D mechanical plaque to locations 03–06.
- Added a fail-closed `CanDeduce` guard for chapter-two 3D investigations. Both physical evidence fragments and the mechanism are required for the **3D-to-dossier** handoff.
- Blocked the background input when the modal is active. Chapter One state and other chapters' world mechanisms retain their previous behavior.
- Owned chapter-two decorative objects through the scene root. Uses existing lighting rig; no new real-time lights, collider targets, or per-frame mesh allocations.
- Added source-tracked NUnit EditMode and PlayMode fixtures, updated fixture SHA-256 inventory, and independent static/mutation checks.
- Original location images 01–10, their `.meta` identities, original Unity scene files, and chapter-one assets have not been altered by this update.

### Not claimed / known boundaries

- **Unity compilation, EditMode, PlayMode and Android device tests have not been executed in this environment.** Their test sources exist but are pending editor execution.
- The world mechanisms are a **3D exploration mode**. The atlas's pre-existing, separately authored text-dossier pathway is still available and has not been redefined as world-only; gating it would be a separate product decision.
- These are procedurally staged 3D prototype scenes; visual production approval, frame-time measurement, touch QA, and asset review require Unity/editor or device evidence.
- The four mechanisms currently use evidence-based four-choice restoration interactions, not physical drag handles for every visual motif. Their world-state marks change upon success.

## Unity acceptance

See `CHAPTER_TWO_UNITY_ACCEPTANCE_v5.15.md`. Do not mark any editor or device evidence gate verified without actual logs/results.
