[CmdletBinding()]
param(
    [string]$UnityEditorPath = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Assert-ProjectRoot([string]$Root) {
    foreach ($relative in @("Assets", "Packages/manifest.json", "ProjectSettings/ProjectVersion.txt")) {
        $path = Join-Path $Root $relative
        if (-not (Test-Path -LiteralPath $path)) {
            throw "Unity project is incomplete. Missing: $relative. Extract the entire ZIP before launching."
        }
    }
}

function Get-RequiredVersion([string]$Root) {
    $file = Join-Path $Root "ProjectSettings/ProjectVersion.txt"
    $contents = [System.IO.File]::ReadAllText($file)
    $match = [regex]::Match($contents, '(?m)^m_EditorVersion:\s*(\S+)\s*$')
    if (-not $match.Success) { throw "ProjectSettings/ProjectVersion.txt has no valid Unity editor version." }
    return $match.Groups[1].Value
}

function Find-UnityEditor([string]$Version) {
    $roots = @(
        [Environment]::GetFolderPath('ProgramFiles'),
        [Environment]::GetEnvironmentVariable('ProgramFiles(x86)'),
        [Environment]::GetEnvironmentVariable('ProgramW6432')
    ) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
    foreach ($root in $roots) {
        $candidate = Join-Path $root "Unity/Hub/Editor/$Version/Editor/Unity.exe"
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    throw "Unity $Version is not installed in a standard Unity Hub location. Install the exact version using Unity Hub or supply UnityEditorPath."
}

function Assert-UnityEditorVersion([string]$Editor, [string]$RequiredVersion) {
    if (-not (Test-Path -LiteralPath $Editor -PathType Leaf)) {
        throw "Unity Editor executable does not exist: $Editor"
    }
    $output = @(& $Editor -version 2>&1 | ForEach-Object { $_.ToString().Trim() })
    $exitCode = $LASTEXITCODE
    if ($null -eq $exitCode -or $exitCode -ne 0) {
        throw "Unable to read the Unity Editor version from $Editor. Exit code: $exitCode"
    }
    $versions = @($output | Where-Object { $_ -match '^\d+\.\d+\.\d+[abfp]\d+$' } | Select-Object -Unique)
    if ($versions.Count -ne 1 -or $versions[0] -cne $RequiredVersion) {
        throw "Editor version mismatch. Required $RequiredVersion. Reported: $($output -join ' | ')"
    }
}

try {
    $root = (Resolve-Path -LiteralPath $PSScriptRoot).Path
    Assert-ProjectRoot $root
    $requiredVersion = Get-RequiredVersion $root
    if ([string]::IsNullOrWhiteSpace($UnityEditorPath)) {
        $UnityEditorPath = Find-UnityEditor $requiredVersion
    }
    $UnityEditorPath = (Resolve-Path -LiteralPath $UnityEditorPath).Path
    Assert-UnityEditorVersion $UnityEditorPath $requiredVersion

    Write-Host "Opening TheOrderRoom in Unity $requiredVersion..."
    Write-Host "Project: $root"
    Write-Host "Editor: $UnityEditorPath"
    $process = Start-Process -FilePath $UnityEditorPath -ArgumentList @('-projectPath', ('"' + $root + '"')) -PassThru
    if ($null -eq $process -or $process.Id -le 0) {
        throw 'Unity Editor did not start.'
    }
    Write-Host "Unity process started. PID: $($process.Id)"
    Write-Host "After scripts import, the project opens its integrated Main scene automatically."
    Write-Host "If startup is blocked, choose TheOrderRoom > Play Integrated Game in the editor."
    exit 0
}
catch {
    Write-Error "TheOrderRoom launch failed: $($_.Exception.Message)"
    exit 1
}
