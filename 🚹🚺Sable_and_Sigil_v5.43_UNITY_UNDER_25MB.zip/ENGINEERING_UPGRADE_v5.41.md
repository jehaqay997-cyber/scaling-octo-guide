# Sable & Sigil v5.41 — Architectural Route Consolidation

**Target editor:** Unity 2022.3.62f3. **Status:** canonical narrative source candidate, Unity execution pending.

## Audited defect

The previous v5.40 acceptance configuration required a fifth, simultaneously enabled legacy `Main.unity` symbol-sorting scene after the four narrative chapters. Moreover, the old batch bootstrap constructed that legacy scene during Sable acceptance, and Android preprocessing partially depended on its validator. This allowed two distinct game loops to coexist in a shipping build, while the Sable narrative story, ten cases and finale were intended to be authoritative.

## Changes implemented in Unity source

- New `SableChapterBuildRoute.cs` centralizes build ordering, enables precisely four narrative chapters, retains but disables other scenes, detects duplicates and rejects unknown enabled scenes.
- `ChapterCaseSceneBuilder` delegates all build-scene configuration to this single route.
- `SableLaunchAcceptance`, `SableAssetReferenceValidator`, and `OrderBuildGate` validate the narrative scenes directly and no longer require a legacy Main scene.
- The Android test APK gate requires exactly four narrative scenes and rejects the old Main route.
- Editor retry prepares the narrative scenes rather than the legacy prototype. The standalone legacy Main builder now keeps its scene disabled by default.
- Legacy editor menu entries are isolated under **Legacy Diagnostics/TheOrderRoom** without renaming serialized C# types or their Unity `.meta` references.
- The obsolete legacy Main PlayMode smoke test was replaced by a real Chapter One narrative boot test under its existing reviewed fixture name. It now checks chapter initialization, UI event dispatch, UI raycasting, and absence of legacy OrderGame.
- Updated EditMode route/order tests and both PowerShell acceptance scripts to use the same Sable chapter preflight; updated source verification contracts and the tracked NUnit source hashes.
- Added `verify_canonical_chapter_route_v541.py` and 16 adversarial regression tests to prevent accidental reintroduction of the parallel shipping route.

## Deliberately unchanged

- All original and newly generated cinematic art, textures, `.meta` identifiers, Unity version, authored clue/puzzle solutions, narrative case progression, save-file schema, story ending, Input System version and Android application ID.
- Original legacy source code retained in the source archive for historical compatibility; it is excluded from the shipping scene route, not erased from source assemblies.

## Verification policy

Python regression and static source gates exercise source contracts, not Unity rendering, package resolution or a physical device. A successful source gate cannot certify an APK, memory usage, 3D art quality or player-facing game flow.

## Remaining P0

1. Open imported project in Unity **2022.3.62f3**, obtain clean compiler logs and resolve dependencies.
2. Verify all four generated scenes serialize correctly, are the only enabled Build Settings entries, and pass EditMode/PlayMode NUnit.
3. Complete an uninterrupted manual narrative playthrough from Chapter One to the final record, including clean and corrupt checkpoint recovery, all ten unique puzzles and Back/gesture paths.
4. Test builds and run on actual Android hardware, including touch safe area, audio, performance, transitions and privacy.

## Remaining P1 / art

Complete panoramic assets for locations 3, 6, 8 and 9; build genuine explorable 3D spaces with coherent materials, lights and animation; perform qualitative cinematic grading and realistic interaction testing. These tasks were not claimed to be delivered by this routing-focused release.
