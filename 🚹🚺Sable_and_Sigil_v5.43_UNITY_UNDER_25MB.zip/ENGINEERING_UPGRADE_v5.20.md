# Sable & Sigil v5.20 — Chapter Three Pre-Unity Closure

**Baseline:** v5.19. **Target Editor:** Unity 2022.3.62f3. **Scope:** Chapter Three (07–09) runtime state consistency only.

## Changes

- Hardened Chapter Three orbit rotation and zoom to reject commands when any chapter-three mechanism, artwork, or clue-comparison modal is visible. The lock is explicitly chapter-scoped to avoid altering Chapters One and Two.
- Added a finite-number validation to the world camera's rotation path, preventing nonfinite inputs from corrupting camera orientation.
- Fail-closed direct atlas exits for Chapter Three while a modal is active, preserving Back/Escape one-layer-at-a-time behavior. Deduction gating remains unchanged; no evidence or persistent progress is created by navigation.
- Maintained existing guard in `TryFocusEvidence` and `ReturnToOverview`, and verified it using explicit regression checks.
- Added two Chapter Three PlayMode test methods covering queued camera actions, artwork/comparison/mechanism modal isolation, background exit, clue and mechanism preservation, finite rotation and normal post-close controls.
- Added one new static source gate and 18 mutation-based Python tests, strengthened the legacy relic-rotation contract to check its own method (rather than another camera method), and reconciled the changed PlayMode fixture's SHA-256 in the NUnit inventory.
- Updated the evidence runner's source baseline to `v5.20` and aligned its source-audit assertions. No existing Unity GUID, scene, imported artwork, or original media asset is intentionally modified.

## What the checks cannot prove

Passing static gates and Python regressions does **not** establish successful C# compilation, functioning UI draw order, real pointer device handling, exact lighting/shader appearance, graphics memory, frame times or Android behavior. The PlayMode tests are authored and inventoried, **not executed**. Required evidence is listed in `CHAPTER_THREE_UNITY_ACCEPTANCE_v5.20.md`.

## Release boundary

- `DESIGN_SOURCE_VERIFIED`: only if the independent source checks pass on the sealed ZIP.
- `UNITY_COMPILE_VERIFIED`: false until a real Unity 2022.3.62f3 editor log shows success.
- `UNITY_EDITMODE_VERIFIED`: false until real NUnit XML is supplied.
- `UNITY_PLAYMODE_VERIFIED`: false until real NUnit XML is supplied.
- `ANDROID_DEVICE_VERIFIED`: false until real device results are supplied.
- **99% completion and production readiness are not certified by source-only evidence.**
