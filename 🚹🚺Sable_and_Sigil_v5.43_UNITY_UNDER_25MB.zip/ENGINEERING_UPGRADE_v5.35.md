# Sable & Sigil v5.35 — Final Source Audit and Unity Test Classification Repair

**Target:** Unity 2022.3.62f3. **Parent:** v5.34. **Evidence:** offline source and artifact validation only.

## Confirmed P0 defect fixed

The PlayMode test assembly incorrectly used `includePlatforms: ["Editor"]`, which Unity Test Framework 1.1.33 documents as the EditMode test-assembly selection rule. The PlayMode assembly now uses an unrestricted platform list (`[]`), and the EditMode assembly remains Editor-only. Neither C# code nor the Unity Editor or Android player has been compiled in this runtime.

The tests are not included in ordinary production builds because the existing test assembly requires `UNITY_INCLUDE_TESTS`. The `UnityEditor.TestRunner` dependency is prohibited from the PlayMode assembly. The official reference is https://docs.unity.cn/Packages/com.unity.test-framework%401.1/manual/edit-mode-vs-play-mode-tests.html .

## Confirmed P1 integrity weakness fixed

The final-record modal previously trusted an in-memory eligibility check made when the gallery was refreshed, even if stored checkpoints had changed since then. `OpenFinale` now reloads verified durable progress immediately before opening, and `SetFinalePage` revalidates before each page transition. Any damaged, regressed, or invalidated state prevents entry or closes the finale without altering save slots. A new PlayMode fixture explicitly corrupts both checkpoint slots between rendering an unlocked button and the button action.

## Offline gates and immutable content

The source integrity gate now checks the correct PlayMode / EditMode `includePlatforms` split; the mandatory PlayMode acceptance gate rejects Editor-only dependencies and Editor-only targeting. Two mutation tests guard these rules. No prior artwork, Unity `.meta` GUID, package version, puzzle solution, or saved-game file name is modified. The fixture manifest fingerprint for the amended existing test class is regenerated.

## Open verification blockers

- P0 Unity 2022.3.62f3 compiler, package resolution and Safe Mode: NOT EXECUTED.
- P0 Unity EditMode/PlayMode tests including the new checkpoint test: AUTHORED, NOT EXECUTED.
- P0 actual four chapter 3D experience, puzzle inputs, camera, audio and finale UI: NOT EXECUTED.
- P0 Android API 36, AAB, IL2CPP, ARM64, 16 KB native alignment, signing and device testing: NOT EXECUTED.
- P1 layout, accessibility, audio/video fidelity and power/memory/thermal metrics: NOT MEASURED.
- P1 PlayerPrefs saves remain checksummed but not encrypted or authenticated; no private data should be stored there.

This is a repaired SOURCE CANDIDATE, not a claim that the game is fully bug-free or certified for release.
