# TheOrderRoom v4.29 — Lifecycle, Gesture, and UI State Integrity

## Source baseline and scope
- Baseline: v4.28 archive, 393 original entries.
- No original entry removed.
- Three runtime source changes, one NUnit EditMode test file, and two new Python validation tools.
- Target editor **not migrated**: current project remains on Unity 2022.3.62f3; compatibility with Unity 6.3.28f1 remains unverified.

## Confirmed source-level defects and corrections
1. **Empty-surface gesture was promoted to dragging.** `OrderGame.UpdateWorldGesture` could mark a gesture as dragging even when no item was acquired. Now it only enters dragging when an `OrderClick` is held, preserving tap behavior on destinations after moving the pointer.
2. **A suspended app could accept surviving contacts as new interactions.** `OrderPointerInput` cancels the active gesture on disable, pause, and focus loss and blocks resumed touch initiation until contact count reaches zero.
3. **Screen layout leaked modified viewport/canvas settings when disabled.** `OrderScreenLayout` now restores captured canvas anchors and offsets, CanvasScaler reference resolution and matching mode, plus original camera viewport and pose.

## Automated checks
All commands under `Verification/` ran to completion with process exit code 0 in this environment:
- `governance_gate.py`
- `governance_v423.py`
- `architecture_gate_v426.py`
- `camera_contract_gate_v427.py`
- `integration_gate_v428.py`
- `test_integration_gate_v428.py` (four Python tests)
- `independent_adventure_oracle.py` (20 reachable states; 34 transitions; three winning states; zero softlocks **for its modeled state space**)
- `lifecycle_gate_v429.py` (11 static contracts)
- `test_lifecycle_gate_v429.py` (four Python tests, three deliberate contract mutations).

## New Unity EditMode test
`LifecycleIntegrityRegressionTests.cs` covers:
- Restoring board camera pose and viewport, root canvas anchors/offsets, and CanvasScaler settings when the layout is disabled.
- Blocking input initiation on application pause.

**Not executed:** These C# tests and existing NUnit tests require Unity. Neither the Unity editor nor a C# compiler is present in the available environment.

## Engineering constraints and residual risk
- Source-pattern gates validate narrow contracts; they are **not** a proof of runtime behavior, security, memory safety, or absence of all vulnerabilities.
- Critical: execute Unity batchmode, compile assemblies, create/validate the scene, run EditMode and PlayMode tests, and retain machine-readable logs before marking COMPILE_VERIFIED or TEST_VERIFIED.
- Android GC, CPU, GPU, thermal throttling, battery drain, accessibility, and actual touch latency have not been measured.
- Existing journal storage still requires device-backed crash/power interruption tests and a long-history performance strategy.
- Main gameplay orchestration remains concentrated in `OrderGame`; gradual refactoring needs regression coverage before changing ownership boundaries.
- The Input System branch and legacy branch must both be tested under the configured player input handling mode.

## Primary references
- Unity 2022.3 Editor command-line arguments: https://docs.unity3d.com/2022.3/Documentation/Manual/EditorCommandLineArguments.html
- Unity 2022.3 Camera.ScreenPointToRay: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Camera.ScreenPointToRay.html
- Microsoft FileStream.Flush(bool): https://learn.microsoft.com/en-us/dotnet/api/system.io.filestream.flush

## Gate status
- SOURCE_STATIC: PASS
- PYTHON_CONTRACT_MUTATIONS: PASS
- INDEPENDENT_MODEL: PASS (limited model)
- COMPILE_VERIFIED: NOT RUN
- TEST_VERIFIED: NOT RUN
- SCENE_VERIFIED: NOT RUN
- DEVICE_VERIFIED: NOT RUN
