# Sable & Sigil v4.89 — Gothic Geometry and 3D Evidence Lifecycle

**Source baseline:** v4.88 procedural 3D chapter cases
**Unity compatibility target:** 2022.3.62f3
**Acceptance classification:** STATIC_SOURCE_ACCEPTED; UNITY_RUNTIME_NOT_VERIFIED

## Functional work delivered

1. **Actual authored procedural architecture.** Added `ChapterWorldGothicGeometry.CreatePointedArch`, a bounded mesh generator implementing two equilateral circular arcs with finite-input checks, consistently indexed front/back/side faces, normals and bounds. All ten existing location prototypes now create a central Gothic portal and two flanking Gothic arcades with keystones.
2. **Resource ownership.** Every generated arch Mesh is owned by `ChapterWorldExplorer` and destroyed on `Close`, `OnDisable`, or `OnDestroy`. Each opened location owns exactly three of these meshes; none is cached globally or added to save data.
3. **Evidence visibility.** Inspecting either of the two 3D evidence objects changes its renderer to an owned inspected-state material. Repeated inspection remains idempotent; the existing `StoryDossierSession` remains the sole durable case-completion owner.
4. **Runtime observability.** Read-only `OwnedMeshCount`, `OwnedMaterialCount`, `CameraYaw`, and `CameraDistance` assist nonintrusive PlayMode acceptance checks.
5. **Regression tests authored.** EditMode tests cover finite coordinates, mesh extents, index ranges, maximum segment count and invalid input. PlayMode tests exercise 3D evidence raycasts, texture-independent memory disposal across all ten locations, camera clamp under repeated UI actions, visual feedback and lifecycle cleanup. These NUnit/Unity tests are **NOT executed** in the offline environment.
6. **Numerical preflight.** A separate Python gate independently models the mesh, checks positive-area triangles, validates the equilateral arch apex, prevents source regressions in cleanup and forbids direct saves from rendering. Ten new mutation/positive Python tests were added and the gate registered with the maintained full static audit runner.

## Quantified geometry budget

At 16 segments per side and 3 arches per opened location:
- Exactly **408 new procedural mesh vertices** and **792 triangles**, plus three small primitive keystones.
- The mesh vertex and triangle counts are mathematical design counts, **not GPU draw-call measurements**.
- All ten locations retain their original 1280x720 artwork unchanged. The reference art is a flat image panel, not a photogrammetric reconstruction.
- All ten locations remain prototypes; Chapters II–IV are not complete 3D narrative chapters.

## Static checks performed

- Full Python suite: **296 tests passed**.
- Complete maintained static runner: **45/45 stages passed** (44 gates plus the regression suite).
- Numeric geometry gate: **4 segment-resolution samples**, no zero-area triangles, and clean triangle-index bounds.
- Original source/image preservation is rechecked during final packaging with SHA-256, ZIP CRC, GUID and `.meta` checks.

## Execution evidence intentionally absent

- Unity project import / C# compilation in Editor 2022.3.62f3: **NOT EXECUTED**.
- Unity EditMode and PlayMode NUnit tests: **NOT EXECUTED**.
- Physical rendering comparison, real-device performance, Android build and memory profiling: **NOT EXECUTED**.
- **Release status remains unverified** until Unity Console logs, test results and device evidence are available.

## Next highest-priority acceptance sequence

1. Open v4.89 as a separate local Unity project in Editor 2022.3.62f3; address any new Console compiler errors before editing game content.
2. Run **Sable & Sigil > Validate 3D Case Prototypes** and record inspector/console asset validation.
3. Run `ChapterWorldGothicGeometryTests`, then `ChapterWorldExplorerPlayModeTests`, and the complete EditMode/PlayMode suites. Capture XML logs and reproducible failure cases.
4. Use physical gameplay inspection for all ten scenes: artwork proportions, arch silhouette, clue raycast accuracy, pointer/UI blocking, no double progress awards, safe areas, pause/resume and scene cleanup.
5. On Android, profile frame pacing, graphics memory, GPU draw calls and lifecycle reliability before production art expansion.

## Authoritative design references

- Unity 2022.3 Mesh API: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.html
- Unity 2022.3 Physics.Raycast: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Physics.Raycast.html
- Unity 2022.3 Object.Destroy: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Object.Destroy.html
- Unity 2022.3 assembly definitions: https://docs.unity3d.com/2022.3/Documentation/Manual/AssemblyDefinitionFileFormat.html
- NIST Secure Software Development Framework: https://csrc.nist.gov/pubs/sp/800/218/final
