# Sable & Sigil v4.58 — Runtime Readiness Acceptance

## Scope and evidence
Source: v4.57 checkpoint recovery candidate; actual source extracted and audited.
Editor version recorded in ProjectSettings/ProjectVersion.txt: Unity 2022.3.62f3.
This release is a **static-source acceptance candidate**, not an executed Unity release.

## Confirmed defect
The Unity first-import auto-launch path accepted `EnteredPlayMode` merely when a
`ChapterOneExperience` component existed in the active scene. An exception in its
`Awake()` path disables that component, yet it can still exist in the hierarchy.
Consequently the auto-launch path could incorrectly mark an unusable game as launched.

## Changes
1. In Editor/OrderFirstImportSetup.cs, launch success now requires both
`chapter.isActiveAndEnabled` and `chapter.IsChapterReady`, together with the
required active scene. Failure exits Play Mode and uses the existing bounded
retry path; success is not recorded prematurely.
2. In Tests/PlayMode/ChapterOneSceneTests.cs, the scene test requires the
chapter component to remain active and enabled, in addition to existing
world/UI, hotspot, camera, inspection and narrative assertions.
3. Strengthened the existing startup regression suite and gate, then added
`chapter_runtime_readiness_gate_v458.py` plus six targeted mutation tests.
4. Registered the new gate in the unified static audit.

## Evidence summary
- Python unittest discovery: 170 passed, 0 failed.
- Unified offline static audit: 32/32 executed stages passed (31 gates + test suite).
- Unity asset file completeness scan: 325 files, 0 empty, 0 missing .meta.
- ChapterArt: 4 JPEG files, 1280x720. LocationArt: 10 JPEG files, 1280x720.
- Archive integrity and every listed file hash verified after packaging.
- Unity editor, PowerShell runtime, C# compiler, PlayMode, Android APK and device tests were **NOT EXECUTED** here.
- A saved .unity scene is **not** included; ChapterOneSceneBuilder is responsible for creation on first import.
- No claim of fixing every gameplay issue or earning a perfect score.

## Release decision
SOURCE_STATIC_VERIFIED = PASS in the described tests.
UNITY_COMPILE_VERIFIED = UNVERIFIED.
EDITMODE_VERIFIED = UNVERIFIED.
PLAYMODE_VERIFIED = UNVERIFIED.
ANDROID_BUILD_VERIFIED = UNVERIFIED.
DEVICE_VERIFIED = UNVERIFIED.

Run `OPEN_GAME.cmd` on Windows with the exact recorded editor version,
then `Verification/Run-UnityVerification.ps1 -BuildAndroid` where all required
Unity Android modules are installed. Investigate the generated logs if any step fails.

## Documentation references
- Unity 2022.3 PlayModeStateChange.EnteredPlayMode:
  https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PlayModeStateChange.EnteredPlayMode.html
- Unity Behaviour.isActiveAndEnabled:
  https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Behaviour-isActiveAndEnabled.html
- NIST SSDF SP 800-218:
  https://csrc.nist.gov/pubs/sp/800/218/final
