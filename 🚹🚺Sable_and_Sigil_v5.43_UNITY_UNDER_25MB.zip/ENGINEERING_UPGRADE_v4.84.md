# Sable & Sigil v4.84 — Chapter Systems and Evidence Graph

## Baseline and scope
- Parent candidate: `Sable_and_Sigil_v4.83_COMPILER_AND_AUDIT_HARDENED_CANDIDATE.zip`.
- Unity Editor compatibility target: `2022.3.62f3`; Test Framework `1.1.33`.
- No existing scenes, existing GUIDs, player-save keys, assembly names, existing art files, or legacy puzzle rules have been changed.
- The existing P0 NUnit/PlayMode dependency repairs from v4.82/v4.83 are preserved.
- Four chapter visual previews and ten concept scene images exist. Only Chapter One has a playable 3D scene. No other location is declared playable.

## Actual implementation
- New pure C# domain `ChapterStoryGraph`: immutable authored metadata for ten scene concepts, typed evidence dependencies, three-tier hints, strict catalog validation, acyclic/reachable order and deterministic next-location planning.
- New pure C# domain `StoryEvidenceLedger`: revision-bound commits, monotonic prerequisites, duplicate/stale/overflow defense, detached sorted snapshots and transactional restore validation. It is **not** wired into persistent gameplay rewards or chapter unlocks; this would require an explicit save-schema migration and implemented scene interactions.
- Chapter gallery: validates its legacy title/mapping arrays against the new domain graph, displays mechanism and contextual authored clue tiers with an interactive `SCENE HINT` control, resets hint tier on scene selection and retains disabled Enter controls for unfinished locations.
- Chapter One: captures previous external camera state and global ambient/fog settings before modifying them, restores them on destruction or initialization failure. The generated fallback camera still belongs to the chapter root.
- Authored contract: ten scene concepts have 30 location-specific hint tiers, mirrored in the C# graph. The new `Design/CHAPTER_BEATS_v4.84.json` maps 30 ordered Observe/Infer/Resolve authoring beats with evidence identifiers and explicit NOT_IMPLEMENTED runtime states.
- Art: 14 existing chapter/scene images preserved byte-for-byte. New `Design/CHAPTER_ASSET_MANIFEST_v4.84.json` provides per-file SHA-256, paths and sizes; offline gate checks JPEG frame geometry, RGB components, order and bounds. It does not certify visual realism.
- Tests: seven new Unity EditMode authored tests and two new PlayMode scene lifecycle/UI tests, **written but not executed in Unity**. Python mutation suites and two fail-closed gates were added to the full static audit.

## 30-step engineering acceptance matrix

| # | Work item | Status |
|---|---|---|
| 01 | Preserve and hash the v4.83 full-source baseline | Implemented; archive recheck required |
| 02 | Retain the two NUnit/compiler P0 fixes | Implemented in parent |
| 03 | Preserve original `.meta` identity and assembly references | Implemented; archive recheck required |
| 04 | Introduce typed domain model for authored locations | Implemented |
| 05 | Normalize ten location-to-chapter assignments | Implemented |
| 06 | Reject duplicate authored scene and evidence identities | Implemented |
| 07 | Reject future-chapter prerequisites | Implemented |
| 08 | Enforce deterministic, terminating evidence traversal | Implemented |
| 09 | Ensure each of four chapters contains authored locations | Implemented |
| 10 | Author three clue tiers for every location | Implemented, design only |
| 11 | Create monotonic evidence ledger for eventual runtime use | Implemented, not wired |
| 12 | Reject stale expected revisions | Implemented |
| 13 | Fail closed on revision exhaustion | Implemented |
| 14 | Prevent duplicate location completion | Implemented |
| 15 | Validate restored dependency closure before mutation | Implemented |
| 16 | Detach and sort progress snapshots | Implemented |
| 17 | Cross-check gallery labels against domain IDs | Implemented |
| 18 | Add in-gallery authoring hint-tier navigation | Implemented; Unity untested |
| 19 | Keep unimplemented scene entry controls disabled | Retained and audited |
| 20 | Author 30 linked story beats with explicit design status | Implemented, design only |
| 21 | Restore reused camera position/rotation/projection state | Implemented; Unity untested |
| 22 | Restore ambient and fog settings on scene disposal | Implemented; Unity untested |
| 23 | Restore environment after failed scene initialization | Implemented; Unity untested |
| 24 | Hash and verify 14 existing image resources | Implemented, static only |
| 25 | Validate 1280×720 JPEG headers and decode memory upper bound | Implemented, static only |
| 26 | Add negative mutation regression gates and Unity tests | Implemented; Unity tests unexecuted |
| 27 | Compile the full project in Unity 2022.3.62f3 | PENDING — Editor unavailable |
| 28 | Run Unity EditMode/PlayMode and visual/safe-area acceptance | PENDING — Editor unavailable |
| 29 | Implement and test actual 3D scenes for Chapters II–IV | PENDING — story concepts only |
| 30 | Android IL2CPP/device profiling and quality release gate | PENDING — device unavailable |

## Executed checks and limitations
- Offline Python `unittest` suite: **245/245 passed**.
- Full static audit: **40/40 passed** (39 named gates and the final regression stage).
- Includes the new story/beat and artwork corruption mutation checks. These passes do not establish C# compilation, scene generation, GPU memory use on Android, frame rate, chapter completion or published quality.
- C# test sources were authored; no CLR/Unity NUnit runner was available to execute them.
- New PlayMode camera restoration test must be checked for rendering pipeline differences in a real Unity editor. No global settings restoration guarantee is asserted without that test evidence.

## Immediate acceptance path
1. Back up your locally edited project. Extract v4.84 to a **new** folder and open using Unity `2022.3.62f3`.
2. Confirm Unity Console has zero compiler errors. Existing screenshot of v4.81 Safe Mode is not compilation evidence for v4.84.
3. Use `Sable & Sigil/Create or Open Chapter One`; verify the gallery's 10 locations, 3-tier hints, canvas safe area and preview-only entry controls.
4. Execute all EditMode and PlayMode tests via Test Runner; capture `Editor.log`, NUnit XML and any diagnostics.
5. Run Android validation only after the desktop compile/test gates have passed. Do not promote the other three conceptual chapters as playable.

## Official baseline references
- Unity 2022.3 assembly definition format: https://docs.unity3d.com/2022.3/Documentation/Manual/AssemblyDefinitionFileFormat.html
- Unity RenderSettings reference: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/RenderSettings.html
- Unity Test Framework 1.1: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/index.html
- NIST Secure Software Development Framework: https://csrc.nist.gov/pubs/sp/800/218/final
