# Sable & Sigil — Chapters One to Three Acceptance (v5.25)

**Unity Editor:** 2022.3.62f3  
**Scope:** Chapters I, II, III; Chapter IV remains locked.  
**Status:** Offline source candidate. Real Editor/Android acceptance is NOT_EXECUTED.

## 1. Editor import and compilation

Extract the full ZIP into a fresh writable directory. Open the extracted Unity project using exactly Unity 2022.3.62f3. Resolve `Packages/manifest.json` and preserve the resulting `packages-lock.json` as build evidence. Ensure the Console reports zero compile errors, including all NUnit, test assembly, Input System, UI, and Editor assembly references.

Execute `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` on Windows. The runner must emit `SABLE_SIGIL_LAUNCH_PREFLIGHT_PASS`, produce evidence logs, and **not** claim a passing verdict when expected files or any compiled fixtures are absent.

## 2. Generate all required scenes

The Unity Editor must create and serialize the following scenes in enabled Build Settings order:

1. `Assets/_Project/Scenes/ChapterOne.unity`
2. `Assets/_Project/Scenes/ChapterTwo.unity`
3. `Assets/_Project/Scenes/ChapterThree.unity`
4. `Assets/_Project/Scenes/Main.unity`

Validate each generated scene for missing scripts and correct active scene bootstrap. These scenes are not included pre-generated in the ZIP; a passing Python/ZIP check is **not** evidence that Unity generated them.

## 3. Mandatory connected gameplay

- On a clean save, only Chapter I is enterable. The two unfinished case files cannot be opened directly from the atlas.
- Finish location 01 by inspecting both clues, choosing the added crest ray, opening the dossier, submitting the authored correct deduction, and reloading the save.
- Finish location 02 by inspecting both clues, restoring the missing spiral star, submitting its deduction, and reloading the save. Verify Chapter II unlocks.
- Finish locations 03–06 using their authored physical mechanisms. Verify incorrect choices, hints, camera focus, Back, close/reopen, dossier transfer, and Chapter III unlocking.
- Finish locations 07–09 using their authored physical mechanisms. Verify the three relief states: locked before evidence, readable after both pieces of evidence, and restored after correct verification.
- Confirm that the single-use `WorldInvestigationGrant` cannot be reused or passed to a different location. In particular, invalid artwork, already-open dossier overlays, stale save revisions, and save reload failures must not produce a recorded deduction.
- After finishing 01–09, **Chapter IV and location 10 must remain unenterable and their unresolved dossier inaccessible** through both button callbacks and the public dossier API. Previously completed cases can be reviewed from the atlas.

## 4. Unity PlayMode fixture checkpoints

Confirm the current source-fingerprint manifest reconciles with the test runner, and that all required test fixtures appear with executed results. In particular, run `StoryDossierPlayModeTests`, `ChapterArtGalleryTests`, `ThreeChapterEntryPlayModeTests`, `ThreeChapterHandoffPlayModeTests`, and the Chapter Two/Three world tests. No failed, skipped, inconclusive, omitted or duplicated fixture may be interpreted as a pass.

## 5. Device and visual quality

On an Android device test touch occlusion, safe area, Back/Escape, landscape aspect ratios, input system, camera transitions, navigation, and resource cleanup after repeated scene switches. Review all nine locations for readable visual clues, composition, lighting, and procedural 3D geometry. The source-only project contains no evidence proving a production-realistic art target.

**Release decision:** `COMPILE_VERIFIED = false`, `EDITMODE_VERIFIED = false`, `PLAYMODE_VERIFIED = false`, `SCENE_VERIFIED = false`, `ANDROID_VERIFIED = false`, `DEVICE_VERIFIED = false`, `RELEASE_APPROVED = false` until captured runtime evidence independently proves each gate.
