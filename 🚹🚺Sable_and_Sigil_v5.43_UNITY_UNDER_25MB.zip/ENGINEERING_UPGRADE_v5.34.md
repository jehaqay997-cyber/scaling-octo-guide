# Sable & Sigil v5.34 — Finale and Formal Puzzle Engineering

**Target:** Unity 2022.3.62f3  
**Parent:** v5.33 (source-only candidate)  
**Build evidence:** No Unity Editor executable or C# compiler was available in the validation runtime.  
**Release status:** SOURCE_CANDIDATE, not gameplay or Android release approval.

## 1. Verified engineering changes

### Pure domain and mathematical constraints

- `Assets/_Project/Domain/StoryDeductionProof.cs`: a standalone proof evaluator for all ten authored cases. It derives an expected answer from mathematical or logical rules without reading the authored `correctChoice` index. It independently verifies the displayed choices and solution metadata. For four-symbol fountain and meridian orderings, it enumerates all `4! = 24` assignments and rejects models without exactly one valid ordering.
- `Assets/_Project/Domain/StoryDossierCases.cs`: catalog validation fails closed if a correct index contradicts an independently derived proof, the proven answer is missing, or multiple choices duplicate the proven result.
- `Assets/_Project/Domain/StoryFinalePolicy.cs`: immutable, read-only finale eligibility. It demands the complete set of ten distinct validated evidence IDs and exactly ten committed revisions, with all dependency edges satisfied. Navigation clamps at page boundaries.
- `Assets/_Project/Domain/ChapterStoryGraph.cs` and `StoryDossierPersistence.cs`: reject states with a revision larger or smaller than the number of completed cases. This follows from the single valid transition rule: every committed conclusion increases both revision and completed count exactly once.
- Existing valid v5.33 checkpoints are preserved: the shipping repository always authored one revision per completed case. Checkpoints produced outside that contract are rejected instead of silently repaired.

### Final narrative and interface

- `Assets/_Project/Runtime/CampaignNarrative.cs`: four complete finale pages with authored investigative payoff. The opening crest, garden's multi-clue itinerary, gallery's impossible 1904/1912 chronology, restored REMEMBER inscription and meridian A-B-C-D ordering are tied to the closing story.
- `Assets/_Project/Runtime/ChapterGalleryView.cs`: creates a dedicated, blocking final-record modal. It reuses existing Chapter IV artwork, supports bounded previous/next navigation, fits long text inside the safe-area Canvas, and prevents navigating underneath the modal. There is no duplicate texture allocation or persistent "ending completed" save.
- `StoryDossierSession.IsFinaleUnlocked` reads only the authoritative checked evidence ledger. The finale button is unavailable for incomplete, unreadable or inconsistent progress and appears only under the completed fourth chapter.
- `Assets/_Project/Runtime/StoryDossierView.cs`: completion of the last investigation directs the player back to Chapter IV for the actual ending.

### Test and verification coverage

- New EditMode fixtures `StoryDeductionProofTests` and `StoryFinalePolicyTests` cover unique answers, immutable proof reads, invalid evidence, early finale denial and bounded page navigation.
- New PlayMode fixture `ChapterFinalePlayModeTests` covers early-access prevention, a completed ten-case progression, modal shielding and return to ordinary navigation. This fixture is authored **but not executed** in Unity.
- Updated historic tests that relied on previously permissive synthetic evidence revisions. The authoritative save format version remains unchanged for valid production checkpoints.
- `Verification/verify_finale_puzzle_math_v534.py` is an independently implemented Python oracle for the authored answer set; its mutation tests challenge stale or corrupted answer indices, missing save invariants, and broken finale activation.
- Existing static gates and regression tests remain in the audit registry. All Unity .meta GUIDs and prior art hashes are maintained without regeneration.

## 2. Mathematical proof sketches

1. **Monotonic checkpoint:** initial revision `r_0 = 0`, accepted case count `c_0 = 0`. A valid durable commit has `r' = r + 1`, `c' = c + 1`; thus by induction `r = c` in every reachable valid state. The encoded save rejects noncanonical pairs.
2. **Finite evidence graph:** every authored prerequisite points to a lower numbered location. The graph is acyclic; each correct deduction can add only one previously unresolved location and cannot remove an earlier one. At most ten case commits are possible.
3. **Finale gate:** `Unlocked` requires `r = 10`, `|resolved| = 10` and `resolved = {1,...,10}`, with every prerequisite present. Consequently no prefix with fewer than ten commits can display the finale under this model.
4. **Fountain uniqueness:** among `4! = 24` permutations, requiring the first pair `(1,3)`, last value `4`, and `2` before `4` produces only `1-3-2-4`.
5. **Meridian uniqueness:** among `24` permutations, constraints `index(B) = index(A) + 1`, `index(A) < index(C)` and `last = D` produce only `A-B-C-D`.
6. **Other cases:** the three-element motif uses modular indexing; the four-phase dial uses modular addition; the flower count is the verified two-term recurrence `5 + 8 = 13`; the portrait contradiction is `1912 - 1904 = 8` years; the mechanical glass exchange swaps outer positions only; the epitaph matches seven of eight letters.

These are proofs of the **modeled constraints and authored choices**, not proofs that the 3D mechanics are fun, visually faithful, or executable inside Unity.

## 3. Security, privacy and trust boundaries

- No third-party telemetry, device identifier collection, account system or network dependency was added.
- The finale is deliberately read-only; it does not alter save data, player identity, or analytics.
- The investigation checkpoints remain device-local PlayerPrefs values protected by a corruption checksum. **They are not encrypted or cryptographically authenticated.** Unity explicitly documents that PlayerPrefs is not encrypted and must not hold sensitive data: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PlayerPrefs.html
- Authored conclusions and numerical constraints remain public game data; the integrity gates detect accidental source-content drift but do not claim anti-cheat or protection against a compromised device.

## 4. Acceptance tests still required — P0

1. Open a freshly extracted copy in **Unity 2022.3.62f3**; capture Unity Console and compile artifacts. Do not claim success merely because standalone static scripts pass.
2. Run EditMode / PlayMode through the Unity Test Framework and capture XML and logs. Official Unity test-package information: https://docs.unity3d.com/2022.3/Documentation/Manual/com.unity.test-framework.html
3. Check ten scene mechanisms, required evidence transfers, all three hint tiers and final-case persistence; verify finale remains locked after nine cases, opens after ten, and displays all four pages without truncation or unsafe touch regions at device resolutions.
4. Test power loss, app pause/resume and external save tampering at each checkpoint; verify blocked transactions do not overwrite both durable slots.
5. Profile shader/native allocations, texture memory, touch performance, audio lifecycle, thermal behavior and battery on target Android phones.
6. Complete Android publication gates: API 36, AAB/IL2CPP/ARM64, native 16 KB alignment, package lock resolution, trusted signing and privacy declaration.

## 5. Open limitations and priority

| Priority | Issue | Verification state |
|---|---|---|
| P0 | Unity C# compile and package resolution | NOT_EXECUTED |
| P0 | New NUnit EditMode and PlayMode fixtures | AUTHORED_NOT_EXECUTED |
| P0 | Four-page ending and world/dossier UI in actual scenes | NOT_EXECUTED |
| P0 | Android SDK, target API and native binaries | NOT_EXECUTED |
| P1 | UI readability and true multi-resolution layout | NOT_MEASURED |
| P1 | Battery, memory, thermal and microphone/network privacy | NOT_MEASURED |
| P1 | Full 3D visual artistic parity with reference JPEGs | NOT_VISUALLY_VERIFIED_IN_UNITY |

**No Unity scene, C# assembly, APK or AAB was fabricated or marked as built.**
