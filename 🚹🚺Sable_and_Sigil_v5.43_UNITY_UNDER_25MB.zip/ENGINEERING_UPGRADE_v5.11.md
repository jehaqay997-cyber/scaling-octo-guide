# Sable & Sigil v5.11 — Chapter One 3D Occlusion and Input Integrity

## Baseline and scope

- Parent archive: v5.10, Unity compatibility target: 2022.3.62f3.
- Scope: Chapter One, first-location 3D evidence and six-ray threshold crest.
- Preserve all original chapter artwork, Unity `.meta` GUIDs, scenes, domain puzzle contracts, and later-location content.
- This is a candidate source release, not a compiled Unity release.

## Implementation

1. `ChapterWorldExplorer.ProcessPointer`: when a first-location drag enters UI or exits the camera viewport, cancel the gesture; do not keep rotating the camera or allow a trailing release to select an item.
2. `ChapterWorldExplorer.InspectAtScreenPoint`: fail closed when the world, camera or current scene is absent or a modal overlay is open.
3. First-location raycasts now include the scenery blocker layer as well as evidence, and only a **nearest hit on the evidence layer** may select a crest ray or inspect evidence. Decorative mesh colliders remain disabled by design; opaque enabled scenery colliders can now block foreground selection.
4. Other locations retain their previous evidence-layer selection mask.
5. `ChapterWorldExplorerPlayModeTests`: add `FirstChapter_OpaqueForegroundBlocksEvidenceUntilCleared`, checking a placed collider blocks evidence inspection without affecting attempts; disabling the collider restores normal interaction. **This C# test is authored but not executed by Unity here.**
6. Update the reviewed NUnit fixture source fingerprint, and append independent source-contract and mutation tests plus the static audit gate.

## Independent execution evidence

- Python unittest discovery: **578/578 PASS**, including 11 new v5.11 source-level mutation checks.
- Static audit gate executions: **65/65 PASS**. See separate `Sable_and_Sigil_v5.11_Static_Gates.json` evidence.
- NUnit fixture source inventory validation: **PASS (static)**; it does not constitute NUnit execution.
- All inherited media, scenes and `.meta` files unchanged by this upgrade; see separate source-link map and SHA-256 manifest.
- Tests were performed on source files and numerical/static contracts. No Unity Editor binary, Unity C# compiler, live GPU capture or Android device was present in the execution environment.

## Required Unity acceptance (must be performed before release)

1. Use Unity **2022.3.62f3** and run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` on an extracted local project.
2. Confirm zero compiler errors and complete passing EditMode/PlayMode XML. The new occlusion fixture must appear among discovered PlayMode tests.
3. In the Chapter One threshold world, place an enabled opaque collider on the scenery layer in front of evidence. Tapping the hidden evidence must do nothing; after removing the blocker, the evidence must be inspectable.
4. Drag the 3D view into a HUD control, then release: no unintended evidence inspection, crest selection, or camera continuation.
5. Check all six ray selections, incorrect/correct colors, hint gating, dossier unlock, original photograph and cropped stage photo, portrait/landscape safe areas, light/texture quality, memory, performance and Android touch on a physical device.

## Explicit verification flags

- `DESIGN_VERIFIED`: source contracts checked by available offline tests; runtime visuals unverified.
- `COMPILE_VERIFIED`: NO.
- `EDITMODE_VERIFIED`: NO.
- `PLAYMODE_VERIFIED`: NO.
- `DEVICE_VERIFIED`: NO.
- `RELEASE_APPROVED`: NO.

## Source references

- Unity Physics.Raycast (layerMask, QueryTriggerInteraction): https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Physics.Raycast.html
- Unity Physics.SyncTransforms: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Physics.SyncTransforms.html
- Unity EventSystem.RaycastAll: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/EventSystems.EventSystem.RaycastAll.html
