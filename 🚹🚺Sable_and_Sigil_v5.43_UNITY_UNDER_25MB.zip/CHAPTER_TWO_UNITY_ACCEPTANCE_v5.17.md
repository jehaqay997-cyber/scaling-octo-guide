# Sable & Sigil — Chapter Two Acceptance, v5.17

**Target:** Unity 2022.3.62f3. **Scope:** locations 03–06. This document is a planned editor/device acceptance checklist; it is not executed evidence.

## 1. Import, assemblies, launch

1. Extract the complete ZIP into a dedicated local Windows directory with sufficient free disk space. Do not import from a synchronized or cloud-placeholder directory.
2. Open the project in **Unity 2022.3.62f3**. Resolve editor/package diagnostics without changing pre-existing `.meta` GUIDs or silencing compiler errors.
3. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the extracted project root. Preserve the emitted logs, EditMode and PlayMode NUnit XML, and acceptance JSON **outside** the source archive.
4. Confirm Unity C# compilation, import dependencies and 80 inventoried NUnit test fixtures. The test inventory is a declaration, not proof of execution.

## 2. Four-site end-to-end acceptance

| Location | Puzzle | Verified answer | World result |
|---|---|---|---|
| 03 — The Lantern Ascent | Lunar phase calibration | Full Moon | Missing moon phase restored |
| 04 — The Rose Pavilion | Petal recurrence | 13 | Fifth rosette has 13 petals |
| 05 — The Fountain of Echoes | Fountain spout ordering | 1–3–2–4 | All four fountain heights shown |
| 06 — The Silent Crossing | Witness route | South–East–West | Route motif completed |

For **each** site, perform all of these checks:

- Open with no inspected clues. `OPEN DEDUCTION` and `EXAMINE CHAPTER TWO MECHANISM` remain blocked. Physically tapping the carved backplate cannot bypass evidence gating.
- Tap `FOCUS MECHANISM` **before** examining evidence. It moves the view to the physical plate, never reveals an answer or marks either clue as inspected. Verify the plate remains legible in landscape phone aspect ratios and at ±31° camera yaw.
- In focus mode, `ZOOM +`, `ZOOM -`, pinch and mouse wheel respect **4.3–8.8** world units without jumping to the room's **6.6–11** range. The initial close-up distance is **6.2**; inspect A/B and return to overview must clear the close-up mode. Room overview returns to distance **8.7**.
- Inspect both evidence fragments, reopen the plate viewer, request up to 3 hints and attempt an incorrect choice; neither a hint nor an incorrect answer should restore the 3D relief or enable deduction.
- Verify the correct choice changes the **same** mesh instance in place, changes the material to the verified state, and enables deduction. Confirm the viewer blocks camera changes, evidence input and UI actions behind it.
- Close the viewer and choose `OPEN DEDUCTION`. Confirm one verified transfer with both inspected clue flags into the authored dossier. Return and reopen the site: clues, puzzle attempts, hint stage, focus state and transient materials must reset.

## 3. NUnit and regressions

- Run **EditMode**: `ChapterTwoMechanismTests` and `ChapterTwoReliefMeshTests`; ensure all four solutions are unique and geometry is finite, front facing and under the triangle limit.
- Run **PlayMode**: `ChapterTwoWorldPlayModeTests`, including `ChapterTwoPhysicalFocus_PreservesEvidenceAndUsesContinuousZoomBounds` and `AllFourSites_TransferOnlyVerifiedEvidenceToAuthoredDeduction`.
- Execute the complete Unity test suite: Chapter One, source image framing, Save/Load, unlock progression, UI/modal guards, camera and memory lifecycle. Do not accept an NUnit fixture merely because the static inventory names it.

## 4. Visual and Android acceptance

Check both 16:9 and taller phone displays, UI safe areas, tappable plate targeting, relief visibility, scene lights, original artwork composition, continuous zoom, audio/feedback if present and missing shader diagnostics. Build and test on an Android device, recording measured frame time, draw calls, memory before/after repeated load/unload and device logs. No performance benchmark is claimed in this source delivery.

## Evidence status before actual Unity execution

| Gate | Status |
|---|---|
| Offline Python regressions | 673/673 PASS |
| Offline static gates | 71/71 PASS |
| Unity C# compile | NOT VERIFIED |
| Unity EditMode | NOT EXECUTED |
| Unity PlayMode | NOT EXECUTED |
| Android device | NOT EXECUTED |

**Release decision:** Source candidate only. Every failed editor or device gate must be corrected and rerun before release.
