# Sable & Sigil v4.86 — Chapter Progression and Narrative Integrity

**Starting source:** `Sable_and_Sigil_v4.85_INTERACTIVE_CHAPTER_DOSSIERS_CANDIDATE.zip`  
**Editor compatibility target:** Unity **2022.3.62f3**  
**Build acceptance:** **SOURCE / STATIC-VERIFIED CANDIDATE; UNITY NOT COMPILED**.

## Delivered gameplay and chapter-system changes

1. Added `ChapterInvestigationProgression.cs`: an engine-independent, immutable derived view of each chapter's first/last investigation, completed count, total count, unlock state, and next available location. The existing `StoryEvidenceLedger` remains the single progress owner.
2. Chapter 1 maps to cases 01–02, Chapter 2 to 03–06, Chapter 3 to 07–09, and Chapter 4 to case 10. Unlocking a later chapter's dossier requires completion of earlier chapter dossiers. These boundaries are enforced by both the evidence graph and the new chapter UI.
3. Added `CHAPTER CASES` to the chapter selector. Selecting a chapter now exposes its case-file progress and navigates directly to the first currently available case rather than an unrelated last-viewed atlas location. Fully completed chapters can be reviewed. Locked chapters cannot open their dossiers.
4. Retained the existing four chapter preview artworks and ten location artworks without replacement or recompression, and retained Chapter I's current 3D scene entry. Unfinished 3D scenes for Chapters II–IV remain explicitly unavailable.
5. Added `StoryDossierSession.TryReload()` to reconcile persisted progress when the gallery opens. The operation refuses to silently roll back a previously confirmed live-session state or accept an evidence fork after corrupt storage or another writer's update. A fresh session may still perform the existing older-checkpoint recovery when appropriate.
6. Added a session-derived, read-only chapter progress API; no chapter achievement, reward, or scene unlock is inferred from browsing artwork.
7. Updated five location hint sets (04, 05, 07, 08, 10) to match the already implemented case-file deductions, including the additive petal sequence, fountain permutation, reversed glass order, death-year contradiction, and meridian ordering constraints. Updated both `Design/SCENE_PUZZLE_CONTRACT_v4.65.json` and `Design/CHAPTER_BEATS_v4.84.json` to remain in exact agreement with the C# authored data. Case answers and existing progression/checkpoint schemas were not changed.
8. Improved chapter selector layout to prevent hit-area overlap between chapter entry, case-file navigation, and exit controls. The modal overlay continues to shield the 3D world from UI pointer events.

## Engineering constraints preserved

- Pure C# Domain remains independent of Unity APIs; runtime UI and PlayerPrefs remain in the Runtime assembly.
- `StoryEvidenceLedger` is the authoritative owner of resolved evidence and revision; summaries are derived from snapshots and never mutate state.
- `StoryDossierRepository` retains the two-slot versioned saves with bounded SHA-256 accidental corruption detection, optimistic revision checks, and a fail-closed policy for future schema versions. SHA-256 here is **not an authenticated signature or anti-tamper guarantee**.
- No legacy Chapter I save key, journal key, asset GUID, `asmdef` reference or existing scene was intentionally changed.
- Unity Editor/PlayMode/Android success is not implied by any offline/static check.

## Validation performed

- Python regression suite: **264 / 264 passed**, including 8 chapter-progression mutation tests.
- Full static runner: **42 / 42 stages passed** (41 targeted gates + one Python regression run).
- New gate checks 44 derived chapter transition states, 30 hint objectives and their alignment with the authoring contract, persistence guards, UI controls, and test coverage.
- Authored Unity EditMode test file: `ChapterInvestigationProgressionTests.cs` with five new NUnit tests; new PlayMode test in `StoryDossierPlayModeTests.cs`. These C# tests are **not executed** in this environment.
- Complete source archive and its historical files are checked independently during packaging; see `Verification/SHA256_MANIFEST_v4.86.json` for a per-file digest inventory.

## Unverified execution gates

| Gate | Result | Required evidence |
| --- | --- | --- |
| Unity 2022.3.62f3 package import and C# assembly compilation | NOT EXECUTED | Editor compile log with zero errors |
| Unity EditMode and PlayMode Test Runner | NOT EXECUTED | NUnit/Test Runner XML and Editor log |
| Chapter I real 3D scene and 2D dossier UI | NOT EXECUTED | In-editor functional acceptance |
| Chapter II–IV 3D production scenes | NOT IMPLEMENTED | New authored scenes, interactions and content acceptance |
| Android IL2CPP/player lifecycle/device FPS, memory and thermal tests | NOT EXECUTED | Build log, logcat and device profile |

## Unity acceptance procedure

1. Extract the complete ZIP into a separate directory; do not overwrite the Unity project currently in use. Open with Unity **2022.3.62f3**. Keep Safe Mode active if the Editor reports a compile error.
2. Resolve the current Console's exact compiler diagnostics before assuming the game is playable; verify NUnit/Test Framework assembly definitions.
3. Run Unity Test Runner EditMode tests including `ChapterInvestigationProgressionTests` and `StoryDossierTests`.
4. Run PlayMode tests including `StoryDossierPlayModeTests` and `ChapterOneSceneTests`. Validate that `CHAPTER CASES` for Chapter II is locked initially, Chapter I case 01 unlocks case 02, and completing case 02 enables Chapter II case 03. Check resume after restarting Play Mode.
5. Test one corrupt checkpoint slot, both corrupt slots, a future-version slot, stale concurrent sessions, and live-session rollback rejection. Use a disposable profile and preserve real PlayerPrefs data.
6. Inspect the chapter gallery and dossier on narrow landscape screens, notches and Android touch input; confirm no button overlap, cropped text, missing images or pointer leakage.
7. Validate chapter animation, rendering, sound and controls in real Unity PlayMode, then build and profile on an Android device before release approval.

## References and practice context

- Unity 2022.3 assembly definitions: https://docs.unity.cn/2022.3/Documentation/Manual/ScriptCompilationAssemblyDefinitionFiles.html
- Unity 2022.3 resource management: https://docs.unity.cn/2022.3/Documentation/ScriptReference/Resources.html
- Unity 2022.3 PlayerPrefs: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PlayerPrefs.html
- Unity Test Framework 1.1: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/index.html
- NIST SSDF (process guidance, not a certification): https://csrc.nist.gov/pubs/sp/800/218/final
