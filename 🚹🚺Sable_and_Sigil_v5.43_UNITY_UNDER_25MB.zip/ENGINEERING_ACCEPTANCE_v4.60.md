# Sable & Sigil v4.60 — Engineering Acceptance

## Scope and source
The complete v4.59 archive was used as the baseline. Source compatibility target remains Unity 2022.3.62f3; there has been no Unity editor execution in this environment.

## Source corrections
- `ChapterGalleryView.cs`: Chapter preview art is loaded on demand rather than all four chapters at gallery construction. Exactly one chapter texture is owned by this gallery at a time. Switching chapters detaches and unloads the prior asset; closing, disabling or destroying the gallery releases the active preview. Location artwork retains the existing single-texture policy.
- `ChapterGalleryView.cs`: Exposes `ResidentChapterArtworkCount` for explicit Unity PlayMode memory-ownership assertions, not a global GPU/CPU memory metric.
- `ChapterOneExperience.cs`: Caches the gallery component to avoid repeated lookups and pauses scene animations / world input while the full-screen chapter gallery is visible. The world camera suspension from v4.59 remains intact.
- `ChapterArtGalleryTests.cs`: Adds a PlayMode acceptance test for chapter switching, release on close, and successful reload. The test also asserts bounded chapter texture ownership.
- `Verification/chapter_texture_memory_gate_v460.py`: New static guard for image lifecycle and hidden-world updates.
- `Verification/test_chapter_texture_memory_gate_v460.py`: Seven mutation-oriented regressions, including detection of image preloading, unguarded world updates and missing close cleanup.
- `Verification/run_full_static_audit_v443.py`: Integrates the new gate into the maintained offline audit.

## Verification results
- Python regression suite: **185 passed**.
- Offline audit: **33 static gates and 1 test suite passed (34/34)**.
- No Unity, C# compiler, Android build, rendering or battery profiler was executed here. **COMPILE_VERIFIED / PLAYMODE_VERIFIED / ANDROID_DEVICE_VERIFIED remain false.**
- An offline pass is not an absence-of-leaks guarantee. Unloading a `Resources` texture removes the gallery's ownership, but actual GPU memory reclamation depends on engine behavior and cannot be measured statically.

## Device verification required
1. Use Unity 2022.3.62f3 with the installed project modules. Run EditMode and PlayMode tests from `Verification/Run-UnityVerification.ps1`.
2. On Android, repeat opening/closing the chapter gallery, switching all four chapters and ten locations, inspecting the lens and foreground/background cycles.
3. Profile Managed Heap, Total Allocated Memory, Texture Memory, RenderTexture Memory, GC allocation per frame, CPU/GPU frame time, sustained frame rate, temperature and power consumption. Compare before/after on the same device and graphics preset.
4. Exercise save interruption/corrupt checkpoint recovery and all chapter-one puzzle transitions on a device. No performance or power improvement is claimed without real measurements.

## Project content status
Chapter I is an implemented but editor-unverified vertical slice. Chapters II–IV remain concept art/locked; the ten location illustrations are references, not explorable 3D levels.
