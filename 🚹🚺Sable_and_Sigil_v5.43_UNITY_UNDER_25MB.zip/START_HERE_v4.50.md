# TheOrderRoom v4.50 — First Run

1. Extract the complete ZIP onto a local Windows filesystem outside cloud-synced folders.
2. Use the exact Unity Editor version named in `ProjectSettings/ProjectVersion.txt` (currently `2022.3.62f3`).
3. Double-click `OPEN_GAME.cmd` to check the Editor and open the project.
4. When packages and scripts finish importing, the Editor creates `Assets/_Project/Scenes/Main.unity` if needed. It requests Play Mode and only records success after observing an active game scene in Play Mode.
5. If automatic startup is blocked by an unsaved scene, save the scene and choose `TheOrderRoom > Retry Automatic Game Launch`.
6. For test evidence, run `Verification/Run-UnityVerification.ps1 -BuildAndroid` using a Windows PowerShell shell and Android Build Support modules.

Do not treat source verification as Unity runtime verification. Save Unity logs and test results for any failure.
