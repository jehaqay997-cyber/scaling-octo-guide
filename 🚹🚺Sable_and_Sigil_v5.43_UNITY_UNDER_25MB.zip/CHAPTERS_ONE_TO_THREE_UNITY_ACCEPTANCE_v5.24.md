# Sable & Sigil v5.24 — Chapters One to Three: Unity Acceptance

**Editor compatibility target:** Unity 2022.3.62f3.
**Delivery class:** Source candidate. This document is an acceptance protocol, not a claim that Unity was executed.

## 1. Source preparation

1. Extract the entire v5.24 ZIP to a local, fully writable folder. Do not extract into an existing project or a cloud placeholder folder.
2. Verify `ProjectSettings/ProjectVersion.txt` is `2022.3.62f3`, that `Packages/manifest.json` is present, and that the `.meta` files remain intact.
3. Open the extracted folder as a Unity project in the exact Editor version. Let Package Manager resolve the dependency graph. Retain the generated `Packages/packages-lock.json` in the resulting editor evidence; the source distribution intentionally does not claim a resolved package lock.
4. Require zero compile errors before interpreting any editor or test results. In particular, check NUnit, Test Framework, EditMode/PlayMode assembly references and editor-only code.

## 2. Generate and validate all scenes

Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` on Windows, or invoke `Verification/Run-SableAcceptance.ps1` with the Editor executable path. The preflight must execute `TheOrderRoom.Editor.SableLaunchAcceptance.PrepareAndValidateBatch` and emit `SABLE_SIGIL_LAUNCH_PREFLIGHT_PASS` only after validation succeeds.

Expect four enabled Build Settings scenes, in order:

1. `Assets/_Project/Scenes/ChapterOne.unity`
2. `Assets/_Project/Scenes/ChapterTwo.unity`
3. `Assets/_Project/Scenes/ChapterThree.unity`
4. `Assets/_Project/Scenes/Main.unity`

The two new chapter-case scenes must contain exactly one enabled `ChapterCaseSceneBootstrap` with matching ChapterNumber, exactly one `ChapterGalleryView`, and no missing scripts. The Main scene retains its separate invariant checks. Scenes are **generated and serialized by Unity**, not shipped as unverified serialized files.

## 3. Mandatory connected campaign tests

Start a clean checkpoint. From the Chapter One gallery, prove locations 01 and 02 require two inspected evidence pieces and their physical mechanisms. Dossier-first access must be rejected until those mechanisms are verified, and saved case reviews must remain available.

After completing both Chapter One cases, select Chapter II and use `ENTER CHAPTER II`: it must open location 03 with an active 3D world. Advance through 03–06 in order, exercising a wrong answer, a correct answer, staged hints, close/reopen, Back navigation, and a reload after each completed case. Verify no provisional puzzle solution is persisted by merely viewing the world.

After completing location 06, enter Chapter III and verify location 07 is opened. Complete 07–09 with the same checks, plus the three-stage locked/investigating/restored relief. Before evidence inspection, no answer-bearing shape may appear. A direct atlas click or public `StoryDossierView.Open` must not bypass the required physical mechanism for any unfinished case in 01–09.

Verify the world-to-dossier transfer requires a location-scoped, single-use `WorldInvestigationGrant`, and that stale checkpoint revisions are rejected. Show that the world handoff does not itself record durable completion; only submitting the correct dossier deduction updates progress. Returning from a Chapter II or III scene to Chapter One must load the authored Chapter One scene rather than leave an empty screen.

## 4. NUnit and platform gates

- **EditMode:** all required fixtures must appear in executed XML, including `ThreeChapterSceneIntegrationTests` and `WorldInvestigationGrantTests`.
- **PlayMode:** all required fixtures must appear in executed XML, including `ThreeChapterEntryPlayModeTests` and `ThreeChapterHandoffPlayModeTests`.
- Reject failed, skipped, inconclusive, missing, duplicated, or unrecognized test evidence.
- Check source fingerprints before and after testing; check generated scene/material fingerprints for unauthorized changes.
- On a physical Android device, verify landscape orientation, touch raycast blocking, Back/Escape, safe-area layouts, camera stability, and texture/mesh release over repeated scene transitions.
- Run a Development APK build only after NUnit and source gates pass. Build scene inclusion must cover all enabled chapter scenes, not Chapter One alone.

## 5. Release blockers and decisions

`COMPILE_VERIFIED`, `EDITMODE_VERIFIED`, `PLAYMODE_VERIFIED`, `SCENE_VERIFIED`, `ANDROID_VERIFIED`, and `DEVICE_VERIFIED` remain **FALSE** unless actual Unity output or device evidence proves otherwise. Static source tests and project archive checks never satisfy them. The fourth chapter is explicitly outside v5.24 scope.

The chapter-world geometry remains primarily procedural, and production-level visual fidelity is not confirmed by offline verification. If camera, scene build, UI, or artistic quality defects surface, reopen development rather than treating the acceptance run as a ceremonial sign-off.
