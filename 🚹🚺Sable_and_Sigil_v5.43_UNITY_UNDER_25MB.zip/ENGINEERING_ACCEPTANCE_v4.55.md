# Sable & Sigil v4.55 — Independent Source Acceptance

## Baseline
The supplied v4.54 ZIP was extracted and inspected directly. This update preserves all previous asset paths, Unity GUIDs and runtime names, including the 10 uploaded original location references and 4 chapter illustrations. No earlier file was deleted. Historical compiled Python cache files are retained as legacy bytes solely to preserve the full reference archive; they are not required by the game.

## Confirmed issue and repair
The chapter gallery displayed location-navigation controls even in the chapter-selection state, allowing an accidental transition to the atlas. The repair introduces explicit navigation button references, hides location-only controls when locationMode is false, and labels the atlas toggle according to its destination. This does not change save schemas, unlock state, chapter identity or puzzle rules.

## Evidence (source checks only)
- Python regression suite: 155 passed.
- Unified static gate: 28 required script gates and the regression suite passed.
- Original ZIP: 670 files, 0 zero-byte files, archive CRC validation passed.
- Original full paths retained: verified during packaging, with only the intended files modified.
- Existing chapter art: 4 entries. Existing location art: 10 landscape derivatives (1280x720) plus original source references.
- New PlayMode assertions exercise chapter-mode and atlas-mode control visibility. They have NOT been executed inside Unity.

## Remaining release blockers
1. No Unity Editor executable or C# compiler is installed in this environment. Compilation, EditMode and PlayMode tests are unverified.
2. No `.unity` scene is packaged. The project relies on editor bootstrap to create the scenes, and that bootstrap must be verified in Unity 2022.3.62f3.
3. No actual APK build, device input, graphics performance, or source-to-image gameplay validation was executed.
4. Location images are story references; they are not independent 3D levels or implemented puzzles.

## Acceptance decision
STATIC-SOURCE CANDIDATE ONLY. Production and device verification remain blocked until Unity and Android execution evidence exists.
