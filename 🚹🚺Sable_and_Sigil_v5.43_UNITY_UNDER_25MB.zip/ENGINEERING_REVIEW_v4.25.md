# TheOrderRoom v4.25 — Storage Trust-Boundary Hardening

## Source baseline
Full copy of v4.24, with targeted modifications documented below. No Unity compilation or device testing is claimed.

## Changes
- `Assets/_Project/Runtime/OrderSaveStore.cs`: replaced unbounded `Directory.GetFiles` allocation with bounded enumeration (maximum 4096 matching journal filenames). The limit fails closed and preserves files for forensic examination.
- `Assets/_Project/Runtime/OrderSaveStore.cs`: replaced file-size probe followed by `File.ReadAllText` with an exact bounded read from one FileStream. Strict UTF-8 decoding rejects malformed data. Limit: 1 MiB.
- `Assets/_Project/Editor/OrderSceneValidator.cs`: validates the UI input component that matches the compilation backend, avoiding a validator/bootstrap mismatch.
- `Assets/_Project/Tests/EditMode/SaveBoundedIoTests.cs`: tests oversized files, malformed UTF-8, and bounded enumeration. Tests are NOT EXECUTED until Unity Test Framework runs.

## Residual risks
- No independent C# compile or NUnit pass is established on this host. Any C# syntax or Unity compatibility errors require the exact Unity editor.
- Full historical verification on every `AdventureJournalStore.Commit` is O(N²) across N commits; optimize only with rigorously verified checkpoint compaction and crash-recovery proofs.
- Hashes are accidental-corruption detectors, not an authenticity guarantee against a malicious local actor.
- Desktop vSync / mobile target fps behavior and actual thermal/battery/GC impact require measurements in Unity Player on the target device.
- Missing Main.unity requires the documented batch bootstrap and its real execution evidence.

## Official references
- OWASP Input Validation Cheat Sheet: https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html
- Unity Application.targetFrameRate: https://docs.unity.cn/ScriptReference/Application-targetFrameRate.html
- Unity Test Framework: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html

## Acceptance gates
- SOURCE_STATIC: rerun all bundled static Python gates, inspect reported warnings.
- COMPILE_VERIFIED: run `Verification/Run-UnityVerification.ps1` with exact project editor.
- TEST_VERIFIED: NUnit XML must contain executed passing tests and no failures.
- DEVICE_VERIFIED: device profiler and battery/thermal test logs for the intended Android hardware.
