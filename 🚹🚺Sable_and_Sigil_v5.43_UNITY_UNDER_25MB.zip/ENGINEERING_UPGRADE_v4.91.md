# Sable & Sigil v4.91 — 3D Input Reliability and Gesture Safety

## Scope and baseline

- Base archive: `Sable_and_Sigil_v4.90_GOTHIC_VAULT_AND_STONE_SURFACE_CANDIDATE.zip`
- Unity target: **2022.3.62f3**.
- Source preservation: all existing v4.90 bytes are unchanged except the two files listed below; no art, puzzle answers, chapter mappings, saves, GUIDs, assembly definitions, packages, or project settings are rewritten.
- This is a **source candidate**, not a validated Unity binary or a release-ready game.

## Engineering defects addressed

1. Pointer-down raycasting treated the initial contact as an evidence inspection. Users could not safely initiate a drag over an evidence relic without inspecting it. The new finite-state gesture classifier requires a completed tap and rejects drags, cancellations, and nonfinite positions.
2. 3D exploration provided only button-based camera controls. Orbit drag, two-finger pinch, and mouse-wheel zoom are now supported in the compiled Input System and legacy Input branches.
3. The previous input path did not distinguish an in-progress gesture from a touch beginning on UI. A gesture must now begin off the UI; pinch and wheel are ignored when the pointer intersects interactive controls.
4. Losing application focus or suspending a mobile app now cancels any pending gesture, preventing a late release from inspecting a relic.
5. Reopening a world resets gesture and pinch baselines; opening and closing the 3D scene never writes dossier completion to PlayerPrefs.

## Modified source files

- `Assets/_Project/Runtime/ChapterWorldExplorer.cs`
- `Verification/run_full_static_audit_v443.py` (registers the new v4.91 static source gate)

## New files

- `Assets/_Project/Runtime/ChapterWorldGestureState.cs` and `.meta`
- `Assets/_Project/Tests/EditMode/ChapterWorldGestureStateTests.cs` and `.meta`
- `Verification/verify_world_gestures_v491.py`
- `Verification/test_world_gestures_v491.py`
- `ENGINEERING_UPGRADE_v4.91.md`
- `Verification/ReleaseManifest_v491.json` (created during packaging)

## Executed verification

- **313/313 Python unit tests passed** using `python -m unittest discover -s Verification -p test_*.py -q`.
- **46/46 independent static gates passed** in fresh separate processes with per-gate timeouts.
- New numerical threshold cases: 8 source-independent examples, including threshold equality, vertical motion and large movements.
- New mutation-focused Python tests assert that removing press/release separation, pinch, UI blocking, focus/pause safety, or finite-state safeguards makes the gate fail.
- New Unity EditMode NUnit tests cover five gesture regression scenarios. These tests were **authored but not run within Unity**.
- See the final archive's SHA-256 manifest for exact file preservation and provenance.

## Unverified acceptance stages

- `DESIGN_VERIFIED`: partial, static source contracts only.
- `COMPILE_VERIFIED`: false. No Unity Editor or C# compiler executed.
- `TEST_VERIFIED`: false for Unity EditMode/PlayMode. Offline Python tests are not a substitute.
- `DEVICE_VERIFIED`: false. No Android build or on-device gesture measurement.

## Next real-editor gates

1. Open the new folder using Unity 2022.3.62f3; resolve any new Console diagnostics without overwriting the baseline project.
2. Run the Unity Test Runner EditMode and PlayMode suites and save XML logs. Confirm `ChapterWorldGestureStateTests` pass.
3. On a touchscreen, test a stationary tap on each relic; a horizontal drag beginning over a relic; vertical drag; two-finger pinch; a finger starting over HUD; device rotation; and background-resume.
4. Verify camera yaw [-31°, +31°] and distance [6.6, 11.0] remain bounded; inspect frame time and GC allocations while repeatedly entering/leaving all ten worlds.
5. Build and profile on Android. No production acceptance is claimed until this completes.

## Primary references

- Unity 2022.3 Touch input phases: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Touch.html
- Unity Input System 1.4.3 touchscreen controls: https://docs.unity3d.com/Packages/com.unity.inputsystem@1.4/api/UnityEngine.InputSystem.Touchscreen.html
- Unity 2022.3 Object.Destroy: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Object.Destroy.html
