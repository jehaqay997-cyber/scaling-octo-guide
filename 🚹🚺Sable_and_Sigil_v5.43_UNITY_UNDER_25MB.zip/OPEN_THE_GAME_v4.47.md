# TheOrderRoom v4.47 — Windows Unity First-Run Acceptance

## How to open the actual Unity game

1. Extract the **entire** ZIP to a local, non-synced folder on Windows.
2. Install **Unity 2022.3.62f3**, the exact version specified in `ProjectSettings/ProjectVersion.txt`. Use Unity Hub to install that version and its Windows support. Android Build Support is optional for Editor Play Mode and required for Android builds.
3. Double-click **`OPEN_GAME.cmd`** in the extracted project root. The launcher validates project structure, discovers the exact Hub Editor, queries its version, and refuses to open a mismatched Unity binary.
4. Let Unity import all assets. The first-import Editor hook generates `Assets/_Project/Scenes/Main.unity` if needed, validates it, opens the Game window and enters Play Mode.
5. The visible game should show a 3D table, item cubes, target compartments, status and 13 interactive UI buttons. The first PlayMode smoke test now rejects a scene without rendered game pieces or a usable status.
6. If Unity is already open or automatic startup was blocked by an unsaved scene, choose **TheOrderRoom > Play Integrated Game**. Do not discard unsaved scenes.

## Verification on Windows

From the extracted root, run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1
```

For Android validation after installing SDK/NDK/OpenJDK and Android Build Support:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1 -BuildAndroid
```

Review `Verification/LocalResults/verification.json`, Editor logs, and NUnit XML. If Unity reports compilation errors or tests fail, do not claim that COMPILE_VERIFIED, TEST_VERIFIED, or DEVICE_VERIFIED has passed.

## What was verified in this delivery

- Extracted ZIP source and Python static regression checks are verifiable here.
- This environment has **no Unity Editor** and **no Windows PowerShell executable**. Consequently, the launcher, C# compilation, Unity scene generation, PlayMode test, Android build and physical device test **have not been executed** here.
- The browser HTML preview is a separate demonstration and must not be reported as a Unity gameplay test.
