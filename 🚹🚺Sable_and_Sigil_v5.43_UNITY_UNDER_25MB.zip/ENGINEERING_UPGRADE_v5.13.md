# Sable & Sigil v5.13 — Chapter One Pre-Unity Acceptance Candidate

## Source and intended scope
- Baseline: v5.12 (two first-chapter locations), with all original paths retained.
- Exact editor target: **Unity 2022.3.62f3**.
- Chapter One: **The Threshold of Vey** and **The Spiral of Testimony**.
- Visual quality, Unity compilation, NUnit execution, Android build and device performance are **not verified** by this offline development pass.

## Changes completed
1. The nearest-hit 3D raycast now respects solid `SceneryLayer` blockers in **both** first-chapter locations, not only the threshold. A new NUnit PlayMode case specifically models blocked and unblocked stair evidence.
2. Added `ChapterOneSymbolAtlas`: a single, transient 384×96 RGBA32 atlas with four visually distinct circle, diamond, star and crescent glyphs. The atlas is created once on opening the stair investigation, uses precomputed polygon vertices, discards its CPU pixel buffer after upload, owns no colliders, and is explicitly destroyed with the world.
3. The location-2 UI shows graphical marks instead of label-only tiles, including a visibly empty sixth slot. The slot turns into a star and receives success coloring only after the authoritative `SpiralBalusterPuzzle` verifies both clues and the choice.
4. Added three optional, bounded, evidence-gated stair hints. They cannot submit a solution, inspect clues, modify saves or grant deductions. Hint state is transient and resets on a new investigation.
5. Repaired the sixth motif **in the existing owned 3D mesh** upon verified selection. This changes the same mesh from 71 vertices/174 indices to 66 vertices/180 indices, without allocating another Mesh, GameObject, light, material or collider. Reopening recreates the unsolved motif.
6. Added/extended NUnit EditMode and PlayMode tests for owned atlas dimensions and UVs, bounded hint stages, non-mutating hints, in-place stair repair, visual feedback and 3D blocker behavior. Updated reviewed NUnit source fingerprints.
7. Updated acceptance metadata to the current v5.13 source while preserving exact Unity editor restrictions; added a detailed two-location playthrough acceptance checklist.
8. Added a new independent static and adversarial regression gate. All existing offline gates remain maintained.

## Evidence obtained in this offline environment
- Python regression suite: **608/608 PASS**.
- Maintained static source gates: **67/67 PASS**.
- Source images, serialized Unity scenes, existing `.meta` GUIDs: untouched, confirmed by parent-byte hashes in the version linkage report.
- Package CRC, per-entry SHA-256 and fresh-extraction replay: recorded in the external independent-verification report.

## Important limits
- `DESIGN_VERIFIED`: source contract and static checks passed; no rendered frame inspected inside Unity.
- `COMPILE_VERIFIED`: **NO**.
- `EDITMODE_VERIFIED`: **NO** (NUnit tests added, not run in Unity).
- `PLAYMODE_VERIFIED`: **NO** (NUnit tests added, not run in Unity).
- `DEVICE_VERIFIED`: **NO**.
- `RELEASE_APPROVED`: **NO**.

The requested **99% completion** is a target, not a defensible measured result. The project still uses a procedural 3D investigation scene and requires actual Unity rendering and input checks to establish production quality. A mobile build and device test remain separate acceptance gates.

## Windows handoff
1. Extract the ZIP to a local, writable, non-cloud-synced folder.
2. Close any other Unity instance using the project and run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd`.
3. Require successful Unity compiler, EditMode and PlayMode logs, inspect the full `SableSigilVerification` output; do not infer pass from script presence alone.
4. Follow `CHAPTER_ONE_UNITY_ACCEPTANCE_v5.13.md` for both cases, camera, touch, 3D/2D feedback, save and level unlocks.
5. After Unity acceptance, conduct real Android build and touch/safe-area/performance tests; do not claim shipped status before those results.

## Source of API compatibility guidance
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.Clear.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.SetVertices.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Texture2D.Apply.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Physics.Raycast.html
