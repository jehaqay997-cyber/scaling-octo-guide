# Sable & Sigil — Chapter Four Unity Acceptance Checklist (v5.26)

| Gate | Required observation | Evidence state at source delivery |
|---|---|---|
| Editor version | Unity `2022.3.62f3` matches `ProjectSettings/ProjectVersion.txt` | NOT_EXECUTED |
| Package import | Package Manager resolves test, UI and input dependencies | NOT_EXECUTED |
| C# compile | 0 compiler errors; no missing test-assembly references | NOT_EXECUTED |
| Scene serialization | Unity creates/imports `Assets/_Project/Scenes/ChapterFour.unity` | NOT_EXECUTED |
| Build scene ordering | ChapterOne → ChapterTwo → ChapterThree → ChapterFour → Main | NOT_EXECUTED |
| EditMode NUnit | `ChapterFourMeridianPuzzleTests`, `ChapterFourMeridianReliefTests` pass in Unity | NOT_EXECUTED |
| PlayMode NUnit | `ChapterFourWorldPlayModeTests` pass with Unity physics and UI | NOT_EXECUTED |
| Old chapters | Chapter 1–3 regressions pass without source behavior regressions | NOT_EXECUTED |
| Chapter unlock | Chapter IV locked before 01–09 completed; unlocked after case 09 | NOT_EXECUTED |
| Evidence lock | Four rings do not disclose order before two inspected records | NOT_EXECUTED |
| Physical interaction | Swap positions 1↔2 then 3↔4; mesh and source case agree | NOT_EXECUTED |
| Incorrect selection | Wrong swap preserves world control without granting case completion | NOT_EXECUTED |
| Case authority | World proof and dossier answer required; no direct atlas bypass | NOT_EXECUTED |
| Back / overlays | Back closes viewer before leaving; no camera commands pass modal | NOT_EXECUTED |
| State recovery | Scene exit/reentry resets transient ring state and preserves valid saved cases | NOT_EXECUTED |
| Android | Rendering, touch hit boxes, safe-area HUD, memory and save recovery | NOT_EXECUTED |

Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the extracted Unity project on Windows. Preserve all logs, XML and captured scene screenshots; do not infer completion from source static tests.

## Reproducible manual test

1. Reset case progress in a dedicated test profile. Confirm Chapter IV is locked.
2. Complete earlier nine cases through their authored physical investigations and dossiers. Confirm Chapter IV unlocks.
3. Enter `The Meridian Rotunda`. Observe locked, unlabeled rings and a disabled deduction action.
4. Inspect only evidence A. Confirm the ring mechanism is still inaccessible.
5. Inspect evidence B. Confirm the mechanism can open; read its two original case fragments.
6. Select ring position 1, then 2. Confirm the order changes from `BADC` to `ABDC` with one recorded swap.
7. Select positions 3, then 4. Confirm the order is `ABCD` and the 3D relief is restored without replacing its Mesh identity.
8. Confirm deduction still cannot open behind the active modal. Close the modal, enter deduction, and submit the authored correct choice.
9. Reopen the completed dossier from the atlas. Ensure progress persists across a full editor restart.
10. Reopen a fresh incomplete investigation in a separate profile; verify no transient swap state or hint stages leaked from prior sessions.
