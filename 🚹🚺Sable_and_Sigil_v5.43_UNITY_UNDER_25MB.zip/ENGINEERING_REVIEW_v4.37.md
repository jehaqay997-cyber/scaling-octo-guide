# TheOrderRoom v4.37 — Energy and Interaction Hardening

## Baseline
Derived from the supplied v4.36 release-source-governance candidate. Existing source and historical reports retained. Unity version remains 2022.3.62f3.

## Production code changes
1. `Assets/_Project/Domain/EnergyPuzzle.cs`: replaced `List<int[]>` + `RemoveAt(0)` with shared `BoundedHistory<int[]>` capacity 128. Removes O(n) shifting on eviction and reuses preexisting Domain infrastructure. Snapshot cloning still isolates each state. `Undo` and `Reset` retain their established contracts.
2. `Assets/_Project/Runtime/OrderGame.cs`: invalidating a requested item selection now clears `selected` *before* validation, avoiding accidental placement of a previously selected item after a failed selection attempt.

## Tests and protection
- `Assets/_Project/Tests/EditMode/EnergyHistoryRegressionTests.cs`: three new Unity NUnit cases for wraparound, reset, and invalid operations (written, not executed).
- `Verification/interaction_energy_gate_v437.py`: seven contract checks.
- `Verification/test_interaction_energy_gate_v437.py`: five Python tests, including three mutation checks and 120,000 operation differential history model.
- All 50 existing + new Python unittest cases passed in this environment.
- Governance, architecture, integration, camera, screen, restore static checks passed.

## Risks not closed
- Unity/C# compilation and NUnit/PlayMode execution could not run because Unity and a C# compiler are absent in this environment.
- Touchscreen hardware, persistence fault/power loss tests and Android profiling remain unverified.
- No claim of total vulnerability closure, exploit resistance against filesystem attackers, or a production-ready release is made.
- The save checksum is a corruption detector, not a secret-key authentication mechanism.

## Verified source references
- Microsoft `List<T>.RemoveAt` remarks: https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.list-1.removeat
- Unity Test Framework command line: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html
