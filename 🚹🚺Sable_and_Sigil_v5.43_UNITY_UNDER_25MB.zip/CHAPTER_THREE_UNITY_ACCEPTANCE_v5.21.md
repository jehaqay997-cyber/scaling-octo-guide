# Chapter Three Unity Acceptance — v5.21

**Required Editor:** Unity 2022.3.62f3. **Previous source baseline:** v5.20. **Candidate:** v5.21. **Locations:** 07, 08, 09.

## Editor execution

1. Extract the complete ZIP into a local writable directory on Windows, not a cloud placeholder or synchronized folder.
2. Open the **project root** in Unity Hub using the exact Editor above. Resolve Package Manager imports and confirm Console has no C# errors.
3. Exit Play Mode, close the Editor, and run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the extracted project root. Keep the complete Editor log, EditMode and PlayMode NUnit XML, evidence JSON, and compiler diagnostics.
4. Confirm that the Editor-generated scenes exist and are imported, that build scenes are configured and all linked assets resolve. The ZIP does **not** claim pre-generated `.unity` scenes or a resolved `packages-lock.json`.
5. Run the full inherited regression inventory plus `ChapterThreeMechanismTests`, `ChapterThreeReliefMeshTests`, and `ChapterThreeWorldPlayModeTests`. No pass is certified without genuine Unity result XML and an Editor log.

## Three-site playthrough and visual disclosure

For each location, use its actual authored art, not an invented placeholder:

| Location | Before evidence / after first evidence | After inspecting both evidence fragments | After selecting the unique correct answer |
|---|---|---|---|
| 07 — The Glass Testament | `GLASS / MIRROR  \|  INSPECT BOTH FRAGMENTS` | Shows top-to-bottom pane ordering, mirror unknown | Reversed mirror ordering appears |
| 08 — The Hall of False Light | `MEMORIAL / PORTRAIT  \|  INSPECT BOTH RECORDS` | Shows 1904 memorial and 1912 portrait conflict, truth unknown | Contradictory living sitting identified |
| 09 — The Weeping Witness | `DAMAGED EPITAPH  \|  INSPECT BOTH RECORDS` | Shows incomplete inscription, missing glyph unknown | Epitaph E restored |

- Initial world label must not reveal either the case-specific evidence transcript or the answer. Confirm it stays locked after inspecting only A **or only B**. Test both evidence orders in a fresh investigation.
- The second independent evidence inspection changes the world label to the incomplete problem statement. This does **not** credit the puzzle or unlock deduction.
- Wrong options never unlock deduction. A correct option changes the *existing* world label, status material, and owned relief mesh to the solved state, without spawning extra Mesh instances or extra colliders.
- Closing/reopening the mechanism preserves session-only attempts, hints and inspected fragments. Exiting and re-entering the world resets the transient puzzle and initial locked label. The dossier's durable case progress is not modified by world interaction alone.
- The world backplate cannot be used until both fragments are inspected; raycasts must be blocked by the nearest collidable opaque foreground object. The mechanism opens only when both fragments have been inspected.
- Artwork, evidence comparison and mechanism modals prevent camera orbit/zoom and direct atlas-exit callbacks. Android Back/Escape closes the top modal first, then camera focus, then returns to the atlas, without committing evidence or answers.
- Visually review title, inscription, four choice labels, safe-area sizing, touch targets, mesh facing, inlays, lighting, 16:9 and wide mobile layouts. Capture screenshots of all three sites in all three disclosure stages.
- Profile frame time, memory and GC on a real Android device; preserve device identity, logs and recordings.

## Verification matrix

| Gate | Candidate status |
|---|---|
| Python source regression and mutation tests | Source-only results recorded separately |
| Static contract gates and source archive integrity | Source-only results recorded separately |
| Unity Compile | **NOT EXECUTED HERE** |
| Unity EditMode (including ChapterThreeMechanismTests) | **NOT EXECUTED HERE** |
| Unity PlayMode (including ChapterThreeWorldPlayModeTests) | **NOT EXECUTED HERE** |
| Authored scene import, visual gameplay and physical Android | **NOT EXECUTED HERE** |

**Release policy:** This is a source candidate. Do not claim 99% verified completion or successful Unity execution on the basis of offline results.
