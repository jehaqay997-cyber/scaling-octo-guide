# Sable & Sigil v5.33 — UI, Story, Puzzle Disclosure, Privacy, and Audio Hardening

**Date:** 2026-11-22  
**Parent source:** v5.32  
**Required Unity compatibility target:** 2022.3.62f3 (unchanged)  
**Evidence level:** offline source and deterministic Python checks only; not a Unity build certification.

## 1. Changes implemented

### 1.1 Puzzle clue fairness and progression safety

- Added `Domain/ChapterHintDisclosure.cs`, a pure C# disclosure policy independent of Unity.
- All atlas hints begin hidden (tier 0). They are revealed only by explicit player input, one tier at a time, up to tier 3.
- Locked locations cannot reveal hints; a direct or scripted click on the disabled button cannot bypass the authoritative `StoryDossierSession.CanInvestigate` check.
- Switching location or switching between atlas and chapter selection resets the transient hint tier. Hints no longer wrap back to tier 1 after tier 3.
- Did not modify canonical puzzle solutions, unlock prerequisites, save schemas, persistence keys, or authoritative completion checks.
- The chapter-three glass puzzle now describes a mechanically defined silvered mirror carriage that exchanges upper and lower upright panes. This eliminates the earlier inaccurate assertion that a normal mirror vertically reverses the order of upright symbols.
- Synchronized case 7's new language across `StoryDossierCases.cs`, `ChapterStoryGraph.cs`, `PLAYABLE_DOSSIER_CONTRACT_v4.85.json`, `CASE_EVIDENCE_INSPECTION_v4.87.json`, `SCENE_PUZZLE_CONTRACT_v4.65.json`, and `CHAPTER_BEATS_v4.84.json`. The unique correct answer remains unchanged.

### 1.2 GUI readability and interaction

- Raised the brass button base color to `(.83,.69,.46)` for improved text-background separation on both the chapter atlas and interactive case files.
- Added explicit UGUI button normal, highlighted, selected, pressed, and disabled tint states without introducing UI packages or retaining additional image textures.
- Enabled bounded best-fit text for chapter and location labels and for the new privacy disclosure.
- Added a read-only `NEXT LEAD` after a solved case, derived from the authoritative available-but-unsolved location graph. It never awards evidence or bypasses the physical mechanisms. A fully completed investigation shows a completion line instead.
- Estimated sRGB contrast ratios: approximately 9.57:1 for chapter buttons and 9.92:1 for dossier buttons. These are mathematical source-color estimates, **not** actual render, font, resolution, contrast, or WCAG conformance certification.

### 1.3 Privacy transparency and local preference

- Added an in-game `PRIVACY & AUDIO` control. Its full-screen modal has an opaque raycast input shield and blocks underlying chapter/location navigation while open.
- Added `Runtime/LocalPrivacyPreferences.cs`, a small Unity-only adapter for an optional `AudioEnabled` setting stored in `PlayerPrefs` under the new dedicated key `SableAndSigil.Settings.AudioEnabled.v1`.
- Procedural feedback sound now observes the local setting. Muting also stops currently playing feedback on the active gallery audio source.
- The privacy panel accurately states that story checkpoints use local `PlayerPrefs` and other gameplay saves can use the app's local persistent-data directory. It warns that progress is not encrypted, that erasing app data can lose progress, and that Unity, Android and future third-party services need separate privacy review.
- No device identifiers, analytics, advertising, location or external-network API calls were added. A source scan covers the first-party runtime scripts only; it is not proof of all behavior by Unity, OS services or future plugins.
- No global `PlayerPrefs.DeleteAll()` or unrelated data deletion was added.

### 1.4 Test inventory and release governance

- Added `ChapterHintDisclosureTests.cs` (authored NUnit EditMode fixture) and `ChapterGalleryPrivacyPlayModeTests.cs` (authored NUnit PlayMode fixture). These tests have **not** been executed by the Unity Test Runner.
- Updated the SHA-256-hardened NUnit source fixture inventory and preserved all original fixture files.
- Added `verify_ui_privacy_puzzles_v533.py` plus mutation tests covering regressions in hint disclosure, UI modal shielding, audio preference persistence, narrative contract consistency and contrast.
- Updated `Run-SableAcceptance.ps1` candidate marker to v5.33. Kept the pinned Unity editor, package manifest, identity, asset resources and GUIDs unchanged.

## 2. Independent source verification

Working source tests: **918/918 Python regressions passed**.  
Working source gates: **88/88 independent bounded static audit commands passed**.

A second run on independently extracted archive files is recorded in the separately linked machine-readable verification report. A source-only success does not establish successful C# compilation, PlayMode state transitions, Android builds or real-device performance.

## 3. Known limitations and remaining risk

| Priority | Item | Evidence status / required action |
| --- | --- | --- |
| P0 | Unity C# compilation and Safe Mode | NOT EXECUTED. Open project in Unity 2022.3.62f3; capture actual editor/Package Manager logs. |
| P0 | Generated Unity scenes | NOT EXECUTED. Use the project-provided scene build/acceptance scripts; generated `.unity` scene files are not prepackaged. |
| P0 | Unity EditMode and PlayMode tests | NOT EXECUTED. Run the Unity Test Runner, inspect XML results and verify all required fixtures. |
| P0 | Android API 36, AAB, native 16 KB and signing | NOT EXECUTED. Run actual release preflight/build and inspect the output bundle. |
| P1 | UI accessibility, screen sizes and safe areas | NOT EXECUTED. Check case answers, modal input shielding, text, touch targets, keyboard navigation and contrast on devices in landscape. |
| P1 | Privacy behavior and store declarations | FIRST-PARTY SOURCE AUDITED ONLY. Verify installed packages, Android permissions, SDKs, network activity, data collection, privacy statements and Play Data Safety declarations. |
| P1 | FPS, battery, thermals, GPU/CPU memory | NOT MEASURED. Compare device traces before and after, not static estimates. |
| P1 | Package resolution | `packages-lock.json` remains absent; generate/retain the real lock file through Unity Package Manager; do not fabricate dependencies. |
| P1 | Source editor version and security | Keep pinned 2022.3.62f3 for this candidate. Evaluate later editor security fixes separately, with a migration acceptance matrix. |

## 4. Recommended execution order

1. Unzip into a local disk path outside synchronized/cloud placeholders.
2. Open using exactly Unity 2022.3.62f3 and resolve package dependencies; do not auto-migrate to another editor.
3. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` to generate/validate scenes and capture Unity logs.
4. Run the authored EditMode and PlayMode fixtures, including chapter privacy and hint disclosure cases.
5. Run all ten case walkthroughs and chapter handoffs, verify UI on the actual display size and profile GPU/CPU/thermal conditions.
6. Only after editor acceptance, review Android publication settings and produce an Android AAB candidate with artifact evidence.

**Release status: CANDIDATE / OFFLINE SOURCE VERIFIED ONLY.**
