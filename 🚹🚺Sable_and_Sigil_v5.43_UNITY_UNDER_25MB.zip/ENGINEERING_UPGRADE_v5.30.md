# Sable & Sigil v5.30 - Input, Audio, and Narrative Consistency

Compatibility target: Unity 2022.3.62f3. Parent: v5.29.

## Implemented

1. Reconstructed the 3D investigation pointer resume barrier. A gesture cannot resume from a held touch or two-finger pinch after the app loses focus or is suspended; the release frame is ignored. The state is transient and resets at world teardown.
2. Audio synthesis and playback are optional and fault-isolated. Failures release partially constructed native clips, suppress repeated warnings, and disable audio feedback rather than stopping puzzle or deduction progression.
3. Consolidated chapter stage titles and narrative hooks with the four chapters visible in the gallery: House of the Last Star, Veiled Conservatory, Ashen Gallery, and Hollow Meridian. Save identifiers, locations, puzzle solutions, and evidence prerequisites are unchanged.
4. Added EditMode tests for pointer-release hysteresis and a PlayMode lifecycle test for audio, with source fingerprints in the NUnit fixture inventory. These C# tests are not executed until the Unity Editor is run.
5. Added mutation-based static contracts and integrated the new gate into full offline regression auditing.

## Verification boundary

- Offline static source checks cannot certify Unity compilation, graphics, audio audibility, physical-device responsiveness, or measured battery/memory usage.
- Unity 2022.3.62f3 must import the project, build its scenes with the included Editor scripts, and execute both NUnit suites and Android test passes before release approval.
- Historic verification reports and prior manifests are retained as provenance only. New hashes and source-check evidence apply to v5.30 alone.
