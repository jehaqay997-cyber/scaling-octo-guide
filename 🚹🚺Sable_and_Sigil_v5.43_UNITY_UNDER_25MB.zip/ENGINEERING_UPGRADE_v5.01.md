# Sable & Sigil v5.01 — 3D Evidence Camera and Architectural Detail

**Unity compatibility:** 2022.3.62f3. **Status:** source candidate; compile, Unity tests and device evidence pending.

## Runtime development

- Added `ChapterWorldExplorer.TryFocusEvidence(int)` and `ReturnToOverview()` to support direct camera focus on evidence A and B and a deterministic reset to the original hall viewpoint.
- Focus is presentation-only: does not call `StoryCaseInspection.TryInspect`, submit an answer, or persist progress. Invalid indices, closed worlds and open original-artwork overlays reject focus.
- Added three clearly named Unity UI controls: `FOCUS EVIDENCE A`, `FOCUS EVIDENCE B`, `RETURN TO OVERVIEW`. The original artwork viewer retains its own 1×–3× zoom controls and the original resource texture.
- Added symmetrical non-colliding wall recesses, sconces and lantern diffusers beside (rather than over) the reference image. Twelve primitive accents per case share existing owned materials. No additional generated mesh, texture, external art dependency, or persistence schema change.
- Clarified the 3D visual evidence accounting: three owned arch meshes plus one vault and one floor sigil = five owned meshes per scene, matching the pre-existing PlayMode assertion.

## Verification changes

- Added `Verification/verify_world_focus_v501.py` and fourteen regression tests in `Verification/test_world_focus_v501.py`, including mutation attempts to bypass focus guards, grant evidence via focus, remove buttons, disable collider protection, or lose regression coverage.
- Expanded the existing PlayMode fixture with `FocusControls_TrackBothRelicsWithoutGrantingPuzzleProgress` and refreshed its SHA-256 in `EXPECTED_NUNIT_FIXTURES_v494.json`, preserving all 77 fixture identities.
- Updated version-sensitive source acceptance gates from v5.00 to v5.01, preserving the exact Unity editor target and existing assembly identity names.
- Fixed a stale historical static report that said four owned meshes where runtime and PlayMode tests establish five.
- Unit-test evidence: 442/442 Python regression checks passed. The 55 source gates passed in two phases: 51 before the combined runner timed out and four individually rerun afterwards. The original combined runner did not complete; its timeout must not be presented as a combined pass.

## Unity execution still required

Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from a local Windows clone with Unity 2022.3.62f3. The actual scene builder, C# compiler, 77 NUnit fixture discovery gate, PlayMode camera/UI tests, Android build and real-device profiling are NOT verified in this environment. Do not certify launch readiness until those operations produce fresh logs.

## Primary technical references

- https://docs.unity.cn/2022.3/Documentation/ScriptReference/PrimitiveType.Quad.html
- https://docs.unity3d.com/2022.3/Documentation/Manual/AnatomyofaMesh.html
- https://docs.unity.cn/2022.3/Documentation/Manual/ScriptCompilationAssemblyDefinitionFiles.html
