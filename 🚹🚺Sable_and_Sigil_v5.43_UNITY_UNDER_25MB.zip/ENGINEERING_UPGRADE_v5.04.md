# Sable & Sigil v5.04 — Authored Investigation Lighting & Material Response

**Project:** Sable & Sigil  
**Unity compatibility target:** `2022.3.62f3`  
**Baseline:** `v5.03`  
**Release classification:** source candidate; offline static evidence only.

## Shipped implementation

- Added `Assets/_Project/Runtime/ChapterWorldLightingRig.cs` with a validated, deterministic visual lighting profile for each of the ten authored investigation locations. Each location has its own key color, left and right fill colors, and bounded intensities.
- Replaced the single fixed gallery light with a scene-owned lighting rig: one key light and two lower-cost vertex-lit evidence fills. Each light has `LightShadows.None`; the rig is restricted to the existing scenery and evidence layers and follows scene lifecycle ownership.
- Added restrained lantern glass self-emission, distinct from interactive evidence materials. Standard-material metallic/smoothness parameters now differentiate antique brass and gothic stone without replacing imported reference artwork or creating new textures.
- Added Unity EditMode coverage for authored lighting profiles, invalid locations and layers, light count, absence of shadows, and scene ownership; extended the ten-location PlayMode integration suite to verify color, masks, and cleanup.
- Added `Verification/verify_location_lighting_v504.py` and 18 fault-mutation checks in `Verification/test_location_lighting_v504.py`. The static gate is now part of `run_full_static_audit_v443.py`.
- Updated both NUnit fixture source fingerprints and the acceptance source-baseline contract to `v5.04`. Fixture identity/count remained stable.
- Preserved original chapter/location images, existing `.meta` GUIDs and `.asmdef` files, domain puzzle solutions, journal and save storage.

## Verification constraints

- Python unit tests and static gates run outside the Unity Editor: **they cannot prove compilation, runtime shaders, frame rates, EditMode/PlayMode success, Android builds or hardware performance**.
- Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` on Windows with the installed Unity `2022.3.62f3`, after closing the Editor and extracting the ZIP outside cloud-synced folders.
- The Unity acceptance runner must generate new Unity logs and EditMode/PlayMode NUnit XML evidence before anyone may claim `COMPILE_VERIFIED` or `TEST_VERIFIED`.
- Android deployment, GPU profiling and device touch interaction remain independent acceptance gates.

## Design rationale

- One main point light, two vertex-evaluated fills, no per-frame rig updates and no shadow maps offer a bounded, mobile-conscious visual pass. No FPS or GPU savings are claimed without a device benchmark.
- Lights, materials and generated geometry remain owned by each investigation world. The original artwork is reused unchanged.
- Visual profiling never calls the puzzle, hint, reward, or persistence APIs.

## Official Unity API references

- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Light-renderMode.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Light-shadows.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Light-cullingMask.html
