# Start TheOrderRoom in Unity

Target Unity Editor: 2022.3.62f3 (exact version declared by project).

1. Extract this ZIP completely to a local Windows folder.
2. Double-click OPEN_GAME.cmd, or open the extracted folder in Unity Hub with the exact target editor version.
3. Allow import and compilation to finish. The Editor bootstrap creates Assets/_Project/Scenes/Main.unity when absent, opens it, and starts Play Mode after validation.
4. If a modified open scene prevents switching, save your changes then use TheOrderRoom > Retry Automatic Game Launch.
5. For manual override, use TheOrderRoom > Play Integrated Game.
6. For automated Editor validation on Windows, see Verification/Run-UnityVerification.ps1.

Unity compilation and game execution have not been performed in the packaging environment. The source is a candidate until Editor and device verification succeed.
