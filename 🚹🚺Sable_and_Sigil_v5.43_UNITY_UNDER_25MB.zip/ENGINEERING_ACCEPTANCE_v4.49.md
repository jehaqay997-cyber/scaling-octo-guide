# TheOrderRoom v4.49 — Automatic First-Run Recovery

## Source baseline
- Input: TheOrderRoom v4.48 First-Run Gate Integrated Candidate.
- Unity editor declared in ProjectSettings/ProjectVersion.txt: 2022.3.62f3.
- Original project files retained; OrderFirstImportSetup.cs modified.
- No pre-generated Main.unity is bundled. The Editor bootstrap generates it after import.

## Changes
1. Retry transient first-import launch failures at most three times per Editor session.
2. Avoid falsely marking auto-launch as completed before entering Play Mode.
3. Prevent reentrant/duplicate retries during import, compilation and Editor delay callbacks.
4. Preserve open unsaved scenes: never discard them or repeatedly force save dialogs.
5. Provide TheOrderRoom > Retry Automatic Game Launch to reset the retry counter.
6. Add static startup recovery gate with six mutation regressions and integrate it into the full audit.

## Verification executed outside Unity
- 130/130 Python unit tests PASS.
- 23/23 maintained static gates PASS; the unified run also executes the Python suite (24 stages total).
- ZIP integrity and SHA-256 manifest verified at package delivery.

## Not yet verified
- Unity C# compile, Editor import, scene generation, EditMode, PlayMode, Android build, on-device tests.
- Do not treat static source checks as runtime verification.

## Editor launch
1. Extract the entire archive to a local Windows directory.
2. Install Unity 2022.3.62f3 via Unity Hub.
3. Run OPEN_GAME.cmd.
4. If the Editor cannot auto-open because another unsaved scene is active, save that scene then select TheOrderRoom > Retry Automatic Game Launch.
5. If compile errors occur, resolve errors shown in Unity Console; the automatic retry is bounded and cannot repair missing packages or compile errors by itself.
