# TheOrderRoom v4.41 — Automation Governance Review

## Scope and evidence

This candidate extends v4.40. The source was inspected and Python tests were executed. There is no Unity Editor, C# compiler, or Android SDK available in this execution environment. No Unity compile, EditMode, PlayMode, Android build, APK installation, runtime performance, or device testing is claimed.

## Changes

1. Added `Assets/_Project/Editor/OrderAndroidBuildBatch.cs`, a Unity Editor-only, development-APK builder based on `BuildPipeline.BuildPlayer` and `BuildReport`. This fails if Android Build Support is unavailable, the active target is not Android, scene validation fails, the enabled build-scene set is unexpected, the APK output is in the Unity project, or an output artifact already exists.
2. Extended `Verification/Run-UnityVerification.ps1` with optional `-BuildAndroid` and `-AndroidOutputPath`. The stage runs after bootstrap, EditMode, and PlayMode have passed. Its success requires a zero-exit Unity process, a build success log marker, a nonempty APK, and SHA-256 evidence. The default output goes to a sibling directory, outside the project source tree.
3. Both NUnit suites now require no skipped tests, preventing an ignored test from silently qualifying as production evidence.
4. Added seven source-level Python regression checks for the Android automation gate. These do not substitute for C# compilation or real build execution.

## Execution on Windows

Open PowerShell and run from the extracted project folder:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1 -BuildAndroid
```

The exact Unity version is read from `ProjectSettings/ProjectVersion.txt` (`2022.3.62f3`). Install that Editor with Android Build Support plus SDK, NDK, and OpenJDK; or pass `-UnityEditorPath` pointing to the matching Unity executable. Use `-AndroidOutputPath` for a separate empty artifact directory. Do not run the verification against a concurrently open Unity project. The APK is a **development build**, not a signed store release.

## Governance decision

SOURCE_STATIC_PASS can be established by Python checks. COMPILE_VERIFIED, EDITMODE_VERIFIED, PLAYMODE_VERIFIED, ANDROID_BUILD_VERIFIED and DEVICE_VERIFIED remain **NOT VERIFIED** until independent execution evidence is captured. The Android build option cannot replace physical device testing. Release promotion is prohibited until these gates and appropriate signing/distribution reviews pass.

## Primary references

- Unity 2022.3 scripting API: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/BuildPipeline.html
- Unity 2022.3 Android setup: https://docs.unity3d.com/2022.3/Documentation/Manual/android-sdksetup.html
- Unity Test Framework: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html
- Microsoft PowerShell: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_try_catch_finally
