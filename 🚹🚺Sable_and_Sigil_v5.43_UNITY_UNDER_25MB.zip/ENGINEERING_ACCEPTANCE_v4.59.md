# Sable & Sigil v4.59 — Mobile resource lifecycle and power review

## Scope

Actual v4.58 source archive reviewed; all existing source/art paths retained. This is a source-verified candidate, **not** an executed Unity or Android acceptance build.

## Changes

1. ChapterOneExperience dynamically installs a single `OrderPerformanceGovernor` when needed so the chapter participates in the existing 30/24 FPS mobile frame-budget policy. Existing owners remain protected from duplication.
2. Lens inspection checks that the GPU RenderTexture can be created before opening. Closing the inspection or hiding overlays releases its backing GPU memory. Application pause releases it, and resume recreates it only if inspection is still open. The RenderTexture object stays bound to the UI, avoiding an invalid texture pointer or repeated managed allocations.
3. ChapterGalleryView detaches a previous location texture from its RawImage before unloading it, preventing a dangling Unity native-asset reference.
4. An opaque chapter/location gallery suspends the world camera while open, and restores only the camera it previously suspended upon Close/OnDisable/OnDestroy. Its ScreenSpaceOverlay interface remains visible.
5. Added separate Unity PlayMode tests for camera lifecycle and for opening, closing and reopening the lens inspection target.
6. Added `chapter_resource_lifecycle_gate_v459.py` to the unified static gate and eight mutation-oriented Python tests.

## Verified in this environment

- 178 Python unittest assertions passed.
- 32/32 static source gates passed; 33/33 commands including Python suite exited successfully.
- Archive source preservation, 14+ photographic resource dimensions, archive CRC, file lengths and SHA256 are audited in packaging.
- **NOT EXECUTED**: Unity C# compile, EditMode or PlayMode test execution, GPU memory/thermal profiling, battery drain benchmarking, APK production, physical Android checks.

## Unity acceptance sequence

1. Import on Unity 2022.3.62f3 and resolve any Console compiler issues.
2. Run EditMode then PlayMode including `ChapterOneSceneTests.LensInspection_ReleasesAndReacquiresGpuSurface` and `ChapterArtGalleryTests.OpaqueGallerySuspendsWorldCameraAndRestoresItOnClose`.
3. Open/close atlas repeatedly, inspect lens repeatedly, background/foreground the app, check Unity Memory Profiler GPU memory, and verify no persistent RenderTexture increases.
4. Use Android Profiler/ProfilerRecorder on actual hardware: record GPU frame time, CPU time, battery/thermal, FPS and peak memory across at least 15 minutes of interaction. Do not claim battery improvement from source review alone.

## References (official Unity 2022.3)

- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/RenderTexture.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Application-targetFrameRate.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/MonoBehaviour.OnApplicationPause.html

## Evidence limitation

No Windows Unity editor/runtime, Android device or C# compiler was available in the execution container. Source contracts passed; real-time energy leaks and render behavior are **not certified**.
