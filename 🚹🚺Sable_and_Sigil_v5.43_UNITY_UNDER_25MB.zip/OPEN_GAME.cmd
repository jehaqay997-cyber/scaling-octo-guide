@echo off
setlocal
set "TOR_ROOT=%~dp0"
if not exist "%TOR_ROOT%OPEN_GAME.ps1" (
  echo Missing OPEN_GAME.ps1. Extract the complete archive before running.
  pause
  exit /b 1
)
if "%~1"=="" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%TOR_ROOT%OPEN_GAME.ps1"
) else (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%TOR_ROOT%OPEN_GAME.ps1" -UnityEditorPath "%~1"
)
set "TOR_EXIT_CODE=%ERRORLEVEL%"
if not "%TOR_EXIT_CODE%"=="0" pause
exit /b %TOR_EXIT_CODE%
