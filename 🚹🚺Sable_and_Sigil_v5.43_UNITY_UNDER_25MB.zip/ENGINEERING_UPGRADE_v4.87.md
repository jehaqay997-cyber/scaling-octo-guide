# Sable & Sigil v4.87 — Engineering Acceptance Candidate

**Baseline:** v4.86 (`Sable_and_Sigil_v4.86_CHAPTER_PROGRESSION_AND_NARRATIVE_INTEGRITY_CANDIDATE.zip`)
**Target Unity Editor:** 2022.3.62f3
**Scope:** staged evidence inspections and guarded deduction UI across all ten existing dossiers.
**Release state:** STATIC_SOURCE_ACCEPTED; UNITY_COMPILE_NOT_VERIFIED.

## Implemented changes

- Added `StoryCaseInspection` (pure C# domain model): one independent, ephemeral two-fragment inspection per dossier; duplicate inspections do not increment the count; invalid indices have no effects; reopening starts a fresh inspection.
- Extended `StoryDossierCase` with immutable `EvidenceFragments` and validation for exactly two distinct nonblank fragments.
- Authored twenty case-specific evidence excerpts, directly mapped to the ten existing dossier choices and the four-chapter location graph.
- Updated the existing `StoryDossierView` to expose separate evidence A/B controls and disable deduction until both files are inspected. This is a UI flow gate, not an anti-cheat security boundary; `StoryDossierSession` remains the authoritative owner of durable completion.
- Fixed the end-state presentation so the full case finding is displayed in the evidence pane instead of the narrow status area. Progressive hints now stop at tier three rather than wrapping to tier one.
- Expanded EditMode and PlayMode source tests. Existing PlayMode test methods now exercise both evidence inspections and reject premature UI submission before any save writes.
- Upgraded the v4.85 static dossier parser to recognize the new optional fragment metadata, without changing the historical v4.85 authoring contract.
- Introduced a new `CASE_EVIDENCE_INSPECTION_v4.87.json` authored design contract and mutation-gated checks for content drift, repeated inspection, bypassed interaction, future-3D claims and save-key changes.

## Preservation and changes

- Prior archive files retained: **771 / 771**.
- Existing files changed: **5**.
- New source, metadata, tests, and audit contract files added before evidence/manifest: **7**.
- Zero historical `.meta` files, sprites/art, `.asmdef`, Unity scene/prefab assets, `Packages`, or `ProjectSettings` altered.
- No changes to save schema, checkpoint keys, or `StoryDossierRepository` behavior.
- The four chapter art files and ten location images are reused unchanged; no unverified 3D chapter scene is asserted to exist.

## Per-file modifications
- `Assets/_Project/Domain/StoryDossierCases.cs`
- `Assets/_Project/Runtime/StoryDossierView.cs`
- `Assets/_Project/Tests/PlayMode/StoryDossierPlayModeTests.cs`
- `Verification/run_full_static_audit_v443.py`
- `Verification/verify_story_dossiers_v485.py`

## Executed evidence (offline)

- `python -m unittest discover -s Verification -p test_*.py -q`: **276 of 276 Python tests passed**.
- `python Verification/run_full_static_audit_v443.py`: **43 of 43 static gate stages passed**.
- ZIP CRC and per-file SHA-256 manifest: verified after packaging, details in `Verification/SHA256_MANIFEST_v4.87.json`.
- Source preservation and GUID contracts checked against the exact prior ZIP.

## Explicitly unverified

| Gate | Verified? | Needed evidence |
|---|---|---|
| DESIGN_VERIFIED | Partial (source contracts only) | Human playability and scene/UX review |
| COMPILE_VERIFIED | No | Unity 2022.3.62f3 Console / Editor.log after import |
| TEST_VERIFIED | No Unity execution | Actual EditMode and PlayMode test-runner XML + log |
| DEVICE_VERIFIED | No | Android build, device run, logs and profile |

Python source checks do not prove C# compiler acceptance, Unity asset import, user interface layout correctness or mobile accessibility. Local PlayerPrefs saves are not encrypted: checksums detect accidental corruption but do not protect against deliberate modification.

## Next execution priorities

P0. Open this candidate independently in Unity 2022.3.62f3, resolve any assembly/package compilation errors, and retain Editor.log; do not exit Safe Mode on a failed compile.

P0. Run **EditMode** `StoryCaseInspectionTests` and all existing domain/save tests; run **PlayMode** `StoryDossierPlayModeTests` and chapter transition tests; capture XML results.

P1. Test the full 10-case sequence from a clean profile, including wrong guesses, missing evidence, hint tiers and reload after every chapter boundary. Use isolated test save keys only, and restore any original PlayerPrefs values.

P1. Measure font legibility, safe-area layout, and art memory on low-spec Android; test pause/resume, app termination and recovery.

P2. Author real 3D chapter II–IV environments separately with validated scene/puzzle/art contracts before enabling their enter buttons.

## Official references

- Unity 2022.3 assembly definition file format: https://docs.unity3d.com/2022.3/Documentation/Manual/AssemblyDefinitionFileFormat.html
- Unity Test Framework 1.1: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/index.html
- Unity 2022.3 PlayerPrefs: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PlayerPrefs.html
- NIST Secure Software Development Framework (SP 800-218): https://csrc.nist.gov/pubs/sp/800/218/final
