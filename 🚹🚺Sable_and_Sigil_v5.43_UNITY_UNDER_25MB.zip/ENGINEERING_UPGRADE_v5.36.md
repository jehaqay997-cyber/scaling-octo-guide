# Sable & Sigil v5.36 — Cinematic Photographic Adventure Candidate

**Unity target:** 2022.3.62f3 (unchanged)  
**Based on:** v5.35 source integrity / finale / puzzle candidate  
**Reference identity:** the atmosphere of *Lost Lands* (Five-BN Games), not its proprietary imagery, scripts, story, characters, music, levels, assets, or interface designs.  
**Verified class:** offline Python/static and archive integrity only. No Unity or Android execution.

## Intended direction

An original, grounded, cinematic mystery-fantasy adventure with tactile observation and physical puzzles, rather than anime, cartoons, neon-highlighted arcade puzzles, or a dossier-only interface. Photographic natural/architectural environments should communicate the scene first; clue markers, inventory, subtle world mechanisms and the narrative should support exploration rather than dominate the view. The visual reference is a design target, not a claim of equivalent production quality.

## Source modifications executed

1. **Photo-first scenic exploration:** `CinematicScenePresentation.cs` creates a full-bleed original location photograph behind the HUD in every one of the ten authored investigation locations. All photographs are shown with their complete original 16:9 texture coordinates; no user-supplied photograph is altered, copied, regenerated, or transformed by the change. Subtle natural-colored contrast bands help foreground copy remain readable.
2. **Diegetic evidence discovery:** two location-specific tap targets reveal evidence A/B using the *existing* `TryInspectEvidence` authorization path, not a new bypass. When both fragments are inspected, an initially hidden mechanism marker appears and delegates to the original physical Chapter 1–4 puzzle. A modal cannot be bypassed by switching presentation modes. Completion still requires the original mechanism and deduction.
3. **Reversible 3D inspection:** the `INSPECT 3D RELICS` button switches to the existing real-time 3D room to inspect tactile relics, or returns to full-scene photography. The world camera is disabled while the photograph is visible to avoid unnecessary camera rendering. Existing room materials, 3D geometry, colliders, puzzle IDs and UI overlays are retained. Pointer gestures are cancelled across view switches.
4. **Less crowded scenic interface:** existing rotation, camera focus and 3D-control buttons are visually hidden and cannot capture touch while the scenic photograph is on screen, but remain available in the 3D inspection mode. Story and physical puzzle modals render above the switch button.
5. **Original environment narration:** ten new location-specific non-spoiler prose lines add texture and narrative progression without changing puzzle solutions or granting storyline progress.
6. **Mathematical invariants:** `CinematicSceneMap.cs` supplies an immutable per-location hotspot contract with finite normalized coordinates, ten numbered location records, safe photographic bounds and minimum separation (squared normalized Euclidean distance at least `0.0100`). Its consistency is checked by the existing Editor preflight.
7. **New tests:** `CinematicSceneMapTests.cs` (EditMode), `CinematicAdventureScenePlayModeTests.cs` (PlayMode), and a new Python mutation suite. The existing SHA-locked NUnit fixture inventory is updated without removing prior fixtures.
8. **Regression assurance:** ten original photo SHA-256 hashes were snapshotted in `Verification/CINEMATIC_ART_BASELINE_v536.json`. The new source gate detects missing/tampered photographs, missing scene records, overlapping markers, loss of modal/state gates, invalid camera toggling, missing editor validation or removed test coverage.

## Rendering and UX caveats (confirmed from sources)

- The supplied location JPEGs are 1280×720, with some photographs featuring blurred side regions **baked into the image itself**. This update preserves all source bytes and cannot reconstruct missing photographic environment detail from them. New carefully authored wide-frame images are needed to remove these blurred areas without sacrificing image quality.
- The original 3D world is a procedural proxy using cubes, simple materials and per-location photographic panels. It **does not** become photorealistic 3D geometry by introducing a photographic adventure view. Production-grade PBR assets, believable vegetation/stone/wood microgeometry, proper depth, lighting, character animation and cinematic compositions remain an art-production milestone.
- New photo hotspots are source-authored coordinates and have not been tested against real phone resolutions or with screen reader/accessibility services. Art composition, hit target spacing, performance and focus need PlayMode and Android verification.
- The 3D world geometry is still instantiated on entry even if its camera is disabled in scenic mode. Therefore, camera rendering work may be reduced, but CPU creation cost and resident mesh/material memory **have not been independently measured**.
- No audio rights, proprietary Five-BN assets, or external textures were added. No package versions, Unity Editor version, save format, PlayerPrefs keys, existing photo bytes or `.meta` identities were changed.

## Verification

- `python -m unittest discover -s Verification -p 'test_*.py'` — 964/964 PASS on the source worktree.
- Independently invoked static gates — 90/90 PASS, including v5.36 artwork-and-mode source gate.
- Complete source ZIP integrity / clean re-extraction — documented in `Sable_and_Sigil_v5.36_Independent_Verification.json` outside the ZIP after package assembly.
- **Unity C# compile:** NOT EXECUTED; **EditMode/PlayMode NUnit:** AUTHORED BUT NOT EXECUTED; **Android build and gameplay:** NOT EXECUTED; **performance/thermal/battery:** NOT MEASURED.

## Unity acceptance procedure

1. Open the extracted project in Unity **2022.3.62f3**, let packages import, and resolve **all** Console compiler errors before interpreting any results.
2. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` (from Windows with the Unity editor installed). Preserve logs and NUnit XML.
3. Play all ten investigation sites. Each should open in original photographic mode. Tap each scenic clue, confirm no auto-completion, then attempt the original physical mechanism. Toggle `INSPECT 3D RELICS` to verify the 3D room, camera, inspect controls and a return to scenery.
4. Check photo/map layout on 16:9, 20:9 and tablet ratios, safe areas, accessibility sizing, the Chapter 3 and Chapter 4 modals, persistence after process restart and opening the finale **only** with verified full progress.
5. Test actual hardware on Android (touch, frame time, thermal throttling, texture use, memory, crashes and crash-free return from background). Confirm production Play target SDK, package locking, signature, 64-bit and 16 KB compliance separately.

## Official reference documentation

- Five-BN Games' listing for Lost Lands 5: https://play.google.com/store/apps/details?id=com.fivebn.ll5.f2p
- Unity 2022.3 Manual UI scaling: https://docs.unity3d.com/2022.3/Documentation/Manual/script-CanvasScaler.html
- Unity 2022.3 camera lifecycle: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/MonoBehaviour.OnPreCull.html
- Unity rendering pipeline feature comparison: https://docs.unity3d.com/2022.3/Documentation/Manual/render-pipelines-feature-comparison.html

**Acceptance:** v5.36 is an original cinematic-exploration SOURCE CANDIDATE, not a proof of Editor import, interactive PlayMode, photorealism, equivalent scope to Lost Lands or commercial readiness.
