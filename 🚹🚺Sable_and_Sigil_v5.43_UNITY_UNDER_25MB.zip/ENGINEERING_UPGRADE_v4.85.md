# Sable & Sigil v4.85 — Interactive Investigations and Recoverable Progress

**Baseline:** `Sable_and_Sigil_v4.84_CHAPTER_SYSTEMS_AND_30_BEATS_CANDIDATE.zip`.
**Unity target:** 2022.3.62f3. **Release state:** SOURCE CANDIDATE, NOT UNITY COMPILE VERIFIED.

## Delivered gameplay

- All ten existing location concepts now have an **interactive 2D deduction dossier** using their original chapter atlas artwork, a written evidence brief, a question, four distinct conclusions, and an authored explanation.
- Player flow: Chapter One 3D room -> Chapters -> Scene Atlas -> Open Case File -> select a deduction -> return to atlas. The next dossier is unlocked only after the previous evidence is durably committed.
- Cases are assigned to the four chapters under the existing ChapterStoryGraph and retain the 30 authored location-specific hint tiers from v4.84.
- Cases use ten distinct logical/mathematical puzzles: a seal discrepancy, a periodic pattern, a phase cycle, additive flower counts, constrained spout order, direction composition, mirror reversal, contradictory dates, inscription restoration, and meridian constraint ordering.
- Existing 3D chapter entry controls remain explicitly disabled for unfinished locations. **The interactive case-file mode is not a newly implemented 3D chapter scene.** Main Chapter One's existing gameplay is untouched.

## Architecture and state safety

- Domain source: `StoryDossierCases.cs`, `StoryDossierPersistence.cs` are engine-independent and compile within the existing `TheOrderRoom.Domain` assembly.
- Runtime source: `StoryDossierView.cs` owns the overlay and borrows (without duplicating or destroying) the atlas artwork; `PlayerPrefsDossierStorage.cs` is the Unity-specific storage adapter; `ChapterGalleryView.cs` hosts the entry point.
- Progress owner: `StoryDossierSession` clones the current `StoryEvidenceLedger`, validates the answer, expected revision and evidence prerequisites, saves the proposed revision, and only then promotes it to live state.
- Storage: a **new** versioned key namespace, `SableAndSigil.StoryDossier.v1.CheckpointA/B`. Existing Chapter One, journal, and main-game save keys are unchanged. The repository rotates between two independent snapshots, verifies bounded SHA-256 digests, validates semantic ordering, rejects external/stale writers and conflicting history, and never overwrites a recognized unsupported future-version payload.
- Failure policy: if both snapshots are invalid, the dossier is read-only and the original bytes are preserved. A single valid older snapshot can restore progress if its newer partner is corrupted. No silent save reset occurs.
- In-process repository storage operations are serialized with a shared lock. This is **not** cross-process file locking, cryptographic authentication, or proof of device durability.
- Existing picture files and Unity `.meta` identifiers are preserved. The dossier panel reuses the atlas texture, which is detached before atlas resource unload.

## Independent source checks

- Original v4.84 ZIP: 742 entries; every original entry is retained.
- 6 new C# source files and corresponding `.meta` files.
- 1 added authored content contract and new Python static/mutation verification gate.
- 2 new Unity test source files (12 EditMode tests and 1 PlayMode test). They are **authored, not executed**.
- 256/256 Python tests passed, including 11 new dossier mutation/logic checks.
- 41/41 full static audit stages passed (40 gates plus Python suite).
- All 10 dossier answer keys are independently checked against their stated mathematical or logical constraints in the Python gate, including permutation uniqueness for the spout and meridian sequences.
- Current ZIP CRC, path safety, manifest hashes, Unity GUID uniqueness, assembly reference integrity and all-original-file preservation must be independently checked after packaging.

## Evidence boundaries

| Stage | State |
| --- | --- |
| Static source and content audit | PASS |
| C# compilation using Unity 2022.3.62f3 | NOT EXECUTED |
| NUnit EditMode + Unity PlayMode | NOT EXECUTED |
| Gamepad/touch/UI visual acceptance | NOT EXECUTED |
| Android IL2CPP build and hardware performance | NOT EXECUTED |
| 3D production scenes for Chapters II–IV | NOT IMPLEMENTED |

**Do not equate passing Python/static analysis with a Unity compile, playability acceptance, mobile performance, or completion of the 3D chapters.** PlayerPrefs is not encrypted and SHA-256 without a protected secret detects accidental corruption only; it does not prevent intentional local modification.

## Execution acceptance in Unity

1. Back up the locally edited project. Extract v4.85 into a new folder. Open in Unity 2022.3.62f3, not the separate Unity 6 target used by TheOrderRoom.
2. Resolve any compiler diagnostics. Keep Safe Mode until the Console has zero compilation errors.
3. Run Unity Test Runner EditMode and PlayMode. In particular execute `StoryDossierTests` and `StoryDossierPlayModeTests`; record Test Runner XML.
4. In Chapter One, choose `CHAPTERS -> SCENE ATLAS -> LOCATION 01 -> OPEN CASE FILE`. Submit one incorrect option, then the authored correct choice, close it and verify Location 02 becomes available. Validate all ten cases and each chapter boundary.
5. Test malformed/newer checkpoints using an isolated test profile. Verify that both-invalid data stays untouched and an older valid slot remains readable.
6. Confirm that closing the atlas releases its image, while a visible dossier retains its image until dismissal. Verify the touch layout, narrow safe areas, UI event shielding, and device accessibility.
7. Run Android build, on-device interruption and restart tests, memory/GC and frame-time profiling, then visual acceptance for chapter artwork and interaction before promoting to a release.

## Official references

- Unity 2022.3 PlayerPrefs: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PlayerPrefs.html
- Unity 2022.3 Assembly Definition format: https://docs.unity3d.com/2022.3/Documentation/Manual/AssemblyDefinitionFileFormat.html
- Unity Test Framework: https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/index.html
- NIST Secure Software Development Framework: https://csrc.nist.gov/pubs/sp/800/218/final
