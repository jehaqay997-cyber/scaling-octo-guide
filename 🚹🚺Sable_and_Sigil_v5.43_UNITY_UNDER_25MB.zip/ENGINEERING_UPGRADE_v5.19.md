# Sable & Sigil v5.19 — Chapter Three 3D Evidence Mechanisms

**Baseline:** v5.18. **Compatibility target:** Unity 2022.3.62f3.
**Scope:** Locations 07–09 only. Prior chapters, dossier solutions, imported images, scene assets, and existing Unity GUIDs are preserved byte-for-byte.

## Engineering changes

- Added `ChapterThreeMechanismPuzzle` to the pure Domain assembly: three authored locations, exact case-answer authority delegated to `StoryDossierCatalog`, independent clues A/B required, saturating attempt count, single verification, bounded three-stage hints and per-session reset.
- Added visual metadata for the mirrored stained-glass symbol order, contradictory memorial dates and restored inscription. Unsolved world text and inlay conceal the solution until verification.
- Added a chapter-scoped interactive physical backplate in the 3D world. Its nearest-hit physics interaction respects opaque blocking colliders, and the modal blocks world and background UI clicks.
- Added one site-specific, collider-free `ChapterThreeReliefMesh` per scene with explicit back-facing winding toward the game camera. All geometry is bounded under 512 triangles per state; `Rebuild` reuses the owned Mesh and never creates a second engine Mesh.
- Added a dedicated close-up camera orbit for each scene's physical puzzle; Back/Escape consumes one navigation layer and never commits a solution, reveals new evidence or writes to storage.
- Integrated Chapter Three puzzle verification into the `CanDeduce`/`Finish(true)` barrier, without changing the existing text dossier or campaign persistence rules.
- Added two EditMode fixture classes and one PlayMode fixture class, all registered in the approved NUnit manifest. These tests are authored source and have **not been executed within Unity**.
- Updated legacy source-audit scope to check Chapter Two functions specifically, preventing Chapter Three's similarly named code from masking a regression.

## Verification boundary

Offline Python regressions, maintained static gates, asset fingerprint checks and ZIP integrity must be run and documented for this release. This source candidate is **not** compiled, visually rendered, or device-tested by this environment. Consult `CHAPTER_THREE_UNITY_ACCEPTANCE_v5.19.md` for actual acceptance gates.

## No unsupported release claims

`COMPILE_VERIFIED=false`; `EDITMODE_VERIFIED=false`; `PLAYMODE_VERIFIED=false`; `ANDROID_DEVICE_VERIFIED=false`; `RELEASE_VERIFIED=false`.
