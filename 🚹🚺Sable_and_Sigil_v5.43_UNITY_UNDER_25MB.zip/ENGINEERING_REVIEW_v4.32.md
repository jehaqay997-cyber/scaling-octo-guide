# TheOrderRoom v4.32 — Gesture Integrity & Interaction Safety

## Scope

Baseline: TheOrderRoom v4.31 (422 archived entries). This change is an incremental engineering candidate, not a claim of production readiness. The baseline targets Unity Editor `2022.3.62f3` as declared in `ProjectSettings/ProjectVersion.txt`.

## Verified defects and remediation

1. **Tap target changed between press and release.** A world gesture that began on empty space could activate an item under the release point after movement. The input classifier now latches movement beyond its threshold, and a valid tap is dispatched at its original press location only.
2. **UI/world event ambiguity.** A touch ending on an overlaid UI element could still be dispatched as a world tap. A release over UI now aborts the world command for both taps and drags.
3. **Stale item selection after failed acquisition.** A dragged item's `Select` operation was not checked before `Place`; this could leave a previous selection eligible for placement. The gesture drop path now requires `TrySelectItem` success before invoking `Place`, retaining the public `void Select` signature used by Unity's existing integrations.

## Implementation inventory

- `Assets/_Project/Runtime/OrderGame.cs`: gesture threshold, press-anchored taps, UI drop exclusion and safe selection-to-placement dependency.
- `Assets/_Project/Tests/EditMode/WorldGestureTapSafetyTests.cs`: pure mathematical boundary checks, including non-finite coordinates (requires Unity NUnit execution).
- `Verification/gesture_integrity_gate_v432.py`: fail-closed static source checks; deliberately does not substitute for compilation.
- `Verification/test_gesture_integrity_gate_v432.py`: contract tests with four deliberate code mutations.

## Evidence and release gates

- Static governance, assembly graph, camera contract, integration contract, layout contract, and Python mathematical verification executed and passed where available.
- 21 Python contract and mutation tests executed and passed. This tests source-level invariants, not the Unity runtime.
- **Not executed**: C# compilation, Unity EditMode/PlayMode tests, generated scene play session, Android device performance and battery profiling. No claim that every defect has been found or fixed.
- Expected runtime follow-ups: `Verification/Run-UnityVerification.ps1`; add PlayMode tests covering UI interception and physical touch/mouse input, plus Android tracing for CPU/GPU/GC/battery.

## Architecture and risk disposition

Domain/AppCore purity and six asmdef boundaries are checked statically. `OrderGame` still has broad UI, persistence, and domain coordination responsibilities; refactoring it without a verified executable baseline risks introducing regressions. The newest HOPA adventure services are not yet proven fully integrated in the running scene. The append-only save stores have bounded I/O but must still be tested across interruption, power loss and actual Android storage semantics. No evidence proves absence of memory leaks or abnormal battery drain.

## Official engineering references

- Unity 2022.3 Script API, `Screen.safeArea`: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Screen-safeArea.html
- Unity 2022.3 Script API, `Physics.Raycast`: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Physics.Raycast.html
- Unity 2022.3 Editor CLI and batch mode: https://docs.unity3d.com/2022.3/Documentation/Manual/EditorCommandLineArguments.html
- Unity 2022.3 Test Framework: https://docs.unity3d.com/2022.3/Documentation/Manual/com.unity.test-framework.html
