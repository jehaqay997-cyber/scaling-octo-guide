# Sable & Sigil v5.37 — Cinematic Artwork and Interactive Panoramas

## Actual changes

- Produced one NEW 1672x941 photorealistic wide entrance background and imported it as `Resources/CinematicLocations/Location_01.png`, retaining original Scene_01.jpg unchanged for 3D investigation and regression comparison.
- All ten locations use the same bounded, zoomable and draggable 2.5D panoramic interaction architecture; 2–10 deliberately retain the original artwork until independently approved replacements exist.
- The photograph, two evidence hotspots and the mechanism hotspot pan and zoom under one transform to preserve click accuracy.
- Evidence callbacks, puzzle prerequisites, save data, finale eligibility and chapter unlocks are unchanged.
- Transparent drag surface remains behind evidence buttons; motion is blocked whenever a modal is open or the presentation is in 3D mode.
- Resets never write to persistent storage. Geometry clamps panning to avoid revealing empty margins, and rejects non-finite numbers.
- A mobile-oriented texture import rule disables CPU readback/mipmaps and retains platform default compressed GPU formats.
- Updated manifest-locked NUnit fixtures and Unity editor preflight to verify the art and zoom state.

## Actual art coverage and unresolved gaps

- Replaced background: LOCATION 01 of 10. It is a new wide photoreal environment plate, **not** 3D mesh geometry.
- Original preserved: LOCATION 01–10 and Chapter 01–04 reference JPEGs.
- Locations 02–10 still contain baked blurred side regions and require individually approved full-width artwork; no programmatic outpainting or artificial claim of photoreal 3D was used.
- Real 3D world spaces, material scan assets, character animation, lighting and image/interaction alignments require Unity visual inspection and further production work.
- This is a portrait/landscape-scale UI interaction model, not a fully navigable 3D world or a PlayStore-ready game.
- Unity 2022.3.62f3 compile, NUnit EditMode/PlayMode and Android runtime are not executable in this audit environment.

## Validation and priorities

P0: Open in Unity 2022.3.62f3, check that the new entrance image shows correctly and that hotspot hit boxes remain aligned while zooming, dragging and switching to 3D. Run all NUnit tests and inspect Console.
P1: Approve and rebuild full-width textures for locations 02–10, each preserving case-specific clue readability, at consistent viewpoint/palette.
P2: Produce physically based architectural meshes, authored cinematic cameras, real-time performance measurements, HDR/color-grade testing and accessibility on low/mid-tier Android devices.
