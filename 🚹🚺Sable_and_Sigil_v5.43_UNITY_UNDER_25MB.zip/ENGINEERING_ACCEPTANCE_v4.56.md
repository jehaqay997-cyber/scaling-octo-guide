# Sable & Sigil v4.56 — Engineering Acceptance Report

## Scope and verification
- Baseline: v4.55 archive has 674 files, including 51 generated Python bytecode cache files. All 623 noncache files are preserved; the 51 disposable cache artifacts are intentionally omitted from v4.56.
- Compatibility target (unchanged): Unity 2022.3.62f3.
- Offline checks executed: 158/158 Python unit tests PASS and 29/29 steps PASS in run_full_static_audit_v443.py (28 standalone gates plus regression suite).
- Static-only result: Unity C# compilation, PlayMode, EditMode, actual gameplay, rendering quality and Android device tests NOT EXECUTED. No claim of production readiness.

## Fixes
1. ChapterGalleryView: added full-screen modal raycast shield so pointer events cannot leak to the 3D scene outside a notched device's safe region.
2. ChapterGalleryView: moved all visible artwork and chapter UI into safe-area-constrained layout root, while keeping the shield full screen. Responsive layout uses CanvasScaler Expand and a uniform scale; images use min(width ratio, height ratio), never uneven scaling/cropping.
3. ChapterGalleryView: release location-only image when closing the gallery to limit retained resources; preserve Unity chapter-art cache.
4. ChapterOneExperience: ignore clicks outside viewCamera.pixelRect before world raycasting.
5. Extended PlayMode tests for modal safety, safe area, image aspect, chapter navigation. These tests are authored but not executed here.
6. Added gallery_viewport_gate_v456.py and 3 Python tests (including mutation checks), and wired the guard into the unified static audit.

## International engineering references
- Unity 2022.3 Canvas Scaler Manual: https://docs.unity3d.com/2022.3/Documentation/Manual/script-CanvasScaler.html
- Unity 2022.3 Aspect Ratio Fitter Manual: https://docs.unity3d.com/2022.3/Documentation/Manual/script-AspectRatioFitter.html
- Unity Camera ScreenPointToRay: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Camera.ScreenPointToRay.html
- NIST SSDF: https://csrc.nist.gov/pubs/sp/800/218/final

## Critical remaining release gate
1. Run the project's original OPEN_GAME.cmd with the pinned Unity version.
2. Import packages and confirm no C# compiler errors.
3. Run real EditMode and PlayMode suites, including ChapterArtGalleryTests and ChapterOneProgressTests, recording NUnit XML and Editor.log.
4. Validate scene visuals, aspect ratio and camera touch mapping on landscape 16:9, 19.5:9, and notched devices.
5. Build Android and test input, save corruption handling, performance, memory and scene transitions on device.
6. Chapter images and user-reference locations are not a substitute for implemented 3D playable environments; only Chapter I has an unverified playable scene candidate.
