# Sable & Sigil v4.93 — Release Evidence Coverage and Graphics-Aware Test Gate

## Baseline and change scope
- Frozen source baseline: v4.92, Unity Editor 2022.3.62f3.
- Scope: M0 execution readiness only. No gameplay, save schema, scene geometry, image asset, assembly definition, or GUID changes.
- This delivery does **not** claim a Unity compilation, NUnit execution inside Unity, Android build, or device run.

## P0 findings and implemented changes
1. **Incomplete NUnit coverage evidence:** the previous verification pipeline only required one PlayMode fixture to appear in NUnit XML. Now 14 named EditMode fixtures and all six authored PlayMode fixtures are required, in addition to every test case passing with zero skips/inconclusive outcomes.
2. **Graphics disabled in PlayMode:** the previous PlayMode command included `-nographics` although authored tests exercise `RenderTexture`, cameras and 3D materials. The PlayMode test stage now retains graphics initialization in batch mode. If a display/graphics device is unavailable, acceptance fails rather than treating headless testing as graphics evidence. The non-rendering scene bootstrap and EditMode stages remain headless.
3. **Ambiguous NUnit evidence:** duplicate or unnamed NUnit test-case identifiers are now rejected, preventing the result count from concealing a missing or repeated case.
4. **Evidence provenance:** the acceptance report identifies the v4.93 source baseline, required fixture inventory, and the graphics-enabled PlayMode requirement.
5. **Regression detection:** added a new static verification gate and 10 mutation-oriented tests. Updated legacy NUnit evidence tests to enforce the expanded contract.

## Delivery handoff and ownership
| Workstream | Owner role | Current deliverable | Next measurable checkpoint |
|---|---|---|---|
| Architecture and persistence | Backend / System Architect | Source freeze, assembly references, fail-closed test coverage | Zero Unity compile errors; no save regressions in EditMode |
| Scene rendering and input | Frontend / 3D Engineer | Graphics-enabled PlayMode coverage includes chapter scene, atlas, 3D explorer and dossier | All six PlayMode fixture classes appear in passing Unity NUnit XML; inspect actual render output |
| Puzzle correctness and assistance | AI Engineer | Proof-oriented test coverage for story graph, dossier, solvability, hint and progression | Verify candidate answers and constrained hint ordering per location; no uncontrolled model answers |
| Quantitative QA | Data Analyst | Required test-count inventory and structured acceptance reports | Compare NUnit pass counts, render memory/CPU/GC and device FPS across versioned runs |

## Operational invocation (Windows 10)
1. Extract the complete ZIP to a local, non-synchronized directory with enough free space. Close any Unity Editor instance already accessing the project.
2. Run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the extracted project root with Unity 2022.3.62f3 installed. Both generated scenes must exist, and editor import plus NUnit EditMode and PlayMode test stages must pass.
3. Inspect the timestamped sibling directory `SableSigilVerification`. In `verification.json`, require `source_integrity=PASS`, `editmode=PASS`, `playmode=PASS`, `graphics_playmode=ENABLED`, at least 14 required EditMode fixtures, and all six required PlayMode fixtures. `sable-acceptance.json` must report `EDITOR_AND_UNITY_TESTS_VERIFIED_ANDROID_PENDING`.
4. For Android, run `RUN_SABLE_ANDROID_BUILD_GATE.cmd` only after Editor acceptance; inspect the staged APK and build log. Device verification must then be recorded separately.
5. If an Editor test fails or a fixture is missing, preserve its XML, log, and complete command line without downgrading coverage or removing tests.

## Evidence categories
- STATIC_SOURCE_VERIFIED: Python source-contract and mutation tests, archive/hash checks, and existing static gates.
- COMPILE_VERIFIED: Unity editor log with zero compiler errors, generated scenes, valid package import.
- TEST_VERIFIED: actual Unity NUnit XML with all required fixtures and zero failures/skips.
- ANDROID_BUILD_VERIFIED: BuildPipeline success, checked APK, output hash and log.
- DEVICE_VERIFIED: recorded execution on an Android handset, including frame time, memory and an end-to-end gameplay session.

## Official Unity contracts
- Editor CLI and graphics switch: https://docs.unity3d.com/2022.3/Documentation/Manual/EditorCommandLineArguments.html
- Unity Test Framework command-line execution: https://docs.unity.cn/Packages/com.unity.test-framework@1.1/manual/reference-command-line.html
- Editor scene management: https://docs.unity3d.com/2022.3/Documentation/ScriptReference/SceneManagement.EditorSceneManager.SaveScene.html
