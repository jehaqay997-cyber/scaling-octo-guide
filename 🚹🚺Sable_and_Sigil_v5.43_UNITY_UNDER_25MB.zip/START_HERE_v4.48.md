# TheOrderRoom v4.48

Open `OPEN_GAME.cmd` on Windows after extracting the complete archive. The installed Unity Editor must match `ProjectSettings/ProjectVersion.txt` (2022.3.62f3).

Run offline source gates using `python Verification/run_full_static_audit_v443.py`.

Run Unity verification with `powershell -NoProfile -ExecutionPolicy Bypass -File .\Verification\Run-UnityVerification.ps1`. Optionally add `-BuildAndroid` when Android Build Support is installed. Review evidence under `Verification/LocalResults`.

The `Main.unity` scene is generated on first import. This is a source candidate; actual Unity compilation and play are not yet confirmed.
