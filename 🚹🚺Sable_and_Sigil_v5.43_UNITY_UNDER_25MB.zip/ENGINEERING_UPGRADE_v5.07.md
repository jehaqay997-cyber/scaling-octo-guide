# Sable & Sigil v5.07 — First Chapter 3D Engineering Upgrade

**Project:** Sable & Sigil (distinct from TheOrderRoom product)  
**Unity compatibility target:** 2022.3.62f3  
**Parent:** v5.06  
**Scope:** the first playable 3D Threshold investigation, not the other nine locations.  
**Release status:** SOURCE CANDIDATE; Unity compilation and device behavior UNVERIFIED.

## Implemented, first location only

1. Preserved the exact original 1280x720 authored `Scene_01.jpg` texture and its `.meta`. All other original images, scene files, asset GUIDs and assembly declarations remain byte-identical.
2. Added four ascending stone treads with shallow brass nosings aligned to the photographed Gothic portal, plus two flanking door jambs, reveals and plinths. All geometry is on the scenery layer, non-interactive, and reuses materials and the existing three-light rig.
3. Added two owned front-facing engraved crest ring meshes, one around the reference five-ray letter and one around the six-ray arch. Each ring has 96 vertices / 288 triangle indices (96 triangles), a fixed 48-segment budget and no collider. This is deliberately not a new puzzle authority.
4. Linked in-world crest feedback to the same transient domain result as the 2D diagram: rejected ray becomes red, the verified added ray becomes green, and the previously rejected ray restores brass. These materials are created once per open world and destroyed with the world, avoiding per-selection material allocation.
5. Kept existing evidence prerequisites: both fragments must be inspected, the added ray must be verified, and the original dossier remains the sole persistent deduction authority. Closing and reopening resets all temporary crest state.
6. Extended Unity EditMode geometry tests and PlayMode world lifecycle/feedback tests, and updated the cryptographic NUnit fixture inventory.

## Scope and budgets

- Added physical decoration: four stone steps, four brass nosings, six portal trims; all reuse existing owned materials and do not add lights or interactive colliders.
- Additional owned meshes: two for location 1; remaining nine locations remain at the existing seven-mesh budget.
- Crest ring bounds are validated; a separate numerical oracle checks orientation and nondegeneracy of 624 triangles over two crest radii and three tessellation densities.
- No images were synthesized and no Unity rendered screenshot was claimed or fabricated.

## Verification evidence

- Python regression suite: 535 passed, 0 failed, executed in the working container.
- 61 static gates passed. The original consolidated runner was interrupted after 52 successful gates by the container time limit; the remaining nine gates were executed independently, with the complete split-phase evidence in `Verification/STATIC_EVIDENCE_v507.json`.
- Independent math check: 624 reference triangles examined; smallest positive triangle area 0.0007725744640310565 square local units. This does NOT execute C# Mesh.
- Unity Editor 2022.3.62f3 not available in this environment. `COMPILE_VERIFIED=false`, `EDITMODE_VERIFIED=false`, `PLAYMODE_VERIFIED=false`, `DEVICE_VERIFIED=false`.

## Acceptance steps in Unity 2022.3.62f3

1. Extract locally and run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` from the project root. Preserve batch logs and EditMode/PlayMode XML; do not infer success merely from this archive.
2. From the chapter atlas, select first location > `EXPLORE 3D`. Confirm the real Scene_01 image is present; check four stair treads, two crest rings and zero new lights or clickable trim.
3. With zero and one evidence inspected, the crest remains locked. Inspect both relics, open `EXAMINE CREST LOCK`; select a wrong ray. Confirm both its diagram and its 3D piece are red.
4. Select ray five (array index 4). Confirm both rays display green, the previous wrong ray returns brass, and `OPEN DEDUCTION` becomes available only now.
5. Close and re-enter first location; ensure zero inspected fragments, unverified crest, brass rays and no accumulating lights/materials/meshes.
6. Check the other nine locations still render and unload with seven owned meshes and their original source artwork.
7. Review frame pacing and touch hit areas on actual Android hardware before claiming any Android readiness.

## Primary Unity 2022.3 references

- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Mesh.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Physics.Raycast.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Renderer-sharedMaterial.html
