SABLE & SIGIL v5.54 - LOSSLESS PROJECT RESTORATION
==================================================
Unity 2022.3.62f3

These three independent ZIP archives together contain EVERY file from the original full source ZIP.
No original file has been edited, renamed, recompressed internally, or intentionally omitted.
Compression changes the ZIP container, not the file contents.

PART 1: Unity core, packages, settings, runtime artwork, playable browser adaptation, launch scripts.
PART 2: Original ArtSource masters and Verification records.
PART 3: Design artwork, version history, manifests, and development documentation.

TO RESTORE ALL FILES:
1. Download all three ZIPs and the RESTORE_ALL_PARTS.ps1 and RESTORE_ALL_PARTS.cmd files into the same Windows folder.
2. Run RESTORE_ALL_PARTS.cmd.
3. The script extracts the three archives to a single Sable_and_Sigil_v5.54_RESTORED folder.
4. The script checks SHA-256 for ALL files using the original source manifest.
5. In Unity Hub, Add Project from Disk -> Sable_and_Sigil_v5.54_RESTORED.

If you manually extract instead, extract the CONTENTS of all three archives to the SAME destination folder.
Do not extract each archive into a different subfolder inside the project.

The compact part alone is appropriate for SOURCE REVIEW, not as a replacement for the complete archive.
Unity compile and Play Mode are NOT confirmed by file integrity validation.
