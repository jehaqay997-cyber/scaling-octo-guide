@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_DEVELOPMENT_APK.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" (
  echo Build did not complete. See the error above and the Unity build log.
) else (
  echo Development APK creation completed successfully.
)
pause
exit /b %RESULT%
