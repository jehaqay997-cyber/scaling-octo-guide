'use strict';
const CACHE_PREFIX='sable-sigil-playable-';
const CACHE=CACHE_PREFIX+'v4';
const APP=['./','./index.html','./style.css','./game.js','./story.js','./icon.svg','./icon-192.png','./icon-512.png','./manifest.webmanifest'];
const IMAGES=Array.from({length:10},(_,i)=>`./assets/scene_${String(i+1).padStart(2,'0')}.webp`).concat(Array.from({length:4},(_,i)=>`./assets/chapter_${String(i+1).padStart(2,'0')}.webp`));
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(APP.concat(IMAGES))).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith(CACHE_PREFIX)&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET'||new URL(request.url).origin!==self.location.origin)return;
  const pathname=new URL(request.url).pathname;
  const shellAsset=request.mode==='navigate'||/(?:\/|^)(?:index\.html|game\.js|story\.js|style\.css|manifest\.webmanifest)$/.test(pathname);
  if(shellAsset){
    event.respondWith((async()=>{
      try{
        const response=await fetch(request,{cache:'no-store'});
        if(response.ok){
          const cache=await caches.open(CACHE);
          await cache.put(request,response.clone());
        }
        return response;
      }catch(error){
        const cached=await caches.match(request);
        if(cached)return cached;
        if(request.mode==='navigate')return await caches.match('./index.html')||Response.error();
        return Response.error();
      }
    })());
    return;
  }
  event.respondWith(caches.match(request).then(cached=>cached||fetch(request)));
});
