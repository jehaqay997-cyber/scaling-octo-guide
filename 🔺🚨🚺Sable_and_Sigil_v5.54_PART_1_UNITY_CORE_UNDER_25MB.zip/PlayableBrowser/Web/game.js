'use strict';
(() => {
  const STORY=window.SABLE_STORY;
  if(!STORY||STORY.locations.length!==10)throw new Error('Authored content is unavailable.');
  const STORAGE_PREFIX='SableSigilPlayable.v1.';
  const CHAPTER_RANGES=[[1,2],[3,6],[7,9],[10,10]];
  const DEFAULT_SETTINGS=()=>({musicVolume:0.18,sfxVolume:0.72,muteMusic:false,muteSfx:false});
  const byId=id=>document.getElementById(id);
  const h=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const clamp=(n,low,high)=>Math.max(low,Math.min(high,n));
  const sceneImg=n=>{const key=`assets/scene_${String(n).padStart(2,'0')}.webp`;return window.SABLE_ASSETS?.[key]||key;};
  const chapterImg=n=>{const key=`assets/chapter_${String(n).padStart(2,'0')}.webp`;return window.SABLE_ASSETS?.[key]||key;};
  const caseAt=n=>STORY.locations[n-1];
  const blank=()=>({version:1,revision:0,epoch:'',completed:[],settings:DEFAULT_SETTINGS()});
  function newEpoch(){
    const bytes=new Uint8Array(16);
    if(window.crypto&&typeof window.crypto.getRandomValues==='function')window.crypto.getRandomValues(bytes);
    else for(let i=0;i<bytes.length;i++)bytes[i]=Math.floor(Math.random()*256);
    return Array.from(bytes,byte=>byte.toString(16).padStart(2,'0')).join('');
  }
  const fnv=str=>{let hash=2166136261;for(let i=0;i<str.length;i++){hash^=str.charCodeAt(i);hash=Math.imul(hash,16777619);}return (hash>>>0).toString(16).padStart(8,'0');};
  let generation=0;
  let storageWorks=true;
  let recoveredCorruptSave=false;
  let unsavedChanges=false;
  let storageWarningShown=false;
  function noteSaveFailure(){
    unsavedChanges=true;
    storageWorks=false;
    if(!storageWarningShown){
      storageWarningShown=true;
      toast('Your progress could not be saved. Keep this game open until storage is available.');
    }
  }
  function validate(saved){
    if(!saved||saved.version!==1||!Array.isArray(saved.completed)||saved.completed.length>10||saved.revision!==saved.completed.length||
      (saved.epoch!==undefined&&(typeof saved.epoch!=='string'||saved.epoch.length>64||!/^[a-f0-9]*$/.test(saved.epoch))))return false;
    if(saved.completed.some((n,i)=>n!==i+1))return false;
    const s=saved.settings;
    return Boolean(s&&Number.isFinite(s.musicVolume)&&Number.isFinite(s.sfxVolume)&&
      s.musicVolume>=0&&s.musicVolume<=1&&s.sfxVolume>=0&&s.sfxVolume<=1&&
      typeof s.muteMusic==='boolean'&&typeof s.muteSfx==='boolean');
  }
  function readSlot(key){
    try{
      const raw=localStorage.getItem(STORAGE_PREFIX+key);
      if(raw===null)return null;
      const record=JSON.parse(raw);
      if(!record||!Number.isSafeInteger(record.generation)||record.generation<1||
        typeof record.payload!=='string'||record.payload.length>16384||fnv(record.payload)!==record.checksum){
        recoveredCorruptSave=true;return null;
      }
      const value=JSON.parse(record.payload);
      if(!validate(value)){recoveredCorruptSave=true;return null;}
      return {generation:record.generation,value};
    }catch(error){
      recoveredCorruptSave=true;
      return null;
    }
  }
  function readLatestSnapshot(){
    try{
      localStorage.getItem(STORAGE_PREFIX+'A');
      const records=[readSlot('A'),readSlot('B')].filter(Boolean).sort((a,b)=>b.generation-a.generation);
      storageWorks=true;
      return records.length?records[0]:null;
    }catch(error){storageWorks=false;return null;}
  }
  function loadGame(){
    const latest=readLatestSnapshot();
    generation=latest?latest.generation:0;
    return latest?latest.value:blank();
  }
  let state=loadGame();
  function saveGame(intent='progress'){
    if(!validate(state))throw new Error('Attempted to persist invalid investigation state.');
    // A stale tab must never overwrite newer findings or undo a confirmed reset.
    // Local storage is not a transactional database: this is a read-before-write conflict guard.
    const latest=readLatestSnapshot();
    if(!storageWorks){noteSaveFailure();return false;}
    if(latest&&latest.generation>generation){
      const remote=latest.value;
      if(intent==='settings'){
        state={...remote,settings:state.settings};
      }else if(intent==='reset'){
        // An explicit reset writes a fresh epoch beyond the newest known generation.
      }else{
        const sameEpoch=(remote.epoch||'')===(state.epoch||'');
        const remoteIsPrefix=remote.completed.every((number,index)=>state.completed[index]===number);
        if(!sameEpoch||!remoteIsPrefix||remote.completed.length>=state.completed.length){
          state=remote;generation=latest.generation;return false;
        }
        // Progress may advance, but unrelated preferences from the newer tab are retained.
        state.settings=remote.settings;
      }
      generation=latest.generation;
    }
    if(!Number.isSafeInteger(generation)||generation>=Number.MAX_SAFE_INTEGER-2){
      noteSaveFailure();return false;
    }
    const payload=JSON.stringify(state);
    const next=generation+1;
    const record=JSON.stringify({generation:next,payload,checksum:fnv(payload)});
    try{
      localStorage.setItem(STORAGE_PREFIX+(next%2?'A':'B'),record);
      generation=next;storageWorks=true;unsavedChanges=false;storageWarningShown=false;
      return true;
    }catch(error){noteSaveFailure();return false;}
  }
  function resetProgress(){
    state.completed=[];
    state.revision=0;
    state.epoch=newEpoch();
    // Both slots must contain the reset epoch; a stale backup cannot resurrect old findings.
    if(saveGame('reset'))saveGame('reset');
  }
  let view={screen:'title',n:1,inspected:new Set(),selectedClue:0,mechanicSolved:false,
    puzzle:null,hintCount:0,notice:'',noticeType:'',finalePage:0};
  let toastTimer=0;
  function announce(text){const el=byId('announcer');if(el)el.textContent=text;}
  function toast(message){
    const old=byId('game-toast');if(old)old.remove();
    const el=document.createElement('div');el.className='toast';el.id='game-toast';el.textContent=message;
    document.body.appendChild(el);clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.remove(),3300);
    announce(message);
  }
  class SoundEngine{
    constructor(){this.context=null;this.drone=null;this.master=null;this.effectsBus=null;this.activeVoices=0;}
    enable(){
      try{
        if(!this.context){
          const Context=window.AudioContext||window.webkitAudioContext;
          if(!Context)return;
          this.context=new Context();
          this.effectsBus=this.context.createGain();this.effectsBus.gain.value=1;
          this.effectsBus.connect(this.context.destination);
          this.master=this.context.createGain();this.master.gain.value=0;
          const lowpass=this.context.createBiquadFilter();lowpass.type='lowpass';lowpass.frequency.value=360;
          this.master.connect(lowpass).connect(this.context.destination);
          this.drone=[0,1].map((index)=>{
            const osc=this.context.createOscillator();osc.type=index===0?'sine':'triangle';
            osc.frequency.value=index===0?73.42:110;
            const gain=this.context.createGain();gain.gain.value=index===0?0.5:0.19;
            osc.connect(gain).connect(this.master);osc.start();return osc;
          });
        }
        if(this.context.state==='suspended')this.context.resume().catch(()=>{});
        this.sync();
      }catch(error){
        if(this.context){try{this.context.close().catch(()=>{});}catch(closeError){}}
        this.context=null;this.master=null;this.effectsBus=null;this.drone=null;
      }
    }
    sync(){
      if(!this.context||!this.master)return;
      const quiet=state.settings.muteMusic||document.visibilityState==='hidden';
      const amount=quiet?0:Math.pow(state.settings.musicVolume,1.5)*0.20;
      this.master.gain.setTargetAtTime(amount,this.context.currentTime,0.12);
      if(this.effectsBus){
        const effectsAudible=!state.settings.muteSfx&&document.visibilityState!=='hidden';
        this.effectsBus.gain.setTargetAtTime(effectsAudible?1:0,this.context.currentTime,0.012);
      }
    }
    play(type='tap'){
      if(!this.context||this.context.state==='closed'||state.settings.muteSfx||
        state.settings.sfxVolume===0||document.visibilityState==='hidden'||this.activeVoices>=6)return false;
      const tones={tap:[440,0.05,'sine'],inspect:[520,0.18,'triangle'],success:[660,0.30,'sine'],error:[155,0.13,'sawtooth'],unlock:[880,0.48,'sine']};
      const [freq,seconds,wave]=tones[type]||tones.tap;
      try{
        const now=this.context.currentTime;
        const osc=this.context.createOscillator();const gain=this.context.createGain();
        osc.type=wave;osc.frequency.setValueAtTime(freq,now);osc.frequency.exponentialRampToValueAtTime(freq*(type==='success'?1.4:0.88),now+seconds);
        const peak=state.settings.sfxVolume*0.085;
        gain.gain.setValueAtTime(0,now);gain.gain.linearRampToValueAtTime(peak,now+0.006);
        gain.gain.exponentialRampToValueAtTime(0.0001,now+seconds);
        osc.connect(gain).connect(this.effectsBus||this.context.destination);
        this.activeVoices++;
        let ended=false;
        const cleanup=()=>{
          if(ended)return;
          ended=true;
          this.activeVoices=Math.max(0,this.activeVoices-1);
          try{osc.disconnect();gain.disconnect();}catch(error){}
        };
        osc.onended=cleanup;
        try{osc.start(now);osc.stop(now+seconds+0.02);}
        catch(error){cleanup();return false;}
        // Scheduling while suspended preserves the first tap. User activation resumes the clock.
        if(this.context.state==='suspended')this.context.resume().catch(()=>{});
        return true;
      }catch(error){return false;}
    }
  }
  const sound=new SoundEngine();
  document.addEventListener('visibilitychange',()=>{
    sound.sync();
    if(!sound.context)return;
    if(document.visibilityState==='hidden')sound.context.suspend().catch(()=>{});
    else sound.context.resume().then(()=>sound.sync()).catch(()=>{});
  });
  window.addEventListener('pagehide',()=>{if(sound.context)sound.context.suspend().catch(()=>{});});
  window.addEventListener('pageshow',()=>{
    if(sound.context&&document.visibilityState==='visible')
      sound.context.resume().then(()=>sound.sync()).catch(()=>{});
  });
  function shell(body,{title='Investigation'}={}){
    return `<div class="shell"><header class="topbar"><button class="brand" data-action="home" aria-label="Sable and Sigil home">✦ SABLE & SIGIL</button><div class="bar-actions"><span class="progress-inline">${state.completed.length} / 10 FINDINGS</span><button class="pill" data-action="map">Case Atlas</button><button class="pill" data-action="settings" aria-label="Sound and settings">⚙</button></div></header>${body}<footer class="footer">SABLE & SIGIL · THE INVESTIGATION · A PLAYABLE BROWSER EDITION</footer></div>`;
  }
  function renderTitle(){
    const hasSave=state.completed.length>0;
    return `<div class="shell"><header class="topbar"><span class="brand">✦ SABLE & SIGIL</span><div class="bar-actions"><span class="progress-inline">${hasSave?`${state.completed.length} findings recovered`:'The investigation awaits'}</span><button class="pill" data-action="settings">⚙ Sound</button></div></header>
      <main class="hero" style="background-image:url('${chapterImg(1)}')"><div class="hero-content">
      <div class="edition">An Interactive Gothic Mystery · Four Chapters</div><div class="chapter-tag">The House of the Last Star</div><div class="title-line"></div><h1>SABLE <span>&</span><br>SIGIL</h1>
      <p class="hero-subtitle">A letter. An altered seal. Ten investigations across a house built to conceal a witness. Examine the evidence, operate each mechanism, and reconstruct the truth.</p>
      <div class="hero-cta"><button class="button" data-action="${hasSave?'map':'new'}">${hasSave?'Continue Investigation':'Begin Investigation'}</button>
      <button class="button secondary" data-action="${hasSave?'new':'map'}">${hasSave?'New Game':'Explore Chapters'}</button></div>
      <div class="hero-foot">10 LOCATIONS <span class="gold">◆</span> 4 CHAPTERS <span class="gold">◆</span> LOCAL SAVING <span class="gold">◆</span> ORIGINAL CASE FILES</div>
      </div></main></div>`;
  }
  function renderMap(){
    let cards='';
    for(let chapter=1;chapter<=4;chapter++){
      const [first,last]=CHAPTER_RANGES[chapter-1];
      const completed=state.completed.filter(n=>n>=first&&n<=last).length;
      const unlocked=state.completed.length+1>=first;
      const target=completed===last-first+1?first:first+completed;
      cards+=`<article class="chapter-card ${unlocked?'':'locked'}" style="background-image:url('${chapterImg(chapter)}')"><div>
        <div class="chapter-tag">CHAPTER ${chapter} · ${completed}/${last-first+1} FINDINGS</div><h3>${h(STORY.chapterNames[chapter-1])}</h3>
        <p>${h(STORY.chapterHooks[chapter-1])}</p>
        <button class="button ${unlocked?'':'secondary'}" data-action="go-case" data-value="${target}" ${unlocked?'':'disabled'}>${unlocked?(completed===last-first+1?'Review Chapter':'Enter Chapter'):'Locked'}</button></div></article>`;
    }
    const next=Math.min(10,state.completed.length+1);
    const cases=STORY.locations.map(c=>{
      const done=state.completed.includes(c.number),active=c.number===next;
      const allowed=done||active;
      return `<button class="case-box ${done?'done':active?'active':'locked'}" data-action="go-case" data-value="${c.number}" ${allowed?'':'disabled'}>
        <span class="chapter-tag">${done?'✓ SOLVED':active?'◆ AVAILABLE':'LOCKED'} · ${String(c.number).padStart(2,'0')}</span>
        <strong>${h(c.title)}</strong></button>`;
    }).join('');
    return shell(`<main class="screen"><div class="chapter-tag">Case Atlas · The Estate</div><h2>Your Investigation</h2>
      <p class="muted">Each finding unlocks the next. Inspect both clues, solve the physical mechanism, then state your deduction.</p>
      <div class="row between"><span class="tiny-label">Evidence Recovered: ${state.completed.length} / 10</span>${state.completed.length===10?'<button class="button" data-action="finale">Read Final Register</button>':`<button class="button secondary" data-action="go-case" data-value="${next}">Continue at Location ${next}</button>`}</div>
      <div class="timeline" role="progressbar" aria-valuenow="${state.completed.length}" aria-valuemin="0" aria-valuemax="10" aria-label="Cases solved"><div style="width:${state.completed.length*10}%"></div></div>
      <div class="grid">${cards}</div><h3 style="margin-top:40px">Investigation Ledger</h3><div class="case-strip">${cases}</div></main>`);
  }
  function renderScene(){
    const c=caseAt(view.n),done=state.completed.includes(view.n),inspected=view.inspected;
    const points=[{x:32,y:37},{x:72,y:54}];
    const hotspot=points.map((p,i)=>`<button class="hotspot ${inspected.has(i)?'visited':''}" data-action="inspect" data-value="${i}" style="--x:${p.x}%;--y:${p.y}%" aria-label="Inspect evidence ${i+1}">${inspected.has(i)?'✓':i+1}</button>`).join('');
    const clues=c.fragments.map((fragment,i)=>`<div class="evidence-item"><span class="mark">${inspected.has(i)?'✓':i+1}</span><div><button data-action="inspect" data-value="${i}">Evidence Fragment ${i+1}</button>
      <p>${inspected.has(i)?h(fragment):'Unexamined · interact with its marker in the scene'}</p></div></div>`).join('');
    const both=inspected.size===2||done;
    const note=view.selectedClue?`<div class="clue-drawer" role="status"><div class="chapter-tag">EVIDENCE INSPECTED</div><p>${h(c.fragments[view.selectedClue-1])}</p><button class="button secondary" data-action="close-clue">Close Evidence</button></div>`:'';
    return shell(`<main class="screen"><div class="row between"><div><div class="chapter-tag">CHAPTER ${c.chapter} · LOCATION ${String(c.number).padStart(2,'0')}</div><h2>${h(c.title)}</h2></div><button class="button ghost" data-action="map">← Case Atlas</button></div>
      <div class="scene-grid"><div><div class="scene-art" role="img" aria-label="Original artwork of ${h(c.title)}" style="background-image:url('${sceneImg(c.number)}')">${hotspot}<div class="scene-caption">Select the glowing seals to inspect the evidence</div></div>
      <p class="muted small-copy" style="margin-top:14px">${h(c.evidence)}</p></div>
      <aside class="panel"><div class="chapter-tag">Evidence Dossier</div><h3>Examine the scene</h3><p class="muted small-copy">Study both fragments before attempting the mechanism.</p>${clues}${note}
      <div class="line"></div><div class="tiny-label">${inspected.size} of 2 clues inspected</div>
      <button class="button wide" data-action="open-puzzle" ${both?'':'disabled'} style="margin-top:15px">${done?'Revisit Mechanism':'Operate Mechanism'}</button>
      ${!both?'<p class="muted small-copy">Both evidence fragments are required to unlock the mechanism.</p>':''}</aside></div></main>`);
  }
  function resetPuzzle(){
    switch(view.n){
      case 1:return {uv:0,tracing:false};
      case 2:return {motif:''};
      case 3:return {phase:0};
      case 4:return {petals:8};
      case 5:return {sequence:[]};
      case 6:return {route:[]};
      case 7:return {order:['Triangle','Ring','Three rays']};
      case 8:return {claim:''};
      case 9:return {letter:''};
      case 10:return {rings:['D','B','A','C']};
      default:throw new Error('Unsupported mechanism');
    }
  }
  function puzzleHtml(){
    const p=view.puzzle;
    switch(view.n){
      case 1:return `<div class="mechanic-title">Ultraviolet crest inspection</div><div class="uv-wrap">
          <div class="crest"><span class="rays">✺</span><small>LADY VEY'S DRAWING<br>FIVE RAYS</small></div>
          <div class="crest" style="--uv:${p.uv/100}"><span class="rays">✺</span><span class="extra">✦</span><small>ALTERED STONE SEAL<br>SIX RAYS</small></div></div>
          <div class="uv-panel"><label class="mechanic-title" for="uv-range">UV lamp intensity: <output id="uv-value">${p.uv}%</output></label>
          <input id="uv-range" aria-label="Ultraviolet lamp intensity" type="range" min="0" max="100" value="${p.uv}" data-action="uv-range"></div>
          <div class="row" style="justify-content:center"><button class="button" data-action="trace" ${p.uv<70?'disabled':''}>Place Tracing Over Seal</button></div>
          <div class="puzzle-note">${p.uv>=70?'The hidden additional cut is visible. Place the tracing.':'Increase the ultraviolet lamp to reveal hidden cuts.'}</div>`;
      case 2:return `<div class="mechanic-title">The missing sixth baluster</div><div class="symbol-grid">${['○','◇','✦','○','◇'].map((s,i)=>`<div class="symbol-tile">${s}<small>${i+1}</small></div>`).join('')}
          <div class="symbol-tile active">${h(p.motif||'?')}<small>6</small></div></div>
          <p class="puzzle-note">The stair repeats a three-mark cycle. Select the sixth carved motif.</p>
          <div class="symbol-grid">${[['○','Circle'],['◇','Diamond'],['☾','Crescent'],['✦','Star']].map(([symbol,label])=>`<button class="button secondary" data-action="motif" data-value="${label}">${symbol} ${label}</button>`).join('')}</div>`;
      case 3:{
        const phases=[['●','NEW MOON'],['◐','WAXING MOON'],['○','FULL MOON'],['◑','WANING MOON']];
        return `<div class="mechanic-title">Lunar lantern dial</div><div class="dial"><span class="icon-large">${phases[p.phase][0]}</span><strong>${phases[p.phase][1]}</strong></div>
        <div class="row dial-controls"><button class="button secondary" data-action="turn" data-value="-1">↶ Rotate Left</button>
        <button class="button secondary" data-action="turn" data-value="1">Rotate Right ↷</button></div><p class="puzzle-note">The calibration note specifies two phases after New Moon.</p>`;
      }
      case 4:return `<div class="mechanic-title">Rose basin sequence · 2, 3, 5, 8, ?</div><p class="big-number" aria-label="Selected petal count">${p.petals}</p>
          <div class="row num-controls"><button class="button secondary" data-action="petal" data-value="-1" aria-label="Decrease petal count">−</button>
          <button class="button secondary" data-action="petal" data-value="1" aria-label="Increase petal count">+</button></div>
          <p class="puzzle-note">Set the missing petal count and confirm the engraving.</p><div class="row" style="justify-content:center"><button class="button" data-action="confirm-petals">Engrave Petals</button></div>`;
      case 5:return `<div class="mechanic-title">The fountain's four numbered spouts</div><div class="row" style="justify-content:center">${[1,2,3,4].map(n=>`<button class="spout" data-action="spout" data-value="${n}" ${p.sequence.includes(n)?'disabled':''}>⛲<br>${n}</button>`).join('')}</div>
          <div class="sequence">${[0,1,2,3].map(i=>`<span>${p.sequence[i]??'—'}</span>`).join('')}</div>
          <p class="puzzle-note">Spout 1 is first, 3 immediately follows 1, 4 is last, and 2 precedes 4.</p>`;
      case 6:return `<div class="mechanic-title">Follow the witnesses in the order B → A → C</div>
          <div class="symbol-grid">${['NORTH','SOUTH','EAST','WEST'].map(dir=>`<button class="spout" data-action="direction" data-value="${dir}">${dir}</button>`).join('')}</div>
          <div class="sequence">${[0,1,2].map(i=>`<span>${p.route[i]||'—'}</span>`).join('')}</div>
          <p class="puzzle-note">Witness A points East, B South, and C West.</p>`;
      case 7:return `<div class="mechanic-title">Mechanical stained-glass carriage</div>
          <div class="mirror">${p.order.map((s,i)=>`<div class="mirror-pane">${i+1}. ${h(s)}</div>`).join('')}</div>
          <div class="row" style="justify-content:center;margin:22px 0"><button class="button" data-action="swap-glass">Swap Outer Panes</button></div>
          <p class="puzzle-note">Keep every pane upright. Only the top and bottom positions are exchanged.</p>`;
      case 8:return `<div class="mechanic-title">The memorial and the painted testimony</div><div class="portrait-timeline">
        <div class="year-card"><span class="tiny-label">Family memorial</span><b>1904</b><small>Witness died</small></div>
        <div class="year-card"><span class="tiny-label">Signed portrait</span><b>1912</b><small>Claims a live sitting</small></div></div>
        <p class="puzzle-note">Select the impossible assertion, not merely the date or the signature.</p>
        <div class="row" style="justify-content:center"><button class="button secondary" data-action="timeline" data-value="signature">A signature exists</button>
        <button class="button" data-action="timeline" data-value="live">Witness sat alive in 1912</button></div>`;
      case 9:return `<div class="mechanic-title">Restore the erased epitaph</div><div class="big-number" style="font-size:clamp(2rem,7vw,5rem);letter-spacing:.13em">R <span class="gold">${p.letter||'_'}</span> M E M B E R</div>
        <p class="puzzle-note">Select the missing letter using Lady Vey's independent testimony.</p><div class="symbol-grid">${['A','E','I','O'].map(letter=>`<button class="symbol-tile" data-action="letter" data-value="${letter}">${letter}</button>`).join('')}</div>`;
      case 10:return `<div class="mechanic-title">The four meridian rings</div><div class="ring-list">${p.rings.map(letter=>`<div class="ring">${letter}</div>`).join('')}</div>
        <p class="puzzle-note">B immediately follows A. A precedes C. D belongs last. Swap neighbouring rings to align the register.</p>
        <div class="row swap-controls">${[0,1,2].map(n=>`<button class="button secondary" data-action="swap-rings" data-value="${n}" aria-label="Swap rings ${n+1} and ${n+2}">↔ ${n+1}–${n+2}</button>`).join('')}</div>`;
      default:return '';
    }
  }
  function renderPuzzle(){
    const c=caseAt(view.n),solved=view.mechanicSolved;
    const hint=view.hintCount?`<div class="clue-drawer"><div class="chapter-tag">Hint ${view.hintCount} / 3</div><p>${h(c.hints[view.hintCount-1])}</p></div>`:'';
    return shell(`<main class="screen puzzle-page"><div class="row between"><div><div class="chapter-tag">LOCATION ${String(c.number).padStart(2,'0')} · INTERACTIVE MECHANISM</div><h2>${h(c.title)}</h2></div>
        <button class="button ghost" data-action="back-scene">← Examine Scene</button></div><p class="puzzle-instruction">${h(c.fragments[0])}</p>
        <div class="puzzle-frame"><div class="puzzle-content"><div class="puzzle-ui">${puzzleHtml()}</div>
        ${solved?'<div class="notice success" role="status">Mechanism aligned. Your deduction can now be submitted.</div>':''}
        ${view.notice?`<div class="notice ${h(view.noticeType)}" role="status">${h(view.notice)}</div>`:''}
        </div></div>${hint}<div class="row between" style="margin-top:22px"><div class="row"><button class="button secondary" data-action="hint" ${view.hintCount>=3?'disabled':''}>Hint ${view.hintCount}/3</button>
        <button class="button ghost" data-action="reset-puzzle">Reset Mechanism</button></div>
        <button class="button" data-action="verdict" ${solved?'':'disabled'}>Record Deduction →</button></div></main>`);
  }
  function renderVerdict(){
    const c=caseAt(view.n);
    return shell(`<main class="screen puzzle-page"><div class="chapter-tag">The Moment of Judgment · Location ${String(c.number).padStart(2,'0')}</div>
      <h2>State Your Finding</h2><div class="puzzle-frame"><div class="puzzle-content">
      <p class="muted">${h(c.evidence)}</p><div class="line"></div><h3>${h(c.question)}</h3>
      <div class="choice-list">${c.choices.map((choice,i)=>`<button class="choice" data-action="answer" data-value="${i}"><strong>${String.fromCharCode(65+i)}.</strong>${h(choice)}</button>`).join('')}</div>
      ${view.notice?`<div class="notice ${h(view.noticeType)}" role="status">${h(view.notice)}</div>`:''}</div></div>
      <div class="row" style="margin-top:18px"><button class="button ghost" data-action="back-puzzle">← Recheck Mechanism</button><button class="button secondary" data-action="hint" ${view.hintCount>=3?'disabled':''}>Request Hint</button></div>
      ${view.hintCount?`<div class="clue-drawer"><p>${h(c.hints[view.hintCount-1])}</p></div>`:''}</main>`);
  }
  function renderResolved(){
    const c=caseAt(view.n);
    const finishedChapter=CHAPTER_RANGES.some((range)=>range[1]===view.n);
    const body=`<div class="chapter-tag">FINDING ${String(view.n).padStart(2,'0')} VERIFIED</div><h2>${h(c.title)}</h2>
      <p class="large-copy">${h(c.explanation)}</p><p class="large-copy gold">${h(STORY.consequences[view.n-1])}</p>
      ${finishedChapter?`<div class="copybox"><div class="chapter-tag">Chapter ${c.chapter} Coda</div><p>${h(STORY.chapterCodas[c.chapter-1])}</p></div>`:''}
      <div class="row" style="justify-content:center;margin-top:24px">${view.n===10?'<button class="button" data-action="finale">Open the Final Register →</button>':`<button class="button" data-action="go-case" data-value="${view.n+1}">Continue to Location ${view.n+1} →</button>`}
      <button class="button secondary" data-action="map">Case Atlas</button></div>`;
    return shell(`<main class="screen"><div class="chapter-end" style="background-image:url('${chapterImg(c.chapter)}')"><div>${body}</div></div></main>`);
  }
  function renderFinale(){
    if(state.completed.length!==10)return renderMap();
    const page=view.finalePage;
    return shell(`<main class="screen"><div class="chapter-tag">The Unedited Record · ${page+1} / 4</div>
      <div class="finale-layout"><div class="finale-text"><h2>${h(STORY.finaleHeadings[page])}</h2><div class="title-line"></div>
      <p>${h(STORY.finalePages[page])}</p><div class="row"><button class="button secondary" data-action="finale-page" data-value="-1" ${page===0?'disabled':''}>← Previous</button>
      ${page===3?'<button class="button" data-action="map">Review Investigation</button>':`<button class="button" data-action="finale-page" data-value="1">Next Page →</button>`}</div></div>
      <div class="finale-art" style="background-image:url('${chapterImg(Math.min(4,page+1))}')" role="img" aria-label="Original chapter artwork"></div></div></main>`);
  }
  function renderConfirmNew(){
    return shell(`<main class="screen"><div class="settings-panel panel">
      <div class="chapter-tag">Progress protection</div><h2>Begin a New Investigation?</h2>
      <p class="muted">Starting over replaces the ${state.completed.length} findings currently saved on this device. This cannot be undone.</p>
      <div class="row" style="margin-top:24px"><button class="button danger" data-action="new-confirm">Erase Findings & Start Again</button>
      <button class="button secondary" data-action="map">Keep Current Progress</button></div>
      </div></main>`);
  }
  function renderSettings(){
    const s=state.settings;
    return shell(`<main class="screen"><div class="settings-panel panel"><div class="chapter-tag">Audio & Persistence</div><h2>Settings</h2>
      <p class="muted">Music and effects can be independently controlled. Investigation progress is stored locally in alternating protected save slots.</p>
      <div class="settings-entry"><label for="music-volume">Ambient music <output id="music-output">${Math.round(s.musicVolume*100)}%</output></label>
      <input type="range" id="music-volume" data-action="music-volume" min="0" max="100" value="${Math.round(s.musicVolume*100)}" aria-label="Ambient music volume">
      <label for="music-mute">Mute ambient music <input type="checkbox" id="music-mute" data-action="music-mute" ${s.muteMusic?'checked':''}></label></div>
      <div class="settings-entry"><label for="sfx-volume">Effects <output id="sfx-output">${Math.round(s.sfxVolume*100)}%</output></label>
      <input type="range" id="sfx-volume" data-action="sfx-volume" min="0" max="100" value="${Math.round(s.sfxVolume*100)}" aria-label="Effects volume">
      <label for="sfx-mute">Mute effects <input type="checkbox" id="sfx-mute" data-action="sfx-mute" ${s.muteSfx?'checked':''}></label></div>
      <div class="settings-entry"><div class="row between"><span>Saved findings</span><strong class="gold">${state.completed.length} / 10</strong></div>
        <p class="muted small-copy">${storageWorks?'Local device saving is available. Saved progress is checksum-validated, not encrypted.':'Local storage is unavailable here; progress is kept only until this page closes.'}</p>${recoveredCorruptSave?'<p class="notice error">A damaged saved record was ignored. Any valid backup has been recovered.</p>':''}</div>
      <div class="row" style="margin-top:24px"><button class="button" data-action="map">Return to Investigation</button>
      <button class="button secondary" data-action="test-sound">Play Test Sound</button></div>
      <div class="line"></div><div class="row between"><span class="muted small-copy">Reset all investigation progress</span>
      <button class="button danger" data-action="confirm-reset">Reset Game</button></div>${view.notice?`<div class="notice error">${h(view.notice)} <button class="button danger" data-action="reset-confirmed">Confirm Reset</button></div>`:''}</div></main>`);
  }
  function render(){
    const screens={title:renderTitle,map:renderMap,confirmNew:renderConfirmNew,scene:renderScene,puzzle:renderPuzzle,
      verdict:renderVerdict,resolved:renderResolved,finale:renderFinale,settings:renderSettings};
    const app=byId('app');
    const previousScreen=app.dataset.screen||'';
    const active=document.activeElement;
    const focusedAction=active&&active.dataset?active.dataset.action:null;
    const focusedValue=active&&active.dataset?active.dataset.value:null;
    const html=(screens[view.screen]||renderTitle)();
    app.innerHTML=html;
    if(unsavedChanges||!storageWorks){
      const warning=document.createElement('div');
      warning.className='storage-warning';
      warning.setAttribute('role','alert');
      warning.textContent='SAVE UNAVAILABLE — progress is temporary on this device. Do not close the game.';
      const header=app.querySelector('.topbar');
      if(header)header.after(warning);
    }
    app.dataset.screen=view.screen;
    document.title=`${view.screen==='title'?'Sable & Sigil':caseAt(view.n)?.title||'Case Atlas'} · Sable & Sigil`;
    if(previousScreen===view.screen&&focusedAction){
      const match=Array.from(app.querySelectorAll('[data-action]')).find(element=>
        element.dataset.action===focusedAction&&element.dataset.value===focusedValue&&!element.disabled);
      if(match)match.focus({preventScroll:true});
    }else if(previousScreen&&previousScreen!==view.screen){
      const heading=app.querySelector('main h1, main h2');
      if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}
    }
    sound.sync();
  }
  function goCase(n){
    if(!Number.isSafeInteger(n)||n<1||n>10||n>state.completed.length+1){toast('This location has not yet been unlocked.');return;}
    view={screen:'scene',n,inspected:new Set(),selectedClue:0,mechanicSolved:false,
      puzzle:null,hintCount:0,notice:'',noticeType:'',finalePage:0};
    render();window.scrollTo(0,0);
  }
  function solved(){
    if(!view.mechanicSolved){view.mechanicSolved=true;view.notice='Mechanism solved. Record your deduction.';view.noticeType='success';sound.play('success');}
  }
  function fail(message){view.notice=message;view.noticeType='error';sound.play('error');}
  function clearNotice(){view.notice='';view.noticeType='';}
  function changePuzzle(action,value){
    const p=view.puzzle;
    clearNotice();
    if(view.mechanicSolved&&action!=='reset-puzzle')return;
    switch(action){
      case 'trace':if(p.uv>=70){p.tracing=true;solved();}else fail('Illuminate the extra ray first.');break;
      case 'motif':p.motif=value==='Circle'?'○':value==='Diamond'?'◇':value==='Star'?'✦':'☾';if(value==='Star')solved();else fail('This motif breaks the three-mark cycle.');break;
      case 'turn':p.phase=(p.phase+Number(value)+4)%4;if(p.phase===2)solved();else sound.play('tap');break;
      case 'petal':p.petals=clamp(p.petals+Number(value),0,30);sound.play('tap');break;
      case 'confirm-petals':if(p.petals===13)solved();else fail('The next count must be the sum of the previous two.');break;
      case 'spout':{
        const number=Number(value),target=[1,3,2,4];
        if(number!==target[p.sequence.length]){p.sequence=[];fail('Incorrect sequence. The mechanism resets.');}
        else{p.sequence.push(number);if(p.sequence.length===4)solved();else sound.play('tap');}
        break;
      }
      case 'direction':{
        const target=['SOUTH','EAST','WEST'];
        if(value!==target[p.route.length]){p.route=[];fail('The route does not match the witnesses. Start again.');}
        else{p.route.push(value);if(p.route.length===3)solved();else sound.play('tap');}
        break;
      }
      case 'swap-glass':p.order=[p.order[2],p.order[1],p.order[0]];if(p.order.join('|')==='Three rays|Ring|Triangle')solved();break;
      case 'timeline':p.claim=value;if(value==='live')solved();else fail('A signature alone does not contradict the memorial.');break;
      case 'letter':p.letter=value;if(value==='E')solved();else fail('That letter does not agree with the preserved note.');break;
      case 'swap-rings':{
        const i=Number(value);if(!Number.isInteger(i)||i<0||i>2)return;
        [p.rings[i],p.rings[i+1]]=[p.rings[i+1],p.rings[i]];
        if(p.rings.join('')==='ABCD')solved();else sound.play('tap');break;
      }
      default:return;
    }
    render();
  }
  function action(name,value){
    sound.enable();
    if(name==='test-sound'){toast(sound.play('unlock')?'Test sound played.':'Effects are muted or audio has not been activated.');return;}
    if(name==='settings'){view.screen='settings';clearNotice();render();return;}
    if(name==='home'){view.screen='title';render();return;}
    if(name==='map'){view.screen='map';render();return;}
    if(name==='new'){if(state.completed.length>0){view.screen='confirmNew';render();return;}resetProgress();view.screen='map';render();toast('A new investigation has begun.');return;}
    if(name==='new-confirm'&&view.screen==='confirmNew'){resetProgress();view.screen='map';render();toast('A new investigation has begun.');return;}
    if(name==='go-case'){goCase(Number(value));return;}
    if(name==='confirm-reset'){view.notice='This permanently clears all ten findings on this device.';render();return;}
    if(name==='reset-confirmed'&&view.screen==='settings'&&view.notice){resetProgress();view.screen='title';clearNotice();render();toast('Investigation progress reset.');return;}
    if(name==='inspect'&&view.screen==='scene'){
      const index=Number(value);if(index!==0&&index!==1)return;
      view.inspected.add(index);view.selectedClue=index+1;sound.play('inspect');render();announce(`Evidence fragment ${index+1} inspected.`);return;
    }
    if(name==='close-clue'){view.selectedClue=0;render();return;}
    if(name==='open-puzzle'&&view.screen==='scene'){
      if(view.inspected.size!==2&&!state.completed.includes(view.n))return;
      view.puzzle=resetPuzzle();view.mechanicSolved=false;view.screen='puzzle';clearNotice();render();return;
    }
    if(name==='back-scene'){view.screen='scene';render();return;}
    if(name==='reset-puzzle'){view.puzzle=resetPuzzle();view.mechanicSolved=false;clearNotice();render();return;}
    if(name==='hint'&&['puzzle','verdict'].includes(view.screen)){
      view.hintCount=Math.min(3,view.hintCount+1);sound.play('tap');render();return;
    }
    if(name==='verdict'&&view.screen==='puzzle'&&view.mechanicSolved){view.screen='verdict';clearNotice();render();return;}
    if(name==='back-puzzle'&&view.screen==='verdict'){view.screen='puzzle';clearNotice();render();return;}
    if(name==='answer'&&view.screen==='verdict'){
      const choice=Number(value),c=caseAt(view.n);
      if(choice!==c.correct){fail('This deduction does not fit the evidence. Re-examine the mechanism and the two fragments.');render();return;}
      if(!state.completed.includes(view.n)){
        if(view.n!==state.completed.length+1)return;
        state.completed.push(view.n);state.revision=state.completed.length;saveGame('progress');
        if(!state.completed.includes(view.n)){
          view.screen='map';clearNotice();render();toast('A newer save was restored; this finding was not recorded.');return;
        }
      }
      sound.play('unlock');view.screen='resolved';clearNotice();render();window.scrollTo(0,0);announce('Correct deduction. Next location unlocked.');return;
    }
    if(name==='finale'){if(state.completed.length!==10)return;view.screen='finale';view.finalePage=0;render();return;}
    if(name==='finale-page'&&view.screen==='finale'){view.finalePage=clamp(view.finalePage+Number(value),0,3);render();window.scrollTo(0,0);return;}
    if(['trace','motif','turn','petal','confirm-petals','spout','direction','swap-glass','timeline','letter','swap-rings'].includes(name)&&view.screen==='puzzle')changePuzzle(name,value);
  }
  document.addEventListener('click',event=>{
    const button=event.target.closest('[data-action]');
    if(!button||button.disabled)return;
    const type=button.getAttribute('data-action');
    if(['uv-range','music-volume','sfx-volume','music-mute','sfx-mute'].includes(type))return;
    event.preventDefault();action(type,button.getAttribute('data-value'));
  });
  document.addEventListener('input',event=>{
    const control=event.target;if(!control.matches('[data-action]'))return;
    const type=control.getAttribute('data-action');
    if(type==='uv-range'&&view.screen==='puzzle'&&view.n===1){
      view.puzzle.uv=clamp(Number(control.value),0,100);
      const label=byId('uv-value');if(label)label.textContent=`${view.puzzle.uv}%`;
      const target=control.closest('.puzzle-ui').querySelector('.crest[style]');
      if(target)target.style.setProperty('--uv',view.puzzle.uv/100);
      const button=document.querySelector('[data-action="trace"]');if(button)button.disabled=view.puzzle.uv<70;
    }
    if(type==='music-volume'||type==='sfx-volume'){
      const key=type==='music-volume'?'musicVolume':'sfxVolume';
      state.settings[key]=clamp(Number(control.value)/100,0,1);
      const output=byId(type==='music-volume'?'music-output':'sfx-output');if(output)output.textContent=`${control.value}%`;
      sound.sync();
    }
  });
  document.addEventListener('change',event=>{
    const control=event.target;if(!control.matches('[data-action]'))return;
    const type=control.getAttribute('data-action');
    if(type==='uv-range'){sound.play('inspect');render();}
    if(type==='music-volume'||type==='sfx-volume'){saveGame('settings');sound.enable();render();}
    if(type==='music-mute'||type==='sfx-mute'){
      state.settings[type==='music-mute'?'muteMusic':'muteSfx']=Boolean(control.checked);
      saveGame('settings');sound.sync();sound.play('tap');render();
    }
  });
  window.addEventListener('keydown',event=>{
    if(event.key==='Escape'&&['scene','puzzle','verdict','finale','settings','confirmNew'].includes(view.screen)){
      event.preventDefault();view.screen='map';render();
    }
  });
  if('serviceWorker' in navigator&&(location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1'))
    navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
  window.addEventListener('storage',event=>{
    if(event.key!==null&&!event.key.startsWith(STORAGE_PREFIX))return;
    const latest=readLatestSnapshot();
    if(!latest&&storageWorks){
      // Respect an explicit clear/removal from another tab instead of reviving deleted progress.
      generation=0;
      state=blank();
      view={screen:'map',n:1,inspected:new Set(),selectedClue:0,mechanicSolved:false,
        puzzle:null,hintCount:0,notice:'',noticeType:'',finalePage:0};
      render();toast('Local investigation storage was cleared.');return;
    }
    if(latest&&latest.generation>generation){
      generation=latest.generation;
      state=latest.value;
      view={screen:'map',n:Math.min(10,state.completed.length+1),inspected:new Set(),selectedClue:0,
        mechanicSolved:false,puzzle:null,hintCount:0,notice:'',noticeType:'',finalePage:0};
      render();toast('Investigation progress updated from another tab.');
    }
  });
  render();
  window.__SABLE_TEST__={getState:()=>JSON.parse(JSON.stringify(state)),getView:()=>({...view,inspected:[...view.inspected]}),getGeneration:()=>generation};
})();
