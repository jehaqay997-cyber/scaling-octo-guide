@echo off
setlocal
set "GAME=%~dp0PLAY_GAME_NOW.html"
if not exist "%GAME%" (
  echo ERROR: PLAY_GAME_NOW.html was not found in the project folder.
  exit /b 1
)
start "" "%GAME%"
if errorlevel 1 (
  echo ERROR: The default browser did not open the game.
  exit /b 1
)
echo Opened Sable ^& Sigil in the default browser.
exit /b 0
