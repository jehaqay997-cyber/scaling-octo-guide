using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class FrameBudgetPolicyTests
    {
        [Test]
        public void InitialTargetsMatchPlatformClass()
        {
            Assert.AreEqual(30, FrameBudgetPolicy.InitialTarget(true));
            Assert.AreEqual(60, FrameBudgetPolicy.InitialTarget(false));
        }

        [Test]
        public void LowBatteryOnlyThrottlesWhenKnownAndDischarging()
        {
            Assert.AreEqual(24, FrameBudgetPolicy.Choose(60, 16, .1, true, 0));
            Assert.AreEqual(60, FrameBudgetPolicy.Choose(60, 16, .1, false, 0));
            Assert.AreEqual(60, FrameBudgetPolicy.Choose(60, 16, -1, true, 0));
        }

        [Test]
        public void SlowWindowsRequireHysteresisAndNeverIncreaseTarget()
        {
            Assert.AreEqual(60, FrameBudgetPolicy.Choose(60, 40, .8, false, 2));
            Assert.AreEqual(30, FrameBudgetPolicy.Choose(60, 40, .8, false, 3));
            Assert.AreEqual(24, FrameBudgetPolicy.Choose(30, 48, .8, false, 3));
            Assert.AreEqual(30, FrameBudgetPolicy.Choose(30, 10, .8, false, 100));
        }

        [TestCase(60, 60, 60.0, 60)]
        [TestCase(30, 60, 30.0, 30)]
        [TestCase(24, 60, 20.0, 20)]
        [TestCase(60, 90, 45.0, 45)]
        [TestCase(30, 90, 30.0, 30)]
        [TestCase(24, 90, 22.5, 23)]
        [TestCase(24, 120, 24.0, 24)]
        [TestCase(60, 144, 48.0, 48)]
        [TestCase(30, 75, 25.0, 25)]
        public void RequestsRefreshCompatibleMobileCadence(int desired, double refresh,
            double expectedEffective, int expectedRequest)
        {
            Assert.AreEqual(expectedEffective,
                FrameBudgetPolicy.EffectiveMobileFramesPerSecond(desired, refresh), 0.001);
            Assert.AreEqual(expectedRequest, FrameBudgetPolicy.MobileFrameRequest(desired, refresh));
        }

        [Test]
        public void FractionalAndUnknownRefreshRatesAreHandled()
        {
            Assert.AreEqual(29.97,
                FrameBudgetPolicy.EffectiveMobileFramesPerSecond(30, 59.94), 0.001);
            Assert.AreEqual(30, FrameBudgetPolicy.MobileFrameRequest(30, 59.94));
            Assert.AreEqual(30.0,
                FrameBudgetPolicy.EffectiveMobileFramesPerSecond(30, 0), 0.001);
            Assert.AreEqual(30, FrameBudgetPolicy.MobileFrameRequest(30, double.NaN));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                FrameBudgetPolicy.MobileFrameRequest(0, 60));
        }

        [Test]
        public void StablePacedFortyFiveFramesDoesNotTriggerFalseDowngrade()
        {
            Assert.IsFalse(FrameBudgetPolicy.IsFrameOverBudget(1000.0 / 45, 45));
            Assert.AreEqual(60, FrameBudgetPolicy.Choose(60, 1000.0 / 45,
                .75, true, 5, 45.0));
            Assert.AreEqual(30, FrameBudgetPolicy.Choose(60, 31.0,
                .75, true, 5, 45.0));
            Assert.AreEqual(24, FrameBudgetPolicy.Choose(30, 65.0,
                .75, true, 3, 20.0));
        }

        [Test]
        public void RejectsInvalidEffectivePacingMeasurements()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                FrameBudgetPolicy.Choose(60, 22, .8, true, 3, 0));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                FrameBudgetPolicy.IsFrameOverBudget(14, double.NaN));
            Assert.Throws<ArgumentOutOfRangeException>(() =>
                FrameBudgetPolicy.MobileFrameRequest(-1, 120));
        }

        [Test]
        public void RejectsInvalidMeasurementsAndTargets()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => FrameBudgetPolicy.Choose(45, 20, .5, true, 3));
            Assert.Throws<ArgumentOutOfRangeException>(() => FrameBudgetPolicy.Choose(30, double.NaN, .5, true, 3));
            Assert.Throws<ArgumentOutOfRangeException>(() => FrameBudgetPolicy.Choose(30, -1, .5, true, 3));
            Assert.Throws<ArgumentOutOfRangeException>(() => FrameBudgetPolicy.Choose(30, 20, .5, true, -1));
        }
    }
}
