using System;
using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterOneInferenceBoardTests
    {
        [TestCase(1, "sixth ray")]
        [TestCase(1, "Added Sixth Ray")]
        [TestCase(1, "  6th   ray  ")]
        [TestCase(2, "star")]
        [TestCase(2, "STAR MOTIF")]
        public void AuthoredTypedFindingMapsToExistingSessionAnswer(int number, string entry)
        {
            StoryDossierCase dossier = StoryDossierCatalog.Get(number);
            Assert.IsTrue(dossier.TryInterpretTypedFinding(entry, out int choice));
            Assert.IsTrue(dossier.IsCorrect(choice));
        }

        [TestCase(1, "ray")]
        [TestCase(1, "first ray")]
        [TestCase(1, "sixth ray plus another")]
        [TestCase(2, "crescent")]
        [TestCase(2, "STARFISH")]
        [TestCase(2, "")] 
        public void UnsubstantiatedTypedFindingCannotBecomeCompletion(int number, string entry)
        {
            StoryDossierCase dossier = StoryDossierCatalog.Get(number);
            Assert.IsFalse(dossier.TryInterpretTypedFinding(entry, out int choice));
            Assert.AreEqual(-1, choice);
        }

        [Test]
        public void OnlyFirstTwoCasesUsePhysicalInferenceBoard()
        {
            for (int number = 1; number <= ChapterStoryGraph.LocationCount; number++)
            {
                var inspection = new StoryCaseInspection(number);
                Assert.AreEqual(number <= 2, inspection.IsInteractiveBoardCase);
                Assert.IsFalse(inspection.HasCorroboratedFinding);
                if (number > 2)
                {
                    Assert.IsFalse(inspection.TryPlaceOnBoard(0, 0));
                    Assert.IsFalse(inspection.TryExaminePhysicalContradiction());
                    Assert.IsFalse(StoryDossierCatalog.Get(number)
                        .TryInterpretTypedFinding("star", out _));
                }
            }
        }

        [Test]
        public void PhysicalProofNeedsInspectedEvidenceAndCorrectSlotAssignments()
        {
            var inspection = new StoryCaseInspection(1);
            Assert.IsFalse(inspection.TryPlaceOnBoard(0, 0));
            Assert.IsFalse(inspection.TryExaminePhysicalContradiction());
            Assert.IsTrue(inspection.TryInspect(0, out _));
            Assert.IsFalse(inspection.TryPlaceOnBoard(0, 0));
            Assert.IsTrue(inspection.TryInspect(1, out _));
            Assert.IsFalse(inspection.TryPlaceOnBoard(2, 1));
            Assert.IsFalse(inspection.TryPlaceOnBoard(1, 0));
            Assert.IsFalse(inspection.HasPlacedOnBoard(0));
            Assert.IsFalse(inspection.HasPlacedOnBoard(1));
            Assert.IsFalse(inspection.HasPlacedOnBoard(-1));
            Assert.IsFalse(inspection.HasPlacedOnBoard(2));
            Assert.GreaterOrEqual(inspection.RejectedBoardAttempts, 2);
            Assert.IsTrue(inspection.TryPlaceOnBoard(0, 0));
            Assert.IsTrue(inspection.HasPlacedOnBoard(0));
            Assert.IsFalse(inspection.HasPlacedOnBoard(1));
            Assert.IsFalse(inspection.TryPlaceOnBoard(0, 0));
            Assert.IsFalse(inspection.TryExaminePhysicalContradiction());
            Assert.IsTrue(inspection.TryPlaceOnBoard(1, 1));
            Assert.IsTrue(inspection.HasPairedEvidence);
            Assert.IsFalse(inspection.HasCorroboratedFinding);
            Assert.IsTrue(inspection.TryExaminePhysicalContradiction());
            Assert.IsTrue(inspection.HasCorroboratedFinding);
            Assert.IsFalse(inspection.TryExaminePhysicalContradiction());
        }

        [Test]
        public void NewInvestigationGetsFreshUnsharedEvidenceState()
        {
            var first = new StoryCaseInspection(2);
            first.TryInspect(0, out _);
            first.TryInspect(1, out _);
            Assert.IsTrue(first.TryPlaceOnBoard(0, 0));
            Assert.IsTrue(first.TryPlaceOnBoard(1, 1));
            Assert.IsTrue(first.TryExaminePhysicalContradiction());
            var next = new StoryCaseInspection(2);
            Assert.IsFalse(next.HasPairedEvidence);
            Assert.IsFalse(next.HasCorroboratedFinding);
            Assert.AreEqual(0, next.RejectedBoardAttempts);
        }

        [Test]
        public void ExcessivelyLongFindingAndNullTextCannotSubmit()
        {
            StoryDossierCase dossier = StoryDossierCatalog.Get(1);
            Assert.IsFalse(dossier.TryInterpretTypedFinding(null, out _));
            Assert.IsFalse(dossier.TryInterpretTypedFinding(new string('X', 1000), out _));
        }
    }
}
