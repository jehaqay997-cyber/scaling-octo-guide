using NUnit.Framework;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class ChapterInteractiveMechanismTests
    {
        [Test]
        public void TracingRejectsUninspectedEvidenceAndMissedDropWithoutProgress()
        {
            var tracing = new CrestTracingState();
            Assert.AreEqual(PhysicalPlacementResult.EvidenceRequired,
                tracing.TryPlace(true, false, true));
            Assert.AreEqual(0, tracing.Attempts);
            Assert.AreEqual(PhysicalPlacementResult.MissedTarget,
                tracing.TryPlace(false, true, true));
            Assert.AreEqual(1, tracing.Attempts);
            Assert.IsFalse(tracing.IsPlaced);
        }

        [Test]
        public void TracingCanBePlacedOnlyOnceAndResetDoesNotAlterStoryCompletion()
        {
            var tracing = new CrestTracingState();
            Assert.AreEqual(PhysicalPlacementResult.Placed,
                tracing.TryPlace(true, true, true));
            Assert.IsTrue(tracing.IsPlaced);
            Assert.AreEqual(PhysicalPlacementResult.AlreadyPlaced,
                tracing.TryPlace(true, true, true));
            Assert.AreEqual(1, tracing.Attempts);
            tracing.Reset();
            Assert.AreEqual(0, tracing.Attempts);
            Assert.IsFalse(tracing.IsPlaced);
        }

        [Test]
        public void LunarDialCyclesBothDirectionsAndOnlyFullMoonMatchesCaseThree()
        {
            var dial = new LunarPhaseDial();
            StoryDossierCase dossier = StoryDossierCatalog.Get(3);
            Assert.AreEqual(LunarPhase.NewMoon, dial.Phase);
            Assert.IsFalse(dossier.IsCorrect(dial.CurrentChoiceIndex));
            Assert.IsTrue(dial.TryTurn(1));
            Assert.AreEqual(LunarPhase.WaxingMoon, dial.Phase);
            Assert.IsFalse(dossier.IsCorrect(dial.CurrentChoiceIndex));
            Assert.IsTrue(dial.TryTurn(1));
            Assert.AreEqual(LunarPhase.FullMoon, dial.Phase);
            Assert.IsTrue(dossier.IsCorrect(dial.CurrentChoiceIndex));
            Assert.IsTrue(dial.TryTurn(1));
            Assert.AreEqual(LunarPhase.WaningMoon, dial.Phase);
            Assert.IsFalse(dossier.IsCorrect(dial.CurrentChoiceIndex));
            Assert.IsTrue(dial.TryTurn(1));
            Assert.AreEqual(LunarPhase.NewMoon, dial.Phase);
            Assert.IsTrue(dial.TryTurn(-1));
            Assert.AreEqual(LunarPhase.WaningMoon, dial.Phase);
            Assert.AreEqual(5, dial.Turns);
        }

        [Test]
        public void LunarDialRejectsInvalidStepsAndSupportsFreshInvestigation()
        {
            var dial = new LunarPhaseDial();
            Assert.IsFalse(dial.TryTurn(0));
            Assert.IsFalse(dial.TryTurn(2));
            Assert.IsFalse(dial.TryTurn(-2));
            Assert.AreEqual(LunarPhase.NewMoon, dial.Phase);
            Assert.AreEqual(0, dial.Turns);
            Assert.IsTrue(dial.TryTurn(1));
            dial.Reset();
            Assert.AreEqual(LunarPhase.NewMoon, dial.Phase);
            Assert.AreEqual(0, dial.Turns);
        }
    }
}
