using System;
using NUnit.Framework;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    public sealed class WorldTouchChordGateTests
    {
        [Test]
        public void OneContactAndMouseInputWorkWithoutAChord()
        {
            var gate = new WorldTouchChordGate();
            Assert.IsTrue(gate.MayProcessSinglePointer(0));
            Assert.IsTrue(gate.MayProcessSinglePointer(1));
            Assert.IsFalse(gate.IsAwaitingRelease);
        }

        [Test]
        public void TwoFingerChordCannotBecomeOneFingerTap()
        {
            var gate = new WorldTouchChordGate();
            Assert.IsTrue(gate.MayProcessSinglePointer(1));
            Assert.IsFalse(gate.MayProcessSinglePointer(2));
            Assert.IsTrue(gate.IsAwaitingRelease);
            Assert.IsFalse(gate.MayProcessSinglePointer(1));
            Assert.IsFalse(gate.MayProcessSinglePointer(0));
            Assert.IsFalse(gate.IsAwaitingRelease);
            Assert.IsTrue(gate.MayProcessSinglePointer(1));
        }

        [Test]
        public void ThreeFingerChordCannotReopenUntilAllAreReleased()
        {
            var gate = new WorldTouchChordGate();
            Assert.IsFalse(gate.MayProcessSinglePointer(3));
            Assert.IsFalse(gate.MayProcessSinglePointer(2));
            Assert.IsFalse(gate.MayProcessSinglePointer(1));
            Assert.IsFalse(gate.MayProcessSinglePointer(0));
            Assert.IsTrue(gate.MayProcessSinglePointer(0));
        }

        [Test]
        public void NewlyOpenedSceneCanRejectPreexistingTouch()
        {
            var gate = new WorldTouchChordGate();
            gate.Suspend();
            Assert.IsFalse(gate.MayProcessSinglePointer(1));
            Assert.IsFalse(gate.MayProcessSinglePointer(0));
            Assert.IsTrue(gate.MayProcessSinglePointer(1));
            gate.Suspend();
            gate.Reset();
            Assert.IsTrue(gate.MayProcessSinglePointer(0));
        }

        [Test]
        public void NegativeContactCountIsNeverAccepted()
        {
            var gate = new WorldTouchChordGate();
            Assert.Throws<ArgumentOutOfRangeException>(() => gate.MayProcessSinglePointer(-1));
        }
    }
}
