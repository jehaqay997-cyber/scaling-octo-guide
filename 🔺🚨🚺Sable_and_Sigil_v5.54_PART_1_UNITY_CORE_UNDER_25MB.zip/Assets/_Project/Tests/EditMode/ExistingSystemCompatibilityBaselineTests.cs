using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;

namespace TheOrderRoom.Tests.EditMode
{
    /// <summary>
    /// Characterization tests for the existing adventure, deduction and drawer-puzzle
    /// contracts. These tests intentionally make no changes to production state.
    /// </summary>
    public sealed class ExistingSystemCompatibilityBaselineTests
    {
        [Test]
        public void AuthoredCaseProofsStillMatchAllTenCurrentAnswerKeys()
        {
            Assert.IsTrue(StoryDossierCatalog.Validate(out string catalogError), catalogError);
            Assert.AreEqual(10, StoryDossierCatalog.All.Count);

            for (int number = 1; number <= ChapterStoryGraph.LocationCount; number++)
            {
                StoryDossierCase dossier = StoryDossierCatalog.Get(number);
                StoryDeductionProof.Result result = StoryDeductionProof.Solve(number);
                Assert.AreEqual(number, dossier.Number);
                Assert.AreEqual(number, result.LocationNumber);
                Assert.IsTrue(result.IsUnique);
                Assert.IsTrue(StoryDeductionProof.VerifyCatalogCase(dossier, out string error), error);
            }
        }

        [TestCase(1, "SIXTH RAY", 2)]
        [TestCase(1, "  extra   sixth ray  ", 2)]
        [TestCase(2, "STAR", 3)]
        [TestCase(2, "  star motif  ", 3)]
        public void ExistingTypedFindingAliasesMapToOriginalCaseAnswers(
            int caseNumber, string entry, int expectedChoice)
        {
            StoryDossierCase dossier = StoryDossierCatalog.Get(caseNumber);
            Assert.IsTrue(dossier.TryInterpretTypedFinding(entry, out int choice));
            Assert.AreEqual(expectedChoice, choice);
            Assert.IsTrue(dossier.IsCorrect(choice));
        }

        [Test]
        public void InvalidTypedFindingsCannotBecomeSuccessfulChoices()
        {
            foreach (int number in new[] { 1, 2, 3 })
            {
                StoryDossierCase dossier = StoryDossierCatalog.Get(number);
                foreach (string entry in new[] { null, string.Empty, "WRONG", new string('X', 65) })
                {
                    Assert.IsFalse(dossier.TryInterpretTypedFinding(entry, out int choice));
                    Assert.AreEqual(-1, choice);
                }
            }
        }

        [Test]
        public void CurrentStoryGraphKeepsItsExistingSequentialPrerequisites()
        {
            Assert.IsTrue(ChapterStoryGraph.Validate(out string error), error);
            Assert.AreEqual(0, ChapterStoryGraph.GetLocation(1).Prerequisites.Count);

            for (int number = 2; number <= ChapterStoryGraph.LocationCount; number++)
            {
                IReadOnlyList<int> prerequisites = ChapterStoryGraph.GetLocation(number).Prerequisites;
                Assert.AreEqual(1, prerequisites.Count);
                Assert.AreEqual(number - 1, prerequisites[0]);
            }

            Assert.IsTrue(ChapterStoryGraph.IsAvailable(3, new[] { 1, 2 }));
            Assert.IsFalse(ChapterStoryGraph.IsAvailable(4, new[] { 1, 2 }));
            Assert.IsTrue(ChapterStoryGraph.IsAvailable(4, new[] { 1, 2, 3 }));
        }

        [Test]
        public void ProofQueriesDoNotMutateTheCanonicalEvidenceLedger()
        {
            var ledger = new StoryEvidenceLedger();
            Assert.IsTrue(ledger.TryResolve(1, 0, out string error), error);
            long revision = ledger.Revision;
            int[] snapshot = ledger.Snapshot();

            for (int number = 1; number <= ChapterStoryGraph.LocationCount; number++)
                StoryDeductionProof.Solve(number);

            Assert.AreEqual(revision, ledger.Revision);
            CollectionAssert.AreEqual(snapshot, ledger.Snapshot());
        }

        [Test]
        public void LinkedDrawerRulesRemainPartOfExistingCampaignNotDossierProofs()
        {
            var enrichedLevel = CampaignPuzzles.Get(5, 2);
            Assert.IsTrue(enrichedLevel.Rules.OfType<LinkedPairRule>().Any());
            Assert.IsTrue(enrichedLevel.Rules.OfType<DestinationKeyRule>().Any());

            var originalLevel = CampaignPuzzles.Get(5, 1);
            Assert.IsFalse(originalLevel.Rules.OfType<LinkedPairRule>().Any());
            Assert.IsFalse(originalLevel.Rules.OfType<DestinationKeyRule>().Any());
        }

        [Test]
        public void CollectionMilestonesKeepTheirIndependentTwelveArtifactThreshold()
        {
            string[] tenUniqueArtifacts = Enumerable.Range(1, 10)
                .Select(number => "artifact." + number.ToString()).ToArray();
            string[] tenMilestones = CollectionMilestones.Evaluate(tenUniqueArtifacts);
            CollectionAssert.AreEqual(
                new[] { "gallery.first", "gallery.curator", "gallery.archivist" },
                tenMilestones);
            Assert.IsFalse(tenMilestones.Contains("gallery.complete"));

            string[] twelveUniqueArtifacts = Enumerable.Range(1, 12)
                .Select(number => "artifact." + number.ToString()).ToArray();
            CollectionAssert.AreEqual(
                new[] { "gallery.first", "gallery.curator", "gallery.archivist", "gallery.complete" },
                CollectionMilestones.Evaluate(twelveUniqueArtifacts));
        }
    }
}
