using System;
using System.Collections;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class SoundSettingsUpgradePlayModeTests
    {
        private static readonly string[] PreferenceKeys =
        {
            LocalPrivacyPreferences.AudioEnabledKey,
            LocalPrivacyPreferences.EffectsEnabledKey,
            LocalPrivacyPreferences.AmbienceEnabledKey,
            LocalPrivacyPreferences.EffectsVolumeKey,
            LocalPrivacyPreferences.AmbienceVolumeKey
        };

        private sealed class SavedPreferences : IDisposable
        {
            private readonly bool[] existing = new bool[PreferenceKeys.Length];
            private readonly int[] values = new int[PreferenceKeys.Length];

            public SavedPreferences()
            {
                for (int i = 0; i < PreferenceKeys.Length; i++)
                {
                    existing[i] = PlayerPrefs.HasKey(PreferenceKeys[i]);
                    values[i] = PlayerPrefs.GetInt(PreferenceKeys[i], 0);
                }
            }

            public void Dispose()
            {
                for (int i = 0; i < PreferenceKeys.Length; i++)
                {
                    if (existing[i]) PlayerPrefs.SetInt(PreferenceKeys[i], values[i]);
                    else PlayerPrefs.DeleteKey(PreferenceKeys[i]);
                }
                PlayerPrefs.Save();
            }
        }

        [Test]
        public void ExistingMasterMuteIsPreservedAndChannelsRemainIndependent()
        {
            using (new SavedPreferences())
            {
                for (int i = 0; i < PreferenceKeys.Length; i++)
                    PlayerPrefs.DeleteKey(PreferenceKeys[i]);

                Assert.IsTrue(LocalPrivacyPreferences.AudioEnabled);
                Assert.IsTrue(LocalPrivacyPreferences.EffectsEnabled);
                Assert.IsTrue(LocalPrivacyPreferences.AmbienceEnabled);
                Assert.AreEqual(1f, LocalPrivacyPreferences.EffectsVolume);
                Assert.AreEqual(1f, LocalPrivacyPreferences.AmbienceVolume);

                Assert.IsTrue(LocalPrivacyPreferences.TrySetAudioEnabled(false, out string masterError), masterError);
                Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsEnabled(false, out string effectsError), effectsError);
                Assert.IsTrue(LocalPrivacyPreferences.TrySetAmbienceVolume(.4f, out string ambienceError), ambienceError);

                Assert.IsFalse(LocalPrivacyPreferences.AudioEnabled);
                Assert.IsFalse(LocalPrivacyPreferences.EffectsAudible);
                Assert.IsFalse(LocalPrivacyPreferences.AmbienceAudible);
                Assert.AreEqual(.4f, LocalPrivacyPreferences.AmbienceVolume, .001f);

                Assert.IsTrue(LocalPrivacyPreferences.TrySetAudioEnabled(true, out masterError), masterError);
                Assert.IsFalse(LocalPrivacyPreferences.EffectsEnabled);
                Assert.IsTrue(LocalPrivacyPreferences.AmbienceEnabled);
                Assert.IsFalse(LocalPrivacyPreferences.EffectsAudible);
                Assert.IsTrue(LocalPrivacyPreferences.AmbienceAudible);
            }
        }

        [Test]
        public void InvalidVolumesDoNotAlterSavedSettingsOrEmitEvents()
        {
            using (new SavedPreferences())
            {
                Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsVolume(.6f, out string error), error);
                int changes = 0;
                Action observer = () => changes++;
                LocalPrivacyPreferences.AudioSettingsChanged += observer;
                try
                {
                    Assert.IsFalse(LocalPrivacyPreferences.TrySetEffectsVolume(float.NaN, out error));
                    Assert.IsFalse(LocalPrivacyPreferences.TrySetEffectsVolume(float.PositiveInfinity, out error));
                    Assert.IsFalse(LocalPrivacyPreferences.TrySetEffectsVolume(-.01f, out error));
                    Assert.IsFalse(LocalPrivacyPreferences.TrySetAmbienceVolume(1.01f, out error));
                    Assert.AreEqual(0, changes);
                    Assert.AreEqual(.6f, LocalPrivacyPreferences.EffectsVolume, .001f);
                    Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsVolume(.8f, out error), error);
                    Assert.AreEqual(1, changes);
                    Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsVolume(.8f, out error), error);
                    Assert.AreEqual(1, changes);
                }
                finally
                {
                    LocalPrivacyPreferences.AudioSettingsChanged -= observer;
                }
            }
        }

        [UnityTest]
        public IEnumerator EffectsMuteAndVolumeApplyToExistingAudioProviderImmediately()
        {
            using (new SavedPreferences())
            {
                Assert.IsTrue(LocalPrivacyPreferences.TrySetAudioEnabled(true, out string masterError), masterError);
                Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsEnabled(true, out string effectsError), effectsError);
                Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsVolume(.5f, out string volumeError), volumeError);

                var host = new GameObject("Independent Effects Volume Test");
                try
                {
                    var feedback = host.AddComponent<OrderAudioFeedback>();
                    var source = host.GetComponent<AudioSource>();
                    Assert.IsNotNull(source);
                    Assert.AreEqual(.2f, source.volume, .001f);
                    Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsVolume(0f, out volumeError), volumeError);
                    Assert.AreEqual(0f, source.volume, .001f);
                    Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsVolume(.5f, out volumeError), volumeError);
                    Assert.AreEqual(.2f, source.volume, .001f);
                    feedback.PlayHint();
                    Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsEnabled(false, out effectsError), effectsError);
                    Assert.AreEqual(0f, source.volume, .001f);
                    Assert.IsFalse(source.isPlaying);
                    Assert.IsTrue(LocalPrivacyPreferences.TrySetEffectsEnabled(true, out effectsError), effectsError);
                    Assert.AreEqual(.2f, source.volume, .001f);
                    Assert.IsTrue(LocalPrivacyPreferences.TrySetAudioEnabled(false, out masterError), masterError);
                    Assert.AreEqual(0f, source.volume, .001f);
                }
                finally
                {
                    Object.Destroy(host);
                }
                yield return null;
            }
        }

        [UnityTest]
        public IEnumerator AmbienceFadesAfterVolumeChangeAndStopsWhenMuted()
        {
            using (new SavedPreferences())
            {
                Assert.IsTrue(LocalPrivacyPreferences.TrySetAudioEnabled(true, out string masterError), masterError);
                Assert.IsTrue(LocalPrivacyPreferences.TrySetAmbienceEnabled(true, out string ambienceError), ambienceError);
                Assert.IsTrue(LocalPrivacyPreferences.TrySetAmbienceVolume(1f, out string volumeError), volumeError);

                var host = new GameObject("Independent Ambience Volume Test");
                try
                {
                    var ambience = host.AddComponent<ChapterWorldAtmosphere>();
                    var source = host.GetComponent<AudioSource>();
                    ambience.Initialize(1);
                    yield return new WaitForSecondsRealtime(.22f);
                    Assert.AreEqual(.19f, source.volume, .015f);

                    Assert.IsTrue(LocalPrivacyPreferences.TrySetAmbienceVolume(.2f, out volumeError), volumeError);
                    yield return new WaitForSecondsRealtime(.22f);
                    Assert.AreEqual(.038f, source.volume, .015f);
                    Assert.IsTrue(LocalPrivacyPreferences.TrySetAudioEnabled(false, out masterError), masterError);
                    yield return new WaitForSecondsRealtime(.22f);
                    Assert.AreEqual(0f, source.volume, .001f);
                    Assert.IsFalse(source.isPlaying);
                }
                finally
                {
                    Object.Destroy(host);
                }
                yield return null;
            }
        }
    }
}
