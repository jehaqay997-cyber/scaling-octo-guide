using System;
using System.Collections;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class WorldPuzzlePointerSafetyPlayModeTests
    {
        private const BindingFlags PrivateInstance = BindingFlags.Instance | BindingFlags.NonPublic;

        [UnityTest]
        public IEnumerator InvalidRotaryPointerCannotInvokePuzzleTurn()
        {
            var root = new GameObject("Rotary Canvas", typeof(RectTransform));
            var face = new GameObject("Dial Face", typeof(RectTransform), typeof(Image));
            var eventSystem = new GameObject("Rotary EventSystem", typeof(EventSystem));
            try
            {
                face.transform.SetParent(root.transform, false);
                var dial = face.AddComponent<ChapterPuzzleRotaryDial>();
                int committedTurns = 0;
                dial.Initialize(root.GetComponent<RectTransform>(), () => true,
                    direction => { committedTurns++; return true; });
                var pointer = new PointerEventData(eventSystem.GetComponent<EventSystem>())
                {
                    position = new Vector2(float.NaN, 12f),
                    pointerId = 12
                };
                dial.OnBeginDrag(pointer);
                dial.OnDrag(pointer);
                dial.OnEndDrag(pointer);
                Assert.AreEqual(0, committedTurns);
                Assert.IsFalse((bool)ReadPrivate(dial, "dragging"));
            }
            finally
            {
                Object.Destroy(face);
                Object.Destroy(root);
                Object.Destroy(eventSystem);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator InvalidDragDropCannotCommitEvidence()
        {
            var root = new GameObject("Drag Canvas", typeof(RectTransform));
            var target = new GameObject("Evidence Socket", typeof(RectTransform));
            var token = new GameObject("Evidence Token", typeof(RectTransform), typeof(Image));
            var eventSystem = new GameObject("Drag EventSystem", typeof(EventSystem));
            try
            {
                target.transform.SetParent(root.transform, false);
                token.transform.SetParent(root.transform, false);
                var drag = token.AddComponent<ChapterPuzzleDragToken>();
                int commits = 0;
                drag.Initialize(root.GetComponent<RectTransform>(), target.GetComponent<RectTransform>(),
                    () => true, inside => { commits++; return inside; });
                var pointer = new PointerEventData(eventSystem.GetComponent<EventSystem>())
                {
                    position = new Vector2(float.PositiveInfinity, 20f),
                    pointerId = 4
                };
                drag.OnBeginDrag(pointer);
                drag.OnDrag(pointer);
                drag.OnEndDrag(pointer);
                Assert.AreEqual(0, commits);
                Assert.IsFalse(drag.IsCommitted);
                Assert.IsFalse((bool)ReadPrivate(drag, "dragging"));
            }
            finally
            {
                Object.Destroy(token);
                Object.Destroy(target);
                Object.Destroy(root);
                Object.Destroy(eventSystem);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator DisabledCinematicSurfaceNeverEmitsDragDelta()
        {
            var root = new GameObject("Cinematic Surface", typeof(RectTransform));
            var eventSystem = new GameObject("Cinematic EventSystem", typeof(EventSystem));
            try
            {
                var surface = root.AddComponent<CinematicSceneDragSurface>();
                int movements = 0;
                surface.Configure(root.GetComponent<RectTransform>(), () => true,
                    delta => movements++, delta => { });
                var pointer = new PointerEventData(eventSystem.GetComponent<EventSystem>())
                {
                    button = PointerEventData.InputButton.Left,
                    pointerId = 2,
                    position = new Vector2(float.NaN, 0f)
                };
                surface.OnBeginDrag(pointer);
                surface.OnDrag(pointer);
                Assert.AreEqual(0, movements);
                Assert.IsFalse((bool)ReadPrivate(surface, "dragging"));
            }
            finally
            {
                Object.Destroy(root);
                Object.Destroy(eventSystem);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator FocusLossCancelsAllTransientPuzzleGestures()
        {
            var root = new GameObject("Pointer Focus Root", typeof(RectTransform));
            var socket = new GameObject("Pointer Focus Socket", typeof(RectTransform));
            var token = new GameObject("Pointer Focus Token", typeof(RectTransform), typeof(Image));
            var dialFace = new GameObject("Pointer Focus Dial", typeof(RectTransform), typeof(Image));
            try
            {
                socket.transform.SetParent(root.transform, false);
                token.transform.SetParent(root.transform, false);
                dialFace.transform.SetParent(root.transform, false);
                var draggingToken = token.AddComponent<ChapterPuzzleDragToken>();
                draggingToken.Initialize(root.GetComponent<RectTransform>(),
                    socket.GetComponent<RectTransform>(), () => true, overTarget => overTarget);
                var rotary = dialFace.AddComponent<ChapterPuzzleRotaryDial>();
                rotary.Initialize(root.GetComponent<RectTransform>(), () => true, direction => true);
                var surface = root.AddComponent<CinematicSceneDragSurface>();
                surface.Configure(root.GetComponent<RectTransform>(), () => true,
                    delta => { }, delta => { });

                WritePrivate(draggingToken, "dragging", true);
                WritePrivate(rotary, "dragging", true);
                WritePrivate(surface, "dragging", true);
                InvokeLifecycle(draggingToken, "OnApplicationFocus", false);
                InvokeLifecycle(rotary, "OnApplicationFocus", false);
                InvokeLifecycle(surface, "OnApplicationFocus", false);

                Assert.IsFalse((bool)ReadPrivate(draggingToken, "dragging"));
                Assert.IsFalse((bool)ReadPrivate(rotary, "dragging"));
                Assert.IsFalse((bool)ReadPrivate(surface, "dragging"));
                Assert.IsFalse(draggingToken.IsCommitted);
            }
            finally
            {
                Object.Destroy(token);
                Object.Destroy(dialFace);
                Object.Destroy(socket);
                Object.Destroy(root);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ApplicationPauseCancelsAllTransientPuzzleGestures()
        {
            var root = new GameObject("Pointer Pause Root", typeof(RectTransform));
            var socket = new GameObject("Pointer Pause Socket", typeof(RectTransform));
            var token = new GameObject("Pointer Pause Token", typeof(RectTransform), typeof(Image));
            var dialFace = new GameObject("Pointer Pause Dial", typeof(RectTransform), typeof(Image));
            try
            {
                socket.transform.SetParent(root.transform, false);
                token.transform.SetParent(root.transform, false);
                dialFace.transform.SetParent(root.transform, false);
                var draggingToken = token.AddComponent<ChapterPuzzleDragToken>();
                draggingToken.Initialize(root.GetComponent<RectTransform>(),
                    socket.GetComponent<RectTransform>(), () => true, overTarget => overTarget);
                var rotary = dialFace.AddComponent<ChapterPuzzleRotaryDial>();
                rotary.Initialize(root.GetComponent<RectTransform>(), () => true, direction => true);
                var surface = root.AddComponent<CinematicSceneDragSurface>();
                surface.Configure(root.GetComponent<RectTransform>(), () => true,
                    delta => { }, delta => { });

                WritePrivate(draggingToken, "dragging", true);
                WritePrivate(rotary, "dragging", true);
                WritePrivate(surface, "dragging", true);
                InvokeLifecycle(draggingToken, "OnApplicationPause", true);
                InvokeLifecycle(rotary, "OnApplicationPause", true);
                InvokeLifecycle(surface, "OnApplicationPause", true);

                Assert.IsFalse((bool)ReadPrivate(draggingToken, "dragging"));
                Assert.IsFalse((bool)ReadPrivate(rotary, "dragging"));
                Assert.IsFalse((bool)ReadPrivate(surface, "dragging"));
                Assert.IsFalse(draggingToken.IsCommitted);
            }
            finally
            {
                Object.Destroy(token);
                Object.Destroy(dialFace);
                Object.Destroy(socket);
                Object.Destroy(root);
            }
            yield return null;
        }

        private static void WritePrivate(object target, string fieldName, object value)
        {
            FieldInfo field = target.GetType().GetField(fieldName, PrivateInstance);
            Assert.IsNotNull(field, "Missing state field: " + fieldName);
            field.SetValue(target, value);
        }

        private static void InvokeLifecycle(object target, string methodName, bool value)
        {
            MethodInfo method = target.GetType().GetMethod(methodName, PrivateInstance);
            Assert.IsNotNull(method, "Missing lifecycle handler: " + methodName);
            method.Invoke(target, new object[] { value });
        }

        private static object ReadPrivate(object target, string fieldName)
        {
            FieldInfo field = target.GetType().GetField(fieldName, PrivateInstance);
            Assert.IsNotNull(field, "Missing state field: " + fieldName);
            return field.GetValue(target);
        }
    }
}
