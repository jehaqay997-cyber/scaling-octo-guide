using System;
using System.Collections;
using System.Reflection;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class PointerLifecycleOwnershipPlayModeTests
    {
        private const BindingFlags NonPublicInstance = BindingFlags.Instance | BindingFlags.NonPublic;

        [UnityTest]
        public IEnumerator AChangedGameReferenceCannotCommitAnOldWorldGesture()
        {
            var firstHost = new GameObject("Original Gesture Owner");
            var secondHost = new GameObject("Replacement Gesture Owner");
            var inputHost = new GameObject("Pointer Ownership Test");
            try
            {
                OrderGame first = firstHost.AddComponent<OrderGame>();
                OrderGame second = secondHost.AddComponent<OrderGame>();
                OrderPointerInput input = inputHost.AddComponent<OrderPointerInput>();
                input.Game = first;

                BeginSyntheticMouseGesture(input);
                Assert.AreSame(first, ReadPrivateField(input, "gestureOwner"));

                input.Game = second;
                InvokePrivate(input, "Update");
                Assert.IsNull(ReadPrivateField(input, "gestureOwner"));
                Assert.AreEqual("None", ReadPrivateField(input, "activePointer").ToString());
                Assert.IsTrue((bool)ReadPrivateField(input, "blockUntilMouseReleased"));
            }
            finally
            {
                Object.Destroy(inputHost);
                Object.Destroy(secondHost);
                Object.Destroy(firstHost);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator DisablingInputAbortsTheGestureOwnedByItsOriginalGame()
        {
            var gameHost = new GameObject("Disabled Pointer Owner");
            var inputHost = new GameObject("Disabled Pointer Test");
            try
            {
                OrderGame owner = gameHost.AddComponent<OrderGame>();
                OrderPointerInput input = inputHost.AddComponent<OrderPointerInput>();
                input.Game = owner;
                BeginSyntheticMouseGesture(input);
                Assert.AreSame(owner, ReadPrivateField(input, "gestureOwner"));

                input.enabled = false;
                Assert.IsNull(ReadPrivateField(input, "gestureOwner"));
                Assert.AreEqual("None", ReadPrivateField(input, "activePointer").ToString());
                Assert.IsTrue((bool)ReadPrivateField(input, "blockUntilTouchesEnd"));
                Assert.IsTrue((bool)ReadPrivateField(input, "blockUntilMouseReleased"));
            }
            finally
            {
                Object.Destroy(inputHost);
                Object.Destroy(gameHost);
            }
            yield return null;
        }

        private static void BeginSyntheticMouseGesture(OrderPointerInput input)
        {
            MethodInfo begin = typeof(OrderPointerInput).GetMethod("BeginGesture", NonPublicInstance);
            Assert.IsNotNull(begin);
            Type pointerKind = begin.GetParameters()[0].ParameterType;
            object mouse = Enum.Parse(pointerKind, "Mouse");
            begin.Invoke(input, new[] { mouse, (object)new Vector2(24f, 24f) });
        }

        private static void InvokePrivate(OrderPointerInput input, string methodName)
        {
            MethodInfo method = typeof(OrderPointerInput).GetMethod(methodName, NonPublicInstance);
            Assert.IsNotNull(method);
            method.Invoke(input, null);
        }

        private static object ReadPrivateField(OrderPointerInput input, string fieldName)
        {
            FieldInfo field = typeof(OrderPointerInput).GetField(fieldName, NonPublicInstance);
            Assert.IsNotNull(field);
            return field.GetValue(input);
        }
    }
}
