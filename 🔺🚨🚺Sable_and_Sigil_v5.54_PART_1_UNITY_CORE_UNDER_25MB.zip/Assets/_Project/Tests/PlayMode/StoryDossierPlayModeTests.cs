using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class StoryDossierPlayModeTests
    {
        private static void InspectBothEvidence(ChapterGalleryView gallery)
        {
            gallery.GetComponentsInChildren<Button>(true)
                .Single(button => button.name == "INSPECT EVIDENCE A").onClick.Invoke();
            gallery.GetComponentsInChildren<Button>(true)
                .Single(button => button.name == "INSPECT EVIDENCE B").onClick.Invoke();
        }

        [UnityTest]
        public IEnumerator ChapterThreeUnfinishedCaseCannotBypassPhysicalMechanismFromAtlas()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(6, new[] { 1, 2, 3, 4, 5, 6 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Chapter Three Atlas Gate Test Host");
                var gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectLocation(7);
                var caseButton = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "OPEN CASE FILE");
                var dossier = gallery.GetComponent<StoryDossierView>();
                var art = gallery.GetComponentsInChildren<RawImage>(true)
                    .Single(image => image.name == "Selected Chapter Artwork");
                Assert.IsNotNull(dossier);
                Assert.IsFalse(caseButton.interactable);
                Assert.That(caseButton.GetComponentInChildren<Text>().text,
                    Is.EqualTo("SOLVE 3D MECHANISM"));
                Assert.Throws<System.InvalidOperationException>(() => dossier.Open(7, (Texture2D)art.texture));
                // A queued or direct button callback must also fail closed.
                caseButton.onClick.Invoke();
                Assert.IsFalse(dossier.IsOpen);
                Assert.IsFalse(PlayerPrefs.HasKey(StoryDossierRepository.KeyB));
                Assert.IsFalse(new StoryDossierSession(new PlayerPrefsDossierStorage()).IsCompleted(7));

                // The world completion path can transfer both inspected relics.
                Assert.Throws<System.InvalidOperationException>(() =>
                    dossier.OpenFromWorldEvidence(7, (Texture2D)art.texture, null));
                Assert.IsFalse(dossier.IsOpen);
                // A world-issued, location-scoped capability is required for transfer.
                // The positive path is covered by the connected ChapterWorldExplorer tests.

                var progress = new StoryDossierSession(new PlayerPrefsDossierStorage());
                Assert.IsTrue(progress.TrySubmit(7, 0, progress.Revision, out string message), message);
                gallery.Show();
                gallery.SelectLocation(7);
                Assert.IsTrue(caseButton.interactable, "A completed case must remain reviewable.");
                caseButton.onClick.Invoke();
                Assert.IsTrue(dossier.IsOpen);
                dossier.Hide();
                gallery.Close();
            }
            finally
            {
                if (host != null) Object.Destroy(host);
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }

        private static StoryDossierView OpenVerifiedChapterOneDossier(
            ChapterGalleryView gallery, int location)
        {
            Assert.That(location, Is.AnyOf(1, 2));
            gallery.SelectLocation(location);
            Button caseButton = gallery.GetComponentsInChildren<Button>(true)
                .Single(button => button.name == "OPEN CASE FILE");
            Assert.IsFalse(caseButton.interactable,
                "An unfinished case must require its physical mechanism.");
            caseButton.onClick.Invoke();
            StoryDossierView dossier = gallery.GetComponent<StoryDossierView>();
            Assert.IsFalse(dossier.IsOpen, "Direct callback must fail closed.");
            Button worldButton = gallery.GetComponentsInChildren<Button>(true)
                .Single(button => button.name == "EXPLORE 3D");
            Assert.IsTrue(worldButton.interactable);
            worldButton.onClick.Invoke();
            ChapterWorldExplorer world = gallery.GetComponent<ChapterWorldExplorer>();
            Assert.IsNotNull(world);
            Assert.IsTrue(world.IsOpen);
            Assert.AreEqual(location, world.ActiveLocation);
            Assert.IsFalse(world.CanDeduce);
            Assert.IsTrue(world.TryInspectEvidence(0));
            Assert.IsTrue(world.TryInspectEvidence(1));
            if (location == 1)
            {
                Assert.IsTrue(world.TryOpenThresholdViewer());
                Assert.IsTrue(world.TryPlaceCrestTracing(),
                    "The case-file handoff must include physical crest-tracing placement.");
                Assert.AreEqual(ThresholdRaySelection.Verified,
                    world.TrySelectThresholdRay(ThresholdCrestPuzzle.AddedRayIndex));
                world.CloseThresholdViewer();
            }
            else
            {
                Assert.IsTrue(world.TryOpenSpiralViewer());
                Assert.AreEqual(BalusterSelection.Verified,
                    world.TrySelectSpiralSymbol(BalusterSymbol.Star));
                world.CloseSpiralViewer();
            }
            Assert.IsTrue(world.CanDeduce);
            Button deduction = world.GetComponentsInChildren<Button>(true)
                .Single(button => button.name == "OPEN DEDUCTION");
            deduction.onClick.Invoke();
            Assert.IsFalse(world.IsOpen);
            Assert.IsTrue(dossier.IsOpen, "Verified evidence must reach the case file.");
            return dossier;
        }

        private static void SubmitAuthoredDeduction(ChapterGalleryView gallery, int location)
        {
            if (location <= 2)
            {
                var dossier = gallery.GetComponent<StoryDossierView>();
                Assert.IsNotNull(dossier);
                Assert.IsFalse(dossier.TryPlaceBoardEvidence(0, 0, false),
                    "A missed drop must not register evidence.");
                Assert.IsFalse(dossier.TryPlaceBoardEvidence(2, 1, true),
                    "A misleading claim must not fill the physical evidence slot.");
                Assert.IsTrue(dossier.TryPlaceBoardEvidence(0, 0, true));
                Assert.IsTrue(dossier.TryPlaceBoardEvidence(1, 1, true));
                Assert.IsTrue(dossier.TryExaminePhysicalContradiction());
                var entry = gallery.GetComponentsInChildren<InputField>(true)
                    .Single(field => field.name == "Deduction Conclusion Input");
                var record = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "RECORD FINDING");
                Assert.IsTrue(record.interactable);
                entry.text = "unrelated rumor";
                record.onClick.Invoke();
                Assert.IsFalse(new StoryDossierSession(new PlayerPrefsDossierStorage())
                    .IsCompleted(location), "A rejected free-text claim must not persist completion.");
                entry.text = location == 1 ? "sixth ray" : "star";
                record.onClick.Invoke();
            }
            else
            {
                int correct = Enumerable.Range(0, 4)
                    .Single(StoryDossierCatalog.Get(location).IsCorrect);
                Button answer = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "Dossier Answer " + (correct + 1));
                Assert.IsTrue(answer.interactable);
                answer.onClick.Invoke();
            }
            StoryDossierSession persisted = new StoryDossierSession(new PlayerPrefsDossierStorage());
            Assert.IsTrue(persisted.IsReady, persisted.Error);
            Assert.IsTrue(persisted.IsCompleted(location));
        }

        [UnityTest]
        public IEnumerator VerifiedUnfinishedDossierResumesWithoutRepeatingWorldAndCannotUnlockAnotherCase()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Resume Verified Dossier Test Host");
                ChapterGalleryView gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                StoryDossierView dossier = OpenVerifiedChapterOneDossier(gallery, 1);
                Assert.IsTrue(dossier.TryPlaceBoardEvidence(0, 0, true));
                ChapterPuzzleDragToken firstCard = gallery.GetComponentsInChildren<ChapterPuzzleDragToken>(true)
                    .Single(token => token.name == "Dossier Evidence Card 1");
                Assert.IsTrue(firstCard.IsCommitted);
                Button returnToAtlas = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "RETURN TO ATLAS");
                returnToAtlas.onClick.Invoke();
                Assert.IsFalse(dossier.IsOpen);
                Assert.IsFalse(new StoryDossierSession(new PlayerPrefsDossierStorage()).IsCompleted(1));
                Assert.IsTrue(dossier.CanResumeVerifiedCase(1));
                Assert.IsFalse(dossier.CanResumeVerifiedCase(2));
                Button reopen = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "OPEN CASE FILE");
                Assert.IsTrue(reopen.interactable);
                Assert.That(reopen.GetComponentInChildren<Text>().text, Is.EqualTo("RESUME CASE FILE"));
                gallery.SelectLocation(2);
                Assert.IsFalse(reopen.interactable, "Physical verification for case one must not unlock case two.");
                reopen.onClick.Invoke();
                Assert.IsFalse(dossier.IsOpen);
                gallery.SelectLocation(1);
                reopen.onClick.Invoke();
                Assert.IsTrue(dossier.IsOpen);
                Assert.IsTrue(firstCard.IsCommitted, "The previously placed evidence card must remain placed.");
                Assert.IsFalse(dossier.TryPlaceBoardEvidence(0, 0, true));
                Assert.IsTrue(dossier.TryPlaceBoardEvidence(1, 1, true));
                Assert.IsTrue(dossier.TryExaminePhysicalContradiction());
                InputField finding = gallery.GetComponentsInChildren<InputField>(true)
                    .Single(field => field.name == "Deduction Conclusion Input");
                Button record = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "RECORD FINDING");
                finding.text = "sixth ray";
                record.onClick.Invoke();
                Assert.IsTrue(new StoryDossierSession(new PlayerPrefsDossierStorage()).IsCompleted(1));
                Assert.IsFalse(dossier.CanResumeVerifiedCase(1), "Completion revokes the ephemeral resume grant.");
                dossier.Close();
                Assert.That(reopen.GetComponentInChildren<Text>().text, Is.EqualTo("REVIEW CASE FILE"));
                gallery.Close();
            }
            finally
            {
                if (host != null) Object.Destroy(host);
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator InferenceCardsAreReusableForCaseTwoAndRejectIncorrectSockets()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Two Case Reusable Dossier Cards Host");
                ChapterGalleryView gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                StoryDossierView dossier = OpenVerifiedChapterOneDossier(gallery, 1);
                Assert.IsFalse(dossier.TryPlaceBoardEvidence(1, 0, true));
                Assert.IsFalse(dossier.TryPlaceBoardEvidence(2, 1, true));
                SubmitAuthoredDeduction(gallery, 1);
                ChapterPuzzleDragToken first = gallery.GetComponentsInChildren<ChapterPuzzleDragToken>(true)
                    .Single(token => token.name == "Dossier Evidence Card 1");
                ChapterPuzzleDragToken second = gallery.GetComponentsInChildren<ChapterPuzzleDragToken>(true)
                    .Single(token => token.name == "Dossier Evidence Card 2");
                Assert.IsTrue(first.IsCommitted);
                Assert.IsTrue(second.IsCommitted);
                dossier.Close();
                dossier = OpenVerifiedChapterOneDossier(gallery, 2);
                Assert.IsFalse(first.IsCommitted, "A card used in case one must reset before case two.");
                Assert.IsFalse(second.IsCommitted);
                Assert.IsTrue(first.GetComponent<Image>().raycastTarget);
                Assert.IsTrue(second.GetComponent<Image>().raycastTarget);
                Assert.IsFalse(dossier.TryPlaceBoardEvidence(0, 1, true));
                SubmitAuthoredDeduction(gallery, 2);
                Assert.IsTrue(new StoryDossierSession(new PlayerPrefsDossierStorage()).IsCompleted(2));
                dossier.Close();
                gallery.Close();
            }
            finally
            {
                if (host != null) Object.Destroy(host);
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator ChapterCaseButtonFollowsUnlockedEvidenceWithoutOpeningFuture3DScenes()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Connected Chapter Progression Test Host");
                ChapterGalleryView gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                Button caseNavigation = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "CHAPTER CASES");
                Button caseFile = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "OPEN CASE FILE");
                Button returnButton = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "RETURN TO ATLAS");
                Text heading = gallery.GetComponentsInChildren<Text>(true)
                    .Single(label => label.name == "Selected Chapter Heading");
                Text availability = gallery.GetComponentsInChildren<Text>(true)
                    .Single(label => label.name == "Selected Chapter Availability");

                gallery.SelectChapter(2);
                Assert.IsFalse(caseNavigation.interactable);
                Assert.That(availability.text, Does.Contain("0/4"));
                gallery.SelectChapter(1);
                Assert.IsTrue(caseNavigation.interactable);
                caseNavigation.onClick.Invoke();
                Assert.That(heading.text, Does.Contain("LOCATION 01"));
                Assert.IsFalse(caseFile.interactable);
                OpenVerifiedChapterOneDossier(gallery, 1);
                SubmitAuthoredDeduction(gallery, 1);
                returnButton.onClick.Invoke();
                yield return null;

                gallery.SelectChapter(1);
                Assert.That(availability.text, Does.Contain("1/2"));
                caseNavigation.onClick.Invoke();
                Assert.That(heading.text, Does.Contain("LOCATION 02"));
                Assert.IsFalse(caseFile.interactable);
                OpenVerifiedChapterOneDossier(gallery, 2);
                SubmitAuthoredDeduction(gallery, 2);
                returnButton.onClick.Invoke();
                yield return null;

                gallery.SelectChapter(2);
                Assert.IsTrue(caseNavigation.interactable);
                Assert.That(availability.text, Does.Contain("0/4"));
                caseNavigation.onClick.Invoke();
                Assert.That(heading.text, Does.Contain("LOCATION 03"));
                Assert.IsFalse(caseFile.interactable,
                    "Chapter Two's first dossier must require its 3D mechanism.");
                Assert.IsTrue(gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "EXPLORE 3D").interactable);
                gallery.Close();
            }
            finally
            {
                if (host != null)
                {
                    ChapterGalleryView gallery = host.GetComponent<ChapterGalleryView>();
                    if (gallery != null) gallery.Close();
                    UnityEngine.Object.Destroy(host);
                }
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator InvestigationPanel_AnswersUnlockNextCaseWithoutPretendingToOpen3D()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Verified Dossier PlayMode Test Host");
                ChapterGalleryView gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectLocation(2);
                Button caseButton = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "OPEN CASE FILE");
                Assert.That(caseButton.interactable, Is.False);
                gallery.SelectLocation(1);
                Assert.That(caseButton.interactable, Is.False);
                caseButton.onClick.Invoke();
                Assert.IsFalse(gallery.GetComponent<StoryDossierView>().IsOpen);
                Assert.IsFalse(PlayerPrefs.HasKey(StoryDossierRepository.KeyA),
                    "Uninspected deduction must not persist.");
                StoryDossierView dossier = OpenVerifiedChapterOneDossier(gallery, 1);
                Assert.IsTrue(dossier.IsOpen);
                // The world passes both inspected evidence fragments automatically.
                InspectBothEvidence(gallery);
                Button answer = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "Dossier Answer 3");
                Assert.IsFalse(answer.gameObject.activeSelf,
                    "Case One cannot expose the legacy four-choice answer menu.");
                Button record = gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "RECORD FINDING");
                Assert.IsFalse(record.interactable,
                    "The typed finding must require two placed evidence cards.");
                SubmitAuthoredDeduction(gallery, 1);
                Assert.IsFalse(record.interactable);
                gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "RETURN TO ATLAS").onClick.Invoke();
                gallery.SelectLocation(2);
                Assert.That(caseButton.interactable, Is.False);
                Assert.IsTrue(gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "EXPLORE 3D").interactable);
                gallery.Close();
            }
            finally
            {
                if (host != null)
                {
                    ChapterGalleryView gallery = host.GetComponent<ChapterGalleryView>();
                    if (gallery != null) gallery.Close();
                    UnityEngine.Object.Destroy(host);
                }
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator FailedDossierRenderCanRetryWithSameReservedGrant()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(6, new[] { 1, 2, 3, 4, 5, 6 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("Dossier Reservation Failure Injection Host");
                var gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectLocation(7);
                var dossier = host.GetComponent<StoryDossierView>();
                Texture2D artwork = (Texture2D)gallery.GetComponentsInChildren<RawImage>(true)
                    .Single(image => image.name == "Selected Chapter Artwork").texture;
                Assert.IsNotNull(artwork);
                var constructor = typeof(WorldInvestigationGrant).GetConstructor(
                    System.Reflection.BindingFlags.NonPublic |
                    System.Reflection.BindingFlags.Instance,
                    null, new[] { typeof(int) }, null);
                Assert.IsNotNull(constructor);
                var grant = (WorldInvestigationGrant)constructor.Invoke(new object[] { 7 });
                var headingField = typeof(StoryDossierView).GetField("heading",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic);
                Assert.IsNotNull(headingField);
                Text originalHeading = (Text)headingField.GetValue(dossier);
                Assert.IsNotNull(originalHeading);
                try
                {
                    headingField.SetValue(dossier, null);
                    Assert.Throws<System.NullReferenceException>(() =>
                        dossier.OpenFromWorldEvidence(7, artwork, grant));
                    Assert.IsFalse(dossier.IsOpen);
                }
                finally
                {
                    headingField.SetValue(dossier, originalHeading);
                }
                dossier.OpenFromWorldEvidence(7, artwork, grant);
                Assert.IsTrue(dossier.IsOpen);
                var consume = typeof(WorldInvestigationGrant).GetMethod("TryConsume",
                    System.Reflection.BindingFlags.NonPublic |
                    System.Reflection.BindingFlags.Instance);
                Assert.IsFalse((bool)consume.Invoke(grant, new object[] { 7 }));
                dossier.Hide();
                gallery.Close();
            }
            finally
            {
                if (host != null) UnityEngine.Object.Destroy(host);
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator InvalidWorldHandoffDoesNotConsumeAnOtherwiseValidGrant()
        {
            bool hadA = PlayerPrefs.HasKey(StoryDossierRepository.KeyA);
            bool hadB = PlayerPrefs.HasKey(StoryDossierRepository.KeyB);
            string savedA = PlayerPrefs.GetString(StoryDossierRepository.KeyA, string.Empty);
            string savedB = PlayerPrefs.GetString(StoryDossierRepository.KeyB, string.Empty);
            GameObject host = null;
            try
            {
                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(6, new[] { 1, 2, 3, 4, 5, 6 }));
                PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                host = new GameObject("World Handoff Validation Test Host");
                ChapterGalleryView gallery = host.AddComponent<ChapterGalleryView>();
                gallery.Show();
                gallery.SelectLocation(7);
                StoryDossierView dossier = host.GetComponent<StoryDossierView>();
                Assert.IsNotNull(dossier);
                var constructor = typeof(WorldInvestigationGrant).GetConstructor(
                    System.Reflection.BindingFlags.NonPublic |
                    System.Reflection.BindingFlags.Instance,
                    null, new[] { typeof(int) }, null);
                var consume = typeof(WorldInvestigationGrant).GetMethod("TryConsume",
                    System.Reflection.BindingFlags.NonPublic |
                    System.Reflection.BindingFlags.Instance);
                Assert.IsNotNull(constructor);
                Assert.IsNotNull(consume);
                var badArtGrant = (WorldInvestigationGrant)constructor.Invoke(new object[] { 7 });
                Assert.Throws<System.InvalidOperationException>(() =>
                    dossier.OpenFromWorldEvidence(7, null, badArtGrant));
                Assert.IsTrue((bool)consume.Invoke(badArtGrant, new object[] { 7 }),
                    "An invalid artwork request must not consume the capability.");
                Assert.IsFalse((bool)consume.Invoke(badArtGrant, new object[] { 7 }));
                Assert.IsFalse(dossier.IsOpen);

                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(7, new[] { 1, 2, 3, 4, 5, 6, 7 }));
                gallery.Show();
                gallery.SelectLocation(7);
                Texture2D artwork = (Texture2D)gallery.GetComponentsInChildren<RawImage>(true)
                    .Single(image => image.name == "Selected Chapter Artwork").texture;
                dossier.Open(7, artwork);
                var activeModalGrant = (WorldInvestigationGrant)constructor.Invoke(new object[] { 7 });
                Assert.Throws<System.InvalidOperationException>(() =>
                    dossier.OpenFromWorldEvidence(7, artwork, activeModalGrant));
                Assert.IsTrue((bool)consume.Invoke(activeModalGrant, new object[] { 7 }),
                    "Opening over an active dossier must not consume the capability.");
                dossier.Hide();

                PlayerPrefs.SetString(StoryDossierRepository.KeyA,
                    StoryDossierCheckpointCodec.Encode(9, new[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 }));
                gallery.Show();
                gallery.SelectLocation(10);
                Texture2D fourthArt = (Texture2D)gallery.GetComponentsInChildren<RawImage>(true)
                    .Single(image => image.name == "Selected Chapter Artwork").texture;
                Assert.IsTrue(gallery.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "EXPLORE 3D").interactable,
                    "Chapter Four must become available after the nine prior cases.");
                Assert.Throws<System.InvalidOperationException>(() => dossier.Open(10, fourthArt),
                    "An uncompleted meridian case still requires physical world verification.");
                Assert.IsFalse(dossier.IsOpen);
                gallery.Close();
            }
            finally
            {
                if (host != null)
                {
                    ChapterGalleryView gallery = host.GetComponent<ChapterGalleryView>();
                    if (gallery != null) gallery.Close();
                    UnityEngine.Object.Destroy(host);
                }
                if (hadA) PlayerPrefs.SetString(StoryDossierRepository.KeyA, savedA);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyA);
                if (hadB) PlayerPrefs.SetString(StoryDossierRepository.KeyB, savedB);
                else PlayerPrefs.DeleteKey(StoryDossierRepository.KeyB);
                PlayerPrefs.Save();
            }
            yield return null;
        }
    }
}
