using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Domain;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.TestTools;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterInteractiveWorldPlayModeTests
    {
        [UnityTest]
        public IEnumerator CrestTracingControlsWhetherDiagramRayCanBeSelected()
        {
            var host = new GameObject("Crest Tracing PlayMode Host");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                Texture2D image = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(1).ArtResource);
                Assert.IsNotNull(image);
                explorer.Open(1, image, (location, deduction, first, second) => { });
                Assert.IsTrue(explorer.TryInspectEvidence(0));
                Assert.IsTrue(explorer.TryInspectEvidence(1));
                Assert.IsTrue(explorer.TryOpenThresholdViewer());
                Button ray = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "SELECT DIAGRAM RAY 5");
                Assert.IsFalse(ray.interactable);
                Assert.IsFalse(explorer.IsCrestTracingPlaced);
                Assert.IsFalse(explorer.TryPlaceCrestTracing(false));
                Assert.IsFalse(explorer.IsCrestTracingPlaced);
                Assert.IsTrue(explorer.TryPlaceCrestTracing());
                Assert.IsTrue(explorer.IsCrestTracingPlaced);
                Assert.IsTrue(ray.interactable);
                ray.onClick.Invoke();
                Assert.IsTrue(explorer.IsThresholdVerified);
                explorer.CloseThresholdViewer();
                Assert.IsTrue(explorer.CanDeduce);
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator StairSymbolOptionsAreDraggableAndCannotResolveWithoutTwoClues()
        {
            var host = new GameObject("Stair Drag PlayMode Host");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                Texture2D image = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(2).ArtResource);
                Assert.IsNotNull(image);
                explorer.Open(2, image, (location, deduction, first, second) => { });
                Assert.IsFalse(explorer.TryOpenSpiralViewer());
                Assert.IsTrue(explorer.TryInspectEvidence(0));
                Assert.IsTrue(explorer.TryInspectEvidence(1));
                Assert.IsTrue(explorer.TryOpenSpiralViewer());
                Button star = explorer.GetComponentsInChildren<Button>(true)
                    .Single(button => button.name == "SELECT STAR");
                Assert.IsNotNull(star.GetComponent<ChapterPuzzleDragToken>());
                Assert.IsTrue(star.interactable);
                Assert.IsFalse(explorer.IsSpiralVerified);
                Assert.IsNotNull(explorer.GetComponentsInChildren<Image>(true)
                    .Single(imageComponent => imageComponent.name == "Stair Motif Slot 6"));
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
            yield return null;
        }

        [UnityTest]
        public IEnumerator LunarDialRotatesBeforeExistingChapterTwoAuthorityConfirmsPhase()
        {
            var host = new GameObject("Lunar Dial PlayMode Host");
            ChapterWorldExplorer explorer = host.AddComponent<ChapterWorldExplorer>();
            try
            {
                Texture2D image = Resources.Load<Texture2D>(
                    ChapterWorldSceneCatalog.Get(3).ArtResource);
                Assert.IsNotNull(image);
                explorer.Open(3, image, (location, deduction, first, second) => { });
                Assert.IsFalse(explorer.TryTurnMoonDial(1));
                Assert.IsTrue(explorer.TryInspectEvidence(0));
                Assert.IsTrue(explorer.TryInspectEvidence(1));
                Assert.IsTrue(explorer.TryOpenChapterTwoViewer());
                Assert.AreEqual(LunarPhase.NewMoon, explorer.MoonDialPhase);
                Assert.IsNotNull(explorer.GetComponentsInChildren<ChapterPuzzleRotaryDial>(true)
                    .Single());
                Assert.AreEqual(ChapterTwoSelection.Incorrect, explorer.TryLockMoonDial());
                Assert.IsTrue(explorer.TryTurnMoonDial(1));
                Assert.IsTrue(explorer.TryTurnMoonDial(1));
                Assert.AreEqual(LunarPhase.FullMoon, explorer.MoonDialPhase);
                Assert.AreEqual(ChapterTwoSelection.Verified, explorer.TryLockMoonDial());
                Assert.IsTrue(explorer.IsChapterTwoVerified);
                Assert.IsFalse(explorer.TryTurnMoonDial(1));
                explorer.CloseChapterTwoViewer();
                Assert.IsTrue(explorer.CanDeduce);
            }
            finally
            {
                explorer.Close();
                Object.Destroy(host);
            }
            yield return null;
        }
    }
}
