using System;
using System.Collections.Generic;

namespace TheOrderRoom.Domain
{
    /// <summary>An authored, self-contained deduction. These case files are not 3D scenes.</summary>
    public sealed class StoryDossierCase
    {
        private readonly string[] choices;
        private readonly int correctChoice;
        private readonly string[] evidenceFragments;

        public int Number { get; }
        public string Evidence { get; }
        public string Question { get; }
        public string Explanation { get; }
        public IReadOnlyList<string> Choices { get; }
        public IReadOnlyList<string> EvidenceFragments { get; }

        internal StoryDossierCase(int number, string evidence, string question,
            string explanation, int correctChoice, string[] choices, string[] fragments)
        {
            Number = number;
            Evidence = evidence;
            Question = question;
            Explanation = explanation;
            this.correctChoice = correctChoice;
            this.choices = (string[])choices.Clone();
            Choices = Array.AsReadOnly(this.choices);
            this.evidenceFragments = fragments == null ? Array.Empty<string>() : (string[])fragments.Clone();
            EvidenceFragments = Array.AsReadOnly(this.evidenceFragments);
        }

        public bool IsCorrect(int choice)
        {
            return choice >= 0 && choice < choices.Length && choice == correctChoice;
        }

        /// <summary>
        /// Interprets an authored, player-typed finding without presenting the
        /// answer menu. This translates into the existing session authority;
        /// no parallel progress or save system is created.
        /// </summary>
        public bool TryInterpretTypedFinding(string entry, out int choiceIndex)
        {
            choiceIndex = -1;
            if ((Number != 1 && Number != 2) || string.IsNullOrWhiteSpace(entry) ||
                entry.Length > 64) return false;
            string normalized = entry.Trim().ToUpperInvariant();
            while (normalized.Contains("  "))
                normalized = normalized.Replace("  ", " ");
            bool supported = Number == 1 ?
                normalized == "SIXTH RAY" || normalized == "6TH RAY" ||
                normalized == "ADDED SIXTH RAY" || normalized == "EXTRA SIXTH RAY" :
                normalized == "STAR" || normalized == "STAR MOTIF" ||
                normalized == "STAR SYMBOL";
            if (!supported) return false;
            choiceIndex = correctChoice;
            return true;
        }

        internal bool Validate(out string error)
        {
            error = null;
            if (Number < 1 || Number > ChapterStoryGraph.LocationCount ||
                string.IsNullOrWhiteSpace(Evidence) ||
                string.IsNullOrWhiteSpace(Question) ||
                string.IsNullOrWhiteSpace(Explanation) ||
                correctChoice < 0 || correctChoice >= choices.Length || choices.Length != 4 ||
                evidenceFragments.Length != 2)
            {
                error = "Invalid dossier metadata.";
                return false;
            }

            var distinct = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (string choice in choices)
            {
                if (string.IsNullOrWhiteSpace(choice) || !distinct.Add(choice))
                {
                    error = "Duplicate or blank choice.";
                    return false;
                }
            }
            if (string.Equals(evidenceFragments[0], evidenceFragments[1], StringComparison.OrdinalIgnoreCase))
            {
                error = "Evidence fragments must be distinct.";
                return false;
            }
            foreach (string fragment in evidenceFragments)
            {
                if (string.IsNullOrWhiteSpace(fragment) || fragment.Length > 300)
                {
                    error = "Invalid evidence fragment.";
                    return false;
                }
            }
            return true;
        }
    }

    /// <summary>Ten playable text-and-art investigations; visual chapter scenes remain separately gated.</summary>
    public static class StoryDossierCatalog
    {
        private static readonly StoryDossierCase[] Cases =
        {
            new StoryDossierCase(1,
                "Lady Vey's damaged drawing and the stone threshold disagree. The missing corner suggests an unreliable original, but ultraviolet inspection can distinguish torn parchment from missing ink. The surviving five rays align with five original cuts on the arch; the stone bears six rays in all.",
                "The letter may be damaged. Which physical mark proves the seal was altered?",
                "Ultraviolet inspection rules out a lost sixth ink stroke. The added sixth stone ray contradicts the original drawing: the seal was altered after the letter was written.",
                2, new[] { "The original first ray", "The matching central circle", "The additional sixth ray", "The unaltered fifth ray" }, new[] { "Lady Vey's letter retains five original rays. A torn corner raises a doubt about whether the drawing was ever complete.", "The arch repeats those five rays, but another cut is visible. Its carved edge does not share the wear of the original five." }),
            new StoryDossierCase(2,
                "The ceremonial staircase repeats a three-mark cycle. The sixth position is missing. A replacement stone block has a smoother, darker grain than its neighbors, while a recent repaint makes several authentic stones appear equally dark.",
                "Which motif restores the repeating design on the substituted baluster?",
                "The repeating marks require a star at position six. The different stone grain, not its paint color, establishes that the baluster was replaced.",
                3, new[] { "Circle", "Diamond", "Crescent", "Star" }, new[] { "The original stair carving repeats circle, diamond and star. Its fifth surviving symbol is a diamond.", "The sixth block has different stone pores beneath its surface paint. A fresh coat makes several authentic blocks seem just as dark." }),
            new StoryDossierCase(3,
                "The garden calendar is circular: New Moon, Waxing Moon, Full Moon, Waning Moon, and back to New. A dated note says the lantern was last calibrated two positions after New Moon.",
                "Which phase must the lantern dial indicate?",
                "Two steps from New Moon are Waxing Moon and Full Moon; the required setting is Full Moon.",
                0, new[] { "Full Moon", "New Moon", "Waning Moon", "Waxing Moon" }, new[] { "The lunar dial cycles New, Waxing, Full, and Waning Moon.", "The calibration note requires exactly two positions after New Moon." }),
            new StoryDossierCase(4,
                "Four basin engravings show flowers with 2, 3, 5, and 8 petals. An inscription says each new count is the sum of the previous two counts.",
                "How many petals belong on the next engraving?",
                "The stated additive rule gives 5 + 8 = 13 petals.",
                1, new[] { "11 petals", "13 petals", "16 petals", "21 petals" }, new[] { "The engraved petals are counted as 2, 3, 5, and 8.", "The inscription requires each new count to equal the previous two combined." }),
            new StoryDossierCase(5,
                "The fountain has spouts numbered 1 through 4. The gardener wrote: spout 1 sounds first; spout 3 immediately follows 1; spout 4 sounds last; spout 2 precedes 4.",
                "Which sequence satisfies every constraint?",
                "The only compatible sequence is 1-3-2-4: first 1, immediately 3, then 2, with 4 last.",
                3, new[] { "1-2-3-4", "3-1-2-4", "1-3-4-2", "1-3-2-4" }, new[] { "The gardener places spout 1 first and spout 3 immediately after it.", "The final spout is 4, and spout 2 must occur before 4." }),
            new StoryDossierCase(6,
                "Three stone witnesses are marked A, B, and C. A points East, B points South, and C points West. The boat inscription reads: follow B, then A, then C.",
                "What three-direction route leads toward the crossing?",
                "B points South, A points East, and C points West: South-East-West.",
                1, new[] { "East-South-West", "South-East-West", "West-East-South", "South-West-East" }, new[] { "Witness A points East; B points South; C points West.", "The crossing inscription specifies the witness order B, A, C." }),
            new StoryDossierCase(7,
                "The glass panes show, from top to bottom: triangle, ring, three rays. The gallery mirror carriage swaps the top and bottom panes while keeping every engraved glyph upright.",
                "What order appears after the mirror carriage swaps the outer panes?",
                "Exchanging the first and third panes, while preserving the middle pane, gives three rays, ring, triangle.",
                0, new[] { "Three rays, ring, triangle", "Triangle, ring, three rays", "Ring, triangle, three rays", "Three rays, triangle, ring" }, new[] { "The stained glass reads triangle, ring, three rays from top to bottom.", "The mechanical mirror carriage exchanges the upper and lower panes; the middle remains fixed." }),
            new StoryDossierCase(8,
                "The family memorial records a witness dying in 1904. A signed portrait dated 1912 claims that this same witness sat for the painter in person that year.",
                "Which statement contradicts the memorial?",
                "The portrait's claim of a living sitting in 1912 is impossible if the witness died in 1904.",
                2, new[] { "The memorial is engraved", "The portrait has a signature", "The witness sat alive in 1912", "The portrait is displayed in a hall" }, new[] { "The family memorial records that the witness died in 1904.", "The signed portrait states the witness attended a live sitting in 1912." }),
            new StoryDossierCase(9,
                "The damaged epitaph reads R _ M E M B E R. Lady Vey's preserved note contains the complete word REMEMBER in the same position.",
                "Which letter restores the missing glyph?",
                "The surviving inscription and the independent letter both require the missing letter E.",
                1, new[] { "A", "E", "I", "O" }, new[] { "The epitaph is damaged: R _ M E M B E R.", "Lady Vey's independent letter spells the full word REMEMBER." }),
            new StoryDossierCase(10,
                "The meridian has four rings A, B, C and D. An archive note says: A precedes C; B follows immediately after A; and D must be the final ring.",
                "Which alignment satisfies every requirement?",
                "A-B-C-D places B immediately after A, keeps A before C, and places D last.",
                2, new[] { "B-A-C-D", "A-C-B-D", "A-B-C-D", "A-B-D-C" }, new[] { "Ring A must be placed before ring C, and ring B must immediately follow A.", "Ring D is required to occupy the final position." }),
        };
        private static readonly IReadOnlyList<StoryDossierCase> ReadOnlyCases = Array.AsReadOnly(Cases);
        public static IReadOnlyList<StoryDossierCase> All => ReadOnlyCases;

        public static StoryDossierCase Get(int number)
        {
            if (number < 1 || number > Cases.Length)
                throw new ArgumentOutOfRangeException(nameof(number));
            return Cases[number - 1];
        }

        public static bool Validate(out string error)
        {
            if (!ChapterStoryGraph.Validate(out error)) return false;
            if (Cases.Length != ChapterStoryGraph.LocationCount)
            {
                error = "Dossier count differs from authored locations.";
                return false;
            }
            for (int index = 0; index < Cases.Length; index++)
            {
                if (Cases[index].Number != index + 1 || !Cases[index].Validate(out error) ||
                    !StoryDeductionProof.VerifyCatalogCase(Cases[index], out error))
                {
                    error = "Case " + (index + 1) + ": " + error;
                    return false;
                }
            }
            error = null;
            return true;
        }
    }
}
