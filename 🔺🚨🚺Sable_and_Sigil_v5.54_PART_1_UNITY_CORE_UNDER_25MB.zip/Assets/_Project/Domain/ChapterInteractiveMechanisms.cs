using System;

namespace TheOrderRoom.Domain
{
    public enum PhysicalPlacementResult
    {
        Invalid = 0,
        EvidenceRequired = 1,
        MissedTarget = 2,
        Placed = 3,
        AlreadyPlaced = 4
    }

    /// <summary>
    /// An inspected tracing must physically be placed over the altered crest before
    /// the player can compare engraved rays. The UI owns pointer coordinates; this
    /// state only validates evidence and a confirmed geometric hit.
    /// </summary>
    public sealed class CrestTracingState
    {
        private bool placed;
        private int attempts;

        public bool IsPlaced => placed;
        public int Attempts => attempts;

        public PhysicalPlacementResult TryPlace(bool targetContainsRelease,
            bool firstEvidenceInspected, bool secondEvidenceInspected)
        {
            if (placed) return PhysicalPlacementResult.AlreadyPlaced;
            if (!firstEvidenceInspected || !secondEvidenceInspected)
                return PhysicalPlacementResult.EvidenceRequired;
            if (attempts < int.MaxValue) attempts++;
            if (!targetContainsRelease) return PhysicalPlacementResult.MissedTarget;
            placed = true;
            return PhysicalPlacementResult.Placed;
        }

        public void Reset()
        {
            placed = false;
            attempts = 0;
        }
    }

    public enum LunarPhase
    {
        NewMoon = 0,
        WaxingMoon = 1,
        FullMoon = 2,
        WaningMoon = 3
    }

    /// <summary>
    /// Discrete, reversible physical dial. Each quarter-turn changes the indicator,
    /// not the authoritative case result. Only the existing chapter-two puzzle can
    /// confirm a completed calibration after both clues have been examined.
    /// </summary>
    public sealed class LunarPhaseDial
    {
        private int phase;
        private int turns;
        public LunarPhase Phase => (LunarPhase)phase;
        public int Turns => turns;

        public bool TryTurn(int quarterTurns)
        {
            if (quarterTurns != -1 && quarterTurns != 1) return false;
            phase = (phase + quarterTurns + 4) % 4;
            if (turns < int.MaxValue) turns++;
            return true;
        }

        public int CurrentChoiceIndex
        {
            get
            {
                switch (Phase)
                {
                    case LunarPhase.NewMoon: return 1;
                    case LunarPhase.WaxingMoon: return 3;
                    case LunarPhase.FullMoon: return 0;
                    case LunarPhase.WaningMoon: return 2;
                    default: throw new InvalidOperationException("Invalid lunar dial phase.");
                }
            }
        }

        public static string GetPhaseLabel(LunarPhase selected)
        {
            switch (selected)
            {
                case LunarPhase.NewMoon: return "NEW MOON";
                case LunarPhase.WaxingMoon: return "WAXING MOON";
                case LunarPhase.FullMoon: return "FULL MOON";
                case LunarPhase.WaningMoon: return "WANING MOON";
                default: throw new ArgumentOutOfRangeException(nameof(selected));
            }
        }

        public void Reset()
        {
            phase = 0;
            turns = 0;
        }
    }
}
