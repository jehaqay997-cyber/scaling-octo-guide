using System;

namespace TheOrderRoom.Domain
{
    /// <summary>
    /// Transient, case-scoped evidence inspection. Durable completion remains exclusively
    /// owned by StoryDossierSession. Switching cases creates a fresh inspection state.
    /// </summary>
    public sealed class StoryCaseInspection
    {
        private readonly StoryDossierCase dossier;
        private readonly bool[] inspected;
        private readonly bool[] matchedBoardEvidence = new bool[2];
        private bool materialCorroborated;
        private int rejectedBoardAttempts;

        public int CaseNumber => dossier.Number;
        public int EvidenceCount => dossier.EvidenceFragments.Count;
        public int InspectedCount { get; private set; }
        public int SelectedEvidenceIndex { get; private set; } = -1;
        public bool CanDeduce => InspectedCount == EvidenceCount;
        public bool IsInteractiveBoardCase => CaseNumber == 1 || CaseNumber == 2;
        public bool HasPairedEvidence => matchedBoardEvidence[0] && matchedBoardEvidence[1];
        public bool HasCorroboratedFinding => IsInteractiveBoardCase &&
            HasPairedEvidence && materialCorroborated;
        public bool HasInspectedMaterial => materialCorroborated;
        public int RejectedBoardAttempts => rejectedBoardAttempts;

        public StoryCaseInspection(int caseNumber)
        {
            dossier = StoryDossierCatalog.Get(caseNumber);
            inspected = new bool[dossier.EvidenceFragments.Count];
            if (inspected.Length != 2)
                throw new InvalidOperationException("A case must have exactly two evidence fragments.");
        }

        /// <summary>
        /// Reuses the two inspected story fragments as physical dossier cards.
        /// The false third card is deliberately non-committable: it is a rumor,
        /// not an independently inspected piece of evidence.
        /// </summary>
        public bool TryPlaceOnBoard(int evidenceIndex, int targetIndex)
        {
            if (!IsInteractiveBoardCase || !CanDeduce ||
                targetIndex < 0 || targetIndex >= matchedBoardEvidence.Length ||
                matchedBoardEvidence[targetIndex]) return false;
            if (evidenceIndex != targetIndex || !HasInspected(evidenceIndex))
            {
                RegisterBoardError();
                return false;
            }
            matchedBoardEvidence[targetIndex] = true;
            return true;
        }

        public bool TryExaminePhysicalContradiction()
        {
            if (!IsInteractiveBoardCase || !HasPairedEvidence || materialCorroborated)
                return false;
            materialCorroborated = true;
            return true;
        }

        public void RegisterBoardError()
        {
            if (rejectedBoardAttempts < int.MaxValue) rejectedBoardAttempts++;
        }

        public bool HasPlacedOnBoard(int slotIndex)
        {
            return slotIndex >= 0 && slotIndex < matchedBoardEvidence.Length &&
                matchedBoardEvidence[slotIndex];
        }

        public bool HasInspected(int evidenceIndex)
        {
            return evidenceIndex >= 0 && evidenceIndex < inspected.Length && inspected[evidenceIndex];
        }

        public bool TryInspect(int evidenceIndex, out string transcript)
        {
            transcript = null;
            if (evidenceIndex < 0 || evidenceIndex >= inspected.Length)
                return false;
            if (!inspected[evidenceIndex])
            {
                inspected[evidenceIndex] = true;
                InspectedCount++;
            }
            SelectedEvidenceIndex = evidenceIndex;
            transcript = dossier.EvidenceFragments[evidenceIndex];
            return true;
        }
    }
}
