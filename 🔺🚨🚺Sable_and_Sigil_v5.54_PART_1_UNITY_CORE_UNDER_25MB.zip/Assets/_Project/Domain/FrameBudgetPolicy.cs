using System;

namespace TheOrderRoom.Domain
{
    /// <summary>Pure decision policy for user-visible refresh rates. All values are in milliseconds.</summary>
    public static class FrameBudgetPolicy
    {
        public const int Low = 24;
        public const int Balanced = 30;
        public const int High = 60;

        public static int InitialTarget(bool mobile) => mobile ? Balanced : High;

        public static int Choose(int current, double meanFrameMilliseconds, double batteryLevel,
            bool batteryDischarging, int consecutiveSlowWindows)
        {
            return Choose(current, meanFrameMilliseconds, batteryLevel,
                batteryDischarging, consecutiveSlowWindows, current);
        }

        /// <summary>
        /// Estimate display-paced rendering without assuming that the requested rate
        /// is a divisor of the screen refresh rate. Unknown rates retain the request.
        /// </summary>
        public static double EffectiveMobileFramesPerSecond(int desiredFps, double refreshHertz)
        {
            if (desiredFps <= 0) throw new ArgumentOutOfRangeException(nameof(desiredFps));
            if (double.IsNaN(refreshHertz) || double.IsInfinity(refreshHertz) ||
                refreshHertz < 1.0 || refreshHertz > 1000.0) return desiredFps;

            // Normalize 59.94/89.91/119.88 Hz displays to the nearest nominal
            // refresh family before determining the integer VBlank interval.
            double nominalHertz = Math.Round(refreshHertz, MidpointRounding.AwayFromZero);
            int interval = Math.Max(1, (int)Math.Ceiling(nominalHertz / desiredFps));
            return refreshHertz / interval;
        }

        /// <summary>
        /// Request the smallest integer rate that allows Unity to select the
        /// intended VBlank interval, including fractional display frequencies.
        /// </summary>
        public static int MobileFrameRequest(int desiredFps, double refreshHertz)
        {
            double effective = EffectiveMobileFramesPerSecond(desiredFps, refreshHertz);
            return Math.Max(1, (int)Math.Ceiling(effective));
        }

        public static bool IsFrameOverBudget(double meanFrameMilliseconds, double effectiveFps)
        {
            if (double.IsNaN(meanFrameMilliseconds) || double.IsInfinity(meanFrameMilliseconds) ||
                meanFrameMilliseconds < 0) throw new ArgumentOutOfRangeException(nameof(meanFrameMilliseconds));
            if (double.IsNaN(effectiveFps) || double.IsInfinity(effectiveFps) || effectiveFps <= 0)
                throw new ArgumentOutOfRangeException(nameof(effectiveFps));
            return meanFrameMilliseconds > 1000.0 / effectiveFps * 1.25;
        }

        /// <summary>
        /// Uses effective display-paced FPS to avoid demoting a perfectly stable
        /// 45 FPS cadence on a 90 Hz panel when the logical target is 60 FPS.
        /// </summary>
        public static int Choose(int current, double meanFrameMilliseconds, double batteryLevel,
            bool batteryDischarging, int consecutiveSlowWindows, double effectiveFps)
        {
            if (current != Low && current != Balanced && current != High)
                throw new ArgumentOutOfRangeException(nameof(current));
            if (double.IsNaN(meanFrameMilliseconds) || double.IsInfinity(meanFrameMilliseconds) ||
                meanFrameMilliseconds < 0)
                throw new ArgumentOutOfRangeException(nameof(meanFrameMilliseconds));
            if (consecutiveSlowWindows < 0) throw new ArgumentOutOfRangeException(nameof(consecutiveSlowWindows));
            if (double.IsNaN(effectiveFps) || double.IsInfinity(effectiveFps) || effectiveFps <= 0)
                throw new ArgumentOutOfRangeException(nameof(effectiveFps));

            // -1 is the platform's unknown battery reading. It must not be interpreted as empty.
            bool knownBattery = batteryLevel >= 0 && batteryLevel <= 1 &&
                !double.IsNaN(batteryLevel) && !double.IsInfinity(batteryLevel);
            if (batteryDischarging && knownBattery && batteryLevel <= 0.15) return Low;
            if (consecutiveSlowWindows < 3) return current;
            // Require a sustained >25% overrun of the ACTUAL device-paced rate.
            if (current == High && IsFrameOverBudget(meanFrameMilliseconds, effectiveFps)) return Balanced;
            if (current == Balanced && IsFrameOverBudget(meanFrameMilliseconds, effectiveFps)) return Low;
            // No automatic promotion: a throttled target cannot measure headroom for 60fps.
            return current;
        }
    }
}
