using System;
using TheOrderRoom.Domain;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Chapter artwork and interactive case-file navigation.
    /// Chapter One owns the authored narrative scene. Chapters Two through Four
    /// enter their connected, procedurally built case investigations. These
    /// are source-backed gameplay paths, not claims of final authored 3D art.
    /// </summary>
    public sealed class ChapterGalleryView : MonoBehaviour
    {
        private static readonly string[] ChapterNames =
        {
            "The House of the Last Star", "The Veiled Conservatory",
            "The Ashen Gallery", "The Hollow Meridian"
        };
        private static readonly string[] ChapterDescriptions =
        {
            "Find Lady Vey's last letter, examine the celestial lens, and unseal the forgotten observatory.",
            "Beyond the estate, the glass gardens keep a botanical star map beneath living vines.",
            "An ash-filled portrait hall preserves faces that should never have been painted.",
            "Across the cloud sea, the last meridian is aligned with a constellation no one remembers."
        };
        private static readonly string[] LocationNames =
        {
            "The Threshold of Vey", "The Spiral of Testimony", "The Lantern Ascent",
            "The Rose Pavilion", "The Fountain of Echoes", "The Silent Crossing",
            "The Glass Testament", "The Hall of False Light", "The Weeping Witness",
            "The Meridian Rotunda"
        };
        private static readonly string[] LocationDescriptions =
        {
            "A sealed arch bears the lost-star crest. Compare the seal with Lady Vey's last letter.",
            "One section of the ceremonial staircase has been replaced. Follow its repeating pattern.",
            "A lantern along the garden approach remains lit at the wrong hour.",
            "An overgrown pavilion surrounds a basin engraved with a forgotten flower sequence.",
            "Four fountain spouts once sounded the notes of the gardener's lunar calendar.",
            "A boat and three statues conceal the direction to a hidden shore.",
            "Colored windowpanes form a sequence visible only from the correct angle.",
            "The vaulted gallery contradicts a family memorial hidden behind the light.",
            "A damaged epitaph beneath the stone witness conceals one erased word.",
            "The circular archive holds a sphere aligned with a star absent from every chart."
        };
        private static readonly int[] LocationChapters = { 1, 1, 2, 2, 2, 2, 3, 3, 3, 4 };
        public const int LocationCount = 10;
        private static readonly Color Parchment = new Color(.91f, .84f, .69f);
        private static readonly Color AntiqueBrass = new Color(.83f, .69f, .46f);
        private GameObject galleryCanvas;
        private RawImage artwork;
        private Text heading;
        private Text description;
        private Text availability;
        private Button enterButton;
        private Button caseFileButton;
        private Button chapterCasesButton;
        private Button recoveryButton;
        private Button finaleButton;
        private GameObject finalePanel;
        private RawImage finaleArtwork;
        private Text finaleHeading;
        private Text finaleText;
        private Text finaleProgress;
        private Button finalePreviousButton;
        private Button finaleNextButton;
        private int finalePage;
        private GameObject privacyPanel;
        private Button privacyAudioButton;
        private Button privacyEffectsButton;
        private Button privacyAmbienceButton;
        private Text privacySoundSummary;
        private Text privacyEffectsLevel;
        private Text privacyAmbienceLevel;
        private Text privacyStatus;
        private string privacyNotice = string.Empty;
        private Button exploreWorldButton;
        private ChapterWorldExplorer worldExplorer;
        private StoryDossierSession dossierSession;
        private StoryDossierView dossierView;
        private OrderAudioFeedback audioFeedback;
        private Button previousSceneButton;
        private Button nextSceneButton;
        private Button sceneAtlasButton;
        private Button sceneHintButton;
        private int sceneHintTier;
        private Text enterCaption;
        private readonly Texture2D[] chapterTextures = new Texture2D[4];
        private int activeChapterTextureIndex = -1;
        private Texture2D activeLocationTexture;
        private int activeLocationTextureIndex = -1;
        private RectTransform artworkRect;
        private RectTransform safeAreaRoot;
        private RectTransform layoutRoot;
        private CanvasScaler galleryScaler;
        private int lastScreenWidth = -1;
        private int lastScreenHeight = -1;
        private Rect lastSafeArea;
        private bool locationMode;
        private int locationIndex;
        private int selectedIndex;
        private Camera hiddenWorldCamera;
        private bool worldCameraWasEnabled;
        private long activeWorldRevision = -1;
        private bool sceneTransitionInProgress;

        public bool IsOpen => galleryCanvas != null && galleryCanvas.activeSelf ||
            worldExplorer != null && worldExplorer.IsOpen;
        public int SelectedChapter => selectedIndex + 1;
        public bool IsPrivacyPanelOpen => privacyPanel != null && privacyPanel.activeSelf;
        public bool IsFinaleOpen => finalePanel != null && finalePanel.activeSelf;
        public int ResidentChapterArtworkCount
        {
            get
            {
                int count = 0;
                for (int index = 0; index < chapterTextures.Length; index++)
                    if (chapterTextures[index] != null) count++;
                return count;
            }
        }
        public const int ChapterCount = 4;

        public static int GetChapterForLocation(int locationNumber)
        {
            if (locationNumber < 1 || locationNumber > LocationCount)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            return LocationChapters[locationNumber - 1];
        }

        /// <summary>
        /// Every unresolved case requires an authored physical mechanism.
        /// Unfinished cases require their physical world mechanism; completed
        /// dossiers remain reviewable without re-solving the mechanism.
        /// </summary>
        public static bool CanOpenDossierFromAtlas(int locationNumber, bool completed)
        {
            GetChapterForLocation(locationNumber);
            return completed;
        }

        public static bool ValidateContentCatalog(out string error)
        {
            error = null;
            if (ChapterNames.Length != ChapterCount || ChapterDescriptions.Length != ChapterCount ||
                LocationNames.Length != LocationCount || LocationDescriptions.Length != LocationCount ||
                LocationChapters.Length != LocationCount)
            {
                error = "Chapter and location catalog lengths do not agree.";
                return false;
            }
            var chaptersWithLocations = new bool[ChapterCount];
            var uniqueChapterNames = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            var uniqueLocationNames = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            int previousChapter = 1;
            for (int chapter = 0; chapter < ChapterCount; chapter++)
            {
                if (string.IsNullOrWhiteSpace(ChapterNames[chapter]) ||
                    string.IsNullOrWhiteSpace(ChapterDescriptions[chapter]) ||
                    !uniqueChapterNames.Add(ChapterNames[chapter]))
                {
                    error = "Missing or duplicate chapter content at index " + chapter;
                    return false;
                }
            }
            for (int location = 0; location < LocationCount; location++)
            {
                int chapterNumber = LocationChapters[location];
                if (chapterNumber < 1 || chapterNumber > ChapterCount || chapterNumber < previousChapter ||
                    string.IsNullOrWhiteSpace(LocationNames[location]) ||
                    string.IsNullOrWhiteSpace(LocationDescriptions[location]) ||
                    !uniqueLocationNames.Add(LocationNames[location]))
                {
                    error = "Invalid location mapping or content at index " + location;
                    return false;
                }
                previousChapter = chapterNumber;
                chaptersWithLocations[chapterNumber - 1] = true;
            }
            for (int chapter = 0; chapter < chaptersWithLocations.Length; chapter++)
            {
                if (chaptersWithLocations[chapter]) continue;
                error = "Chapter " + (chapter + 1) + " has no mapped locations.";
                return false;
            }
            if (!ChapterStoryGraph.Validate(out error)) return false;
            for (int location = 0; location < LocationCount; location++)
            {
                StoryLocation authored = ChapterStoryGraph.GetLocation(location + 1);
                if (authored.Chapter == LocationChapters[location] &&
                    string.Equals(authored.Title, LocationNames[location], StringComparison.Ordinal)) continue;
                error = "Gallery and domain scene catalog have diverged at " + (location + 1);
                return false;
            }
            return true;
        }

        public void Show()
        {
            activeWorldRevision = -1;
            if (worldExplorer != null) worldExplorer.Close();
            if (galleryCanvas == null) Build();
            if (dossierView != null) dossierView.Hide();
            CloseFinale();
            ClosePrivacyPanel();
            if (dossierSession != null) dossierSession.TryReload(out _);
            selectedIndex = 0;
            locationMode = false;
            sceneHintTier = 0;
            Refresh();
            galleryCanvas.SetActive(true);
            UpdateSafeAreaLayout();
            SuspendWorldCamera();
        }

        public void Close()
        {
            CloseFinale();
            activeWorldRevision = -1;
            if (worldExplorer != null) worldExplorer.Close();
            if (dossierView != null) dossierView.Hide();
            ClosePrivacyPanel();
            if (galleryCanvas != null) galleryCanvas.SetActive(false);
            RestoreWorldCamera();
            ReleaseLocationTexture();
            ReleaseChapterTexture();
        }

        private void SuspendWorldCamera()
        {
            if (hiddenWorldCamera != null) return;
            // Only the opaque ScreenSpaceOverlay gallery is visible at this point.
            // Preserve the previous camera state; never enable a previously disabled camera.
            var camera = Camera.main;
            if (camera == null) return;
            hiddenWorldCamera = camera;
            worldCameraWasEnabled = camera.enabled;
            if (worldCameraWasEnabled) camera.enabled = false;
        }

        private void RestoreWorldCamera()
        {
            if (hiddenWorldCamera != null)
            {
                if (worldCameraWasEnabled) hiddenWorldCamera.enabled = true;
                hiddenWorldCamera = null;
            }
            worldCameraWasEnabled = false;
        }

        private void OnDisable()
        {
            CloseFinale();
            if (worldExplorer != null) worldExplorer.Close();
            if (dossierView != null) dossierView.Hide();
            ClosePrivacyPanel();
            if (galleryCanvas != null) galleryCanvas.SetActive(false);
            RestoreWorldCamera();
            ReleaseLocationTexture();
            ReleaseChapterTexture();
        }

        private void LateUpdate()
        {
            if (galleryCanvas != null && galleryCanvas.activeSelf)
                UpdateSafeAreaLayout();
        }

        private void UpdateSafeAreaLayout()
        {
            if (safeAreaRoot == null || layoutRoot == null || galleryScaler == null) return;
            int width = Screen.width;
            int height = Screen.height;
            if (width <= 0 || height <= 0) return;
            Rect safe = Screen.safeArea;
            safe.xMin = Mathf.Clamp(safe.xMin, 0f, width);
            safe.xMax = Mathf.Clamp(safe.xMax, 0f, width);
            safe.yMin = Mathf.Clamp(safe.yMin, 0f, height);
            safe.yMax = Mathf.Clamp(safe.yMax, 0f, height);
            if (safe.width <= 0f || safe.height <= 0f) safe = new Rect(0f, 0f, width, height);
            if (width == lastScreenWidth && height == lastScreenHeight && safe == lastSafeArea) return;
            lastScreenWidth = width;
            lastScreenHeight = height;
            lastSafeArea = safe;
            safeAreaRoot.anchorMin = new Vector2(safe.xMin / width, safe.yMin / height);
            safeAreaRoot.anchorMax = new Vector2(safe.xMax / width, safe.yMax / height);
            safeAreaRoot.offsetMin = Vector2.zero;
            safeAreaRoot.offsetMax = Vector2.zero;
            // Expand never crops the virtual canvas; uniformly shrink the fixed layout
            // only if safe-area insets leave less than the 1600x900 design bounds.
            float virtualScale = Mathf.Min(width / 1600f, height / 900f);
            float safeLogicalWidth = safe.width / Mathf.Max(virtualScale, .0001f);
            float safeLogicalHeight = safe.height / Mathf.Max(virtualScale, .0001f);
            float fit = Mathf.Min(1f, safeLogicalWidth / 1600f, safeLogicalHeight / 900f);
            layoutRoot.localScale = Vector3.one * Mathf.Max(.01f, fit);
        }

        private void ReleaseLocationTexture()
        {
            if (activeLocationTexture == null) return;
            if (artwork != null && artwork.texture == activeLocationTexture)
                artwork.texture = null;
            Resources.UnloadAsset(activeLocationTexture);
            activeLocationTexture = null;
            activeLocationTextureIndex = -1;
        }

        private void ReleaseChapterTexture()
        {
            if (activeChapterTextureIndex < 0) return;
            Texture2D previous = chapterTextures[activeChapterTextureIndex];
            if (artwork != null && artwork.texture == previous) artwork.texture = null;
            chapterTextures[activeChapterTextureIndex] = null;
            activeChapterTextureIndex = -1;
            if (previous != null) Resources.UnloadAsset(previous);
        }

        private Texture2D GetChapterTexture(int index)
        {
            if (index < 0 || index >= ChapterCount)
                throw new ArgumentOutOfRangeException(nameof(index));
            if (activeChapterTextureIndex == index && chapterTextures[index] != null)
                return chapterTextures[index];
            // Acquire before releasing the old image: a failed load must not leave
            // a stale native texture referenced by RawImage.
            Texture2D next = Resources.Load<Texture2D>("ChapterArt/Chapter_" + (index + 1).ToString("00"));
            if (next == null)
                throw new InvalidOperationException("Missing required chapter artwork: " + (index + 1));
            ReleaseChapterTexture();
            chapterTextures[index] = next;
            activeChapterTextureIndex = index;
            return next;
        }

        public void SelectChapter(int number)
        {
            if (IsFinaleOpen) return;
            if (sceneTransitionInProgress) return;
            if (dossierView != null && dossierView.IsOpen) return;
            if (IsPrivacyPanelOpen) return;
            if (number < 1 || number > ChapterCount)
                throw new ArgumentOutOfRangeException(nameof(number));
            if (galleryCanvas == null) Build();
            selectedIndex = number - 1;
            locationMode = false;
            sceneHintTier = 0;
            Refresh();
        }

        private void Build()
        {
            if (!ValidateContentCatalog(out string catalogError))
                throw new InvalidOperationException(catalogError);
            if (!StoryDossierCatalog.Validate(out string dossierError))
                throw new InvalidOperationException(dossierError);
            dossierSession = new StoryDossierSession(new PlayerPrefsDossierStorage());
            galleryCanvas = new GameObject("Chapter Gallery", typeof(RectTransform), typeof(Canvas),
                typeof(CanvasScaler), typeof(GraphicRaycaster));
            galleryCanvas.transform.SetParent(transform, false);
            var canvas = galleryCanvas.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 120;
            var scaler = galleryCanvas.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1600f, 900f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
            galleryScaler = scaler;
            RectTransform canvasRoot = galleryCanvas.GetComponent<RectTransform>();
            // Modal shield must cover the entire physical screen, including unsafe edges.
            // Otherwise taps outside the safe layout could reach the 3D puzzle behind it.
            var shield = new GameObject("Gallery Input Shield", typeof(RectTransform), typeof(Image));
            var shieldRect = shield.GetComponent<RectTransform>();
            shieldRect.SetParent(canvasRoot, false);
            shieldRect.anchorMin = Vector2.zero;
            shieldRect.anchorMax = Vector2.one;
            shieldRect.offsetMin = shieldRect.offsetMax = Vector2.zero;
            var shieldImage = shield.GetComponent<Image>();
            shieldImage.color = new Color(.018f, .025f, .041f, 1f);
            shieldImage.raycastTarget = true;
            var safeAreaObject = new GameObject("Gallery Safe Area", typeof(RectTransform));
            safeAreaRoot = safeAreaObject.GetComponent<RectTransform>();
            safeAreaRoot.SetParent(canvasRoot, false);
            safeAreaRoot.anchorMin = Vector2.zero;
            safeAreaRoot.anchorMax = Vector2.one;
            safeAreaRoot.offsetMin = safeAreaRoot.offsetMax = Vector2.zero;
            var layoutObject = new GameObject("Gallery Layout", typeof(RectTransform));
            layoutRoot = layoutObject.GetComponent<RectTransform>();
            layoutRoot.SetParent(safeAreaRoot, false);
            layoutRoot.anchorMin = layoutRoot.anchorMax = new Vector2(.5f, .5f);
            layoutRoot.anchoredPosition = Vector2.zero;
            layoutRoot.sizeDelta = new Vector2(1600f, 900f);
            RectTransform root = layoutRoot;
            lastScreenWidth = -1;
            UpdateSafeAreaLayout();

            var backdrop = new GameObject("Gallery Backdrop", typeof(RectTransform), typeof(Image));
            var rect = backdrop.GetComponent<RectTransform>();
            rect.SetParent(root, false);
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = rect.offsetMax = Vector2.zero;
            backdrop.GetComponent<Image>().color = new Color(.018f, .025f, .041f, .99f);

            TextLabel("Gallery Header", root, "SABLE & SIGIL  |  CHAPTERS", new Vector2(0f, 367f),
                new Vector2(1350f, 75f), 34);

            var artObject = new GameObject("Selected Chapter Artwork", typeof(RectTransform), typeof(RawImage));
            artObject.transform.SetParent(root, false);
            var artRect = artObject.GetComponent<RectTransform>();
            artworkRect = artRect;
            artRect.anchorMin = artRect.anchorMax = new Vector2(.5f, .5f);
            artRect.anchoredPosition = new Vector2(-215f, 31f);
            artRect.sizeDelta = new Vector2(880f, 495f);
            artwork = artObject.GetComponent<RawImage>();
            artwork.color = Color.white;
            artwork.raycastTarget = false;

            heading = TextLabel("Selected Chapter Heading", root, "", new Vector2(530f, 206f),
                new Vector2(420f, 124f), 27);
            description = TextLabel("Selected Chapter Description", root, "", new Vector2(530f, 41f),
                new Vector2(415f, 194f), 21);
            availability = TextLabel("Selected Chapter Availability", root, "", new Vector2(530f, -105f),
                new Vector2(430f, 68f), 19);

            for (int i = 0; i < ChapterCount; i++)
            {
                int chapterNumber = i + 1;
                MakeButton(root, "Chapter " + chapterNumber, new Vector2(-568f + i * 275f, -304f),
                    () => SelectChapter(chapterNumber));
            }
            enterButton = MakeButton(root, "ENTER CHAPTER I", new Vector2(552f, -265f), EnterSelectedChapter);
            enterCaption = enterButton.GetComponentInChildren<Text>();
            caseFileButton = MakeButton(root, "OPEN CASE FILE", new Vector2(552f, -245f), OpenDossier);
            caseFileButton.gameObject.SetActive(false);
            exploreWorldButton = MakeButton(root, "EXPLORE 3D", new Vector2(552f, -177f), OpenWorld);
            exploreWorldButton.gameObject.SetActive(false);
            chapterCasesButton = MakeButton(root, "CHAPTER CASES", new Vector2(552f, -188f), OpenChapterCases);
            finaleButton = MakeButton(root, "READ FINAL RECORD", new Vector2(-274f, -387f), OpenFinale);
            finaleButton.gameObject.SetActive(false);
            recoveryButton = MakeButton(root, "RETRY SAVE RECOVERY", new Vector2(552f, -188f), RetryCaseSave);
            MakeButton(root, "PRIVACY & AUDIO", new Vector2(-566f, -387f), OpenPrivacyPanel);
            sceneAtlasButton = MakeButton(root, "SCENE ATLAS", new Vector2(552f, 316f), () =>
            {
                if (IsFinaleOpen || IsPrivacyPanelOpen || dossierView != null && dossierView.IsOpen) return;
                locationMode = !locationMode;
                sceneHintTier = 0;
                Refresh();
            });
            sceneHintButton = MakeButton(root, "SCENE HINT", new Vector2(-560f, 316f), () =>
            {
                if (!locationMode || IsFinaleOpen || IsPrivacyPanelOpen || !CanRevealSceneHint()) return;
                sceneHintTier = ChapterHintDisclosure.RevealNext(sceneHintTier, true);
                Refresh();
            });
            previousSceneButton = MakeButton(root, "PREVIOUS SCENE", new Vector2(-575f, -221f),
                () => NavigateLocation(-1));
            nextSceneButton = MakeButton(root, "NEXT SCENE", new Vector2(145f, -221f),
                () => NavigateLocation(1));
            MakeButton(root, "BACK TO GAME", new Vector2(552f, -340f), ExitGalleryToGame);
            dossierView = GetComponent<StoryDossierView>();
            if (dossierView == null) dossierView = gameObject.AddComponent<StoryDossierView>();
            dossierView.Initialize(layoutRoot, dossierSession, Refresh);
            worldExplorer = GetComponent<ChapterWorldExplorer>();
            if (worldExplorer == null) worldExplorer = gameObject.AddComponent<ChapterWorldExplorer>();
            audioFeedback = GetComponent<OrderAudioFeedback>();
            if (audioFeedback == null) audioFeedback = gameObject.AddComponent<OrderAudioFeedback>();
            dossierView.ConfigureAudio(audioFeedback);
            worldExplorer.ConfigureAudio(audioFeedback);
            BuildPrivacyPanel(root);
            BuildFinalePanel(root);
            galleryCanvas.SetActive(false);
        }

        private bool CanRevealSceneHint()
        {
            return locationMode && dossierSession != null && dossierSession.IsReady &&
                dossierSession.CanInvestigate(locationIndex + 1);
        }

        private void BuildFinalePanel(Transform parent)
        {
            var panel = new GameObject("Final Record Modal", typeof(RectTransform), typeof(Image));
            finalePanel = panel;
            RectTransform root = panel.GetComponent<RectTransform>();
            root.SetParent(parent, false);
            root.anchorMin = Vector2.zero;
            root.anchorMax = Vector2.one;
            root.offsetMin = root.offsetMax = Vector2.zero;
            Image shield = panel.GetComponent<Image>();
            shield.color = new Color(.013f, .021f, .034f, 1f);
            shield.raycastTarget = true;

            TextLabel("Finale Banner", root, "SABLE & SIGIL  |  THE UNEDITED RECORD",
                new Vector2(0f, 362f), new Vector2(1320f, 66f), 32);
            finaleProgress = TextLabel("Finale Proof Count", root, string.Empty,
                new Vector2(0f, 296f), new Vector2(1210f, 46f), 19);
            finaleHeading = TextLabel("Finale Chapter Heading", root, string.Empty,
                new Vector2(342f, 209f), new Vector2(735f, 74f), 26);
            finaleText = TextLabel("Finale Narrative", root, string.Empty,
                new Vector2(342f, -20f), new Vector2(735f, 370f), 22);
            finaleText.alignment = TextAnchor.MiddleLeft;
            finaleText.resizeTextForBestFit = true;
            finaleText.resizeTextMinSize = 16;
            finaleText.resizeTextMaxSize = 22;

            var art = new GameObject("Finale Evidence Artwork", typeof(RectTransform), typeof(RawImage));
            RectTransform artRect = art.GetComponent<RectTransform>();
            artRect.SetParent(root, false);
            artRect.anchorMin = artRect.anchorMax = new Vector2(.5f, .5f);
            artRect.anchoredPosition = new Vector2(-437f, 0f);
            artRect.sizeDelta = new Vector2(665f, 374f);
            finaleArtwork = art.GetComponent<RawImage>();
            finaleArtwork.color = new Color(.90f, .87f, .80f, 1f);
            finaleArtwork.raycastTarget = false;

            finalePreviousButton = MakeButton(root, "PREVIOUS PAGE", new Vector2(-465f, -334f),
                () => SetFinalePage(StoryFinalePolicy.PreviousPage(finalePage)));
            finaleNextButton = MakeButton(root, "NEXT PAGE", new Vector2(-140f, -334f),
                () => SetFinalePage(StoryFinalePolicy.NextPage(finalePage)));
            MakeButton(root, "RETURN TO CHAPTERS", new Vector2(465f, -334f), CloseFinale);
            panel.SetActive(false);
        }

        public void OpenFinale()
        {
            if (galleryCanvas == null || !galleryCanvas.activeSelf || locationMode ||
                IsPrivacyPanelOpen || IsFinaleOpen ||
                dossierView != null && dossierView.IsOpen ||
                worldExplorer != null && worldExplorer.IsOpen ||
                dossierSession == null || !dossierSession.IsFinaleUnlocked ||
                selectedIndex != ChapterCount - 1 || finalePanel == null) return;
            // A visible button is not durable authorization. External changes or a
            // failed flush can invalidate a checkpoint after the last UI refresh.
            if (!dossierSession.TryReload(out _))
            {
                Refresh();
                return;
            }
            if (!dossierSession.IsFinaleUnlocked)
            {
                Refresh();
                return;
            }
            finalePage = 0;
            finaleArtwork.texture = artwork == null ? null : artwork.texture;
            RefreshFinale();
            finalePanel.SetActive(true);
            finalePanel.transform.SetAsLastSibling();
        }

        private void SetFinalePage(int page)
        {
            if (!IsFinaleOpen || dossierSession == null || !dossierSession.IsFinaleUnlocked ||
                !dossierSession.TryReload(out _) || !dossierSession.IsFinaleUnlocked)
            {
                CloseFinale();
                Refresh();
                return;
            }
            StoryFinalePolicy.ValidatePage(page);
            finalePage = page;
            RefreshFinale();
        }

        private void RefreshFinale()
        {
            if (finaleHeading == null || finaleText == null || finaleProgress == null) return;
            finaleHeading.text = CampaignNarrative.FinaleHeading(finalePage);
            finaleText.text = CampaignNarrative.FinaleText(finalePage);
            finaleProgress.text = "10 / 10 VERIFIED CASE RECORDS   |   PAGE " +
                (finalePage + 1) + " / " + StoryFinalePolicy.PageCount +
                "   |   ENDING IS READ-ONLY";
            if (finalePreviousButton != null)
                finalePreviousButton.interactable = finalePage > 0;
            if (finaleNextButton != null)
            {
                finaleNextButton.interactable = finalePage < StoryFinalePolicy.PageCount - 1;
                Text caption = finaleNextButton.GetComponentInChildren<Text>();
                if (caption != null)
                    caption.text = finalePage == StoryFinalePolicy.PageCount - 1 ?
                        "RECORD COMPLETE" : "NEXT PAGE";
            }
        }

        public void CloseFinale()
        {
            if (finaleArtwork != null) finaleArtwork.texture = null;
            if (finalePanel != null) finalePanel.SetActive(false);
        }

        private void BuildPrivacyPanel(Transform parent)
        {
            var cover = new GameObject("Privacy Input Shield", typeof(RectTransform), typeof(Image));
            privacyPanel = cover;
            RectTransform root = cover.GetComponent<RectTransform>();
            root.SetParent(parent, false);
            root.anchorMin = Vector2.zero;
            root.anchorMax = Vector2.one;
            root.offsetMin = root.offsetMax = Vector2.zero;
            Image shield = cover.GetComponent<Image>();
            shield.color = new Color(.013f, .020f, .034f, 1f);
            shield.raycastTarget = true;

            TextLabel("Privacy Heading", root, "PRIVACY  |  LOCAL SOUND SETTINGS",
                new Vector2(0f, 357f), new Vector2(1250f, 76f), 32);
            Text information = TextLabel("Privacy Disclosure", root,
                "Investigation checkpoints and sound settings are saved locally. " +
                "Other game progress may be stored in the app's local persistent-data directory.\n\n" +
                "This first-party panel uses no account, advertising ID, microphone, " +
                "contacts, or location data, and makes no network requests. " +
                "Unity, Android and separately added services need their own privacy review.\n\n" +
                "Local progress may be lost when clearing app data or uninstalling. " +
                "Saved progress is not encrypted and must not contain private data. " +
                "Sound controls never change puzzle progress or story decisions.",
                new Vector2(0f, 185f), new Vector2(1240f, 257f), 23);
            information.alignment = TextAnchor.MiddleLeft;
            information.resizeTextForBestFit = true;
            information.resizeTextMinSize = 18;
            information.resizeTextMaxSize = 23;

            privacySoundSummary = TextLabel("Sound Setting Summary", root, string.Empty,
                new Vector2(0f, 12f), new Vector2(1330f, 48f), 21);
            privacyAudioButton = MakeButton(root, "TOGGLE SOUND", new Vector2(-320f, -75f),
                ToggleSoundPreference);
            privacyEffectsButton = MakeButton(root, "TOGGLE EFFECTS", new Vector2(0f, -75f),
                ToggleEffectsPreference);
            privacyAmbienceButton = MakeButton(root, "TOGGLE AMBIENCE", new Vector2(320f, -75f),
                ToggleAmbiencePreference);

            privacyEffectsLevel = TextLabel("Effects Volume Level", root, string.Empty,
                new Vector2(-310f, -158f), new Vector2(530f, 42f), 22);
            privacyAmbienceLevel = TextLabel("Ambience Volume Level", root, string.Empty,
                new Vector2(310f, -158f), new Vector2(530f, 42f), 22);
            MakeButton(root, "EFFECTS VOLUME DOWN", new Vector2(-490f, -237f),
                () => AdjustEffectsVolume(-1));
            MakeButton(root, "EFFECTS VOLUME UP", new Vector2(-190f, -237f),
                () => AdjustEffectsVolume(1));
            MakeButton(root, "AMBIENCE VOLUME DOWN", new Vector2(190f, -237f),
                () => AdjustAmbienceVolume(-1));
            MakeButton(root, "AMBIENCE VOLUME UP", new Vector2(490f, -237f),
                () => AdjustAmbienceVolume(1));

            privacyStatus = TextLabel("Privacy Setting Status", root, string.Empty,
                new Vector2(0f, -299f), new Vector2(1200f, 46f), 20);
            MakeButton(root, "CLOSE PRIVACY", new Vector2(0f, -377f), ClosePrivacyPanel);
            privacyPanel.SetActive(false);
        }

        public void OpenPrivacyPanel()
        {
            if (IsFinaleOpen || galleryCanvas == null || !galleryCanvas.activeSelf ||
                dossierView != null && dossierView.IsOpen || worldExplorer != null && worldExplorer.IsOpen ||
                privacyPanel == null) return;
            privacyNotice = string.Empty;
            RefreshPrivacyPanel();
            privacyPanel.SetActive(true);
            privacyPanel.transform.SetAsLastSibling();
        }

        public void ClosePrivacyPanel()
        {
            if (privacyPanel != null) privacyPanel.SetActive(false);
        }

        private void ToggleSoundPreference()
        {
            if (!IsPrivacyPanelOpen) return;
            bool desired = !LocalPrivacyPreferences.AudioEnabled;
            if (!LocalPrivacyPreferences.TrySetAudioEnabled(desired, out string error))
                privacyNotice = error;
            else
            {
                privacyNotice = desired ? "All sound enabled." : "All sound muted.";
                if (!desired && audioFeedback != null) audioFeedback.StopPlayback();
                if (desired && audioFeedback != null) audioFeedback.PlayHint();
            }
            RefreshPrivacyPanel();
        }

        private void ToggleEffectsPreference()
        {
            if (!IsPrivacyPanelOpen) return;
            bool desired = !LocalPrivacyPreferences.EffectsEnabled;
            if (!LocalPrivacyPreferences.TrySetEffectsEnabled(desired, out string error))
                privacyNotice = error;
            else
            {
                privacyNotice = desired ? "Sound effects enabled." : "Sound effects muted.";
                if (desired && audioFeedback != null) audioFeedback.PlayHint();
            }
            RefreshPrivacyPanel();
        }

        private void ToggleAmbiencePreference()
        {
            if (!IsPrivacyPanelOpen) return;
            bool desired = !LocalPrivacyPreferences.AmbienceEnabled;
            if (!LocalPrivacyPreferences.TrySetAmbienceEnabled(desired, out string error))
                privacyNotice = error;
            else privacyNotice = desired ? "Chapter ambience enabled." : "Chapter ambience muted.";
            RefreshPrivacyPanel();
        }

        private void AdjustEffectsVolume(int direction)
        {
            if (!IsPrivacyPanelOpen) return;
            float current = LocalPrivacyPreferences.EffectsVolume;
            float desired = Mathf.Clamp01(Mathf.Round((current * 100f + direction * 20f) / 20f) * .2f);
            if (!LocalPrivacyPreferences.TrySetEffectsVolume(desired, out string error))
                privacyNotice = error;
            else
            {
                privacyNotice = "Effects volume set to " + Mathf.RoundToInt(desired * 100f) + "%.";
                if (desired > 0f && audioFeedback != null) audioFeedback.PlayHint();
            }
            RefreshPrivacyPanel();
        }

        private void AdjustAmbienceVolume(int direction)
        {
            if (!IsPrivacyPanelOpen) return;
            float current = LocalPrivacyPreferences.AmbienceVolume;
            float desired = Mathf.Clamp01(Mathf.Round((current * 100f + direction * 20f) / 20f) * .2f);
            if (!LocalPrivacyPreferences.TrySetAmbienceVolume(desired, out string error))
                privacyNotice = error;
            else privacyNotice = "Ambience volume set to " + Mathf.RoundToInt(desired * 100f) + "%.";
            RefreshPrivacyPanel();
        }

        private void RefreshPrivacyPanel()
        {
            SetSoundButtonCaption(privacyAudioButton,
                LocalPrivacyPreferences.AudioEnabled ? "MUTE ALL SOUND" : "ENABLE ALL SOUND");
            SetSoundButtonCaption(privacyEffectsButton,
                LocalPrivacyPreferences.EffectsEnabled ? "MUTE EFFECTS" : "ENABLE EFFECTS");
            SetSoundButtonCaption(privacyAmbienceButton,
                LocalPrivacyPreferences.AmbienceEnabled ? "MUTE AMBIENCE" : "ENABLE AMBIENCE");

            if (privacySoundSummary != null)
                privacySoundSummary.text = "MASTER: " +
                    (LocalPrivacyPreferences.AudioEnabled ? "ON" : "MUTED") +
                    "   |   EFFECTS: " + (LocalPrivacyPreferences.EffectsEnabled ? "ON" : "MUTED") +
                    "   |   AMBIENCE: " + (LocalPrivacyPreferences.AmbienceEnabled ? "ON" : "MUTED");
            if (privacyEffectsLevel != null)
                privacyEffectsLevel.text = "EFFECTS LEVEL: " +
                    Mathf.RoundToInt(LocalPrivacyPreferences.EffectsVolume * 100f) + "%";
            if (privacyAmbienceLevel != null)
                privacyAmbienceLevel.text = "AMBIENCE LEVEL: " +
                    Mathf.RoundToInt(LocalPrivacyPreferences.AmbienceVolume * 100f) + "%";
            if (privacyStatus != null) privacyStatus.text = privacyNotice;
        }

        private static void SetSoundButtonCaption(Button button, string caption)
        {
            if (button == null) return;
            Text label = button.GetComponentInChildren<Text>();
            if (label != null) label.text = caption;
        }

        /// <summary>
        /// Only a gallery attached to an authored chapter bootstrap may change
        /// scenes. Standalone gallery hosts used for inspection and test harnesses
        /// retain their self-contained, nonshipping investigation behavior.
        /// </summary>
        private bool TryRouteToAuthoredChapter(int destinationChapter)
        {
            if (GetComponent<ChapterOneExperience>() == null &&
                GetComponent<ChapterCaseSceneBootstrap>() == null)
                return false;

            if (sceneTransitionInProgress) return true;
            if (IsFinaleOpen || IsPrivacyPanelOpen ||
                (dossierView != null && dossierView.IsOpen) ||
                (worldExplorer != null && worldExplorer.IsOpen)) return true;
            string destination = NarrativeSceneRoute.SceneName(destinationChapter);
            if (!NarrativeSceneRoute.RequiresSceneTransition(gameObject.scene.name, destinationChapter))
                return false;

            if (!Application.CanStreamedLevelBeLoaded(destination))
            {
                if (availability != null)
                    availability.text = "The requested chapter scene is missing from Build Settings: " + destination;
                Debug.LogError("Sable & Sigil chapter scene is unavailable: " + destination, this);
                return true;
            }

            try
            {
                AsyncOperation loading = SceneManager.LoadSceneAsync(destination, LoadSceneMode.Single);
                if (loading == null)
                    throw new InvalidOperationException("Unity did not create a scene loading operation: " + destination);
            }
            catch (Exception error)
            {
                sceneTransitionInProgress = false;
                Debug.LogException(error, this);
                if (availability != null)
                    availability.text = "Cannot open " + destination + ". Review Unity Console.";
                return true;
            }

            // A successful load request is irreversible from this gallery.
            // Closing resources must never unlock a second competing request.
            sceneTransitionInProgress = true;
            try
            {
                Close();
            }
            catch (Exception error)
            {
                Debug.LogException(error, this);
            }
            return true;
        }

        private void ExitGalleryToGame()
        {
            if (IsFinaleOpen || IsPrivacyPanelOpen) return;
            if (TryRouteToAuthoredChapter(1)) return;
            Close();
        }

        public void EnterSelectedChapter()
        {
            if (sceneTransitionInProgress || galleryCanvas == null || !galleryCanvas.activeSelf || locationMode ||
                IsFinaleOpen || IsPrivacyPanelOpen) return;
            if (selectedIndex == 0)
            {
                ExitGalleryToGame();
                return;
            }
            if (selectedIndex < 1 || selectedIndex > 3 || dossierSession == null ||
                !dossierSession.TryGetChapterProgress(selectedIndex + 1,
                    out ChapterInvestigationProgress progress) || !progress.IsUnlocked) return;
            int target = progress.NextAvailableLocation != 0 ?
                progress.NextAvailableLocation : progress.FirstLocation;
            if (GetChapterForLocation(target) != selectedIndex + 1) return;
            if (TryRouteToAuthoredChapter(selectedIndex + 1)) return;
            SelectLocation(target);
            OpenWorld();
        }

        private void RetryCaseSave()
        {
            if (IsFinaleOpen || dossierSession == null) return;
            if (!dossierSession.TryReload(out string error))
                Debug.LogWarning("Story checkpoint recovery is still blocked: " + error, this);
            Refresh();
        }

        private void OpenChapterCases()
        {
            if (IsFinaleOpen || locationMode || IsPrivacyPanelOpen || dossierSession == null ||
                !dossierSession.TryGetChapterProgress(selectedIndex + 1, out ChapterInvestigationProgress summary) ||
                !summary.IsUnlocked) return;
            int destination = summary.NextAvailableLocation != 0 ?
                summary.NextAvailableLocation : summary.FirstLocation;
            SelectLocation(destination);
        }

        private void OpenDossier()
        {
            if (IsFinaleOpen || !locationMode || IsPrivacyPanelOpen || activeLocationTexture == null || dossierSession == null ||
                dossierView == null || !dossierSession.CanInvestigate(locationIndex + 1)) return;
            if (!CanOpenDossierFromAtlas(locationIndex + 1,
                    dossierSession.IsCompleted(locationIndex + 1)) &&
                !dossierView.CanResumeVerifiedCase(locationIndex + 1)) return;
            dossierView.Open(locationIndex + 1, activeLocationTexture);
        }

        private void OpenWorld()
        {
            if (sceneTransitionInProgress || IsFinaleOpen || !locationMode || IsPrivacyPanelOpen || activeLocationTexture == null || dossierSession == null ||
                GetChapterForLocation(locationIndex + 1) > 4 ||
                !dossierSession.CanInvestigate(locationIndex + 1) || worldExplorer == null ||
                worldExplorer.IsOpen) return;
            int number = locationIndex + 1;
            // An atlas preview may point to a different chapter. Never create
            // its physical investigation in the currently loaded chapter scene.
            // The destination opens its own chapter gallery for case selection.
            if (TryRouteToAuthoredChapter(GetChapterForLocation(number))) return;
            // The chapter camera remains suspended until the gallery is fully closed.
            try
            {
                activeWorldRevision = dossierSession.Revision;
                worldExplorer.Open(number, activeLocationTexture, WorldFinished);
                galleryCanvas.SetActive(false);
            }
            catch (Exception error)
            {
                activeWorldRevision = -1;
                Debug.LogException(error, this);
                availability.text = "3D prototype could not start. Review Unity Console.";
            }
        }

        private void WorldFinished(int number, bool toDossier, bool sawEvidenceA, bool sawEvidenceB)
        {
            long expectedRevision = activeWorldRevision;
            activeWorldRevision = -1;
            if (galleryCanvas == null) return;
            galleryCanvas.SetActive(true);
            UpdateSafeAreaLayout();
            bool reloadSucceeded = dossierSession != null && dossierSession.TryReload(out _);
            Refresh();
            if (!reloadSucceeded || !toDossier || !sawEvidenceA || !sawEvidenceB ||
                number < 1 || number > LocationCount || GetChapterForLocation(number) > 4 ||
                dossierView == null ||
                !locationMode || number != locationIndex + 1 || activeLocationTexture == null ||
                dossierSession == null || !dossierSession.CanInvestigate(number) ||
                expectedRevision < 0 || dossierSession.Revision != expectedRevision) return;
            try
            {
                WorldInvestigationGrant grant = worldExplorer == null ? null :
                    worldExplorer.TakeVerifiedHandoff(number);
                if (grant != null)
                    dossierView.OpenFromWorldEvidence(number, activeLocationTexture, grant);
            }
            catch (Exception error)
            {
                Debug.LogException(error, this);
                if (availability != null)
                    availability.text = "Case handoff failed. Reopen the investigation after reviewing Unity Console.";
            }
        }

        private void NavigateLocation(int delta)
        {
            if (IsFinaleOpen) return;
            if (sceneTransitionInProgress) return;
            if (dossierView != null && dossierView.IsOpen) return;
            if (IsPrivacyPanelOpen) return;
            locationMode = true;
            locationIndex = (locationIndex + delta + LocationCount) % LocationCount;
            sceneHintTier = 0;
            selectedIndex = GetChapterForLocation(locationIndex + 1) - 1;
            Refresh();
        }

        public void SelectLocation(int number)
        {
            if (IsFinaleOpen) return;
            if (sceneTransitionInProgress) return;
            if (dossierView != null && dossierView.IsOpen) return;
            if (IsPrivacyPanelOpen) return;
            if (number < 1 || number > LocationCount)
                throw new ArgumentOutOfRangeException(nameof(number));
            if (galleryCanvas == null) Build();
            locationMode = true;
            locationIndex = number - 1;
            sceneHintTier = 0;
            selectedIndex = GetChapterForLocation(number) - 1;
            Refresh();
        }

        private void FitArtwork(Texture2D texture)
        {
            if (texture == null || artworkRect == null) return;
            const float viewportWidth = 880f;
            const float viewportHeight = 495f;
            float scale = Mathf.Min(viewportWidth / texture.width, viewportHeight / texture.height);
            artworkRect.sizeDelta = new Vector2(texture.width * scale, texture.height * scale);
        }

        private void Refresh()
        {
            bool recoveryRequired = dossierSession == null || !dossierSession.IsReady;
            if (recoveryButton != null)
                recoveryButton.gameObject.SetActive(recoveryRequired);
            if (finaleButton != null)
                finaleButton.gameObject.SetActive(!recoveryRequired && !locationMode &&
                    selectedIndex == ChapterCount - 1 && dossierSession != null &&
                    dossierSession.IsFinaleUnlocked);
            // Scene navigation must never leak into the chapter-selection workflow.
            if (previousSceneButton != null) previousSceneButton.gameObject.SetActive(locationMode);
            if (nextSceneButton != null) nextSceneButton.gameObject.SetActive(locationMode);
            if (sceneHintButton != null)
            {
                sceneHintButton.gameObject.SetActive(locationMode);
                var hintCaption = sceneHintButton.GetComponentInChildren<Text>();
                if (hintCaption != null)
                    hintCaption.text = sceneHintTier >= ChapterHintDisclosure.MaximumTier ?
                        "ALL HINTS REVEALED" : "REVEAL HINT " + (sceneHintTier + 1) + " / 3";
                sceneHintButton.interactable = CanRevealSceneHint() &&
                    ChapterHintDisclosure.CanRevealNext(sceneHintTier, true);
            }
            if (sceneAtlasButton != null)
            {
                var caption = sceneAtlasButton.GetComponentInChildren<Text>();
                if (caption != null) caption.text = locationMode ? "CHAPTERS" : "SCENE ATLAS";
            }
            if (enterButton != null) enterButton.gameObject.SetActive(!locationMode);
            if (chapterCasesButton != null)
            {
                chapterCasesButton.gameObject.SetActive(!locationMode && !recoveryRequired);
                if (!locationMode)
                {
                    ChapterInvestigationProgress chapterSummary = null;
                    bool ready = dossierSession != null &&
                        dossierSession.TryGetChapterProgress(selectedIndex + 1, out chapterSummary);
                    chapterCasesButton.interactable = ready && chapterSummary.IsUnlocked;
                    Text caption = chapterCasesButton.GetComponentInChildren<Text>();
                    if (caption != null)
                        caption.text = !ready ? "SAVE NEEDS RECOVERY" :
                            !chapterSummary.IsUnlocked ? "CASES LOCKED" :
                            chapterSummary.IsComplete ? "REVIEW CASES" : "CHAPTER CASES";
                }
            }
            if (exploreWorldButton != null)
            {
                exploreWorldButton.gameObject.SetActive(locationMode && !recoveryRequired);
                if (locationMode)
                {
                    int targetChapter = GetChapterForLocation(locationIndex + 1);
                    bool authoredHost = GetComponent<ChapterOneExperience>() != null ||
                        GetComponent<ChapterCaseSceneBootstrap>() != null;
                    bool crossChapter = authoredHost &&
                        NarrativeSceneRoute.RequiresSceneTransition(gameObject.scene.name, targetChapter);
                    exploreWorldButton.interactable = GetChapterForLocation(locationIndex + 1) <= 4 &&
                        dossierSession != null && dossierSession.CanInvestigate(locationIndex + 1);
                    Text caption = exploreWorldButton.GetComponentInChildren<Text>();
                    if (caption != null)
                        caption.text = crossChapter ? "ENTER CHAPTER " + targetChapter : "EXPLORE 3D";
                }
            }
            if (caseFileButton != null)
            {
                caseFileButton.gameObject.SetActive(locationMode && !recoveryRequired);
                if (locationMode)
                {
                    bool available = dossierSession != null && dossierSession.CanInvestigate(locationIndex + 1);
                    bool completed = available && dossierSession.IsCompleted(locationIndex + 1);
                    bool canResume = available && dossierView != null &&
                        dossierView.CanResumeVerifiedCase(locationIndex + 1);
                    bool atlasAccess = available && CanOpenDossierFromAtlas(locationIndex + 1, completed);
                    if (!atlasAccess && canResume) atlasAccess = true;
                    caseFileButton.interactable = atlasAccess;
                    var label = caseFileButton.GetComponentInChildren<Text>();
                    if (label != null) label.text = !available ? "CASE FILE LOCKED" :
                        !atlasAccess ? "SOLVE 3D MECHANISM" :
                        completed ? "REVIEW CASE FILE" :
                        canResume ? "RESUME CASE FILE" : "OPEN CASE FILE";
                }
            }
            if (locationMode)
            {
                if (activeLocationTexture == null || activeLocationTextureIndex != locationIndex)
                {
                    Texture2D next = Resources.Load<Texture2D>("LocationArt/Scene_" +
                        (locationIndex + 1).ToString("00"));
                    if (next == null)
                        throw new InvalidOperationException("Missing required location reference: " + (locationIndex + 1));
                    Texture2D previous = activeLocationTexture;
                    activeLocationTexture = next;
                    activeLocationTextureIndex = locationIndex;
                    // Detach the outgoing texture before unloading native image memory.
                    if (previous != null && previous != next)
                    {
                        if (artwork != null && artwork.texture == previous) artwork.texture = null;
                        Resources.UnloadAsset(previous);
                    }
                }
                Texture2D scene = activeLocationTexture;
                artwork.texture = scene;
                // The atlas and chapter selector are mutually exclusive views.
                // Do not retain a hidden chapter image while browsing locations.
                ReleaseChapterTexture();
                FitArtwork(scene);
                heading.text = "LOCATION " + (locationIndex + 1).ToString("00") + " / " + LocationCount +
                    "\n" + LocationNames[locationIndex];
                StoryLocation authored = ChapterStoryGraph.GetLocation(locationIndex + 1);
                description.fontSize = 18;
                bool canReadHints = CanRevealSceneHint();
                bool hintVisible = ChapterHintDisclosure.TryGetVisibleHint(
                    authored, sceneHintTier, canReadHints, out string visibleHint);
                description.text = LocationDescriptions[locationIndex] +
                    "\nPUZZLE: " + authored.Mechanism.Replace('-', ' ').ToUpperInvariant() +
                    (hintVisible ? "\nHINT " + sceneHintTier + ": " + visibleHint :
                    canReadHints ? "\nHINTS HIDDEN - Reveal only if needed." :
                    "\nHINTS LOCKED - Complete earlier investigations.");
                enterButton.interactable = false;
                enterCaption.text = "REFERENCE ONLY";
                string caseStatus = dossierSession == null || !dossierSession.IsReady ? "SAVE NEEDS RECOVERY" :
                    dossierSession.IsCompleted(locationIndex + 1) ? "CASE COMPLETE" :
                    dossierSession.CanInvestigate(locationIndex + 1) ? "DOSSIER READY" : "CASE LOCKED";
                availability.text = "CHAPTER " + LocationChapters[locationIndex] + "  |  " + caseStatus +
                    "\nInteractive 3D case prototype available; complete chapter scene not verified.";
                return;
            }
            Texture2D selectedChapterTexture = GetChapterTexture(selectedIndex);
            artwork.texture = selectedChapterTexture;
            ReleaseLocationTexture();
            FitArtwork(selectedChapterTexture);
            heading.text = "CHAPTER " + (selectedIndex + 1).ToString("00") + "\n" + ChapterNames[selectedIndex];
            description.fontSize = 21;
            description.text = ChapterDescriptions[selectedIndex];
            bool chapterReady = selectedIndex == 0;
            if (selectedIndex > 0 && selectedIndex <= 3 && dossierSession != null &&
                dossierSession.TryGetChapterProgress(selectedIndex + 1,
                    out ChapterInvestigationProgress entryProgress))
                chapterReady = entryProgress.IsUnlocked;
            enterButton.interactable = chapterReady;
            enterCaption.text = selectedIndex == 0 ? "ENTER CHAPTER I" :
                selectedIndex == 1 ? (chapterReady ? "ENTER CHAPTER II" : "CHAPTER II LOCKED") :
                selectedIndex == 2 ? (chapterReady ? "ENTER CHAPTER III" : "CHAPTER III LOCKED") :
                (chapterReady ? "ENTER CHAPTER IV" : "CHAPTER IV LOCKED");
            string sceneStatus = selectedIndex == 0 ? "3D CHAPTER I  |  START OR CONTINUE" :
                selectedIndex <= 3 ? "CONNECTED 3D CASE INVESTIGATIONS  |  Unity acceptance pending." :
                "SCENE UNAVAILABLE";
            if (dossierSession != null &&
                dossierSession.TryGetChapterProgress(selectedIndex + 1, out ChapterInvestigationProgress chapter))
            {
                string dossierStatus = chapter.IsComplete ? "COMPLETE" :
                    chapter.IsUnlocked ? "IN PROGRESS" : "LOCKED";
                availability.text = sceneStatus + "\nCASE FILES  " + chapter.CompletedCount +
                    "/" + chapter.TotalCount + "  |  " + dossierStatus;
            }
            else availability.text = sceneStatus + "\nCASE SAVE UNAVAILABLE; RECOVERY REQUIRED";
        }

        private static Text TextLabel(string name, Transform parent, string value, Vector2 position,
            Vector2 size, int fontSize)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Text));
            obj.transform.SetParent(parent, false);
            var rect = obj.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            var text = obj.GetComponent<Text>();
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.text = value;
            text.fontSize = fontSize;
            text.color = Parchment;
            text.alignment = TextAnchor.MiddleCenter;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = Mathf.Max(14, fontSize - 7);
            text.resizeTextMaxSize = fontSize;
            return text;
        }

        private static Button MakeButton(Transform parent, string label, Vector2 position,
            UnityEngine.Events.UnityAction action)
        {
            var obj = new GameObject(label, typeof(RectTransform), typeof(Image), typeof(Button));
            obj.transform.SetParent(parent, false);
            var rect = obj.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = new Vector2(245f, 62f);
            obj.GetComponent<Image>().color = AntiqueBrass;
            var button = obj.GetComponent<Button>();
            button.transition = Selectable.Transition.ColorTint;
            ColorBlock interaction = button.colors;
            interaction.normalColor = Color.white;
            interaction.highlightedColor = new Color(1f, .96f, .87f, 1f);
            interaction.selectedColor = interaction.highlightedColor;
            interaction.pressedColor = new Color(.78f, .78f, .76f, 1f);
            interaction.disabledColor = new Color(.78f, .78f, .78f, 1f);
            interaction.colorMultiplier = 1f;
            button.colors = interaction;
            button.onClick.AddListener(action);
            var text = TextLabel("Button Caption", obj.transform, label, Vector2.zero,
                new Vector2(235f, 58f), 19);
            text.color = new Color(.038f, .046f, .06f);
            return button;
        }

        private void OnDestroy()
        {
            CloseFinale();
            if (worldExplorer != null) worldExplorer.Close();
            RestoreWorldCamera();
            ReleaseLocationTexture();
            ReleaseChapterTexture();
            // Only the displayed image is retained while the gallery is open.
            if (galleryCanvas != null) Destroy(galleryCanvas);
        }
    }
}
