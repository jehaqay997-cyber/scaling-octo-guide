using System;
using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Scene-owned original chapter ambience. One looped, nonstreaming clip and
    /// one 2D AudioSource; preference changes trigger a short volume transition.
    /// No procedural synthesis or temporary buffers are created per frame.
    /// </summary>
    [RequireComponent(typeof(AudioSource))]
    [DisallowMultipleComponent]
    public sealed class ChapterWorldAtmosphere : MonoBehaviour
    {
        private const float BaseVolume = .19f;
        private const float FadeDurationSeconds = .15f;
        private const float CheckIntervalSeconds = .25f;
        private AudioSource audioSource;
        private AudioClip clip;
        private float nextPreferenceCheck;
        private float fadeStart;
        private float fadeTarget;
        private float fadeElapsed;
        private bool fading;
        private bool paused;
        private bool focused = true;
        private bool initialized;

        private void Awake()
        {
            audioSource = GetComponent<AudioSource>();
            if (audioSource == null)
            {
                enabled = false;
                return;
            }
            audioSource.playOnAwake = false;
            audioSource.loop = true;
            audioSource.spatialBlend = 0f;
            audioSource.spatialize = false;
            audioSource.volume = 0f;
        }

        private void OnEnable()
        {
            LocalPrivacyPreferences.AudioSettingsChanged += Refresh;
            Refresh();
        }

        public void Initialize(int chapterNumber)
        {
            if (initialized) throw new InvalidOperationException("Chapter ambience is already configured.");
            if (chapterNumber < 1 || chapterNumber > 4)
                throw new ArgumentOutOfRangeException(nameof(chapterNumber));
            if (audioSource == null)
                throw new InvalidOperationException("Chapter ambience requires AudioSource.");

            float[] samples = CinematicAmbientSynthesis.Create(chapterNumber);
            AudioClip created = null;
            try
            {
                created = AudioClip.Create("Original Chapter Atmosphere " + chapterNumber,
                    CinematicAmbientSynthesis.SampleCount, 1,
                    CinematicAmbientSynthesis.SampleRate, false);
                if (created == null || !created.SetData(samples, 0))
                    throw new InvalidOperationException("Ambient clip creation failed.");

                clip = created;
                audioSource.clip = clip;
                initialized = true;
                Refresh();
            }
            catch
            {
                audioSource.Stop();
                audioSource.clip = null;
                clip = null;
                initialized = false;
                fading = false;
                if (created != null) DestroyClip(created);
                throw;
            }
        }

        private void Update()
        {
            if (!initialized) return;
            if (Time.unscaledTime >= nextPreferenceCheck)
            {
                nextPreferenceCheck = Time.unscaledTime + CheckIntervalSeconds;
                Refresh();
            }
            if (!fading || audioSource == null) return;

            fadeElapsed += Time.unscaledDeltaTime;
            float progress = Mathf.Clamp01(fadeElapsed / FadeDurationSeconds);
            audioSource.volume = Mathf.Lerp(fadeStart, fadeTarget, progress);
            if (progress < 1f) return;

            fading = false;
            if (fadeTarget <= 0f) audioSource.Stop();
        }

        private void Refresh()
        {
            if (audioSource == null || !initialized) return;
            if (!isActiveAndEnabled || paused || !focused || AudioListener.pause)
            {
                fading = false;
                audioSource.volume = 0f;
                audioSource.Stop();
                return;
            }

            float target = LocalPrivacyPreferences.AmbienceAudible
                ? BaseVolume * LocalPrivacyPreferences.AmbienceVolume : 0f;

            if (target > 0f && !audioSource.isPlaying)
            {
                audioSource.volume = 0f;
                audioSource.Play();
            }

            if (Mathf.Approximately(target, fadeTarget) &&
                (fading || Mathf.Approximately(audioSource.volume, target))) return;

            fadeStart = audioSource.volume;
            fadeTarget = target;
            fadeElapsed = 0f;
            fading = !Mathf.Approximately(fadeStart, fadeTarget);
            if (!fading)
            {
                audioSource.volume = target;
                if (target <= 0f && audioSource.isPlaying) audioSource.Stop();
            }
        }

        private void OnApplicationPause(bool value)
        {
            paused = value;
            Refresh();
        }

        private void OnApplicationFocus(bool value)
        {
            focused = value;
            Refresh();
        }

        private void OnDisable()
        {
            LocalPrivacyPreferences.AudioSettingsChanged -= Refresh;
            fading = false;
            if (audioSource != null) audioSource.Stop();
        }

        private void OnDestroy()
        {
            LocalPrivacyPreferences.AudioSettingsChanged -= Refresh;
            if (audioSource != null)
            {
                audioSource.Stop();
                audioSource.clip = null;
            }
            if (clip != null) DestroyClip(clip);
            clip = null;
            initialized = false;
        }

        private static void DestroyClip(AudioClip sound)
        {
            if (Application.isPlaying) UnityEngine.Object.Destroy(sound);
            else UnityEngine.Object.DestroyImmediate(sound);
        }
    }
}
