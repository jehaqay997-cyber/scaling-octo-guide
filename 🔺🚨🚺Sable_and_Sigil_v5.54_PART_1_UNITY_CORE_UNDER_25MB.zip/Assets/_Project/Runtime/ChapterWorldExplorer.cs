using System;
using System.Collections.Generic;
using TheOrderRoom.Domain;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// A lightweight isolated 3D case-exploration prototype for the ten authored locations.
    /// All objects, materials, lights and the untagged camera are owned by this component.
    /// It shares the existing chapter/location artwork and never writes persistent progress.
    /// </summary>
    public sealed class ChapterWorldExplorer : MonoBehaviour
    {
        private const int SceneryLayer = 26;
        private const int EvidenceLayer = 27;
        private const float MinimumCameraDistance = 6.6f;
        private const float MaximumCameraDistance = 11f;
        private const float DefaultCameraDistance = 8.7f;
        private const float EvidenceFocusDistance = 7.2f;
        // The two small crest plaques need a closer inspection orbit than the room.
        // Independent limits keep pinch and button zoom continuous in this mode.
        private const float CrestFocusDistance = 4.8f;
        private const float MinimumCrestFocusDistance = 3.8f;
        private const float MaximumCrestFocusDistance = 8.2f;
        // Physical mechanism plates in Chapter Two use a dedicated close-up orbit.
        // Distances are independent from room exploration to prevent zoom jumps.
        private const float ChapterTwoFocusDistance = 6.2f;
        private const float MinimumChapterTwoFocusDistance = 4.3f;
        private const float MaximumChapterTwoFocusDistance = 8.8f;
        private const float ChapterFourFocusDistance = 6.2f;
        private const float MinimumChapterFourFocusDistance = 4.3f;
        private const float MaximumChapterFourFocusDistance = 8.8f;
        private const float ChapterThreeFocusDistance = 6.2f;
        private const float MinimumChapterThreeFocusDistance = 4.3f;
        private const float MaximumChapterThreeFocusDistance = 8.8f;
        private const float EvidencePedestalOffset = 2.35f;
        // Source art includes blurred horizontal padding around the photographed doorway.
        // Crop only the world reference; the original-art inspection overlay stays untouched.
        private const int ChapterOneReferenceWidth = 1280;
        private const int ChapterOneReferenceHeight = 720;
        private const int ChapterOneCropLeft = 424;
        private const int ChapterOneCropWidth = 432;
        // The second reference photograph likewise contains dark horizontal side padding.
        // Preserve the imported texture; crop only the physical stage display.
        private const int SpiralReferenceWidth = 1280;
        private const int SpiralReferenceHeight = 720;
        private const int SpiralCropLeft = 400;
        private const int SpiralCropWidth = 480;
        private const float ReferencePanelHeight = 4.95f;
        private const float DefaultReferencePanelWidth = 8.8f;
        private static readonly Color Ink = new Color(.055f, .073f, .10f);
        private static readonly Color Ivory = new Color(.9f, .83f, .68f);
        private static readonly Color Brass = new Color(.66f, .47f, .24f);
        private readonly List<Material> materials = new List<Material>(12);
        private readonly List<Mesh> ownedMeshes = new List<Mesh>(11);
        private readonly List<Texture2D> ownedTextures = new List<Texture2D>(1);
        private readonly Renderer[] evidenceRenderers = new Renderer[2];
        private readonly Transform[] relicRoots = new Transform[2];
        private readonly Quaternion[] relicInitialRotations = new Quaternion[2];
        private readonly float[] relicYawDegrees = new float[2];
        private readonly ThresholdCrestPuzzle thresholdCrest = new ThresholdCrestPuzzle();
        private readonly CrestTracingState crestTracing = new CrestTracingState();
        private PhysicalPlacementResult lastCrestPlacement;
        private readonly LunarPhaseDial lunarDial = new LunarPhaseDial();
        private RectTransform spiralDropTarget;
        private RectTransform crestDropTarget;
        private RectTransform moonDialFace;
        private Text moonPhaseLabel;
        private Button moonLockButton;
        private readonly SpiralBalusterPuzzle spiralPuzzle = new SpiralBalusterPuzzle();
        private WorldInvestigationGrant pendingDossierHandoff;
        private OrderAudioFeedback audioFeedback;

        public void ConfigureAudio(OrderAudioFeedback feedback)
        {
            audioFeedback = feedback;
        }
        private ChapterTwoMechanismPuzzle chapterTwoPuzzle;
        private GameObject chapterTwoOverlay;
        private Button chapterTwoButton;
        private Button chapterTwoFocusButton;
        private bool chapterTwoFocusActive;
        private Button chapterTwoHintButton;
        private Text chapterTwoHintText;
        private Text chapterTwoFeedback;
        private TextMesh chapterTwoWorldMark;
        private Renderer chapterTwoWorldIndicator;
        private Collider chapterTwoWorldCollider;
        private Mesh chapterTwoReliefMesh;
        private Renderer chapterTwoReliefRenderer;
        private Material chapterTwoSolvedMaterial;
        private readonly Button[] chapterTwoOptions = new Button[4];
        private ChapterTwoSelection lastChapterTwoSelection = ChapterTwoSelection.Invalid;
        private ChapterFourMeridianPuzzle chapterFourPuzzle;
        private GameObject chapterFourOverlay;
        private Button chapterFourButton;
        private Button chapterFourFocusButton;
        private Button chapterFourHintButton;
        private Text chapterFourFeedback;
        private Text chapterFourHintText;
        private TextMesh chapterFourWorldMark;
        private Renderer chapterFourWorldIndicator;
        private Collider chapterFourWorldCollider;
        private Mesh chapterFourReliefMesh;
        private Renderer chapterFourReliefRenderer;
        private Material chapterFourSolvedMaterial;
        private MeridianReliefStage chapterFourReliefStage = MeridianReliefStage.Locked;
        private MeridianMoveResult lastChapterFourMove = MeridianMoveResult.Invalid;
        private bool chapterFourVisualDesynchronized;
        private readonly Button[] chapterFourSlots = new Button[ChapterFourMeridianPuzzle.RingCount];
        private readonly Transform[] meridianWorldRings = new Transform[ChapterFourMeridianPuzzle.RingCount];
        private readonly Renderer[] meridianWorldRingRenderers = new Renderer[ChapterFourMeridianPuzzle.RingCount];
        private bool chapterFourFocusActive;
        private ChapterThreeMechanismPuzzle chapterThreePuzzle;
        private GameObject chapterThreeOverlay;
        private Button chapterThreeButton;
        private Button chapterThreeFocusButton;
        private bool chapterThreeFocusActive;
        private Button chapterThreeHintButton;
        private Text chapterThreeHintText;
        private Text chapterThreeFeedback;
        private TextMesh chapterThreeWorldMark;
        private Renderer chapterThreeWorldIndicator;
        private Collider chapterThreeWorldCollider;
        private Mesh chapterThreeReliefMesh;
        private ChapterThreeReliefStage chapterThreeReliefStage = ChapterThreeReliefStage.Locked;
        private Renderer chapterThreeReliefRenderer;
        private Material chapterThreeSolvedMaterial;
        private readonly Button[] chapterThreeOptions = new Button[4];
        private ChapterThreeSelection lastChapterThreeSelection = ChapterThreeSelection.Invalid;
        private GameObject spiralOverlay;
        private Text spiralFeedback;
        private Button spiralButton;
        private Button spiralHintButton;
        private Text spiralHintText;
        private int spiralHintStage;
        private RawImage spiralMissingIcon;
        private Text spiralMissingCaption;
        private Image spiralMissingTile;
        private Texture2D spiralSymbolAtlas;
        private Mesh spiralGlyphMesh;
        private readonly Button[] spiralOptions = new Button[4];
        private BalusterSelection lastSpiralSelection = BalusterSelection.Invalid;
        private BalusterSymbol lastSpiralSymbol = BalusterSymbol.Missing;
        private readonly Renderer[] thresholdRayRenderers =
            new Renderer[6];
        private GameObject thresholdOverlay;
        private Text thresholdFeedback;
        private Button thresholdButton;
        private Button thresholdHintButton;
        private Text thresholdHintText;
        private int thresholdHintStage;
        private readonly Image[] thresholdDiagramRays = new Image[6];
        private readonly Button[] thresholdDiagramButtons = new Button[6];
        private bool crestFocusActive;
        private int lastThresholdRayIndex = -1;
        private ThresholdRaySelection lastThresholdSelection;

        private Material inspectedEvidenceMaterial;
        private Material crestOriginalMaterial;
        private Material crestIncorrectMaterial;
        private Material crestVerifiedMaterial;
        private readonly List<RaycastResult> pointerHits = new List<RaycastResult>(8);
        private GameObject sceneRoot;
        private GameObject interfaceRoot;
        private RectTransform safeAreaRoot;
        private RectTransform safeLayoutRoot;
        private int lastScreenWidth = -1;
        private int lastScreenHeight = -1;
        private Rect lastSafeArea;
        private Camera sceneCamera;
        private CinematicScenePresentation cinematicScene;
        // This Resources-loaded artwork belongs to the current investigation only.
        // Never unload the gallery-owned or material-owned reference texture here.
        private Texture2D featuredSceneTexture;
        private Button scenicModeButton;
        private Text scenicModeCaption;
        private readonly List<CanvasGroup> threeDControls = new List<CanvasGroup>(18);
        private bool scenicMode;
        private Text evidenceStatus;
        private Text caseTitle;
        private GameObject artworkOverlay;
        private RawImage artworkImage;
        private GameObject comparisonOverlay;
        private Text comparisonEvidenceA;
        private Text comparisonEvidenceB;
        private Button comparisonButton;
        private Button turnRelicLeftButton;
        private Button turnRelicRightButton;
        private Button resetRelicButton;
        private readonly ChapterArtworkViewport artworkViewport = new ChapterArtworkViewport();
        private Button deductionButton;
        private Button evidenceAButton;
        private Button evidenceBButton;
        private ChapterWorldSceneSpec current;
        private StoryCaseInspection inspection;
        private Action<int, bool, bool, bool> finished;
        private PointerEventData pointer;
        private EventSystem pointerEventSystem;
        private float cameraYaw;
        private float cameraDistance;
        private int focusedEvidenceIndex = -1;
        private readonly ChapterWorldGestureState gesture = new ChapterWorldGestureState();
        private readonly WorldPointerResumeGate pointerResumeGate = new WorldPointerResumeGate();
        private readonly WorldTouchChordGate touchChordGate = new WorldTouchChordGate();
        private bool applicationFocused = true;
        private bool applicationPaused;
        private float previousPinchDistance = -1f;
        private const float DragYawDegreesPerPixel = .17f;
        private const float PinchZoomUnitsPerPixel = .008f;
        private bool isOpen;

        public bool IsOpen => isOpen;
        public int ActiveLocation => isOpen && current != null ? current.LocationNumber : 0;
        public int InspectedCount => isOpen && inspection != null ? inspection.InspectedCount : 0;
        public bool CanDeduce => isOpen && inspection != null && inspection.CanDeduce &&
            (current == null || current.LocationNumber != 1 || thresholdCrest.IsVerified) &&
            (current == null || current.LocationNumber != 2 || spiralPuzzle.IsVerified) &&
            (current == null || current.ChapterNumber != 2 ||
                (chapterTwoPuzzle != null && chapterTwoPuzzle.IsVerified)) &&
            (current == null || current.ChapterNumber != 3 ||
                (chapterThreePuzzle != null && chapterThreePuzzle.IsVerified)) &&
            (current == null || current.ChapterNumber != 4 ||
                (chapterFourPuzzle != null && chapterFourPuzzle.IsVerified &&
                 !chapterFourVisualDesynchronized));
        public bool IsThresholdVerified => isOpen && current != null &&
            current.LocationNumber == 1 && thresholdCrest.IsVerified;
        public int CrestHintStage => isOpen && current != null &&
            current.LocationNumber == 1 ? thresholdHintStage : 0;
        public int ThresholdAttempts => isOpen && current != null &&
            current.LocationNumber == 1 ? thresholdCrest.Attempts : 0;
        public ThresholdRaySelection LastThresholdSelection => lastThresholdSelection;
        public bool IsThresholdOpen => thresholdOverlay != null && thresholdOverlay.activeSelf;
        public bool IsSpiralOpen => spiralOverlay != null && spiralOverlay.activeSelf;
        public bool IsChapterFourOpen => chapterFourOverlay != null && chapterFourOverlay.activeSelf;
        private bool IsChapterFourLocation => isOpen && current != null &&
            current.ChapterNumber == 4 && chapterFourPuzzle != null;
        public bool IsChapterFourVerified => IsChapterFourLocation &&
            chapterFourPuzzle.IsVerified && !chapterFourVisualDesynchronized;
        public bool IsChapterFourVisualDesynchronized => IsChapterFourLocation && chapterFourVisualDesynchronized;
        public int ChapterFourAttempts => IsChapterFourLocation ? chapterFourPuzzle.Attempts : 0;
        public int ChapterFourHintStage => IsChapterFourLocation ? chapterFourPuzzle.HintStage : 0;
        public bool IsChapterFourFocused => IsChapterFourLocation && chapterFourFocusActive;
        public string ChapterFourOrder => chapterFourPuzzle == null ? string.Empty :
            new string(new[] { chapterFourPuzzle.Order[0], chapterFourPuzzle.Order[1],
                chapterFourPuzzle.Order[2], chapterFourPuzzle.Order[3] });
        public bool IsChapterThreeOpen => chapterThreeOverlay != null && chapterThreeOverlay.activeSelf;
        public bool IsChapterThreeVerified => isOpen && current != null &&
            current.ChapterNumber == 3 && chapterThreePuzzle != null && chapterThreePuzzle.IsVerified;
        public int ChapterThreeAttempts => IsChapterThreeLocation ? chapterThreePuzzle.Attempts : 0;
        public int ChapterThreeHintStage => IsChapterThreeLocation ? chapterThreePuzzle.HintStage : 0;
        private bool IsChapterThreeLocation => isOpen && current != null &&
            current.ChapterNumber == 3 && chapterThreePuzzle != null;
        public bool IsChapterThreeFocused => IsChapterThreeLocation && chapterThreeFocusActive;
        public bool IsChapterTwoOpen => chapterTwoOverlay != null && chapterTwoOverlay.activeSelf;
        public bool IsChapterTwoVerified => isOpen && current != null &&
            current.ChapterNumber == 2 && chapterTwoPuzzle != null && chapterTwoPuzzle.IsVerified;
        public int ChapterTwoAttempts => IsChapterTwoLocation ? chapterTwoPuzzle.Attempts : 0;
        public int ChapterTwoHintStage => IsChapterTwoLocation ? chapterTwoPuzzle.HintStage : 0;
        private bool IsChapterTwoLocation => isOpen && current != null &&
            current.ChapterNumber == 2 && chapterTwoPuzzle != null;
        public bool IsCrestTracingPlaced => isOpen && current != null &&
            current.LocationNumber == 1 && crestTracing.IsPlaced;
        public LunarPhase MoonDialPhase => lunarDial.Phase;
        public bool IsSpiralVerified => isOpen && current != null &&
            current.LocationNumber == SpiralBalusterPuzzle.LocationNumber && spiralPuzzle.IsVerified;
        public int SpiralAttempts => isOpen && current != null &&
            current.LocationNumber == SpiralBalusterPuzzle.LocationNumber ? spiralPuzzle.Attempts : 0;
        public int SpiralHintStage => isOpen && current != null &&
            current.LocationNumber == SpiralBalusterPuzzle.LocationNumber ? spiralHintStage : 0;
        public bool IsCrestFocused => isOpen && crestFocusActive;
        public bool IsChapterTwoFocused => IsChapterTwoLocation && chapterTwoFocusActive;
        public Camera SceneCamera => sceneCamera;
        public bool IsScenicMode => isOpen && scenicMode && cinematicScene != null && cinematicScene.IsScenic;
        public float ScenicZoom => IsScenicMode ? cinematicScene.Zoom : 1f;
        public bool TryZoomScenery(float delta) => IsScenicMode && cinematicScene.TryZoom(delta);
        public bool TryPanScenery(float dx, float dy) => IsScenicMode && cinematicScene.TryPan(dx, dy);
        public int OwnedMeshCount => ownedMeshes.Count;
        public int OwnedTextureCount => ownedTextures.Count;
        public bool IsArtworkOpen => artworkOverlay != null && artworkOverlay.activeSelf;
        public bool IsComparisonOpen => comparisonOverlay != null && comparisonOverlay.activeSelf;
        public float ArtworkZoom => artworkViewport.Zoom;
        public Rect ArtworkUvRect => artworkImage != null ? artworkImage.uvRect : new Rect(0f, 0f, 1f, 1f);
        public int OwnedMaterialCount => materials.Count;
        public float CameraYaw => cameraYaw;
        public float CameraDistance => cameraDistance;
        public int FocusedEvidenceIndex => isOpen ? focusedEvidenceIndex : -1;
        public Vector3 CameraFocusTarget => GetCameraTarget();

        public void Open(int locationNumber, Texture2D referenceArtwork, Action<int, bool, bool, bool> onFinished)
        {
            if (isOpen) throw new InvalidOperationException("A 3D investigation is already open.");
            pendingDossierHandoff = null;
            if (referenceArtwork == null) throw new ArgumentNullException(nameof(referenceArtwork));
            if (onFinished == null) throw new ArgumentNullException(nameof(onFinished));
            if (!ChapterWorldSceneCatalog.Validate(out string error))
                throw new InvalidOperationException(error);
            if (!ChapterEvidenceVisualCatalog.Validate(out error))
                throw new InvalidOperationException(error);
            if (!CinematicEnvironmentCatalog.Validate(out error))
                throw new InvalidOperationException(error);

            ChapterWorldSceneSpec selected = ChapterWorldSceneCatalog.Get(locationNumber);
            if (selected.ChapterNumber == 2 && !ChapterTwoMechanismPuzzle.Validate(out error))
                throw new InvalidOperationException(error);
            if (selected.ChapterNumber == 3 && !ChapterThreeMechanismPuzzle.Validate(out error))
                throw new InvalidOperationException(error);
            if (selected.ChapterNumber == 4 && !ChapterFourMeridianPuzzle.Validate(out error))
                throw new InvalidOperationException(error);
            current = selected;
            chapterTwoPuzzle = current.ChapterNumber == 2 ?
                new ChapterTwoMechanismPuzzle(locationNumber) : null;
            chapterThreePuzzle = current.ChapterNumber == 3 ?
                new ChapterThreeMechanismPuzzle(locationNumber) : null;
            chapterFourPuzzle = current.ChapterNumber == 4 ?
                new ChapterFourMeridianPuzzle() : null;
            inspection = new StoryCaseInspection(locationNumber);
            finished = onFinished;
            cameraYaw = 0f;
            cameraDistance = DefaultCameraDistance;
            scenicMode = true;
            focusedEvidenceIndex = -1;
            crestFocusActive = false;
            chapterTwoFocusActive = false;
            chapterThreeFocusActive = false;
            chapterFourFocusActive = false;
            lastChapterFourMove = MeridianMoveResult.Invalid;
            chapterFourVisualDesynchronized = false;
            lastChapterThreeSelection = ChapterThreeSelection.Invalid;
            thresholdCrest.Reset();
            crestTracing.Reset();
            lastCrestPlacement = PhysicalPlacementResult.Invalid;
            lunarDial.Reset();
            spiralPuzzle.Reset();
            spiralHintStage = 0;
            lastSpiralSelection = BalusterSelection.Invalid;
            lastSpiralSymbol = BalusterSymbol.Missing;
            thresholdHintStage = 0;
            lastThresholdRayIndex = -1;
            lastThresholdSelection = ThresholdRaySelection.Invalid;
            for (int index = 0; index < relicRoots.Length; index++)
            {
                relicRoots[index] = null;
                relicInitialRotations[index] = Quaternion.identity;
                relicYawDegrees[index] = 0f;
            }
            gesture.Cancel();
            pointerResumeGate.Reset();
            if (ActiveWorldTouchCount() > 0) touchChordGate.Suspend();
            else touchChordGate.Reset();
            previousPinchDistance = -1f;
            try
            {
                BuildWorld(referenceArtwork);
                BuildInterface();
                isOpen = true;
                RefreshInterface();
            }
            catch
            {
                Close();
                throw;
            }
        }

        internal WorldInvestigationGrant TakeVerifiedHandoff(int locationNumber)
        {
            WorldInvestigationGrant pending = pendingDossierHandoff;
            if (pending == null || pending.LocationNumber != locationNumber) return null;
            pendingDossierHandoff = null;
            return pending;
        }

        public bool TryInspectEvidence(int evidenceIndex)
        {
            if (!isOpen || inspection == null || IsArtworkOpen || IsSpiralOpen ||
                IsComparisonOpen || IsThresholdOpen || IsChapterTwoOpen ||
                (cinematicScene != null && cinematicScene.IsEvidencePreviewOpen)) return false;
            if (IsChapterThreeOpen || IsChapterFourOpen) return false;
            if (!inspection.TryInspect(evidenceIndex, out _)) return false;
            if (evidenceRenderers[evidenceIndex] != null && inspectedEvidenceMaterial != null)
                evidenceRenderers[evidenceIndex].sharedMaterial = inspectedEvidenceMaterial;
            RefreshInterface();
            if (IsComparisonOpen) RefreshComparison();
            if (audioFeedback != null) audioFeedback.PlayDiscovery();
            return true;
        }

        public void Close()
        {
            pendingDossierHandoff = null;
            isOpen = false;
            focusedEvidenceIndex = -1;
            gesture.Cancel();
            pointerResumeGate.Reset();
            touchChordGate.Reset();
            crestFocusActive = false;
            chapterTwoFocusActive = false;
            chapterThreeFocusActive = false;
            chapterFourFocusActive = false;
            previousPinchDistance = -1f;
            artworkViewport.Reset();
            thresholdCrest.Reset();
            crestTracing.Reset();
            lastCrestPlacement = PhysicalPlacementResult.Invalid;
            lunarDial.Reset();
            spiralPuzzle.Reset();
            if (chapterTwoPuzzle != null) chapterTwoPuzzle.Reset();
            chapterTwoPuzzle = null;
            lastChapterTwoSelection = ChapterTwoSelection.Invalid;
            if (chapterThreePuzzle != null) chapterThreePuzzle.Reset();
            chapterThreePuzzle = null;
            lastChapterThreeSelection = ChapterThreeSelection.Invalid;
            if (chapterFourPuzzle != null) chapterFourPuzzle.Reset();
            chapterFourPuzzle = null;
            lastChapterFourMove = MeridianMoveResult.Invalid;
            chapterFourVisualDesynchronized = false;
            spiralHintStage = 0;
            lastSpiralSelection = BalusterSelection.Invalid;
            lastSpiralSymbol = BalusterSymbol.Missing;
            thresholdHintStage = 0;
            lastThresholdRayIndex = -1;
            lastThresholdSelection = ThresholdRaySelection.Invalid;
            if (cinematicScene != null) cinematicScene.Release();
            cinematicScene = null;
            if (featuredSceneTexture != null)
            {
                Resources.UnloadAsset(featuredSceneTexture);
                featuredSceneTexture = null;
            }
            scenicModeButton = null;
            scenicModeCaption = null;
            threeDControls.Clear();
            scenicMode = false;
            if (sceneCamera != null) sceneCamera.enabled = false;
            if (sceneRoot != null)
            {
                sceneRoot.SetActive(false);
                Destroy(sceneRoot);
            }
            if (interfaceRoot != null)
            {
                interfaceRoot.SetActive(false);
                Destroy(interfaceRoot);
            }
            sceneRoot = null;
            interfaceRoot = null;
            safeAreaRoot = null;
            safeLayoutRoot = null;
            lastScreenWidth = -1;
            lastScreenHeight = -1;
            sceneCamera = null;
            artworkOverlay = null;
            artworkImage = null;
            comparisonOverlay = null;
            comparisonEvidenceA = null;
            comparisonEvidenceB = null;
            comparisonButton = null;
            thresholdOverlay = null;
            thresholdFeedback = null;
            thresholdButton = null;
            thresholdHintButton = null;
            thresholdHintText = null;
            chapterTwoOverlay = null;
            chapterTwoButton = null;
            chapterTwoFocusButton = null;
            chapterTwoHintButton = null;
            chapterTwoHintText = null;
            chapterTwoFeedback = null;
            chapterTwoWorldMark = null;
            chapterTwoWorldIndicator = null;
            chapterTwoWorldCollider = null;
            chapterTwoReliefMesh = null;
            chapterTwoReliefRenderer = null;
            chapterTwoSolvedMaterial = null;
            chapterThreeOverlay = null;
            chapterThreeButton = null;
            chapterThreeFocusButton = null;
            chapterThreeHintButton = null;
            chapterThreeHintText = null;
            chapterThreeFeedback = null;
            chapterThreeWorldMark = null;
            chapterThreeWorldIndicator = null;
            chapterThreeWorldCollider = null;
            chapterThreeReliefMesh = null;
            chapterThreeReliefStage = ChapterThreeReliefStage.Locked;
            chapterThreeReliefRenderer = null;
            chapterThreeSolvedMaterial = null;
            chapterFourOverlay = null;
            chapterFourButton = null;
            chapterFourFocusButton = null;
            chapterFourHintButton = null;
            chapterFourFeedback = null;
            chapterFourHintText = null;
            chapterFourWorldMark = null;
            chapterFourWorldIndicator = null;
            chapterFourWorldCollider = null;
            chapterFourReliefMesh = null;
            chapterFourReliefRenderer = null;
            chapterFourSolvedMaterial = null;
            chapterFourReliefStage = MeridianReliefStage.Locked;
            for (int index = 0; index < chapterFourSlots.Length; index++)
            {
                chapterFourSlots[index] = null;
                meridianWorldRings[index] = null;
                meridianWorldRingRenderers[index] = null;
            }
            for (int index = 0; index < chapterThreeOptions.Length; index++)
                chapterThreeOptions[index] = null;
            for (int index = 0; index < chapterTwoOptions.Length; index++)
                chapterTwoOptions[index] = null;
            spiralOverlay = null;
            spiralFeedback = null;
            spiralButton = null;
            spiralHintButton = null;
            spiralHintText = null;
            spiralMissingIcon = null;
            spiralMissingCaption = null;
            spiralMissingTile = null;
            spiralSymbolAtlas = null;
            spiralGlyphMesh = null;
            for (int index = 0; index < spiralOptions.Length; index++)
                spiralOptions[index] = null;
            for (int index = 0; index < thresholdRayRenderers.Length; index++)
            {
                thresholdRayRenderers[index] = null;
                thresholdDiagramRays[index] = null;
                thresholdDiagramButtons[index] = null;
            }
            turnRelicLeftButton = null;
            turnRelicRightButton = null;
            resetRelicButton = null;
            evidenceStatus = null;
            caseTitle = null;
            evidenceAButton = null;
            evidenceBButton = null;
            deductionButton = null;
            inspection = null;
            current = null;
            finished = null;
            pointer = null;
            pointerEventSystem = null;
            pointerHits.Clear();
            for (int index = 0; index < materials.Count; index++)
                if (materials[index] != null) Destroy(materials[index]);
            materials.Clear();
            for (int index = 0; index < ownedMeshes.Count; index++)
                if (ownedMeshes[index] != null) Destroy(ownedMeshes[index]);
            ownedMeshes.Clear();
            for (int index = 0; index < ownedTextures.Count; index++)
                if (ownedTextures[index] != null) Destroy(ownedTextures[index]);
            ownedTextures.Clear();
            for (int index = 0; index < relicRoots.Length; index++)
            {
                evidenceRenderers[index] = null;
                relicRoots[index] = null;
                relicInitialRotations[index] = Quaternion.identity;
                relicYawDegrees[index] = 0f;
            }
            inspectedEvidenceMaterial = null;
            crestOriginalMaterial = null;
            crestIncorrectMaterial = null;
            crestVerifiedMaterial = null;
        }

        private enum PointerPhase
        {
            Began,
            Held,
            Ended,
            Cancelled
        }

        private void Update()
        {
            if (!isOpen || sceneCamera == null) return;
            if (!applicationFocused || applicationPaused) return;
            if (pointerResumeGate.IsAwaitingRelease &&
                !pointerResumeGate.MayProcessFrame(AnyWorldPointerHeld()))
            {
                gesture.Cancel();
                previousPinchDistance = -1f;
                return;
            }
            // An open evidence inspection takes Back before every chapter-level exit.
            // This keeps Android navigation inside the current location and never
            // awards a clue as a side effect of dismissing its preview.
            if (cinematicScene != null && cinematicScene.IsEvidencePreviewOpen)
            {
                if (IsBackPressedThisFrame()) cinematicScene.TryCloseEvidencePreview();
                gesture.Cancel();
                previousPinchDistance = -1f;
                return;
            }
            if (current != null && current.ChapterNumber == 1 && IsBackPressedThisFrame())
            {
                TryNavigateChapterOneBack();
                return;
            }
            if (current != null && current.ChapterNumber == 2 && IsBackPressedThisFrame())
            {
                TryNavigateBack();
                return;
            }
            if (current != null && current.ChapterNumber == 3 && IsBackPressedThisFrame())
            {
                TryNavigateChapterThreeBack();
                return;
            }
            if (current != null && current.ChapterNumber == 4 && IsBackPressedThisFrame())
            {
                TryNavigateChapterFourBack();
                return;
            }
            if (IsArtworkOpen || IsComparisonOpen)
            {
                gesture.Cancel();
                previousPinchDistance = -1f;
                return;
            }
            if (IsThresholdOpen || IsSpiralOpen || IsChapterTwoOpen)
            {
                gesture.Cancel();
                previousPinchDistance = -1f;
                return;
            }

            if (IsChapterThreeOpen || IsChapterFourOpen)
            {
                gesture.Cancel();
                previousPinchDistance = -1f;
                return;
            }
            int touchContacts = ActiveWorldTouchCount();
            bool mayProcessSinglePointer = touchChordGate.MayProcessSinglePointer(touchContacts);
            if (!mayProcessSinglePointer) gesture.Cancel();
            if (scenicMode)
            {
                gesture.Cancel();
                bool pinching = touchContacts == 2 && TryGetPinchDistance(out float distance,
                    out Vector2 firstTouch, out Vector2 secondTouch) &&
                    Screen.safeArea.Contains(firstTouch) && Screen.safeArea.Contains(secondTouch);
                if (cinematicScene != null)
                {
                    cinematicScene.SetPinchActive(pinching);
                    if (pinching && previousPinchDistance > 0f)
                        cinematicScene.TryZoom((distance - previousPinchDistance) * .0015f);
                }
                previousPinchDistance = pinching ? distance : -1f;
                return;
            }

            if (touchContacts == 2 && TryGetPinchDistance(out float pinchDistance, out Vector2 pinchFirst,
                out Vector2 pinchSecond))
            {
                gesture.Cancel();
                if (!IsWorldPointerAllowed(pinchFirst) || !IsWorldPointerAllowed(pinchSecond))
                {
                    previousPinchDistance = -1f;
                    return;
                }
                if (previousPinchDistance > 0f)
                    Zoom((previousPinchDistance - pinchDistance) * PinchZoomUnitsPerPixel);
                previousPinchDistance = pinchDistance;
                return;
            }
            previousPinchDistance = -1f;
            if (!mayProcessSinglePointer) return;

            if (TryReadPointer(out Vector2 position, out PointerPhase phase))
                ProcessPointer(position, phase);

            if (TryGetMouseWheel(out float wheel, out Vector2 mousePosition) &&
                IsWorldPointerAllowed(mousePosition))
            {
                Zoom(wheel > 0f ? -.8f : .8f);
            }
        }

        /// <summary>
        /// Every world gesture, including a two-finger zoom, must remain inside the
        /// camera viewport and outside interactive UI. This check is shared across
        /// all authored locations so future chapters cannot reintroduce input leaks.
        /// </summary>
        /// <summary>
        /// The Android Back key is delivered as Escape when the application owns it.
        /// The keyboard path matches the project's active input backend.
        /// </summary>
        private static bool IsBackPressedThisFrame()
        {
#if ENABLE_INPUT_SYSTEM
            Keyboard keyboard = Keyboard.current;
            return keyboard != null && keyboard.escapeKey.wasPressedThisFrame;
#else
            return Input.GetKeyDown(KeyCode.Escape);
#endif
        }

        /// <summary>
        /// Chapter Two navigation consumes one layer per request: modal, camera focus,
        /// then return to the atlas. This never commits deduction or changes evidence.
        /// </summary>
        public bool TryNavigateBack()
        {
            if (!IsChapterTwoLocation) return false;
            if (IsChapterTwoOpen)
            {
                CloseChapterTwoViewer();
                return true;
            }
            if (IsArtworkOpen)
            {
                SetArtworkFocus(false);
                return true;
            }
            if (IsComparisonOpen)
            {
                CloseComparison();
                return true;
            }
            if (chapterTwoFocusActive || focusedEvidenceIndex >= 0 ||
                Mathf.Abs(cameraDistance - DefaultCameraDistance) > .0001f ||
                Mathf.Abs(cameraYaw) > .0001f)
            {
                ReturnToOverview();
                return true;
            }
            Finish(false);
            return true;
        }

        /// <summary>One-layer Back behavior scoped to Chapter Three only.</summary>
        public bool TryNavigateChapterThreeBack()
        {
            if (!IsChapterThreeLocation) return false;
            if (IsChapterThreeOpen)
            {
                CloseChapterThreeViewer();
                return true;
            }
            if (IsArtworkOpen)
            {
                SetArtworkFocus(false);
                return true;
            }
            if (IsComparisonOpen)
            {
                CloseComparison();
                return true;
            }
            if (chapterThreeFocusActive || focusedEvidenceIndex >= 0 ||
                Mathf.Abs(cameraDistance - DefaultCameraDistance) > .0001f ||
                Mathf.Abs(cameraYaw) > .0001f)
            {
                ReturnToOverview();
                return true;
            }
            Finish(false);
            return true;
        }

        /// <summary>Back dismisses a Chapter Four modal, then focus, then atlas.</summary>
        public bool TryNavigateChapterFourBack()
        {
            if (!IsChapterFourLocation) return false;
            if (IsChapterFourOpen)
            {
                CloseChapterFourViewer();
                return true;
            }
            if (IsArtworkOpen)
            {
                SetArtworkFocus(false);
                return true;
            }
            if (IsComparisonOpen)
            {
                CloseComparison();
                return true;
            }
            if (chapterFourFocusActive || focusedEvidenceIndex >= 0 ||
                Mathf.Abs(cameraDistance - DefaultCameraDistance) > .0001f ||
                Mathf.Abs(cameraYaw) > .0001f)
            {
                ReturnToOverview();
                return true;
            }
            Finish(false);
            return true;
        }

        /// <summary>
        /// Chapter One's Android Back/Escape follows the same one-layer policy as
        /// later chapters: cancel mechanism, close inspection, reset camera, exit.
        /// This never records evidence or commits a puzzle answer.
        /// </summary>
        public bool TryNavigateChapterOneBack()
        {
            if (!isOpen || current == null || current.ChapterNumber != 1) return false;
            if (cinematicScene != null && cinematicScene.IsEvidencePreviewOpen)
                return cinematicScene.TryCloseEvidencePreview();
            if (IsThresholdOpen)
            {
                CloseThresholdViewer();
                return true;
            }
            if (IsSpiralOpen)
            {
                CloseSpiralViewer();
                return true;
            }
            if (IsArtworkOpen)
            {
                SetArtworkFocus(false);
                return true;
            }
            if (IsComparisonOpen)
            {
                CloseComparison();
                return true;
            }
            if (crestFocusActive || focusedEvidenceIndex >= 0 ||
                Mathf.Abs(cameraDistance - DefaultCameraDistance) > .0001f ||
                Mathf.Abs(cameraYaw) > .0001f)
            {
                ReturnToOverview();
                return true;
            }
            Finish(false);
            return true;
        }

        private bool IsWorldPointerAllowed(Vector2 position)
        {
            return sceneCamera != null && sceneCamera.pixelRect.Contains(position) &&
                !IsPointerOverInterface(position);
        }

        private void ProcessPointer(Vector2 position, PointerPhase phase)
        {
            switch (phase)
            {
                case PointerPhase.Began:
                    gesture.Cancel();
                    if (IsWorldPointerAllowed(position))
                        gesture.Begin(position);
                    break;
                case PointerPhase.Held:
                    if (!gesture.IsActive) break;
                    if (!IsWorldPointerAllowed(position))
                    {
                        gesture.Cancel();
                        break;
                    }
                    float horizontalDelta = gesture.Move(position);
                    if (horizontalDelta != 0f)
                        Rotate(horizontalDelta * DragYawDegreesPerPixel);
                    break;
                case PointerPhase.Ended:
                    bool withinWorld = IsWorldPointerAllowed(position);
                    if (gesture.End(position) && withinWorld)
                        InspectAtScreenPoint(position);
                    break;
                case PointerPhase.Cancelled:
                    gesture.Cancel();
                    break;
            }
        }

        private void InspectAtScreenPoint(Vector2 position)
        {
            if (!isOpen || sceneCamera == null || current == null ||
                IsArtworkOpen || IsComparisonOpen || IsThresholdOpen || IsChapterTwoOpen) return;
            if (IsSpiralOpen || IsChapterThreeOpen || IsChapterFourOpen) return;

            // Both chapter-one locations must respect the nearest opaque foreground collider.
            // Noninteractive scenery has disabled colliders, while future authored doors or
            // blockers can deliberately prevent seeing evidence through solid geometry.
            bool thresholdLocation = current.LocationNumber == 1;
            int layerMask = (1 << EvidenceLayer) | (1 << SceneryLayer);
            if (!Physics.Raycast(sceneCamera.ScreenPointToRay(position), out RaycastHit hit,
                100f, layerMask, QueryTriggerInteraction.Ignore) ||
                hit.collider.gameObject.layer != EvidenceLayer) return;
            if (current.ChapterNumber == 2 &&
                hit.collider == chapterTwoWorldCollider)
            {
                TryOpenChapterTwoViewer();
                return;
            }
            if (current.ChapterNumber == 3 && hit.collider == chapterThreeWorldCollider)
            {
                TryOpenChapterThreeViewer();
                return;
            }
            if (current.ChapterNumber == 4 && hit.collider == chapterFourWorldCollider)
            {
                TryOpenChapterFourViewer();
                return;
            }
            if (thresholdLocation)
            {
                ThresholdCrestRayMarker ray =
                    hit.collider.GetComponent<ThresholdCrestRayMarker>();
                if (ray != null)
                {
                    if (!IsThresholdOpen) TryOpenThresholdViewer();
                    if (IsThresholdOpen) TrySelectThresholdRayWithTracing(ray.RayIndex);
                    return;
                }
            }
            ChapterWorldEvidenceMarker marker =
                hit.collider.GetComponentInParent<ChapterWorldEvidenceMarker>();
            if (marker == null || marker.LocationNumber != ActiveLocation) return;
            TryInspectEvidence(marker.EvidenceIndex);
        }

        private void LateUpdate()
        {
            if (isOpen) UpdateSafeArea();
        }

        private void UpdateSafeArea()
        {
            if (safeAreaRoot == null || safeLayoutRoot == null) return;
            int width = Screen.width;
            int height = Screen.height;
            if (width <= 0 || height <= 0) return;
            Rect safe = Screen.safeArea;
            safe.xMin = Mathf.Clamp(safe.xMin, 0f, width);
            safe.xMax = Mathf.Clamp(safe.xMax, 0f, width);
            safe.yMin = Mathf.Clamp(safe.yMin, 0f, height);
            safe.yMax = Mathf.Clamp(safe.yMax, 0f, height);
            if (safe.width <= 0f || safe.height <= 0f)
                safe = new Rect(0f, 0f, width, height);
            if (lastScreenWidth == width && lastScreenHeight == height && lastSafeArea == safe) return;
            lastScreenWidth = width;
            lastScreenHeight = height;
            lastSafeArea = safe;
            safeAreaRoot.anchorMin = new Vector2(safe.xMin / width, safe.yMin / height);
            safeAreaRoot.anchorMax = new Vector2(safe.xMax / width, safe.yMax / height);
            safeAreaRoot.offsetMin = safeAreaRoot.offsetMax = Vector2.zero;
            float scale = Mathf.Min(width / 1600f, height / 900f);
            float virtualWidth = safe.width / Mathf.Max(.0001f, scale);
            float virtualHeight = safe.height / Mathf.Max(.0001f, scale);
            float fit = Mathf.Min(1f, virtualWidth / 1600f, virtualHeight / 900f);
            safeLayoutRoot.localScale = Vector3.one * Mathf.Max(.01f, fit);
        }

        private static int ActiveWorldTouchCount()
        {
#if ENABLE_INPUT_SYSTEM
            Touchscreen screen = Touchscreen.current;
            if (screen == null) return 0;
            int count = 0;
            foreach (var touch in screen.touches)
                if (touch.press.isPressed) count++;
            return count;
#elif ENABLE_LEGACY_INPUT_MANAGER
            int count = 0;
            for (int index = 0; index < Input.touchCount; index++)
            {
                Touch touch = Input.GetTouch(index);
                if (touch.phase != TouchPhase.Ended && touch.phase != TouchPhase.Canceled)
                    count++;
            }
            return count;
#else
            return 0;
#endif
        }

        private static bool AnyWorldPointerHeld()
        {
#if ENABLE_INPUT_SYSTEM
            Touchscreen screen = Touchscreen.current;
            if (screen != null)
            {
                foreach (var touch in screen.touches)
                    if (touch.press.isPressed) return true;
            }
            Mouse mouse = Mouse.current;
            return mouse != null && mouse.leftButton.isPressed;
#else
            return Input.touchCount > 0 || Input.GetMouseButton(0);
#endif
        }

        private static bool TryReadPointer(out Vector2 position, out PointerPhase phase)
        {
            position = Vector2.zero;
            phase = PointerPhase.Cancelled;
#if ENABLE_INPUT_SYSTEM
            Touchscreen touchscreen = Touchscreen.current;
            if (touchscreen != null)
            {
                var touch = touchscreen.primaryTouch;
                if (touch.press.isPressed || touch.press.wasReleasedThisFrame)
                {
                    position = touch.position.ReadValue();
                    phase = touch.press.wasPressedThisFrame ? PointerPhase.Began :
                        touch.press.wasReleasedThisFrame ? PointerPhase.Ended : PointerPhase.Held;
                    return true;
                }
            }
            Mouse mouse = Mouse.current;
            if (mouse == null) return false;
            if (mouse.leftButton.wasPressedThisFrame || mouse.leftButton.isPressed ||
                mouse.leftButton.wasReleasedThisFrame)
            {
                position = mouse.position.ReadValue();
                phase = mouse.leftButton.wasPressedThisFrame ? PointerPhase.Began :
                    mouse.leftButton.wasReleasedThisFrame ? PointerPhase.Ended : PointerPhase.Held;
                return true;
            }
#else
            if (Input.touchCount > 0)
            {
                Touch touch = Input.GetTouch(0);
                position = touch.position;
                phase = touch.phase == TouchPhase.Began ? PointerPhase.Began :
                    touch.phase == TouchPhase.Ended ? PointerPhase.Ended :
                    touch.phase == TouchPhase.Canceled ? PointerPhase.Cancelled : PointerPhase.Held;
                return true;
            }
            if (Input.GetMouseButtonDown(0) || Input.GetMouseButton(0) || Input.GetMouseButtonUp(0))
            {
                position = Input.mousePosition;
                phase = Input.GetMouseButtonDown(0) ? PointerPhase.Began :
                    Input.GetMouseButtonUp(0) ? PointerPhase.Ended : PointerPhase.Held;
                return true;
            }
#endif
            return false;
        }

        private static bool TryGetPinchDistance(out float distance, out Vector2 firstPosition,
            out Vector2 secondPosition)
        {
            distance = 0f;
            firstPosition = Vector2.zero;
            secondPosition = Vector2.zero;
#if ENABLE_INPUT_SYSTEM
            Touchscreen touchscreen = Touchscreen.current;
            if (touchscreen == null) return false;
            int count = 0;
            Vector2 first = Vector2.zero;
            for (int index = 0; index < touchscreen.touches.Count; index++)
            {
                var touch = touchscreen.touches[index];
                if (!touch.press.isPressed) continue;
                if (count == 0) first = touch.position.ReadValue();
                else
                {
                    firstPosition = first;
                    secondPosition = touch.position.ReadValue();
                    distance = Vector2.Distance(firstPosition, secondPosition);
                    return !float.IsNaN(distance) && !float.IsInfinity(distance) &&
                        distance > .001f;
                }
                count++;
            }
#else
            if (Input.touchCount < 2) return false;
            Touch first = Input.GetTouch(0);
            Touch second = Input.GetTouch(1);
            if (first.phase == TouchPhase.Ended || first.phase == TouchPhase.Canceled ||
                second.phase == TouchPhase.Ended || second.phase == TouchPhase.Canceled)
                return false;
            firstPosition = first.position;
            secondPosition = second.position;
            distance = Vector2.Distance(firstPosition, secondPosition);
            return !float.IsNaN(distance) && !float.IsInfinity(distance) &&
                distance > .001f;
#endif
            return false;
        }

        private static bool TryGetMouseWheel(out float delta, out Vector2 position)
        {
            delta = 0f;
            position = Vector2.zero;
#if ENABLE_INPUT_SYSTEM
            Mouse mouse = Mouse.current;
            if (mouse == null) return false;
            delta = mouse.scroll.ReadValue().y;
            position = mouse.position.ReadValue();
#else
            if (Input.touchCount != 0) return false;
            delta = Input.mouseScrollDelta.y;
            position = Input.mousePosition;
#endif
            return !float.IsNaN(delta) && !float.IsInfinity(delta) && Mathf.Abs(delta) > .001f;
        }

        private bool IsPointerOverInterface(Vector2 position)
        {
            EventSystem system = EventSystem.current;
            if (system == null) return true;
            if (pointerEventSystem != system || pointer == null)
            {
                pointerEventSystem = system;
                pointer = new PointerEventData(system);
            }
            pointer.Reset();
            pointer.position = position;
            pointerHits.Clear();
            system.RaycastAll(pointer, pointerHits);
            return pointerHits.Count > 0;
        }

        private void BuildWorld(Texture2D referenceArtwork)
        {
            sceneRoot = new GameObject("3D Chapter Case - " + current.LocationNumber.ToString("00"));
            sceneRoot.transform.SetParent(transform, false);
            // The environment's original, bounded soundscape follows the world lifecycle.
            // It does not observe or mutate puzzles, deductions or persistence.
            try
            {
                sceneRoot.AddComponent<ChapterWorldAtmosphere>().Initialize(current.ChapterNumber);
            }
            catch (Exception error)
            {
                // Optional sound must never prevent a puzzle or chapter from opening.
                var atmosphere = sceneRoot.GetComponent<ChapterWorldAtmosphere>();
                if (atmosphere != null) atmosphere.enabled = false;
                Debug.LogWarning("Optional chapter ambience unavailable: " + error.GetType().Name, this);
            }
            var cameraObject = new GameObject("3D Case Camera");
            cameraObject.transform.SetParent(sceneRoot.transform, false);
            sceneCamera = cameraObject.AddComponent<Camera>();
            sceneCamera.tag = "Untagged";
            sceneCamera.cullingMask = (1 << SceneryLayer) | (1 << EvidenceLayer);
            sceneCamera.clearFlags = CameraClearFlags.SolidColor;
            sceneCamera.backgroundColor = Ink;
            sceneCamera.fieldOfView = 53f;
            sceneCamera.nearClipPlane = .1f;
            sceneCamera.farClipPlane = 42f;
            sceneCamera.depth = 15f;
            SetCameraOrbit();

            // One authored location profile lights the geometry and both evidence pedestals.
            // The rig is owned by sceneRoot, so Close() destroys every light with the world.
            ChapterWorldLightingRig.Create(sceneRoot.transform, current.LocationNumber,
                SceneryLayer, EvidenceLayer);

            var palette = ColorPalette(current.ChapterNumber);
            Material stone = CreateColorMaterial("Chapter Stone", palette[0]);
            Material darkStone = CreateColorMaterial("Chapter Slate", palette[1]);
            Texture2D ownedStoneTexture = ChapterWorldStoneSurface.Create(current.ChapterNumber);
            ownedTextures.Add(ownedStoneTexture);
            stone.mainTexture = ownedStoneTexture;
            stone.mainTextureScale = new Vector2(2f, 2f);
            darkStone.mainTexture = ownedStoneTexture;
            darkStone.mainTextureScale = new Vector2(2f, 2f);
            Material metal = CreateColorMaterial("Antique Brass", Brass);
            ConfigureStandardSurface(metal, .54f, .32f);
            ConfigureStandardSurface(stone, 0f, .12f);
            ConfigureStandardSurface(darkStone, 0f, .08f);
            Material glow = CreateColorMaterial("Evidence Ceramic", new Color(.9f, .72f, .43f));
            ChapterWorldLightingProfile lighting = ChapterWorldLightingRig.Get(current.LocationNumber);
            Material lanternGlass = CreateColorMaterial("Lantern Glass", lighting.RightFillColor);
            if (lanternGlass.HasProperty("_EmissionColor"))
            {
                lanternGlass.EnableKeyword("_EMISSION");
                lanternGlass.SetColor("_EmissionColor", lighting.RightFillColor * .16f);
            }
            Material detail = CreateColorMaterial("Chapter Accent", palette[2]);
            inspectedEvidenceMaterial = CreateColorMaterial("Inspected Evidence",
                new Color(.17f, .43f, .33f));

            // Photo-backed theatrical set: the image remains a reference texture, not fake geometry.
            CreatePrimitive("Stage Floor", PrimitiveType.Cube, new Vector3(0f, -.21f, .4f),
                new Vector3(11.5f, .4f, 8.0f), darkStone);
            CreatePrimitive("Rear Wall", PrimitiveType.Cube, new Vector3(0f, 2.6f, 3.58f),
                new Vector3(11.5f, 6f, .35f), stone);
            CreatePrimitive("Left Buttress", PrimitiveType.Cube, new Vector3(-5.45f, 2.4f, 1.1f),
                new Vector3(.4f, 5f, 5f), stone);
            CreatePrimitive("Right Buttress", PrimitiveType.Cube, new Vector3(5.45f, 2.4f, 1.1f),
                new Vector3(.4f, 5f, 5f), stone);

            var imageMaterial = CreateReferenceMaterial(referenceArtwork);
            // The first authored photograph is letterboxed with blurred side extensions.
            // Display its actual central doorway at its native aspect ratio in the stage;
            // leave the full, original Texture2D unchanged for VIEW ORIGINAL ART.
            bool cropChapterOnePhoto = current.LocationNumber == 1 &&
                referenceArtwork.width == ChapterOneReferenceWidth &&
                referenceArtwork.height == ChapterOneReferenceHeight;
            float referenceWidth = DefaultReferencePanelWidth;
            if (cropChapterOnePhoto)
            {
                imageMaterial.mainTextureScale = new Vector2(
                    (float)ChapterOneCropWidth / ChapterOneReferenceWidth, 1f);
                imageMaterial.mainTextureOffset = new Vector2(
                    (float)ChapterOneCropLeft / ChapterOneReferenceWidth, 0f);
                referenceWidth = ReferencePanelHeight * ChapterOneCropWidth /
                    ChapterOneReferenceHeight;
            }
            else if (current.LocationNumber == SpiralBalusterPuzzle.LocationNumber &&
                referenceArtwork.width == SpiralReferenceWidth &&
                referenceArtwork.height == SpiralReferenceHeight)
            {
                imageMaterial.mainTextureScale = new Vector2(
                    (float)SpiralCropWidth / SpiralReferenceWidth, 1f);
                imageMaterial.mainTextureOffset = new Vector2(
                    (float)SpiralCropLeft / SpiralReferenceWidth, 0f);
                referenceWidth = ReferencePanelHeight * SpiralCropWidth /
                    SpiralReferenceHeight;
            }
            GameObject reference = CreatePrimitive("Original Location Reference Panel", PrimitiveType.Quad,
                new Vector3(0f, 3.05f, 3.35f),
                new Vector3(referenceWidth, ReferencePanelHeight, 1f), imageMaterial);
            // Unity Quad faces local -Z. The panel must face the camera at negative world Z.
            reference.transform.localRotation = Quaternion.identity;
            CreatePrimitive("Reference Frame Top", PrimitiveType.Cube, new Vector3(0f, 5.56f, 3.25f),
                new Vector3(referenceWidth + .2f, .11f, .13f), metal);
            CreatePrimitive("Reference Frame Bottom", PrimitiveType.Cube, new Vector3(0f, .54f, 3.25f),
                new Vector3(referenceWidth + .2f, .11f, .13f), metal);
            float frameSideX = (referenceWidth + .1f) * .5f;
            foreach (float x in new[] { -frameSideX, frameSideX })
                CreatePrimitive("Reference Frame Side", PrimitiveType.Cube, new Vector3(x, 3.05f, 3.25f),
                    new Vector3(.11f, 5.05f, .13f), metal);
            BuildWallLightingDetails(darkStone, metal, lanternGlass);

            BuildSetGeometry(current.SetType, stone, darkStone, metal, detail);
            if (current.ChapterNumber == 2)
                BuildChapterTwoWorldDisplay(stone, darkStone, metal);
            if (current.ChapterNumber == 3)
                BuildChapterThreeWorldDisplay(stone, darkStone, metal);
            if (current.ChapterNumber == 4)
                BuildChapterFourWorldDisplay(stone, darkStone, metal);
            if (current.LocationNumber == 1)
            {
                BuildFirstChapterThresholdSet(stone, darkStone, metal);
                BuildThresholdCrest(metal, darkStone);
            }
            if (current.LocationNumber == SpiralBalusterPuzzle.LocationNumber)
                BuildSpiralBalusterMotifs(metal);
            CreateVaultCanopy(stone);
            CreateInvestigationFloorSigil(metal);
            // Three architectural spans frame the artwork without approximating its geometry.
            // Geometry is constructed per world and deterministically disposed on Close.
            CreateArchitecturalArch("Central Gothic Portal", 0f, 2.05f, .25f,
                .38f, 1.25f, 2.48f, metal);
            CreateArchitecturalArch("Left Gothic Arcade", -3.27f, 1.09f, .17f,
                .28f, 1.18f, 2.52f, stone);
            CreateArchitecturalArch("Right Gothic Arcade", 3.27f, 1.09f, .17f,
                .28f, 1.18f, 2.52f, stone);
            CreateEvidencePedestal(0, -2.35f, glow, metal, darkStone);
            CreateEvidencePedestal(1, 2.35f, glow, metal, darkStone);
            AddWorldLabel("Evidence A Label", "A  -  " + current.EvidenceALabel,
                new Vector3(-2.35f, .24f, -2.17f), .13f, Ivory);
            AddWorldLabel("Evidence B Label", "B  -  " + current.EvidenceBLabel,
                new Vector3(2.35f, .24f, -2.17f), .13f, Ivory);
        }

        /// <summary>
        /// The first portal is a physical companion to the unchanged photographic artwork.
        /// Every element is non-interactive and uses the existing shared stone/brass surfaces.
        /// The four treads rise towards the authored gothic doorway without occluding the
        /// investigation pedestals or consuming any extra realtime lights.
        /// </summary>
        private void BuildFirstChapterThresholdSet(Material stone, Material slate, Material brass)
        {
            for (int step = 0; step < 4; step++)
            {
                float rise = .13f * (step + 1);
                float depth = .12f + step * .58f;
                float width = 6.7f - step * .18f;
                CreatePrimitive("Chapter One Stair Tread " + (step + 1), PrimitiveType.Cube,
                    new Vector3(0f, rise * .5f - .012f, depth),
                    new Vector3(width, rise, .60f), stone);
                CreatePrimitive("Chapter One Brass Stair Nosing " + (step + 1), PrimitiveType.Cube,
                    new Vector3(0f, rise - .002f, depth - .286f),
                    new Vector3(width - .14f, .022f, .042f), brass);
            }

            for (int side = 0; side < 2; side++)
            {
                float sign = side == 0 ? -1f : 1f;
                string direction = sign < 0f ? "West" : "East";
                CreatePrimitive("Chapter One " + direction + " Door Jamb", PrimitiveType.Cube,
                    new Vector3(sign * 3.93f, 3.04f, 2.78f),
                    new Vector3(.24f, 4.82f, .32f), slate);
                CreatePrimitive("Chapter One " + direction + " Brass Reveal", PrimitiveType.Cube,
                    new Vector3(sign * 3.77f, 3.04f, 2.58f),
                    new Vector3(.052f, 4.46f, .07f), brass);
                CreatePrimitive("Chapter One " + direction + " Pilaster Plinth", PrimitiveType.Cube,
                    new Vector3(sign * 3.93f, .41f, 2.74f),
                    new Vector3(.58f, .72f, .70f), stone);
            }
        }

        private void BuildThresholdCrest(Material brass, Material slate)
        {
            if (!ThresholdCrestPuzzle.ValidateGeometryContract())
                throw new InvalidOperationException("Invalid threshold crest geometry contract.");
            crestOriginalMaterial = brass;
            crestIncorrectMaterial = CreateColorMaterial("Rejected Crest Ray", new Color(.86f, .35f, .35f));
            crestVerifiedMaterial = CreateColorMaterial("Verified Crest Ray", new Color(.32f, .78f, .50f));
            ConfigureStandardSurface(crestIncorrectMaterial, .38f, .18f);
            ConfigureStandardSurface(crestVerifiedMaterial, .38f, .18f);
            const float sealCenterX = 0f;
            const float letterCenterX = -2.14f;
            const float centerY = 2.88f;
            GameObject sealBase = CreatePrimitive("Arch Crest Backplate",
                PrimitiveType.Cylinder, new Vector3(sealCenterX, centerY, -.28f),
                new Vector3(.78f, .07f, .78f), slate);
            sealBase.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            GameObject letterBase = CreatePrimitive("Letter Crest Reference",
                PrimitiveType.Cylinder, new Vector3(letterCenterX, centerY, -.25f),
                new Vector3(.50f, .07f, .50f), slate);
            letterBase.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            CreateCrestEngraving("Original Letter Engraved Ring",
                new Vector3(letterCenterX, centerY, -.455f), .57f, .525f, brass);
            CreateCrestEngraving("Altered Arch Engraved Ring",
                new Vector3(sealCenterX, centerY, -.525f), .88f, .825f, brass);
            for (int index = 0; index < ThresholdCrestPuzzle.LetterRayAngles.Count; index++)
            {
                float degrees = ThresholdCrestPuzzle.LetterRayAngles[index];
                float radians = degrees * Mathf.Deg2Rad;
                GameObject letterRay = CreatePrimitive("Letter Crest Original Ray " +
                    (index + 1), PrimitiveType.Cube,
                    new Vector3(letterCenterX + Mathf.Cos(radians) * .34f,
                        centerY + Mathf.Sin(radians) * .34f, -.39f),
                    new Vector3(.105f, .28f, .10f), brass);
                letterRay.transform.localRotation = Quaternion.Euler(0f, 0f, degrees - 90f);
            }
            for (int index = 0; index < ThresholdCrestPuzzle.SealRayAngles.Count; index++)
            {
                float degrees = ThresholdCrestPuzzle.SealRayAngles[index];
                float radians = degrees * Mathf.Deg2Rad;
                GameObject archRay = CreatePrimitive("Arch Crest Ray " + (index + 1),
                    PrimitiveType.Cube,
                    new Vector3(sealCenterX + Mathf.Cos(radians) * .58f,
                        centerY + Mathf.Sin(radians) * .58f, -.45f),
                    new Vector3(.17f, .43f, .12f), brass, true);
                archRay.transform.localRotation = Quaternion.Euler(0f, 0f, degrees - 90f);
                archRay.AddComponent<ThresholdCrestRayMarker>().Configure(index);
                thresholdRayRenderers[index] = archRay.GetComponent<Renderer>();
            }
            AddWorldLabel("Letter Crest Heading", "ORIGINAL: FIVE RAYS",
                new Vector3(letterCenterX, 1.95f, -.45f), .14f, Ivory);
            AddWorldLabel("Arch Crest Heading", "ALTERED SEAL: SIX RAYS",
                new Vector3(sealCenterX, 1.62f, -.45f), .14f, Ivory);
            CreateCrestRayStuds(letterCenterX, sealCenterX, centerY, brass);
        }

        private void CreateCrestEngraving(string name, Vector3 center,
            float outerRadius, float innerRadius, Material material)
        {
            Mesh mesh = ChapterOneCrestReliefMesh.CreateRing(outerRadius, innerRadius, 48);
            ownedMeshes.Add(mesh);
            GameObject relief = new GameObject(name, typeof(MeshFilter), typeof(MeshRenderer));
            relief.layer = SceneryLayer;
            relief.transform.SetParent(sceneRoot.transform, false);
            relief.transform.localPosition = center;
            relief.GetComponent<MeshFilter>().sharedMesh = mesh;
            relief.GetComponent<MeshRenderer>().sharedMaterial = material;
        }

        /// <summary>
        /// All eleven orientation studs are one owned mesh, one draw surface and no collider.
        /// These details are visual only; the domain remains authoritative for answers.
        /// </summary>
        private void CreateCrestRayStuds(float letterCenterX, float sealCenterX,
            float centerY, Material brass)
        {
            var positions = new List<Vector2>(11);
            foreach (int degrees in ThresholdCrestPuzzle.LetterRayAngles)
            {
                float radians = degrees * Mathf.Deg2Rad;
                positions.Add(new Vector2(letterCenterX + Mathf.Cos(radians) * .485f,
                    centerY + Mathf.Sin(radians) * .485f));
            }
            foreach (int degrees in ThresholdCrestPuzzle.SealRayAngles)
            {
                float radians = degrees * Mathf.Deg2Rad;
                positions.Add(new Vector2(sealCenterX + Mathf.Cos(radians) * .795f,
                    centerY + Mathf.Sin(radians) * .795f));
            }
            Mesh mesh = ChapterOneCrestReliefMesh.CreateStuds(positions, .042f);
            ownedMeshes.Add(mesh);
            var studs = new GameObject("First Chapter Engraved Crest Studs",
                typeof(MeshFilter), typeof(MeshRenderer));
            studs.layer = SceneryLayer;
            studs.transform.SetParent(sceneRoot.transform, false);
            studs.transform.localPosition = new Vector3(0f, 0f, -.54f);
            studs.GetComponent<MeshFilter>().sharedMesh = mesh;
            studs.GetComponent<MeshRenderer>().sharedMaterial = brass;
        }

        /// <summary>
        /// Bounded architectural accents sit outside the reference artwork's horizontal extent.
        /// All parts share existing materials and have no colliders or runtime update cost.
        /// </summary>
        private void BuildWallLightingDetails(Material darkStone, Material metal, Material glow)
        {
            for (int index = 0; index < 2; index++)
            {
                float direction = index == 0 ? -1f : 1f;
                string side = index == 0 ? "Left" : "Right";
                float x = direction * 4.95f;
                CreatePrimitive(side + " Recessed Wall Panel", PrimitiveType.Cube,
                    new Vector3(x, 2.68f, 3.29f), new Vector3(.72f, 3.84f, .12f), darkStone);
                CreatePrimitive(side + " Recessed Wall Lintel", PrimitiveType.Cube,
                    new Vector3(x, 4.63f, 3.19f), new Vector3(.84f, .14f, .22f), metal);
                CreatePrimitive(side + " Recessed Wall Sill", PrimitiveType.Cube,
                    new Vector3(x, .72f, 3.19f), new Vector3(.84f, .14f, .22f), metal);
                CreatePrimitive(side + " Lantern Wall Bracket", PrimitiveType.Cube,
                    new Vector3(x, 2.78f, 2.97f), new Vector3(.26f, .65f, .36f), metal);
                CreatePrimitive(side + " Lantern Housing", PrimitiveType.Cube,
                    new Vector3(x, 3.29f, 2.79f), new Vector3(.40f, .67f, .40f), metal);
                CreatePrimitive(side + " Lantern Diffuser", PrimitiveType.Sphere,
                    new Vector3(x, 3.29f, 2.55f), new Vector3(.30f, .43f, .22f), glow);
            }
        }

        private static Color[] ColorPalette(int chapterNumber)
        {
            switch (chapterNumber)
            {
                case 1: return new[] { new Color(.31f, .30f, .29f), new Color(.11f, .12f, .15f), new Color(.51f, .42f, .29f) };
                case 2: return new[] { new Color(.27f, .32f, .27f), new Color(.09f, .15f, .13f), new Color(.36f, .49f, .29f) };
                case 3: return new[] { new Color(.31f, .28f, .33f), new Color(.12f, .10f, .16f), new Color(.46f, .34f, .49f) };
                case 4: return new[] { new Color(.28f, .30f, .37f), new Color(.09f, .10f, .16f), new Color(.33f, .43f, .57f) };
                default: throw new ArgumentOutOfRangeException(nameof(chapterNumber));
            }
        }

        private void BuildSetGeometry(ChapterWorldSetType type, Material stone, Material darkStone,
            Material metal, Material accent)
        {
            switch (type)
            {
                case ChapterWorldSetType.Threshold:
                    PairColumns(3.45f, stone, metal);
                    CreatePrimitive("Sealed Arch Lintel", PrimitiveType.Cube, new Vector3(0f, 3.32f, .8f), new Vector3(7.5f, .58f, .8f), metal);
                    CreatePrimitive("Lost Star Seal", PrimitiveType.Sphere, new Vector3(0f, 2.9f, .18f), new Vector3(.95f, .95f, .32f), accent);
                    AddWorldLabel("Crest Comparison", "LETTER: FIVE RAYS    ARCH: SIX RAYS",
                        new Vector3(0f, 1.65f, .1f), .16f, Ivory);
                    break;
                case ChapterWorldSetType.Staircase:
                    for (int step = 0; step < 6; step++)
                        CreatePrimitive("Ceremonial Step " + step, PrimitiveType.Cube,
                            new Vector3(0f, step * .22f, 1.9f - step * .55f),
                            new Vector3(6f, .22f + step * .22f, .55f), stone);
                    PairColumns(3.5f, stone, metal);
                    AddWorldLabel("Stair Pattern", "CIRCLE  DIAMOND  STAR  |  CIRCLE  DIAMOND  ?",
                        new Vector3(0f, 1.6f, -.1f), .13f, Ivory);
                    break;
                case ChapterWorldSetType.LanternPath:
                    PairColumns(3.6f, stone, accent);
                    for (int index = 0; index < 5; index++)
                        CreatePrimitive("Lantern " + index, PrimitiveType.Sphere,
                            new Vector3(-3f + index * 1.5f, 2.1f + (index % 2) * .18f, .6f),
                            new Vector3(.36f, .52f, .36f), metal);
                    AddWorldLabel("Lunar Calibration", "NEW   WAXING   FULL   WANING",
                        new Vector3(0f, 1.3f, .1f), .18f, Ivory);
                    break;
                case ChapterWorldSetType.RosePavilion:
                    PairColumns(3.4f, stone, metal);
                    CreatePrimitive("Pavilion Roof", PrimitiveType.Cylinder, new Vector3(0f, 3.46f, 1.05f),
                        new Vector3(3.3f, .24f, 2.4f), accent);
                    CreatePrimitive("Carved Basin", PrimitiveType.Cylinder, new Vector3(0f, .55f, 1.12f),
                        new Vector3(1.8f, .35f, 1.6f), stone);
                    AddWorldLabel("Petal Counts", "2   3   5   8   ?",
                        new Vector3(0f, 1.25f, .15f), .23f, Ivory);
                    break;
                case ChapterWorldSetType.Fountain:
                    CreatePrimitive("Echo Fountain Basin", PrimitiveType.Cylinder, new Vector3(0f, .28f, 1.0f),
                        new Vector3(2.6f, .31f, 2.6f), stone);
                    CreatePrimitive("Echo Fountain Core", PrimitiveType.Cylinder, new Vector3(0f, 1.0f, 1.0f),
                        new Vector3(.64f, .86f, .64f), metal);
                    for (int index = 0; index < 4; index++)
                    {
                        float angle = (float)(index * Math.PI * .5);
                        CreatePrimitive("Numbered Spout " + (index + 1), PrimitiveType.Sphere,
                            new Vector3(Mathf.Cos(angle) * 1.15f, 1.16f, 1f + Mathf.Sin(angle) * 1.15f),
                            new Vector3(.33f, .33f, .33f), accent);
                    }
                    AddWorldLabel("Spout Constraints", "ONE FIRST  |  THREE FOLLOWS ONE  |  FOUR LAST",
                        new Vector3(0f, 2.0f, .2f), .13f, Ivory);
                    break;
                case ChapterWorldSetType.SilentCrossing:
                    for (int index = 0; index < 3; index++)
                    {
                        float x = -2.0f + index * 2f;
                        CreatePrimitive("Stone Witness " + index, PrimitiveType.Capsule,
                            new Vector3(x, 1.7f, 1.25f), new Vector3(.7f, 1.6f, .7f), stone);
                    }
                    CreatePrimitive("Crossing Skiff", PrimitiveType.Cube,
                        new Vector3(0f, .32f, .15f), new Vector3(3.9f, .38f, 1.1f), accent);
                    AddWorldLabel("Witness Direction Clue", "A: EAST  |  B: SOUTH  |  C: WEST",
                        new Vector3(0f, 2.8f, .05f), .16f, Ivory);
                    break;
                case ChapterWorldSetType.GlassTestament:
                    PairColumns(3.3f, stone, metal);
                    for (int index = 0; index < 3; index++)
                        CreatePrimitive("Stained Glass Sigil " + index, PrimitiveType.Cube,
                            new Vector3(0f, 3.25f - index * .7f, .38f),
                            new Vector3(.94f, .52f, .11f), accent);
                    AddWorldLabel("Glass Symbol Order", "TRIANGLE  /  RING  /  THREE RAYS",
                        new Vector3(0f, 1.35f, .08f), .15f, Ivory);
                    break;
                case ChapterWorldSetType.PortraitGallery:
                    PairColumns(3.1f, stone, metal);
                    for (int index = 0; index < 3; index++)
                        CreatePrimitive("Portrait Frame " + index, PrimitiveType.Cube,
                            new Vector3(-2.35f + index * 2.35f, 2.2f, 1.45f),
                            new Vector3(1.5f, 2.15f, .18f), metal);
                    AddWorldLabel("Memorial Dates", "MEMORIAL: 1904  |  PORTRAIT: 1912",
                        new Vector3(0f, .9f, .1f), .16f, Ivory);
                    break;
                case ChapterWorldSetType.WitnessStatue:
                    PairColumns(3.4f, stone, metal);
                    CreatePrimitive("Witness Plinth", PrimitiveType.Cube, new Vector3(0f, .55f, .84f),
                        new Vector3(2.1f, .9f, 1.65f), stone);
                    CreatePrimitive("Weeping Witness", PrimitiveType.Capsule, new Vector3(0f, 2.05f, .84f),
                        new Vector3(.95f, 1.45f, .88f), accent);
                    AddWorldLabel("Damaged Epitaph", "R _ M E M B E R",
                        new Vector3(0f, .78f, -.1f), .21f, Ivory);
                    break;
                case ChapterWorldSetType.MeridianRotunda:
                    PairColumns(3.55f, stone, metal);
                    for (int index = 0; index < 4; index++)
                    {
                        // A true annular mesh replaces the former flat cylinder placeholder.
                        Mesh ringMesh = ChapterWorldRingGeometry.Create(.47f + index * .135f,
                            .035f, 40, 10);
                        ownedMeshes.Add(ringMesh);
                        var ring = new GameObject("Meridian Ring " + (char)('A' + index),
                            typeof(MeshFilter), typeof(MeshRenderer));
                        ring.layer = SceneryLayer;
                        ring.transform.SetParent(sceneRoot.transform, false);
                        ring.transform.localPosition = new Vector3(0f, 1.2f, .55f);
                        ring.transform.localRotation = Quaternion.Euler(
                            18f + index * 24f, 0f, 20f + index * 33f);
                        ring.GetComponent<MeshFilter>().sharedMesh = ringMesh;
                        MeshRenderer ringRenderer = ring.GetComponent<MeshRenderer>();
                        ringRenderer.sharedMaterial = metal;
                        meridianWorldRings[index] = ring.transform;
                        meridianWorldRingRenderers[index] = ringRenderer;
                    }
                    CreatePrimitive("Celestial Sphere", PrimitiveType.Sphere, new Vector3(0f, 1.2f, .55f),
                        new Vector3(.86f, .86f, .86f), accent);
                    AddWorldLabel("Meridian Constraints", "A BEFORE C  |  B AFTER A  |  D LAST",
                        new Vector3(0f, 2.75f, .1f), .15f, Ivory);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(type));
            }
        }

        private void BuildSpiralBalusterMotifs(Material brass)
        {
            if (!SpiralBalusterPuzzle.ValidatePattern())
                throw new InvalidOperationException("The ceremonial stair pattern contract is invalid.");
            for (int index = 0; index < SpiralBalusterPuzzle.VisibleSequence.Count; index++)
            {
                float x = -2.4f + index * .96f;
                float y = .75f + index * .21f;
                float z = 1.4f - index * .55f;
                CreatePrimitive("Ceremonial Baluster " + (index + 1), PrimitiveType.Cube,
                    new Vector3(x, y, z), new Vector3(.18f, 1.25f, .22f), brass);
            }
            Mesh glyphs = ChapterWorldSpiralGlyphGeometry.Create();
            spiralGlyphMesh = glyphs;
            ownedMeshes.Add(glyphs);
            var glyphRoot = new GameObject("Ceremonial Stair Sequence", typeof(MeshFilter),
                typeof(MeshRenderer));
            glyphRoot.layer = SceneryLayer;
            glyphRoot.transform.SetParent(sceneRoot.transform, false);
            glyphRoot.GetComponent<MeshFilter>().sharedMesh = glyphs;
            glyphRoot.GetComponent<MeshRenderer>().sharedMaterial = brass;
        }

        private void CreateArchitecturalArch(string name, float x, float halfSpan,
            float bandThickness, float depth, float springHeight, float z, Material stone)
        {
            Mesh mesh = ChapterWorldGothicGeometry.CreatePointedArch(
                halfSpan, bandThickness, depth, springHeight, 16);
            ownedMeshes.Add(mesh);
            var portal = new GameObject(name, typeof(MeshFilter), typeof(MeshRenderer));
            portal.layer = SceneryLayer;
            portal.transform.SetParent(sceneRoot.transform, false);
            portal.transform.localPosition = new Vector3(x, 0f, z);
            portal.GetComponent<MeshFilter>().sharedMesh = mesh;
            portal.GetComponent<MeshRenderer>().sharedMaterial = stone;
            // A visible keystone seals the two pointed masonry halves at the crown.
            float keystoneY = springHeight + Mathf.Sqrt(3f) * halfSpan;
            CreatePrimitive(name + " Keystone", PrimitiveType.Cube,
                new Vector3(x, keystoneY, z - depth * .05f),
                new Vector3(bandThickness * 1.35f, bandThickness * 1.35f,
                    depth * 1.1f), stone);
        }

        private void CreateVaultCanopy(Material stone)
        {
            Mesh mesh = ChapterWorldVaultGeometry.CreateVault(
                5.06f, 5.71f, 1.14f, -2.65f, 3.02f, 20, 8);
            ownedMeshes.Add(mesh);
            var vault = new GameObject("Gothic Ribbed Vault", typeof(MeshFilter), typeof(MeshRenderer));
            vault.layer = SceneryLayer;
            vault.transform.SetParent(sceneRoot.transform, false);
            vault.GetComponent<MeshFilter>().sharedMesh = mesh;
            vault.GetComponent<MeshRenderer>().sharedMaterial = stone;
        }

        private void CreateInvestigationFloorSigil(Material metal)
        {
            Mesh mesh = ChapterWorldFloorSigilGeometry.Create(current.LocationNumber);
            ownedMeshes.Add(mesh);
            var inlay = new GameObject("Investigation Floor Sigil", typeof(MeshFilter),
                typeof(MeshRenderer));
            inlay.layer = SceneryLayer;
            inlay.transform.SetParent(sceneRoot.transform, false);
            inlay.transform.localPosition = new Vector3(0f, 0f, -1.18f);
            inlay.GetComponent<MeshFilter>().sharedMesh = mesh;
            inlay.GetComponent<MeshRenderer>().sharedMaterial = metal;
        }

        private void PairColumns(float x, Material stone, Material capital)
        {
            foreach (float direction in new[] { -1f, 1f })
            {
                CreatePrimitive("Gothic Column", PrimitiveType.Cylinder,
                    new Vector3(x * direction, 1.5f, .8f), new Vector3(.45f, 1.5f, .45f), stone);
                CreatePrimitive("Column Capital", PrimitiveType.Cube,
                    new Vector3(x * direction, 3.1f, .8f), new Vector3(.9f, .35f, .85f), capital);
            }
        }

        private void AddWorldLabel(string name, string message, Vector3 position, float characterSize, Color color)
        {
            var objectWithLabel = new GameObject(name, typeof(TextMesh));
            objectWithLabel.layer = SceneryLayer;
            objectWithLabel.transform.SetParent(sceneRoot.transform, false);
            objectWithLabel.transform.localPosition = position;
            objectWithLabel.transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
            TextMesh text = objectWithLabel.GetComponent<TextMesh>();
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.text = message;
            text.fontSize = 72;
            text.characterSize = characterSize;
            text.color = color;
            text.anchor = TextAnchor.MiddleCenter;
            text.alignment = TextAlignment.Center;
            Renderer renderer = objectWithLabel.GetComponent<Renderer>();
            if (text.font != null && renderer != null)
                renderer.sharedMaterial = text.font.material;
        }

        private void CreateEvidencePedestal(int index, float x, Material evidenceMaterial,
            Material trimMaterial, Material baseMaterial)
        {
            CreatePrimitive("Evidence Base " + (char)('A' + index), PrimitiveType.Cylinder,
                new Vector3(x, .34f, -1.35f), new Vector3(.75f, .34f, .75f), baseMaterial);
            CreatePrimitive("Evidence Trim", PrimitiveType.Cylinder,
                new Vector3(x, .71f, -1.35f), new Vector3(.84f, .065f, .84f), trimMaterial);
            ChapterEvidenceVisualSpec visual = ChapterEvidenceVisualCatalog.Get(current.LocationNumber, index);
            Mesh inlayMesh = ChapterWorldPedestalInlayGeometry.Create(visual.MotifCount);
            ownedMeshes.Add(inlayMesh);
            var pedestalInlay = new GameObject("Evidence Pedestal Inlay " + (char)('A' + index),
                typeof(MeshFilter), typeof(MeshRenderer));
            pedestalInlay.layer = SceneryLayer;
            pedestalInlay.transform.SetParent(sceneRoot.transform, false);
            pedestalInlay.transform.localPosition = new Vector3(x, .799f, -1.35f);
            pedestalInlay.GetComponent<MeshFilter>().sharedMesh = inlayMesh;
            pedestalInlay.GetComponent<MeshRenderer>().sharedMaterial = trimMaterial;
            GameObject evidence = ChapterWorldRelicFactory.Create(sceneRoot.transform, visual,
                new Vector3(x, 1.34f, -1.35f), EvidenceLayer, SceneryLayer,
                evidenceMaterial, trimMaterial, baseMaterial);
            var marker = evidence.AddComponent<ChapterWorldEvidenceMarker>();
            marker.Configure(current.LocationNumber, index);
            evidenceRenderers[index] = evidence.GetComponent<Renderer>();
            relicRoots[index] = evidence.transform;
            relicInitialRotations[index] = evidence.transform.localRotation;
            relicYawDegrees[index] = 0f;
        }

        private GameObject CreatePrimitive(string objectName, PrimitiveType primitive,
            Vector3 position, Vector3 size, Material surface, bool interactable = false)
        {
            GameObject obj = GameObject.CreatePrimitive(primitive);
            obj.name = objectName;
            obj.layer = interactable ? EvidenceLayer : SceneryLayer;
            obj.transform.SetParent(sceneRoot.transform, false);
            obj.transform.localPosition = position;
            obj.transform.localScale = size;
            Renderer renderer = obj.GetComponent<Renderer>();
            renderer.sharedMaterial = surface;
            Collider collider = obj.GetComponent<Collider>();
            if (!interactable && collider != null) collider.enabled = false;
            return obj;
        }

        private static void ConfigureStandardSurface(Material material, float metallic,
            float smoothness)
        {
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", smoothness);
        }

        private Material CreateColorMaterial(string label, Color color)
        {
            Shader shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Unlit/Color");
            if (shader == null) throw new InvalidOperationException("No compatible 3D material shader was found.");
            var material = new Material(shader) { name = label, color = color, enableInstancing = true };
            materials.Add(material);
            return material;
        }

        private Material CreateReferenceMaterial(Texture2D texture)
        {
            Shader shader = Shader.Find("Unlit/Texture");
            if (shader == null) shader = Shader.Find("Standard");
            if (shader == null) throw new InvalidOperationException("No compatible reference-image shader was found.");
            var material = new Material(shader) { name = "Location Artwork - Owned Material" };
            material.mainTexture = texture;
            materials.Add(material);
            return material;
        }

        private Vector3 GetCameraTarget()
        {
            if (chapterTwoFocusActive && current != null && current.ChapterNumber == 2)
                return new Vector3(0f, 2.23f, .10f);
            if (chapterThreeFocusActive && current != null && current.ChapterNumber == 3)
                return new Vector3(0f, 2.23f, .10f);
            if (chapterFourFocusActive && current != null && current.ChapterNumber == 4)
                return new Vector3(0f, 2.23f, .10f);
            if (crestFocusActive && current != null && current.LocationNumber == 1)
                return new Vector3(-1.07f, 2.78f, -.42f);
            if (focusedEvidenceIndex < 0 || focusedEvidenceIndex >= ChapterEvidenceVisualCatalog.EvidencePerLocation)
                return new Vector3(0f, 1.83f, .6f);
            float x = focusedEvidenceIndex == 0 ? -EvidencePedestalOffset : EvidencePedestalOffset;
            return new Vector3(x, 1.34f, -1.35f);
        }

        /// <summary>
        /// Rotates only the selected relic around world-up, preserving its authored rest pose.
        /// This visual interaction never changes inspection, deduction, or durable progress.
        /// </summary>
        public bool TryRotateFocusedRelic(float degrees)
        {
            if (!CanManipulateFocusedRelic() || float.IsNaN(degrees) ||
                float.IsInfinity(degrees) || Mathf.Abs(degrees) > 45f ||
                Mathf.Abs(degrees) < .0001f) return false;
            int index = focusedEvidenceIndex;
            float angle = Mathf.Repeat(relicYawDegrees[index] + degrees + 180f, 360f) - 180f;
            relicYawDegrees[index] = angle;
            relicRoots[index].localRotation =
                Quaternion.AngleAxis(angle, Vector3.up) * relicInitialRotations[index];
            return true;
        }

        public bool TryResetFocusedRelic()
        {
            if (!CanManipulateFocusedRelic()) return false;
            int index = focusedEvidenceIndex;
            relicYawDegrees[index] = 0f;
            relicRoots[index].localRotation = relicInitialRotations[index];
            return true;
        }

        public float GetRelicYawDegrees(int evidenceIndex)
        {
            if (evidenceIndex < 0 || evidenceIndex >= ChapterEvidenceVisualCatalog.EvidencePerLocation)
                throw new ArgumentOutOfRangeException(nameof(evidenceIndex));
            return isOpen ? relicYawDegrees[evidenceIndex] : 0f;
        }

        private bool CanManipulateFocusedRelic()
        {
            return isOpen && !IsArtworkOpen && !IsComparisonOpen &&
                !IsThresholdOpen && !IsSpiralOpen && !IsChapterTwoOpen && focusedEvidenceIndex >= 0 &&
                focusedEvidenceIndex < ChapterEvidenceVisualCatalog.EvidencePerLocation &&
                relicRoots[focusedEvidenceIndex] != null && !IsChapterThreeOpen && !IsChapterFourOpen;
        }

        /// <summary>Visual-only camera focus; does not inspect evidence or advance case progress.</summary>
        public bool TryFocusEvidence(int index)
        {
            if (!isOpen || IsArtworkOpen || index < 0 ||
                index >= ChapterEvidenceVisualCatalog.EvidencePerLocation) return false;
            if (IsComparisonOpen) return false;
            if (IsThresholdOpen || IsSpiralOpen || IsChapterTwoOpen) return false;
            if (IsChapterThreeOpen || IsChapterFourOpen) return false;
            focusedEvidenceIndex = index;
            crestFocusActive = false;
            chapterTwoFocusActive = false;
            chapterThreeFocusActive = false;
            chapterFourFocusActive = false;
            cameraYaw = 0f;
            cameraDistance = EvidenceFocusDistance;
            gesture.Cancel();
            previousPinchDistance = -1f;
            SetCameraOrbit();
            RefreshInterface();
            return true;
        }

        /// <summary>
        /// Chapter-one-only camera inspection of the original and altered reliefs.
        /// Focusing is presentation state, not evidence inspection or puzzle completion.
        /// </summary>
        public bool TryFocusCrest()
        {
            if (!isOpen || current == null || current.LocationNumber != 1 ||
                IsArtworkOpen || IsComparisonOpen || IsThresholdOpen) return false;
            if (IsChapterThreeOpen || IsChapterFourOpen) return false;
            focusedEvidenceIndex = -1;
            crestFocusActive = true;
            cameraYaw = 0f;
            cameraDistance = CrestFocusDistance;
            gesture.Cancel();
            previousPinchDistance = -1f;
            SetCameraOrbit();
            RefreshInterface();
            return true;
        }

        /// <summary>
        /// Presentation-only focus for the four physical Chapter Two mechanism plates.
        /// This cannot reveal clues, submit answers, or change durable progress.
        /// </summary>
        public bool TryFocusChapterTwoMechanism()
        {
            if (!IsChapterTwoLocation || sceneCamera == null ||
                IsArtworkOpen || IsComparisonOpen || IsThresholdOpen ||
                IsSpiralOpen || IsChapterTwoOpen) return false;
            focusedEvidenceIndex = -1;
            crestFocusActive = false;
            chapterTwoFocusActive = true;
            chapterThreeFocusActive = false;
            chapterFourFocusActive = false;
            cameraYaw = 0f;
            cameraDistance = ChapterTwoFocusDistance;
            gesture.Cancel();
            previousPinchDistance = -1f;
            SetCameraOrbit();
            RefreshInterface();
            return true;
        }

        /// <summary>Zoom into Chapter Three's physical panel without revealing clues.</summary>
        public bool TryFocusChapterThreeMechanism()
        {
            if (!IsChapterThreeLocation || sceneCamera == null ||
                IsArtworkOpen || IsComparisonOpen || IsThresholdOpen ||
                IsSpiralOpen || IsChapterTwoOpen || IsChapterThreeOpen) return false;
            focusedEvidenceIndex = -1;
            crestFocusActive = false;
            chapterTwoFocusActive = false;
            chapterThreeFocusActive = true;
            chapterFourFocusActive = false;
            cameraYaw = 0f;
            cameraDistance = ChapterThreeFocusDistance;
            gesture.Cancel();
            previousPinchDistance = -1f;
            SetCameraOrbit();
            RefreshInterface();
            return true;
        }

        public void ReturnToOverview()
        {
            if (!isOpen || IsArtworkOpen || IsComparisonOpen || IsThresholdOpen) return;
            if (IsSpiralOpen || IsChapterTwoOpen || IsChapterThreeOpen || IsChapterFourOpen) return;
            focusedEvidenceIndex = -1;
            cameraYaw = 0f;
            crestFocusActive = false;
            chapterTwoFocusActive = false;
            chapterThreeFocusActive = false;
            chapterFourFocusActive = false;
            cameraDistance = DefaultCameraDistance;
            gesture.Cancel();
            previousPinchDistance = -1f;
            SetCameraOrbit();
            RefreshInterface();
        }

        private void SetCameraOrbit()
        {
            if (sceneCamera == null) return;
            float angle = cameraYaw * Mathf.Deg2Rad;
            Vector3 target = GetCameraTarget();
            sceneCamera.transform.position = target +
                new Vector3(Mathf.Sin(angle) * cameraDistance, 2.0f, -Mathf.Cos(angle) * cameraDistance);
            sceneCamera.transform.LookAt(target);
        }

        // The Chapter Three overlay is a state boundary: a queued HUD action,
        // scripted callback, or hardware input must never move the camera behind
        // an open evidence, artwork, or mechanism modal.
        private bool IsChapterThreeCameraBlocked => IsChapterThreeLocation &&
            (IsArtworkOpen || IsComparisonOpen || IsChapterThreeOpen);
        private bool IsChapterFourCameraBlocked => IsChapterFourLocation &&
            (IsArtworkOpen || IsComparisonOpen || IsChapterFourOpen);

        private void Rotate(float degrees)
        {
            if (!isOpen || IsChapterThreeCameraBlocked || IsChapterFourCameraBlocked ||
                float.IsNaN(degrees) || float.IsInfinity(degrees)) return;
            cameraYaw = Mathf.Clamp(cameraYaw + degrees, -31f, 31f);
            SetCameraOrbit();
        }

        private void Zoom(float distanceDelta)
        {
            if (!isOpen || IsChapterThreeCameraBlocked || IsChapterFourCameraBlocked) return;
            if (float.IsNaN(distanceDelta) || float.IsInfinity(distanceDelta)) return;
            float minimumDistance = crestFocusActive ? MinimumCrestFocusDistance :
                MinimumCameraDistance;
            float maximumDistance = crestFocusActive ? MaximumCrestFocusDistance :
                MaximumCameraDistance;
            if (chapterTwoFocusActive)
            {
                minimumDistance = MinimumChapterTwoFocusDistance;
                maximumDistance = MaximumChapterTwoFocusDistance;
            }
            if (chapterThreeFocusActive)
            {
                minimumDistance = MinimumChapterThreeFocusDistance;
                maximumDistance = MaximumChapterThreeFocusDistance;
            }
            if (chapterFourFocusActive)
            {
                minimumDistance = MinimumChapterFourFocusDistance;
                maximumDistance = MaximumChapterFourFocusDistance;
            }
            cameraDistance = Mathf.Clamp(cameraDistance + distanceDelta,
                minimumDistance, maximumDistance);
            SetCameraOrbit();
        }

        private void BuildInterface()
        {
            interfaceRoot = new GameObject("3D Case Interface", typeof(RectTransform), typeof(Canvas),
                typeof(CanvasScaler), typeof(GraphicRaycaster));
            interfaceRoot.transform.SetParent(transform, false);
            Canvas canvas = interfaceRoot.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 140;
            var scaler = interfaceRoot.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1600f, 900f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
            RectTransform canvasRoot = interfaceRoot.GetComponent<RectTransform>();
            var safeAreaObject = new GameObject("3D Case Safe Area", typeof(RectTransform));
            safeAreaRoot = safeAreaObject.GetComponent<RectTransform>();
            safeAreaRoot.SetParent(canvasRoot, false);
            safeAreaRoot.anchorMin = Vector2.zero;
            safeAreaRoot.anchorMax = Vector2.one;
            safeAreaRoot.offsetMin = safeAreaRoot.offsetMax = Vector2.zero;
            var layoutObject = new GameObject("3D Case Fixed Layout", typeof(RectTransform));
            safeLayoutRoot = layoutObject.GetComponent<RectTransform>();
            safeLayoutRoot.SetParent(safeAreaRoot, false);
            safeLayoutRoot.anchorMin = safeLayoutRoot.anchorMax = new Vector2(.5f, .5f);
            safeLayoutRoot.anchoredPosition = Vector2.zero;
            safeLayoutRoot.sizeDelta = new Vector2(1600f, 900f);
            canvasRoot = safeLayoutRoot;
            lastScreenWidth = -1;
            UpdateSafeArea();
            // Photo-first presentation replaces the procedural room as the default scene.
            // The original 3D inspection remains available through a reversible switch.
            Texture2D authoredScene = materials.Find(material =>
                material != null && material.name == "Location Artwork - Owned Material")?.mainTexture as Texture2D;
            if (authoredScene == null)
                throw new InvalidOperationException("The original cinematic scene photograph is unavailable.");
            // A quality-approved full-bleed landscape can replace the legacy padded
            // reference without modifying its source, 3D inspection or save state.
            Texture2D cinematicArtwork = Resources.Load<Texture2D>(
                "CinematicLocations/Location_" + current.LocationNumber.ToString("00"));
            featuredSceneTexture = cinematicArtwork;
            Texture2D sceneBackdrop = cinematicArtwork != null ? cinematicArtwork : authoredScene;
            cinematicScene = new CinematicScenePresentation(canvasRoot, sceneBackdrop,
                current.LocationNumber, index => TryInspectEvidence(index),
                () => TryOpenScenicMechanism());
            cinematicScene.SetScenic(true, sceneCamera);
            var background = new GameObject("3D HUD Top Bar", typeof(RectTransform), typeof(Image));
            background.transform.SetParent(canvasRoot, false);
            RectTransform topRect = background.GetComponent<RectTransform>();
            topRect.anchorMin = new Vector2(0f, .84f);
            topRect.anchorMax = Vector2.one;
            topRect.offsetMin = topRect.offsetMax = Vector2.zero;
            Image topImage = background.GetComponent<Image>();
            topImage.color = new Color(.018f, .025f, .035f, .90f);
            topImage.raycastTarget = false;
            caseTitle = AddText("3D Case Title", canvasRoot, string.Empty, new Vector2(0f, 375f),
                new Vector2(1250f, 72f), 30);
            evidenceStatus = AddText("3D Evidence Transcript", canvasRoot, string.Empty,
                new Vector2(0f, -256f), new Vector2(1220f, 135f), 20);
            evidenceStatus.alignment = TextAnchor.MiddleCenter;
            AddButton("RETURN TO ATLAS", canvasRoot, new Vector2(-640f, 375f),
                new Vector2(250f, 62f), () => Finish(false));
            deductionButton = AddButton("OPEN DEDUCTION", canvasRoot, new Vector2(620f, -370f),
                new Vector2(315f, 66f), () => Finish(true));
            evidenceAButton = AddButton("INSPECT A", canvasRoot, new Vector2(-600f, -370f),
                new Vector2(220f, 64f), () => TryInspectEvidence(0));
            evidenceBButton = AddButton("INSPECT B", canvasRoot, new Vector2(-350f, -370f),
                new Vector2(220f, 64f), () => TryInspectEvidence(1));
            AddButton("ROTATE LEFT", canvasRoot, new Vector2(25f, -370f),
                new Vector2(205f, 64f), () => Rotate(-15f));
            AddButton("ROTATE RIGHT", canvasRoot, new Vector2(255f, -370f),
                new Vector2(205f, 64f), () => Rotate(15f));
            AddButton("ZOOM +", canvasRoot, new Vector2(455f, 373f),
                new Vector2(145f, 58f), () => Zoom(-1.1f));
            AddButton("ZOOM -", canvasRoot, new Vector2(605f, 373f),
                new Vector2(145f, 58f), () => Zoom(1.1f));
            AddButton("FOCUS EVIDENCE A", canvasRoot, new Vector2(-620f, 294f),
                new Vector2(218f, 60f), () => TryFocusEvidence(0));
            AddButton("FOCUS EVIDENCE B", canvasRoot, new Vector2(-384f, 294f),
                new Vector2(218f, 60f), () => TryFocusEvidence(1));
            AddButton("RETURN TO OVERVIEW", canvasRoot, new Vector2(-124f, 294f),
                new Vector2(280f, 60f), ReturnToOverview);
            AddButton("VIEW ORIGINAL ART", canvasRoot, new Vector2(594f, 294f),
                new Vector2(236f, 60f), () => SetArtworkFocus(true));
            turnRelicLeftButton = AddButton("TURN RELIC LEFT", canvasRoot,
                new Vector2(-571f, 211f), new Vector2(234f, 58f),
                () => TryRotateFocusedRelic(-22.5f));
            turnRelicRightButton = AddButton("TURN RELIC RIGHT", canvasRoot,
                new Vector2(-313f, 211f), new Vector2(234f, 58f),
                () => TryRotateFocusedRelic(22.5f));
            resetRelicButton = AddButton("RESET RELIC", canvasRoot,
                new Vector2(-66f, 211f), new Vector2(215f, 58f),
                () => TryResetFocusedRelic());
            comparisonButton = AddButton("COMPARE CLUES", canvasRoot,
                new Vector2(241f, 211f), new Vector2(274f, 58f),
                () => TryOpenComparison());
            // Build before modal overlays so their panels always render above this toggle.
            scenicModeButton = AddButton("INSPECT 3D RELICS", canvasRoot,
                new Vector2(0f, 135f), new Vector2(278f, 60f),
                () => TrySetScenicMode(!scenicMode));
            scenicModeCaption = scenicModeButton.GetComponentInChildren<Text>();
            if (current.LocationNumber == SpiralBalusterPuzzle.LocationNumber)
            {
                spiralButton = AddButton("EXAMINE STAIR PATTERN", canvasRoot,
                    new Vector2(574f, 211f), new Vector2(280f, 58f),
                    () => TryOpenSpiralViewer());
                BuildSpiralViewer(canvasRoot);
            }
            if (current.ChapterNumber == 2)
            {
                chapterTwoFocusButton = AddButton("FOCUS MECHANISM", canvasRoot,
                    new Vector2(245f, 294f), new Vector2(218f, 60f),
                    () => TryFocusChapterTwoMechanism());
                chapterTwoButton = AddButton("EXAMINE CHAPTER TWO MECHANISM", canvasRoot,
                    new Vector2(572f, 211f), new Vector2(298f, 58f),
                    () => TryOpenChapterTwoViewer());
                BuildChapterTwoViewer(canvasRoot);
            }
            if (current.ChapterNumber == 4)
            {
                chapterFourFocusButton = AddButton("FOCUS MERIDIAN", canvasRoot,
                    new Vector2(245f, 294f), new Vector2(218f, 60f),
                    () => TryFocusChapterFourMechanism());
                chapterFourButton = AddButton("ALIGN MERIDIAN RINGS", canvasRoot,
                    new Vector2(572f, 211f), new Vector2(298f, 58f),
                    () => TryOpenChapterFourViewer());
                BuildChapterFourViewer(canvasRoot);
            }
            if (current.ChapterNumber == 3)
            {
                chapterThreeFocusButton = AddButton("FOCUS TESTAMENT", canvasRoot,
                    new Vector2(245f, 294f), new Vector2(218f, 60f),
                    () => TryFocusChapterThreeMechanism());
                chapterThreeButton = AddButton("EXAMINE TESTAMENT MECHANISM", canvasRoot,
                    new Vector2(572f, 211f), new Vector2(298f, 58f),
                    () => TryOpenChapterThreeViewer());
                BuildChapterThreeViewer(canvasRoot);
            }
            if (current.LocationNumber == 1)
            {
                AddButton("FOCUS CREST", canvasRoot, new Vector2(245f, 294f),
                    new Vector2(218f, 60f), () => TryFocusCrest());
                thresholdButton = AddButton("EXAMINE CREST LOCK", canvasRoot,
                    new Vector2(574f, 211f), new Vector2(260f, 58f),
                    () => TryOpenThresholdViewer());
                BuildThresholdViewer(canvasRoot);
            }
            BuildArtworkViewer(canvasRoot);
            BuildComparisonViewer(canvasRoot);
            ConfigureCinematicHud(canvasRoot);
        }


        /// <summary>
        /// Cinematic photo exploration never changes durable progress. Every modal and
        /// inspected object remains the responsibility of the existing game state.
        /// </summary>
        public bool TrySetScenicMode(bool enabled)
        {
            if (!isOpen || cinematicScene == null || cinematicScene.IsEvidencePreviewOpen ||
                IsArtworkOpen || IsComparisonOpen || IsThresholdOpen || IsSpiralOpen ||
                IsChapterTwoOpen || IsChapterThreeOpen || IsChapterFourOpen)
                return false;
            scenicMode = enabled;
            gesture.Cancel();
            pointerResumeGate.Suspend();
            previousPinchDistance = -1f;
            cinematicScene.SetScenic(enabled, sceneCamera);
            RefreshInterface();
            return true;
        }

        private void TryOpenScenicMechanism()
        {
            if (!isOpen || inspection == null || !inspection.CanDeduce ||
                current == null || IsArtworkOpen || IsComparisonOpen ||
                (cinematicScene != null && cinematicScene.IsEvidencePreviewOpen)) return;
            if (current.LocationNumber == 1) TryOpenThresholdViewer();
            else if (current.LocationNumber == SpiralBalusterPuzzle.LocationNumber)
                TryOpenSpiralViewer();
            else if (current.ChapterNumber == 2) TryOpenChapterTwoViewer();
            else if (current.ChapterNumber == 3) TryOpenChapterThreeViewer();
            else if (current.ChapterNumber == 4) TryOpenChapterFourViewer();
        }

        private void ConfigureCinematicHud(Transform root)
        {
            string[] worldOnly =
            {
                "ROTATE LEFT", "ROTATE RIGHT", "ZOOM +", "ZOOM -",
                "FOCUS EVIDENCE A", "FOCUS EVIDENCE B", "RETURN TO OVERVIEW",
                "FOCUS CREST", "FOCUS MECHANISM", "FOCUS TESTAMENT", "FOCUS MERIDIAN",
                "TURN RELIC LEFT", "TURN RELIC RIGHT", "RESET RELIC",
                "VIEW ORIGINAL ART", "INSPECT A", "INSPECT B"
            };
            Button[] buttons = root.GetComponentsInChildren<Button>(true);
            foreach (Button button in buttons)
            {
                if (button == null || Array.IndexOf(worldOnly, button.name) < 0) continue;
                CanvasGroup group = button.gameObject.AddComponent<CanvasGroup>();
                threeDControls.Add(group);
            }
            ApplyCinematicHud();
        }

        private void ApplyCinematicHud()
        {
            if (scenicModeButton != null)
            {
                RectTransform toggle = scenicModeButton.GetComponent<RectTransform>();
                if (toggle != null)
                    toggle.anchoredPosition = scenicMode ?
                        new Vector2(CinematicHudClearance.ScenicToggleX,
                            CinematicHudClearance.ScenicToggleY) :
                        new Vector2(0f, 135f);
            }
            foreach (CanvasGroup group in threeDControls)
            {
                if (group == null) continue;
                group.alpha = scenicMode ? 0f : 1f;
                group.blocksRaycasts = !scenicMode;
                group.interactable = !scenicMode;
            }
            if (scenicModeCaption != null)
                scenicModeCaption.text = scenicMode ? "INSPECT 3D RELICS" : "RETURN TO SCENERY";
            if (cinematicScene != null && inspection != null)
            {
                bool modal = IsArtworkOpen || IsComparisonOpen || IsThresholdOpen ||
                    IsSpiralOpen || IsChapterTwoOpen || IsChapterThreeOpen || IsChapterFourOpen;
                cinematicScene.Refresh(inspection.HasInspected(0), inspection.HasInspected(1),
                    inspection.CanDeduce && !CanDeduce, modal);
            }
        }

        /// <summary>
        /// A non-interactive, collider-free diegetic diagram for every Chapter Two case.
        /// Text does not reveal the solution until the world mechanism is verified.
        /// Reuses authored location artwork, three existing lights and stage materials.
        /// </summary>
        private void BuildChapterTwoWorldDisplay(Material stone, Material slate, Material brass)
        {
            ChapterTwoVisualSpec visual = ChapterTwoVisualCatalog.Get(current.LocationNumber);
            chapterTwoSolvedMaterial = CreateColorMaterial("Restored Chapter Two Inlay",
                new Color(.28f, .64f, .44f));
            GameObject backing = CreatePrimitive("Chapter Two Carved Mechanism Backplate",
                PrimitiveType.Cube, new Vector3(0f, 2.27f, .28f),
                new Vector3(4.4f, 1.15f, .16f), stone, true);
            chapterTwoWorldCollider = backing.GetComponent<Collider>();
            GameObject indicator = CreatePrimitive("Chapter Two Mechanism Status Inlay",
                PrimitiveType.Cube, new Vector3(0f, 1.87f, .13f),
                new Vector3(3.91f, .09f, .17f), slate);
            chapterTwoWorldIndicator = indicator.GetComponent<Renderer>();
            AddWorldLabel("Chapter Two Mechanism Title", visual.MechanismTitle,
                new Vector3(0f, 2.62f, .15f), .12f, Ivory);
            AddWorldLabel("Chapter Two Mechanism Inscription", visual.Inscription,
                new Vector3(0f, 2.34f, .14f), .075f, Ivory);
            GameObject diagram = new GameObject("Chapter Two Mechanism State", typeof(TextMesh));
            diagram.layer = SceneryLayer;
            diagram.transform.SetParent(sceneRoot.transform, false);
            diagram.transform.localPosition = new Vector3(0f, 2.02f, .14f);
            diagram.transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
            chapterTwoWorldMark = diagram.GetComponent<TextMesh>();
            chapterTwoWorldMark.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            chapterTwoWorldMark.fontSize = 72;
            chapterTwoWorldMark.characterSize = .09f;
            chapterTwoWorldMark.color = Ivory;
            chapterTwoWorldMark.anchor = TextAnchor.MiddleCenter;
            chapterTwoWorldMark.alignment = TextAlignment.Center;
            chapterTwoWorldMark.text = visual.UnsolvedMark;
            Renderer renderer = diagram.GetComponent<Renderer>();
            if (chapterTwoWorldMark.font != null && renderer != null)
                renderer.sharedMaterial = chapterTwoWorldMark.font.material;
            // One site-specific metal relief replaces four identical cylinders.
            // Only the stone backplate is pickable; decorative geometry has no collider.
            GameObject relief = new GameObject("Chapter Two Physical Relief",
                typeof(MeshFilter), typeof(MeshRenderer));
            relief.layer = SceneryLayer;
            relief.transform.SetParent(sceneRoot.transform, false);
            relief.transform.localPosition = new Vector3(0f, 1.66f, -.08f);
            chapterTwoReliefMesh = ChapterTwoReliefMesh.Create(current.LocationNumber, false);
            ownedMeshes.Add(chapterTwoReliefMesh);
            relief.GetComponent<MeshFilter>().sharedMesh = chapterTwoReliefMesh;
            chapterTwoReliefRenderer = relief.GetComponent<MeshRenderer>();
            chapterTwoReliefRenderer.sharedMaterial = brass;
        }

        private void BuildChapterTwoViewer(Transform parent)
        {
            ChapterTwoVisualSpec visual = ChapterTwoVisualCatalog.Get(current.LocationNumber);
            chapterTwoOverlay = new GameObject("Chapter Two World Mechanism",
                typeof(RectTransform), typeof(Image));
            chapterTwoOverlay.transform.SetParent(parent, false);
            RectTransform root = chapterTwoOverlay.GetComponent<RectTransform>();
            root.anchorMin = root.anchorMax = new Vector2(.5f, .5f);
            root.anchoredPosition = Vector2.zero;
            root.sizeDelta = new Vector2(1600f, 900f);
            Image modalBackdrop = chapterTwoOverlay.GetComponent<Image>();
            modalBackdrop.color = new Color(.015f, .023f, .038f, .98f);
            modalBackdrop.raycastTarget = true;
            AddText("Chapter Two Mechanism Heading", root, visual.MechanismTitle,
                new Vector2(-120f, 350f), new Vector2(1120f, 70f), 32);
            AddText("Chapter Two World Mechanism Inscription", root, visual.Inscription,
                new Vector2(0f, 245f), new Vector2(1400f, 60f), 20);
            StoryDossierCase dossier = StoryDossierCatalog.Get(current.LocationNumber);
            Text evidence = AddText("Chapter Two Inspected Fragments", root,
                "EVIDENCE A: " + dossier.EvidenceFragments[0] + "\n\nEVIDENCE B: " +
                dossier.EvidenceFragments[1],
                new Vector2(0f, 115f), new Vector2(1370f, 190f), 22);
            evidence.alignment = TextAnchor.MiddleLeft;
            AddText("Chapter Two Mechanism Question", root,
                current.LocationNumber == 3 ? "ALIGN THE PHYSICAL LUNAR DIAL" : dossier.Question,
                new Vector2(0f, -24f), new Vector2(1350f, 72f), 24);
            if (current.LocationNumber == 3)
                BuildLunarDial(root);
            else
            {
                for (int index = 0; index < chapterTwoOptions.Length; index++)
                {
                    int captured = index;
                    float x = index % 2 == 0 ? -363f : 363f;
                    float y = index < 2 ? -129f : -230f;
                    chapterTwoOptions[index] = AddButton(dossier.Choices[index], root,
                        new Vector2(x, y), new Vector2(680f, 76f),
                        () => TrySelectChapterTwoChoice(captured));
                }
            }
            chapterTwoFeedback = AddText("Chapter Two Mechanism Feedback", root,
                string.Empty, new Vector2(0f, -320f), new Vector2(1200f, 43f), 22);
            chapterTwoHintText = AddText("Chapter Two Mechanism Hint", root,
                string.Empty, new Vector2(0f, current.LocationNumber == 3 ? -401f : -369f),
                new Vector2(1220f, current.LocationNumber == 3 ? 28f : 36f), 16);
            chapterTwoHintButton = AddButton("REQUEST MECHANISM HINT", root,
                new Vector2(637f, 345f), new Vector2(295f, 56f),
                () => TryRequestChapterTwoHint());
            AddButton("CLOSE CHAPTER TWO MECHANISM", root,
                new Vector2(-638f, 345f), new Vector2(300f, 56f), CloseChapterTwoViewer);
            chapterTwoOverlay.SetActive(false);
        }

        private void BuildLunarDial(RectTransform root)
        {
            AddText("Lunar Dial Guidance", root,
                "ROTATE THE CALIBRATION WHEEL TO THE PHASE INDICATED BY THE CALENDAR.",
                new Vector2(0f, -97f), new Vector2(1100f, 40f), 19);
            var face = new GameObject("Physical Lunar Dial", typeof(RectTransform), typeof(Image));
            face.transform.SetParent(root, false);
            moonDialFace = face.GetComponent<RectTransform>();
            moonDialFace.anchorMin = moonDialFace.anchorMax = new Vector2(.5f, .5f);
            moonDialFace.anchoredPosition = new Vector2(0f, -205f);
            moonDialFace.sizeDelta = new Vector2(172f, 172f);
            face.GetComponent<Image>().color = new Color(.38f, .40f, .48f, 1f);
            face.AddComponent<ChapterPuzzleRotaryDial>().Initialize(root,
                () => IsChapterTwoLocation && current.LocationNumber == 3 &&
                    IsChapterTwoOpen && inspection != null && inspection.CanDeduce &&
                    !chapterTwoPuzzle.IsVerified && !IsArtworkOpen && !IsComparisonOpen,
                TryTurnMoonDial);
            for (int index = 0; index < 4; index++)
            {
                float degrees = index * 90f;
                float radians = degrees * Mathf.Deg2Rad;
                var notch = new GameObject("Lunar Dial Notch " + index,
                    typeof(RectTransform), typeof(Image));
                notch.transform.SetParent(moonDialFace, false);
                RectTransform notchRect = notch.GetComponent<RectTransform>();
                notchRect.anchorMin = notchRect.anchorMax = new Vector2(.5f, .5f);
                notchRect.sizeDelta = new Vector2(14f, 35f);
                notchRect.anchoredPosition = new Vector2(Mathf.Sin(radians) * 62f,
                    Mathf.Cos(radians) * 62f);
                notchRect.localRotation = Quaternion.Euler(0f, 0f, -degrees);
                Image notchImage = notch.GetComponent<Image>();
                notchImage.color = Ivory;
                notchImage.raycastTarget = false;
            }
            moonPhaseLabel = AddText("Selected Lunar Phase", root,
                LunarPhaseDial.GetPhaseLabel(lunarDial.Phase),
                new Vector2(0f, -311f), new Vector2(390f, 36f), 21);
            AddButton("ROTATE MOON LEFT", root,
                new Vector2(-380f, -202f), new Vector2(250f, 70f),
                () => TryTurnMoonDial(-1));
            AddButton("ROTATE MOON RIGHT", root,
                new Vector2(380f, -202f), new Vector2(250f, 70f),
                () => TryTurnMoonDial(1));
            moonLockButton = AddButton("LOCK LUNAR CALIBRATION", root,
                new Vector2(555f, -287f), new Vector2(360f, 56f),
                () => TryLockMoonDial());
        }

        public bool TryTurnMoonDial(int direction)
        {
            if (!IsChapterTwoLocation || current.LocationNumber != 3 ||
                !IsChapterTwoOpen || inspection == null || !inspection.CanDeduce ||
                chapterTwoPuzzle.IsVerified || IsArtworkOpen || IsComparisonOpen ||
                !lunarDial.TryTurn(direction)) return false;
            RefreshChapterTwoViewer();
            return true;
        }

        public ChapterTwoSelection TryLockMoonDial()
        {
            if (!IsChapterTwoLocation || current.LocationNumber != 3 ||
                !IsChapterTwoOpen || inspection == null || !inspection.CanDeduce ||
                IsArtworkOpen || IsComparisonOpen)
                return ChapterTwoSelection.Invalid;
            return TrySelectChapterTwoChoice(lunarDial.CurrentChoiceIndex);
        }

        public bool TryOpenChapterTwoViewer()
        {
            if (!IsChapterTwoLocation || chapterTwoOverlay == null ||
                inspection == null || !inspection.CanDeduce || IsArtworkOpen ||
                IsComparisonOpen || IsThresholdOpen || IsSpiralOpen || IsChapterTwoOpen)
                return false;
            gesture.Cancel();
            previousPinchDistance = -1f;
            chapterTwoOverlay.SetActive(true);
            RefreshChapterTwoViewer();
            RefreshInterface();
            return true;
        }

        public void CloseChapterTwoViewer()
        {
            if (!IsChapterTwoLocation || chapterTwoOverlay == null) return;
            chapterTwoOverlay.SetActive(false);
            RefreshInterface();
        }

        public bool TryRequestChapterTwoHint()
        {
            if (!IsChapterTwoLocation || !IsChapterTwoOpen ||
                inspection == null || IsArtworkOpen || IsComparisonOpen ||
                !chapterTwoPuzzle.TryRevealHint(inspection.HasInspected(0),
                    inspection.HasInspected(1))) return false;
            RefreshChapterTwoViewer();
            return true;
        }

        public ChapterTwoSelection TrySelectChapterTwoChoice(int choiceIndex)
        {
            if (!IsChapterTwoLocation || !IsChapterTwoOpen ||
                inspection == null || IsArtworkOpen || IsComparisonOpen)
                return ChapterTwoSelection.Invalid;
            bool firstClue = inspection.HasInspected(0);
            bool secondClue = inspection.HasInspected(1);
            ChapterTwoSelection result = chapterTwoPuzzle.Select(choiceIndex,
                firstClue, secondClue);
            lastChapterTwoSelection = result;
            if (result == ChapterTwoSelection.Verified)
            {
                ChapterTwoVisualSpec visual = ChapterTwoVisualCatalog.Get(current.LocationNumber);
                if (chapterTwoWorldMark != null)
                    chapterTwoWorldMark.text = visual.SolvedMark;
                if (chapterTwoWorldIndicator != null)
                    chapterTwoWorldIndicator.sharedMaterial = chapterTwoSolvedMaterial;
                if (chapterTwoReliefMesh != null)
                    ChapterTwoReliefMesh.Rebuild(chapterTwoReliefMesh,
                        current.LocationNumber, true);
                if (chapterTwoReliefRenderer != null)
                    chapterTwoReliefRenderer.sharedMaterial = chapterTwoSolvedMaterial;
            }
            RefreshChapterTwoViewer();
            RefreshInterface();
            return result;
        }

        private void RefreshChapterTwoViewer()
        {
            if (!IsChapterTwoLocation || chapterTwoFeedback == null) return;
            bool solved = chapterTwoPuzzle.IsVerified;
            chapterTwoFeedback.text = solved ? "MECHANISM RESTORED - CLUE LOCK RELEASED" :
                lastChapterTwoSelection == ChapterTwoSelection.Incorrect ?
                "THAT ALIGNMENT CONTRADICTS THE EVIDENCE. COMPARE BOTH CLUES." :
                "THE TWO CLUES ARE AVAILABLE. RESTORE THE PHYSICAL MECHANISM.";
            chapterTwoHintText.text = chapterTwoPuzzle.HintStage > 0 ?
                "HINT " + chapterTwoPuzzle.HintStage + "/3: " +
                chapterTwoPuzzle.Hints[chapterTwoPuzzle.HintStage - 1] : string.Empty;
            if (chapterTwoHintButton != null)
                chapterTwoHintButton.interactable = !solved &&
                    chapterTwoPuzzle.HintStage < ChapterTwoMechanismPuzzle.MaximumHintStage;
            if (current.LocationNumber == 3)
            {
                if (moonPhaseLabel != null)
                    moonPhaseLabel.text = LunarPhaseDial.GetPhaseLabel(lunarDial.Phase);
                if (moonDialFace != null)
                    moonDialFace.localRotation = Quaternion.Euler(0f, 0f,
                        -(int)lunarDial.Phase * 90f);
                if (moonLockButton != null) moonLockButton.interactable = !solved;
            }
            for (int index = 0; index < chapterTwoOptions.Length; index++)
            {
                Button option = chapterTwoOptions[index];
                if (option == null) continue;
                option.interactable = !solved;
                option.image.color = solved && chapterTwoPuzzle.Case.IsCorrect(index) ?
                    new Color(.26f, .61f, .40f) :
                    !solved && lastChapterTwoSelection == ChapterTwoSelection.Incorrect &&
                    chapterTwoPuzzle.LastChoice == index ? new Color(.70f, .26f, .26f) : Brass;
            }
        }

        private void BuildChapterThreeWorldDisplay(Material stone, Material slate, Material brass)
        {
            ChapterThreeVisualSpec visual = ChapterThreeVisualCatalog.Get(current.LocationNumber);
            chapterThreeSolvedMaterial = CreateColorMaterial("Restored Chapter Three Inlay",
                new Color(.28f, .64f, .44f));
            GameObject backing = CreatePrimitive("Chapter Three Carved Mechanism Backplate",
                PrimitiveType.Cube, new Vector3(0f, 2.27f, .28f),
                new Vector3(4.4f, 1.15f, .16f), stone, true);
            chapterThreeWorldCollider = backing.GetComponent<Collider>();
            GameObject indicator = CreatePrimitive("Chapter Three Mechanism Status Inlay",
                PrimitiveType.Cube, new Vector3(0f, 1.87f, .13f),
                new Vector3(3.91f, .09f, .17f), slate);
            chapterThreeWorldIndicator = indicator.GetComponent<Renderer>();
            AddWorldLabel("Chapter Three Mechanism Title", visual.MechanismTitle,
                new Vector3(0f, 2.62f, .15f), .12f, Ivory);
            AddWorldLabel("Chapter Three Mechanism Inscription", visual.Inscription,
                new Vector3(0f, 2.34f, .14f), .075f, Ivory);
            GameObject diagram = new GameObject("Chapter Three Mechanism State", typeof(TextMesh));
            diagram.layer = SceneryLayer;
            diagram.transform.SetParent(sceneRoot.transform, false);
            diagram.transform.localPosition = new Vector3(0f, 2.02f, .14f);
            diagram.transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
            chapterThreeWorldMark = diagram.GetComponent<TextMesh>();
            chapterThreeWorldMark.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            chapterThreeWorldMark.fontSize = 72;
            chapterThreeWorldMark.characterSize = .09f;
            chapterThreeWorldMark.color = Ivory;
            chapterThreeWorldMark.anchor = TextAnchor.MiddleCenter;
            chapterThreeWorldMark.alignment = TextAlignment.Center;
            chapterThreeWorldMark.text = visual.LockedMark;
            Renderer renderer = diagram.GetComponent<Renderer>();
            if (chapterThreeWorldMark.font != null && renderer != null)
                renderer.sharedMaterial = chapterThreeWorldMark.font.material;
            // One site-specific metal relief replaces four identical cylinders.
            // Only the stone backplate is pickable; decorative geometry has no collider.
            GameObject relief = new GameObject("Chapter Three Physical Relief",
                typeof(MeshFilter), typeof(MeshRenderer));
            relief.layer = SceneryLayer;
            relief.transform.SetParent(sceneRoot.transform, false);
            relief.transform.localPosition = new Vector3(0f, 1.66f, -.08f);
            chapterThreeReliefMesh = ChapterThreeReliefMesh.Create(current.LocationNumber,
                ChapterThreeReliefStage.Locked);
            chapterThreeReliefStage = ChapterThreeReliefStage.Locked;
            ownedMeshes.Add(chapterThreeReliefMesh);
            relief.GetComponent<MeshFilter>().sharedMesh = chapterThreeReliefMesh;
            chapterThreeReliefRenderer = relief.GetComponent<MeshRenderer>();
            chapterThreeReliefRenderer.sharedMaterial = brass;
        }

        private void BuildChapterThreeViewer(Transform parent)
        {
            ChapterThreeVisualSpec visual = ChapterThreeVisualCatalog.Get(current.LocationNumber);
            chapterThreeOverlay = new GameObject("Chapter Three World Mechanism",
                typeof(RectTransform), typeof(Image));
            chapterThreeOverlay.transform.SetParent(parent, false);
            RectTransform root = chapterThreeOverlay.GetComponent<RectTransform>();
            root.anchorMin = root.anchorMax = new Vector2(.5f, .5f);
            root.anchoredPosition = Vector2.zero;
            root.sizeDelta = new Vector2(1600f, 900f);
            Image modalBackdrop = chapterThreeOverlay.GetComponent<Image>();
            modalBackdrop.color = new Color(.015f, .023f, .038f, .98f);
            modalBackdrop.raycastTarget = true;
            AddText("Chapter Three Mechanism Heading", root, visual.MechanismTitle,
                new Vector2(-120f, 350f), new Vector2(1120f, 70f), 32);
            AddText("Chapter Three World Mechanism Inscription", root, visual.Inscription,
                new Vector2(0f, 245f), new Vector2(1400f, 60f), 20);
            StoryDossierCase dossier = StoryDossierCatalog.Get(current.LocationNumber);
            Text evidence = AddText("Chapter Three Inspected Fragments", root,
                "EVIDENCE A: " + dossier.EvidenceFragments[0] + "\n\nEVIDENCE B: " +
                dossier.EvidenceFragments[1],
                new Vector2(0f, 115f), new Vector2(1370f, 190f), 22);
            evidence.alignment = TextAnchor.MiddleLeft;
            AddText("Chapter Three Mechanism Question", root, dossier.Question,
                new Vector2(0f, -24f), new Vector2(1350f, 72f), 24);
            for (int index = 0; index < chapterThreeOptions.Length; index++)
            {
                int captured = index;
                float x = index % 2 == 0 ? -363f : 363f;
                float y = index < 2 ? -129f : -230f;
                chapterThreeOptions[index] = AddButton(dossier.Choices[index], root,
                    new Vector2(x, y), new Vector2(680f, 76f),
                    () => TrySelectChapterThreeChoice(captured));
            }
            chapterThreeFeedback = AddText("Chapter Three Mechanism Feedback", root,
                string.Empty, new Vector2(0f, -320f), new Vector2(1200f, 43f), 22);
            chapterThreeHintText = AddText("Chapter Three Mechanism Hint", root,
                string.Empty, new Vector2(0f, -369f), new Vector2(1220f, 36f), 17);
            chapterThreeHintButton = AddButton("REQUEST MECHANISM HINT", root,
                new Vector2(637f, 345f), new Vector2(295f, 56f),
                () => TryRequestChapterThreeHint());
            AddButton("CLOSE CHAPTER THREE MECHANISM", root,
                new Vector2(-638f, 345f), new Vector2(300f, 56f), CloseChapterThreeViewer);
            chapterThreeOverlay.SetActive(false);
        }

        public bool TryOpenChapterThreeViewer()
        {
            if (!IsChapterThreeLocation || chapterThreeOverlay == null ||
                inspection == null || !inspection.CanDeduce || IsArtworkOpen ||
                IsComparisonOpen || IsThresholdOpen || IsSpiralOpen || IsChapterThreeOpen)
                return false;
            gesture.Cancel();
            previousPinchDistance = -1f;
            chapterThreeOverlay.SetActive(true);
            RefreshChapterThreeViewer();
            RefreshInterface();
            return true;
        }

        public void CloseChapterThreeViewer()
        {
            if (!IsChapterThreeLocation || chapterThreeOverlay == null) return;
            chapterThreeOverlay.SetActive(false);
            RefreshInterface();
        }

        public bool TryRequestChapterThreeHint()
        {
            if (!IsChapterThreeLocation || !IsChapterThreeOpen ||
                inspection == null || IsArtworkOpen || IsComparisonOpen ||
                !chapterThreePuzzle.TryRevealHint(inspection.HasInspected(0),
                    inspection.HasInspected(1))) return false;
            RefreshChapterThreeViewer();
            return true;
        }

        public ChapterThreeSelection TrySelectChapterThreeChoice(int choiceIndex)
        {
            if (!IsChapterThreeLocation || !IsChapterThreeOpen ||
                inspection == null || IsArtworkOpen || IsComparisonOpen)
                return ChapterThreeSelection.Invalid;
            bool firstClue = inspection.HasInspected(0);
            bool secondClue = inspection.HasInspected(1);
            ChapterThreeSelection result = chapterThreePuzzle.Select(choiceIndex,
                firstClue, secondClue);
            lastChapterThreeSelection = result;
            if (result == ChapterThreeSelection.Verified)
            {
                ChapterThreeVisualSpec visual = ChapterThreeVisualCatalog.Get(current.LocationNumber);
                if (chapterThreeWorldIndicator != null)
                    chapterThreeWorldIndicator.sharedMaterial = chapterThreeSolvedMaterial;
                if (chapterThreeReliefMesh != null)
                {
                    ChapterThreeReliefMesh.Rebuild(chapterThreeReliefMesh,
                        current.LocationNumber, ChapterThreeReliefStage.Restored);
                    chapterThreeReliefStage = ChapterThreeReliefStage.Restored;
                }
                if (chapterThreeReliefRenderer != null)
                    chapterThreeReliefRenderer.sharedMaterial = chapterThreeSolvedMaterial;
            }
            RefreshChapterThreeViewer();
            RefreshInterface();
            return result;
        }

        private void RefreshChapterThreeWorldMark()
        {
            if (chapterThreeWorldMark == null || current == null || inspection == null ||
                current.ChapterNumber != 3 || chapterThreePuzzle == null) return;
            ChapterThreeVisualSpec visual = ChapterThreeVisualCatalog.Get(current.LocationNumber);
            bool inspectedA = inspection.HasInspected(0);
            bool inspectedB = inspection.HasInspected(1);
            chapterThreeWorldMark.text = visual.GetVisibleMark(
                inspection.HasInspected(0), inspection.HasInspected(1), chapterThreePuzzle.IsVerified);
            ChapterThreeReliefStage required = !inspectedA || !inspectedB ?
                ChapterThreeReliefStage.Locked : chapterThreePuzzle.IsVerified ?
                ChapterThreeReliefStage.Restored : ChapterThreeReliefStage.Investigating;
            if (chapterThreeReliefMesh != null && required != chapterThreeReliefStage)
            {
                ChapterThreeReliefMesh.Rebuild(chapterThreeReliefMesh, current.LocationNumber, required);
                chapterThreeReliefStage = required;
            }
        }

        private void RefreshChapterThreeViewer()
        {
            if (!IsChapterThreeLocation || chapterThreeFeedback == null) return;
            bool solved = chapterThreePuzzle.IsVerified;
            chapterThreeFeedback.text = solved ? "MECHANISM RESTORED - CLUE LOCK RELEASED" :
                lastChapterThreeSelection == ChapterThreeSelection.Incorrect ?
                "THAT ALIGNMENT CONTRADICTS THE EVIDENCE. COMPARE BOTH CLUES." :
                "THE TWO CLUES ARE AVAILABLE. RESTORE THE PHYSICAL MECHANISM.";
            chapterThreeHintText.text = chapterThreePuzzle.HintStage > 0 ?
                "HINT " + chapterThreePuzzle.HintStage + "/3: " +
                chapterThreePuzzle.Hints[chapterThreePuzzle.HintStage - 1] : string.Empty;
            if (chapterThreeHintButton != null)
                chapterThreeHintButton.interactable = !solved &&
                    chapterThreePuzzle.HintStage < ChapterThreeMechanismPuzzle.MaximumHintStage;
            for (int index = 0; index < chapterThreeOptions.Length; index++)
            {
                Button option = chapterThreeOptions[index];
                if (option == null) continue;
                option.interactable = !solved;
                option.image.color = solved && chapterThreePuzzle.Case.IsCorrect(index) ?
                    new Color(.26f, .61f, .40f) :
                    !solved && lastChapterThreeSelection == ChapterThreeSelection.Incorrect &&
                    chapterThreePuzzle.LastChoice == index ? new Color(.70f, .26f, .26f) : Brass;
            }
        }


        private void BuildChapterFourWorldDisplay(Material stone, Material slate, Material brass)
        {
            chapterFourSolvedMaterial = CreateColorMaterial("Restored Meridian Brass",
                new Color(.28f, .64f, .44f));
            GameObject backing = CreatePrimitive("Meridian Ring Backplate", PrimitiveType.Cube,
                new Vector3(0f, 2.27f, .28f), new Vector3(4.4f, 1.15f, .16f), stone, true);
            chapterFourWorldCollider = backing.GetComponent<Collider>();
            GameObject indicator = CreatePrimitive("Meridian Alignment Status Inlay",
                PrimitiveType.Cube, new Vector3(0f, 1.87f, .13f),
                new Vector3(3.91f, .09f, .17f), slate);
            chapterFourWorldIndicator = indicator.GetComponent<Renderer>();
            AddWorldLabel("Meridian Title", "THE HOLLOW MERIDIAN",
                new Vector3(0f, 2.62f, .15f), .12f, Ivory);
            AddWorldLabel("Meridian Inscription", "FOUR RINGS. TWO RECORDS. ONE ALIGNMENT.",
                new Vector3(0f, 2.34f, .14f), .075f, Ivory);
            var textObject = new GameObject("Meridian World Ring Order", typeof(TextMesh));
            textObject.layer = SceneryLayer;
            textObject.transform.SetParent(sceneRoot.transform, false);
            textObject.transform.localPosition = new Vector3(0f, 2.02f, .14f);
            textObject.transform.localRotation = Quaternion.Euler(0f, 180f, 0f);
            chapterFourWorldMark = textObject.GetComponent<TextMesh>();
            chapterFourWorldMark.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            chapterFourWorldMark.fontSize = 70;
            chapterFourWorldMark.characterSize = .09f;
            chapterFourWorldMark.color = Ivory;
            chapterFourWorldMark.anchor = TextAnchor.MiddleCenter;
            chapterFourWorldMark.alignment = TextAlignment.Center;
            chapterFourWorldMark.text = "MERIDIAN SEALED - INSPECT TWO RECORDS";
            Renderer textRenderer = textObject.GetComponent<Renderer>();
            if (chapterFourWorldMark.font != null && textRenderer != null)
                textRenderer.sharedMaterial = chapterFourWorldMark.font.material;
            var relief = new GameObject("Meridian Four-Ring Physical Relief",
                typeof(MeshFilter), typeof(MeshRenderer));
            relief.layer = SceneryLayer;
            relief.transform.SetParent(sceneRoot.transform, false);
            relief.transform.localPosition = new Vector3(0f, 1.66f, -.08f);
            chapterFourReliefMesh = ChapterFourMeridianRelief.Create(
                MeridianReliefStage.Locked, chapterFourPuzzle.Order);
            chapterFourReliefStage = MeridianReliefStage.Locked;
            ownedMeshes.Add(chapterFourReliefMesh);
            relief.GetComponent<MeshFilter>().sharedMesh = chapterFourReliefMesh;
            chapterFourReliefRenderer = relief.GetComponent<MeshRenderer>();
            chapterFourReliefRenderer.sharedMaterial = brass;
        }

        private void BuildChapterFourViewer(Transform parent)
        {
            chapterFourOverlay = new GameObject("Meridian Ring Alignment",
                typeof(RectTransform), typeof(Image));
            chapterFourOverlay.transform.SetParent(parent, false);
            RectTransform root = chapterFourOverlay.GetComponent<RectTransform>();
            root.anchorMin = root.anchorMax = new Vector2(.5f, .5f);
            root.anchoredPosition = Vector2.zero;
            root.sizeDelta = new Vector2(1600f, 900f);
            Image modalBackdrop = chapterFourOverlay.GetComponent<Image>();
            modalBackdrop.color = new Color(.015f, .023f, .038f, .98f);
            modalBackdrop.raycastTarget = true;
            AddText("Meridian Heading", root, "THE HOLLOW MERIDIAN | FOUR RINGS",
                new Vector2(0f, 335f), new Vector2(1070f, 72f), 30);
            StoryDossierCase dossier = StoryDossierCatalog.Get(ChapterFourMeridianPuzzle.LocationNumber);
            Text evidence = AddText("Meridian Evidence", root,
                "EVIDENCE A: " + dossier.EvidenceFragments[0] + "\n\nEVIDENCE B: " +
                dossier.EvidenceFragments[1], new Vector2(0f, 172f),
                new Vector2(1370f, 185f), 23);
            evidence.alignment = TextAnchor.MiddleLeft;
            AddText("Meridian Instructions", root,
                "SELECT TWO RING POSITIONS TO SWAP. ALIGN THE ORIGINAL FOUR RINGS.",
                new Vector2(0f, 36f), new Vector2(1370f, 62f), 23);
            for (int index = 0; index < chapterFourSlots.Length; index++)
            {
                int captured = index;
                chapterFourSlots[index] = AddButton("RING", root,
                    new Vector2((index - 1.5f) * 345f, -101f),
                    new Vector2(305f, 92f), () => TrySelectChapterFourPosition(captured));
            }
            chapterFourFeedback = AddText("Meridian Feedback", root, string.Empty,
                new Vector2(0f, -244f), new Vector2(1400f, 82f), 22);
            chapterFourHintText = AddText("Meridian Hint", root, string.Empty,
                new Vector2(0f, -326f), new Vector2(1300f, 65f), 17);
            chapterFourHintButton = AddButton("REQUEST MERIDIAN HINT", root,
                new Vector2(625f, 349f), new Vector2(315f, 55f),
                () => TryRequestChapterFourHint());
            AddButton("CLOSE MERIDIAN", root, new Vector2(-630f, 349f),
                new Vector2(305f, 55f), CloseChapterFourViewer);
            chapterFourOverlay.SetActive(false);
        }

        public bool TryFocusChapterFourMechanism()
        {
            if (!IsChapterFourLocation || sceneCamera == null || IsArtworkOpen ||
                IsComparisonOpen || IsThresholdOpen || IsSpiralOpen ||
                IsChapterTwoOpen || IsChapterThreeOpen || IsChapterFourOpen) return false;
            focusedEvidenceIndex = -1;
            crestFocusActive = chapterTwoFocusActive = chapterThreeFocusActive = false;
            chapterFourFocusActive = true;
            cameraYaw = 0f;
            cameraDistance = ChapterFourFocusDistance;
            gesture.Cancel();
            previousPinchDistance = -1f;
            SetCameraOrbit();
            RefreshInterface();
            return true;
        }

        public bool TryOpenChapterFourViewer()
        {
            if (!IsChapterFourLocation || chapterFourOverlay == null ||
                inspection == null || !inspection.CanDeduce || IsArtworkOpen ||
                IsComparisonOpen || IsThresholdOpen || IsSpiralOpen ||
                IsChapterTwoOpen || IsChapterThreeOpen || IsChapterFourOpen) return false;
            gesture.Cancel();
            previousPinchDistance = -1f;
            chapterFourOverlay.SetActive(true);
            RefreshChapterFourViewer();
            RefreshInterface();
            return true;
        }

        public void CloseChapterFourViewer()
        {
            if (!IsChapterFourLocation || chapterFourOverlay == null) return;
            chapterFourOverlay.SetActive(false);
            RefreshInterface();
        }

        public bool TryRequestChapterFourHint()
        {
            if (!IsChapterFourLocation || !IsChapterFourOpen || inspection == null ||
                chapterFourVisualDesynchronized || IsArtworkOpen || IsComparisonOpen ||
                !chapterFourPuzzle.TryRevealHint(inspection.HasInspected(0),
                    inspection.HasInspected(1))) return false;
            RefreshChapterFourViewer();
            return true;
        }

        public MeridianMoveResult TrySelectChapterFourPosition(int index)
        {
            if (!IsChapterFourLocation || !IsChapterFourOpen || inspection == null ||
                chapterFourVisualDesynchronized || IsArtworkOpen || IsComparisonOpen)
                return MeridianMoveResult.Invalid;
            lastChapterFourMove = chapterFourPuzzle.SelectPosition(index,
                inspection.HasInspected(0), inspection.HasInspected(1));
            try
            {
                if (lastChapterFourMove == MeridianMoveResult.Swapped ||
                    lastChapterFourMove == MeridianMoveResult.Verified)
                {
                    if (chapterFourReliefMesh == null)
                        throw new InvalidOperationException("Chapter Four relief is unavailable.");
                    MeridianReliefStage nextStage = lastChapterFourMove == MeridianMoveResult.Verified ?
                        MeridianReliefStage.Restored : MeridianReliefStage.Investigating;
                    ChapterFourMeridianRelief.Rebuild(chapterFourReliefMesh, nextStage,
                        chapterFourPuzzle.Order);
                    chapterFourReliefStage = nextStage;
                    SynchronizeMeridianWorldRings();
                }
                if (lastChapterFourMove == MeridianMoveResult.Verified)
                {
                    if (chapterFourWorldIndicator != null)
                        chapterFourWorldIndicator.sharedMaterial = chapterFourSolvedMaterial;
                    if (chapterFourReliefRenderer != null)
                        chapterFourReliefRenderer.sharedMaterial = chapterFourSolvedMaterial;
                }
            }
            catch (Exception error)
            {
                // Domain state is never rolled back after a committed move.
                // Block deduction and further mutation until the scene is reopened.
                chapterFourVisualDesynchronized = true;
                Debug.LogException(error, this);
            }
            RefreshChapterFourViewer();
            RefreshInterface();
            return chapterFourVisualDesynchronized ? MeridianMoveResult.Invalid : lastChapterFourMove;
        }

        /// <summary>
        /// Synchronizes the visible physical ring orientations with the authoritative
        /// four-slot permutation. Decorative geometry never decides puzzle success.
        /// </summary>
        private void SynchronizeMeridianWorldRings()
        {
            if (chapterFourPuzzle == null || chapterFourVisualDesynchronized) return;
            for (int index = 0; index < meridianWorldRings.Length; index++)
            {
                Transform ring = meridianWorldRings[index];
                Renderer renderer = meridianWorldRingRenderers[index];
                if (ring == null || renderer == null)
                    throw new InvalidOperationException("Meridian world ring geometry is unavailable.");
                int symbolIndex = chapterFourPuzzle.Order[index] - 'A';
                if (symbolIndex < 0 || symbolIndex >= ChapterFourMeridianPuzzle.RingCount)
                    throw new InvalidOperationException("Meridian world ring order is invalid.");
                ring.localRotation = Quaternion.Euler(
                    18f + index * 24f, symbolIndex * 30f,
                    20f + index * 33f + symbolIndex * 12f);
                if (chapterFourPuzzle.IsVerified && chapterFourSolvedMaterial != null)
                    renderer.sharedMaterial = chapterFourSolvedMaterial;
            }
        }

        private void RefreshChapterFourWorldMark()
        {
            if (!IsChapterFourLocation || inspection == null || chapterFourWorldMark == null)
                return;
            bool cluesRead = inspection.CanDeduce;
            MeridianReliefStage stage = !cluesRead ? MeridianReliefStage.Locked :
                chapterFourPuzzle.IsVerified ? MeridianReliefStage.Restored :
                MeridianReliefStage.Investigating;
            if (!chapterFourVisualDesynchronized && chapterFourReliefMesh != null &&
                stage != chapterFourReliefStage)
            {
                ChapterFourMeridianRelief.Rebuild(chapterFourReliefMesh, stage,
                    chapterFourPuzzle.Order);
                chapterFourReliefStage = stage;
            }
            chapterFourWorldMark.text = chapterFourVisualDesynchronized ?
                "MERIDIAN DISPLAY ERROR - REOPEN INVESTIGATION" :
                !cluesRead ? "MERIDIAN SEALED - INSPECT TWO RECORDS" :
                chapterFourPuzzle.IsVerified ? "MERIDIAN RESTORED: A-B-C-D" :
                "CURRENT: " + ChapterFourOrder + " | ALIGNMENT REQUIRED";
        }

        private void RefreshChapterFourViewer()
        {
            if (!IsChapterFourLocation || chapterFourFeedback == null) return;
            if (!chapterFourVisualDesynchronized)
            {
                try { SynchronizeMeridianWorldRings(); }
                catch (Exception error)
                {
                    chapterFourVisualDesynchronized = true;
                    Debug.LogException(error, this);
                }
            }
            bool solved = chapterFourPuzzle.IsVerified;
            chapterFourFeedback.text = chapterFourVisualDesynchronized ?
                "VISUAL STATE UNAVAILABLE - EXIT AND REOPEN THE INVESTIGATION." :
                solved ? "MERIDIAN RESTORED - DEDUCTION UNLOCKED" :
                lastChapterFourMove == MeridianMoveResult.Swapped ?
                "RINGS MOVED. REVIEW THE ARCHIVE CONSTRAINTS." :
                chapterFourPuzzle.SelectedIndex >= 0 ?
                "FIRST RING SELECTED. CHOOSE ANOTHER POSITION TO SWAP." :
                "SELECT TWO RING POSITIONS TO SWAP.";
            chapterFourHintText.text = chapterFourPuzzle.HintStage > 0 ?
                "HINT " + chapterFourPuzzle.HintStage + "/3: " +
                chapterFourPuzzle.Hints[chapterFourPuzzle.HintStage - 1] : string.Empty;
            if (chapterFourHintButton != null)
                chapterFourHintButton.interactable = !solved && !chapterFourVisualDesynchronized &&
                    chapterFourPuzzle.HintStage < ChapterFourMeridianPuzzle.MaximumHintStage;
            for (int index = 0; index < chapterFourSlots.Length; index++)
            {
                Button button = chapterFourSlots[index];
                if (button == null) continue;
                button.interactable = !solved && !chapterFourVisualDesynchronized;
                button.image.color = chapterFourPuzzle.SelectedIndex == index ?
                    new Color(.90f, .72f, .26f) :
                    solved ? new Color(.26f, .61f, .40f) : Brass;
                Text caption = button.GetComponentInChildren<Text>();
                if (caption != null) caption.text = "SLOT " + (index + 1) +
                    "  |  " + chapterFourPuzzle.Order[index];
            }
        }

        private void BuildSpiralViewer(Transform parent)
        {
            spiralOverlay = new GameObject("Ceremonial Stair Pattern Puzzle",
                typeof(RectTransform), typeof(Image));
            spiralOverlay.transform.SetParent(parent, false);
            RectTransform panel = spiralOverlay.GetComponent<RectTransform>();
            panel.anchorMin = panel.anchorMax = new Vector2(.5f, .5f);
            panel.anchoredPosition = Vector2.zero;
            panel.sizeDelta = new Vector2(1600f, 900f);
            Image background = spiralOverlay.GetComponent<Image>();
            background.color = new Color(.015f, .02f, .035f, .97f);
            background.raycastTarget = true;
            spiralSymbolAtlas = ChapterOneSymbolAtlas.Create();
            ownedTextures.Add(spiralSymbolAtlas);

            AddText("Stair Puzzle Heading", panel,
                "THE SPIRAL OF TESTIMONY  |  RESTORE THE MISSING BALUSTER",
                new Vector2(0f, 335f), new Vector2(1400f, 80f), 28);
            AddText("Stair Puzzle Instructions", panel,
                "Examine the repeating marks, then drag the correct loose symbol into slot six.",
                new Vector2(0f, 235f), new Vector2(1400f, 85f), 22);
            for (int index = 0; index < SpiralBalusterPuzzle.VisibleSequence.Count; index++)
            {
                BalusterSymbol symbol = SpiralBalusterPuzzle.VisibleSequence[index];
                float x = -540f + index * 216f;
                var tile = new GameObject("Stair Motif Slot " + (index + 1),
                    typeof(RectTransform), typeof(Image));
                tile.transform.SetParent(panel, false);
                RectTransform tileRect = tile.GetComponent<RectTransform>();
                tileRect.anchorMin = tileRect.anchorMax = new Vector2(.5f, .5f);
                tileRect.anchoredPosition = new Vector2(x, 45f);
                tileRect.sizeDelta = new Vector2(164f, 155f);
                Image tileImage = tile.GetComponent<Image>();
                tileImage.color = symbol == BalusterSymbol.Missing ?
                    new Color(.28f, .22f, .22f, 1f) : new Color(.16f, .18f, .22f, 1f);
                tileImage.raycastTarget = false;
                var iconObject = new GameObject("Stair Motif Graphic " + (index + 1),
                    typeof(RectTransform), typeof(RawImage));
                iconObject.transform.SetParent(tile.transform, false);
                RectTransform iconRect = iconObject.GetComponent<RectTransform>();
                iconRect.anchorMin = iconRect.anchorMax = new Vector2(.5f, .5f);
                iconRect.anchoredPosition = new Vector2(0f, 28f);
                iconRect.sizeDelta = new Vector2(84f, 84f);
                RawImage icon = iconObject.GetComponent<RawImage>();
                icon.texture = spiralSymbolAtlas;
                icon.uvRect = ChapterOneSymbolAtlas.GetUv(symbol == BalusterSymbol.Missing ?
                    BalusterSymbol.Star : symbol);
                icon.color = Ivory;
                icon.raycastTarget = false;
                iconObject.SetActive(symbol != BalusterSymbol.Missing);
                string mark = symbol == BalusterSymbol.Circle ? "CIRCLE" :
                    symbol == BalusterSymbol.Diamond ? "DIAMOND" :
                    symbol == BalusterSymbol.Star ? "STAR" : "?";
                Text caption = AddText("Stair Motif Identifier " + (index + 1), tile.transform,
                    mark, new Vector2(0f, -36f), new Vector2(154f, 29f), 18);
                AddText("Stair Motif Number " + (index + 1), tile.transform,
                    (index + 1).ToString(), new Vector2(0f, -64f), new Vector2(100f, 24f), 17);
                if (symbol == BalusterSymbol.Missing)
                {
                    spiralDropTarget = tileRect;
                    spiralMissingIcon = icon;
                    spiralMissingCaption = caption;
                    spiralMissingTile = tileImage;
                }
            }
            BalusterSymbol[] symbols = { BalusterSymbol.Circle, BalusterSymbol.Diamond,
                BalusterSymbol.Crescent, BalusterSymbol.Star };
            for (int index = 0; index < symbols.Length; index++)
            {
                BalusterSymbol choice = symbols[index];
                string label = "SELECT " + choice.ToString().ToUpperInvariant();
                spiralOptions[index] = AddButton(label, panel,
                    new Vector2(-435f + index * 290f, -160f), new Vector2(254f, 70f),
                    ShowSpiralDragInstructions);
                Text tokenCaption = spiralOptions[index].GetComponentInChildren<Text>();
                if (tokenCaption != null) tokenCaption.text = "DRAG " + choice.ToString().ToUpperInvariant();
                spiralOptions[index].gameObject.AddComponent<ChapterPuzzleDragToken>().Initialize(
                    panel, spiralDropTarget,
                    () => isOpen && IsSpiralOpen && inspection != null &&
                        inspection.CanDeduce && !spiralPuzzle.IsVerified,
                    inside => inside && TrySelectSpiralSymbol(choice) == BalusterSelection.Verified, true);
            }
            spiralFeedback = AddText("Stair Puzzle Feedback", panel, string.Empty,
                new Vector2(0f, -258f), new Vector2(1380f, 75f), 22);
            spiralHintText = AddText("Stair Pattern Hint Guidance", panel, string.Empty,
                new Vector2(0f, -314f), new Vector2(1390f, 45f), 18);
            spiralHintButton = AddButton("REQUEST STAIR HINT", panel,
                new Vector2(632f, 335f), new Vector2(265f, 56f), TryRequestSpiralHint);
            AddButton("CLOSE STAIR PATTERN", panel, new Vector2(0f, -377f),
                new Vector2(310f, 64f), CloseSpiralViewer);
            spiralOverlay.SetActive(false);
        }

        private void ShowSpiralDragInstructions()
        {
            if (spiralFeedback != null && IsSpiralOpen && !spiralPuzzle.IsVerified)
                spiralFeedback.text = "DRAG A SYMBOL INTO THE EMPTY SIXTH BALUSTER SLOT.";
        }

        public bool TryOpenSpiralViewer()
        {
            if (!isOpen || current == null || current.LocationNumber != SpiralBalusterPuzzle.LocationNumber ||
                spiralOverlay == null || inspection == null || !inspection.CanDeduce ||
                IsArtworkOpen || IsComparisonOpen || IsThresholdOpen || IsSpiralOpen || IsChapterTwoOpen)
                return false;
            gesture.Cancel();
            previousPinchDistance = -1f;
            spiralOverlay.SetActive(true);
            RefreshSpiralFeedback();
            RefreshInterface();
            return true;
        }

        public void CloseSpiralViewer()
        {
            if (!isOpen || spiralOverlay == null) return;
            spiralOverlay.SetActive(false);
            RefreshInterface();
        }

        /// <summary>
        /// Offers optional, case-scoped guidance; hints cannot inspect evidence, unlock
        /// the conclusion, persist progress, or bypass the physical pattern selection.
        /// </summary>
        public bool TryRequestSpiralHint()
        {
            if (!isOpen || current == null ||
                current.LocationNumber != SpiralBalusterPuzzle.LocationNumber ||
                inspection == null || !inspection.CanDeduce || !IsSpiralOpen ||
                IsArtworkOpen || IsComparisonOpen || IsThresholdOpen ||
                spiralPuzzle.IsVerified || spiralHintStage >= 3)
                return false;
            spiralHintStage++;
            RefreshSpiralFeedback();
            return true;
        }

        public BalusterSelection TrySelectSpiralSymbol(BalusterSymbol symbol)
        {
            if (!isOpen || current == null || current.LocationNumber != SpiralBalusterPuzzle.LocationNumber ||
                inspection == null || !IsSpiralOpen || IsArtworkOpen || IsComparisonOpen || IsThresholdOpen)
                return BalusterSelection.Invalid;
            bool hasFirstClue = inspection.HasInspected(0);
            bool hasSecondClue = inspection.HasInspected(1);
            BalusterSelection result = spiralPuzzle.Select(symbol, hasFirstClue, hasSecondClue);
            lastSpiralSelection = result;
            lastSpiralSymbol = symbol;
            if (result == BalusterSelection.Verified && spiralGlyphMesh != null)
                ChapterWorldSpiralGlyphGeometry.Repair(spiralGlyphMesh);
            RefreshSpiralFeedback();
            RefreshInterface();
            return result;
        }

        private void RefreshSpiralFeedback()
        {
            if (spiralFeedback == null) return;
            if (spiralMissingIcon != null)
                spiralMissingIcon.gameObject.SetActive(spiralPuzzle.IsVerified);
            if (spiralMissingCaption != null)
                spiralMissingCaption.text = spiralPuzzle.IsVerified ? "STAR" : "?";
            if (spiralMissingTile != null)
                spiralMissingTile.color = spiralPuzzle.IsVerified ?
                    new Color(.14f, .34f, .24f, 1f) :
                    lastSpiralSelection == BalusterSelection.Incorrect ?
                    new Color(.48f, .22f, .23f, 1f) : new Color(.28f, .22f, .22f, 1f);
            if (spiralHintText != null)
                spiralHintText.text = spiralHintStage == 1 ?
                    "HINT 1/3: Look for a repeating group rather than a color match." :
                    spiralHintStage == 2 ?
                    "HINT 2/3: The first matches the fourth; the second matches the fifth." :
                    spiralHintStage == 3 ?
                    "HINT 3/3: Position six repeats the symbol in position three." : string.Empty;
            if (spiralHintButton != null)
                spiralHintButton.interactable = !spiralPuzzle.IsVerified && spiralHintStage < 3;
            if (spiralPuzzle.IsVerified)
                spiralFeedback.text = "PATTERN RESTORED  |  THE SIXTH BALUSTER MATCHES THE THREE-MARK CYCLE";
            else if (lastSpiralSelection == BalusterSelection.Incorrect)
                spiralFeedback.text = "THAT MARK BREAKS THE CYCLE. COMPARE THE FIRST THREE POSITIONS.";
            else
                spiralFeedback.text = "DRAG THE MISSING MOTIF INTO SLOT SIX. COMPARE THE REPEATING PATTERN.";
            for (int index = 0; index < spiralOptions.Length; index++)
            {
                Button option = spiralOptions[index];
                if (option == null) continue;
                option.interactable = !spiralPuzzle.IsVerified;
                if (spiralPuzzle.IsVerified && spiralOptions[index].name == "SELECT STAR")
                    option.image.color = new Color(.23f, .56f, .35f, 1f);
                else if (!spiralPuzzle.IsVerified && lastSpiralSelection == BalusterSelection.Incorrect &&
                    spiralOptions[index].name == "SELECT " + lastSpiralSymbol.ToString().ToUpperInvariant())
                    option.image.color = new Color(.65f, .25f, .27f, 1f);
                else
                    option.image.color = Brass;
            }
        }

        private void BuildThresholdViewer(Transform parent)
        {
            thresholdOverlay = new GameObject("Threshold Crest Mechanism",
                typeof(RectTransform), typeof(Image));
            thresholdOverlay.transform.SetParent(parent, false);
            RectTransform root = thresholdOverlay.GetComponent<RectTransform>();
            root.anchorMin = root.anchorMax = new Vector2(.5f, .5f);
            root.anchoredPosition = Vector2.zero;
            root.sizeDelta = new Vector2(1600f, 900f);
            Image crestBackdrop = thresholdOverlay.GetComponent<Image>();
            crestBackdrop.color = new Color(.015f, .02f, .035f, .96f);
            crestBackdrop.raycastTarget = true;
            AddText("Crest Mechanism Heading", thresholdOverlay.transform,
                "THE THRESHOLD SEAL  |  COMPARE THE ORIGINAL AND THE ARCH",
                new Vector2(-135f, 354f), new Vector2(1180f, 80f), 28);
            AddText("Crest Mechanism Instructions", thresholdOverlay.transform,
                "Drag the letter tracing onto the arch, align the marks, then inspect the extra ray.",
                new Vector2(0f, 239f), new Vector2(1380f, 100f), 23);
            BuildCrestDiagram(thresholdOverlay.transform, false, new Vector2(-615f, 10f));
            BuildCrestDiagram(thresholdOverlay.transform, true, new Vector2(615f, 10f));
            BuildCrestTracingToken(root);
            thresholdFeedback = AddText("Crest Mechanism Feedback", thresholdOverlay.transform,
                string.Empty, new Vector2(0f, -238f), new Vector2(1400f, 75f), 23);
            thresholdHintText = AddText("Crest Hint Guidance", thresholdOverlay.transform,
                string.Empty, new Vector2(0f, -299f), new Vector2(1420f, 42f), 18);
            thresholdHintText.color = new Color(.83f, .74f, .58f);
            thresholdHintButton = AddButton("REQUEST CREST HINT", thresholdOverlay.transform,
                new Vector2(624f, 350f), new Vector2(270f, 54f),
                () => TryRequestCrestHint());
            for (int index = 0; index < ThresholdCrestPuzzle.SealRayAngles.Count; index++)
            {
                int capturedIndex = index;
                int column = index % 3;
                int row = index / 3;
                AddButton("SELECT ARCH RAY " + (index + 1), thresholdOverlay.transform,
                    new Vector2(-355f + 355f * column, 48f - 115f * row),
                    new Vector2(285f, 75f), () => TrySelectThresholdRayWithTracing(capturedIndex));
            }
            AddButton("CLOSE CREST VIEW", thresholdOverlay.transform,
                new Vector2(0f, -360f), new Vector2(320f, 66f), CloseThresholdViewer);
            thresholdOverlay.SetActive(false);
        }

        /// <summary>
        /// Draws the original and altered outlines from the authoritative domain angles.
        /// Six separate minimum-size button targets sit beyond the six lines and enable
        /// direct touch selection. Central numbered buttons remain an input alternative.
        /// </summary>
        private void BuildCrestDiagram(Transform parent, bool altered, Vector2 center)
        {
            string prefix = altered ? "Altered Seal" : "Original Letter";
            IReadOnlyList<int> angles = altered ? ThresholdCrestPuzzle.SealRayAngles :
                ThresholdCrestPuzzle.LetterRayAngles;
            AddText(prefix + " Diagram Label", parent,
                altered ? "ARCH  /  SIX RAYS" : "LETTER  /  FIVE RAYS",
                center + new Vector2(0f, 158f), new Vector2(330f, 48f), 19);

            var panel = new GameObject(prefix + " Diagram Panel", typeof(RectTransform),
                typeof(Image));
            panel.transform.SetParent(parent, false);
            RectTransform panelRect = panel.GetComponent<RectTransform>();
            panelRect.anchorMin = panelRect.anchorMax = new Vector2(.5f, .5f);
            panelRect.anchoredPosition = center;
            panelRect.sizeDelta = new Vector2(200f, 200f);
            if (altered) crestDropTarget = panelRect;
            Image panelImage = panel.GetComponent<Image>();
            panelImage.color = new Color(.11f, .13f, .16f, .95f);
            panelImage.raycastTarget = false;

            for (int index = 0; index < angles.Count; index++)
            {
                int angle = angles[index];
                float radians = angle * Mathf.Deg2Rad;
                string rayName = prefix + " Diagram Ray " + (index + 1);
                var lineObject = new GameObject(rayName, typeof(RectTransform), typeof(Image));
                lineObject.transform.SetParent(panel.transform, false);
                RectTransform lineRect = lineObject.GetComponent<RectTransform>();
                lineRect.anchorMin = lineRect.anchorMax = new Vector2(.5f, .5f);
                lineRect.sizeDelta = new Vector2(12f, 64f);
                lineRect.anchoredPosition = new Vector2(
                    Mathf.Cos(radians) * 42f, Mathf.Sin(radians) * 42f);
                lineRect.localRotation = Quaternion.Euler(0f, 0f, angle - 90f);
                Image lineImage = lineObject.GetComponent<Image>();
                lineImage.color = Brass;
                lineImage.raycastTarget = false;
                if (altered)
                {
                    thresholdDiagramRays[index] = lineImage;
                    int capturedIndex = index;
                    var target = new GameObject("SELECT DIAGRAM RAY " + (index + 1),
                        typeof(RectTransform), typeof(Image), typeof(Button));
                    target.transform.SetParent(panel.transform, false);
                    RectTransform targetRect = target.GetComponent<RectTransform>();
                    targetRect.anchorMin = targetRect.anchorMax = new Vector2(.5f, .5f);
                    targetRect.anchoredPosition = new Vector2(
                        Mathf.Cos(radians) * 109f, Mathf.Sin(radians) * 109f);
                    targetRect.sizeDelta = new Vector2(52f, 52f);
                    Image targetImage = target.GetComponent<Image>();
                    targetImage.color = new Color(.22f, .25f, .30f, .96f);
                    targetImage.raycastTarget = true;
                    Button targetButton = target.GetComponent<Button>();
                    targetButton.transition = Selectable.Transition.None;
                    targetButton.onClick.AddListener(() => TrySelectThresholdRayWithTracing(capturedIndex));
                    thresholdDiagramButtons[index] = targetButton;
                    Text number = AddText("Arch Diagram Ray Number " + (index + 1),
                        target.transform, (index + 1).ToString(), Vector2.zero,
                        new Vector2(44f, 44f), 20);
                    number.color = Ivory;
                }
            }
        }

        private void BuildCrestTracingToken(RectTransform canvasRoot)
        {
            var tokenObject = new GameObject("Draggable Letter Tracing",
                typeof(RectTransform), typeof(Image));
            tokenObject.transform.SetParent(canvasRoot, false);
            RectTransform tokenRect = tokenObject.GetComponent<RectTransform>();
            tokenRect.anchorMin = tokenRect.anchorMax = new Vector2(.5f, .5f);
            tokenRect.anchoredPosition = new Vector2(-615f, 10f);
            tokenRect.sizeDelta = new Vector2(168f, 168f);
            Image backing = tokenObject.GetComponent<Image>();
            backing.color = new Color(.76f, .67f, .47f, .18f);
            backing.raycastTarget = true;
            for (int index = 0; index < ThresholdCrestPuzzle.LetterRayAngles.Count; index++)
            {
                float radians = ThresholdCrestPuzzle.LetterRayAngles[index] * Mathf.Deg2Rad;
                var rayObject = new GameObject("Tracing Ray " + (index + 1),
                    typeof(RectTransform), typeof(Image));
                rayObject.transform.SetParent(tokenRect, false);
                RectTransform rayRect = rayObject.GetComponent<RectTransform>();
                rayRect.anchorMin = rayRect.anchorMax = new Vector2(.5f, .5f);
                rayRect.sizeDelta = new Vector2(9f, 65f);
                rayRect.anchoredPosition = new Vector2(
                    Mathf.Cos(radians) * 39f, Mathf.Sin(radians) * 39f);
                rayRect.localRotation = Quaternion.Euler(0f, 0f,
                    ThresholdCrestPuzzle.LetterRayAngles[index] - 90f);
                Image rayImage = rayObject.GetComponent<Image>();
                rayImage.color = new Color(.96f, .79f, .42f, .68f);
                rayImage.raycastTarget = false;
            }
            tokenObject.AddComponent<ChapterPuzzleDragToken>().Initialize(
                canvasRoot, crestDropTarget,
                () => isOpen && IsThresholdOpen && inspection != null &&
                    inspection.CanDeduce && !crestTracing.IsPlaced,
                TryPlaceCrestTracing);
        }

        public bool TryPlaceCrestTracing(bool releasedOverSeal = true)
        {
            if (inspection == null || current == null || !isOpen || IsArtworkOpen || IsComparisonOpen ||
                current.LocationNumber != 1 || !IsThresholdOpen)
                return false;
            lastCrestPlacement = crestTracing.TryPlace(releasedOverSeal,
                inspection.HasInspected(0), inspection.HasInspected(1));
            RefreshThresholdFeedback();
            return lastCrestPlacement == PhysicalPlacementResult.Placed;
        }

        private ThresholdRaySelection TrySelectThresholdRayWithTracing(int rayIndex)
        {
            if (!crestTracing.IsPlaced)
            {
                RefreshThresholdFeedback();
                return ThresholdRaySelection.EvidenceRequired;
            }
            return TrySelectThresholdRay(rayIndex);
        }

        public bool TryOpenThresholdViewer()
        {
            if (!isOpen || current == null || current.LocationNumber != 1 ||
                thresholdOverlay == null || inspection == null ||
                !inspection.CanDeduce || IsArtworkOpen || IsComparisonOpen || IsThresholdOpen)
                return false;
            gesture.Cancel();
            previousPinchDistance = -1f;
            thresholdOverlay.SetActive(true);
            RefreshThresholdFeedback();
            RefreshInterface();
            return true;
        }

        public void CloseThresholdViewer()
        {
            if (!isOpen || thresholdOverlay == null) return;
            thresholdOverlay.SetActive(false);
            RefreshInterface();
        }

        /// <summary>
        /// Read-only, progressively clearer guidance for the first crest comparison.
        /// A hint never inspects evidence, selects a ray or changes durable progress.
        /// Each session exposes at most three clues while its crest modal is open.
        /// </summary>
        public bool TryRequestCrestHint()
        {
            if (!isOpen || current == null || current.LocationNumber != 1 ||
                inspection == null || !inspection.CanDeduce || !IsThresholdOpen ||
                IsArtworkOpen || IsComparisonOpen || thresholdCrest.IsVerified ||
                thresholdHintStage >= 3) return false;
            thresholdHintStage++;
            RefreshThresholdFeedback();
            return true;
        }

        public ThresholdRaySelection TrySelectThresholdRay(int rayIndex)
        {
            if (!isOpen || current == null || current.LocationNumber != 1 ||
                inspection == null || IsArtworkOpen || IsComparisonOpen)
                return ThresholdRaySelection.Invalid;
            ThresholdRaySelection outcome = thresholdCrest.Select(rayIndex,
                inspection.HasInspected(0), inspection.HasInspected(1));
            lastThresholdSelection = outcome;
            if (outcome == ThresholdRaySelection.Incorrect ||
                outcome == ThresholdRaySelection.Verified)
                lastThresholdRayIndex = rayIndex;
            RefreshThresholdFeedback();
            RefreshInterface();
            return outcome;
        }

        private void RefreshThresholdFeedback()
        {
            if (thresholdFeedback == null) return;
            if (thresholdCrest.IsVerified)
                thresholdFeedback.text = "CREST VERIFIED  |  THE ALTERED RAY HAS BEEN IDENTIFIED";
            else if (lastThresholdSelection == ThresholdRaySelection.EvidenceRequired)
                thresholdFeedback.text = "INSPECT BOTH EVIDENCE FRAGMENTS BEFORE VERIFYING THE SEAL.";
            else if (lastThresholdSelection == ThresholdRaySelection.Incorrect)
                thresholdFeedback.text = "THIS MARK MATCHES THE ORIGINAL. COMPARE AGAIN.";
            else if (!crestTracing.IsPlaced)
                thresholdFeedback.text = lastCrestPlacement == PhysicalPlacementResult.MissedTarget ?
                    "THE TRACING MISSED THE ARCH. TRY PLACING IT DIRECTLY OVER THE SEAL." :
                    "DRAG THE TRANSPARENT LETTER TRACING ONTO THE ARCH SEAL FIRST.";
            else
                thresholdFeedback.text = "TRACING ALIGNED. SELECT THE ONE EXTRA ARCH RAY.";

            for (int index = 0; index < thresholdDiagramRays.Length; index++)
            {
                bool isVerifiedRay = thresholdCrest.IsVerified &&
                    index == ThresholdCrestPuzzle.AddedRayIndex;
                bool isRejectedRay = !thresholdCrest.IsVerified &&
                    lastThresholdSelection == ThresholdRaySelection.Incorrect &&
                    index == lastThresholdRayIndex;
                Image ray = thresholdDiagramRays[index];
                if (ray != null)
                {
                    if (thresholdCrest.IsVerified && index == ThresholdCrestPuzzle.AddedRayIndex)
                        ray.color = new Color(.32f, .78f, .50f);
                    else if (isRejectedRay)
                        ray.color = new Color(.86f, .35f, .35f);
                    else
                        ray.color = Brass;
                }
                Renderer worldRay = thresholdRayRenderers[index];
                if (worldRay == null) continue;
                Material stateMaterial = isVerifiedRay ? crestVerifiedMaterial :
                    isRejectedRay ? crestIncorrectMaterial : crestOriginalMaterial;
                if (stateMaterial != null && worldRay.sharedMaterial != stateMaterial)
                    worldRay.sharedMaterial = stateMaterial;
            }
            if (thresholdHintText != null)
            {
                if (thresholdCrest.IsVerified || thresholdHintStage == 0)
                    thresholdHintText.text = string.Empty;
                else if (thresholdHintStage == 1)
                    thresholdHintText.text = "HINT 1 / 3  |  Count the marks on both plaques.";
                else if (thresholdHintStage == 2)
                    thresholdHintText.text = "HINT 2 / 3  |  Compare each mark by its direction.";
                else
                    thresholdHintText.text = "HINT 3 / 3  |  Look between the fourth and fifth original rays.";
            }
            if (thresholdHintButton != null)
                thresholdHintButton.interactable = IsThresholdOpen &&
                    !thresholdCrest.IsVerified && thresholdHintStage < 3;
            // The diagram's touch targets mirror the 3D ray materials without allocating.
            for (int index = 0; index < thresholdDiagramButtons.Length; index++)
            {
                Button target = thresholdDiagramButtons[index];
                if (target == null) continue;
                bool verified = thresholdCrest.IsVerified &&
                    index == ThresholdCrestPuzzle.AddedRayIndex;
                bool rejected = !thresholdCrest.IsVerified &&
                    lastThresholdSelection == ThresholdRaySelection.Incorrect &&
                    index == lastThresholdRayIndex;
                target.interactable = crestTracing.IsPlaced && !thresholdCrest.IsVerified;
                target.image.color = verified ? new Color(.18f, .47f, .31f, 1f) :
                    rejected ? new Color(.56f, .18f, .21f, 1f) :
                    new Color(.22f, .25f, .30f, .96f);
            }
        }

        private void BuildArtworkViewer(Transform parent)
        {
            Texture image = materials.Find(material =>
                material != null && material.name == "Location Artwork - Owned Material")?.mainTexture;
            if (image == null || image.width <= 0 || image.height <= 0)
                throw new InvalidOperationException("A valid authored artwork texture is required.");

            artworkOverlay = new GameObject("Original Artwork Focus", typeof(RectTransform),
                typeof(Image));
            artworkOverlay.transform.SetParent(parent, false);
            RectTransform backdropRect = artworkOverlay.GetComponent<RectTransform>();
            backdropRect.anchorMin = backdropRect.anchorMax = new Vector2(.5f, .5f);
            backdropRect.anchoredPosition = Vector2.zero;
            backdropRect.sizeDelta = new Vector2(1600f, 900f);
            Image backdrop = artworkOverlay.GetComponent<Image>();
            backdrop.color = new Color(.015f, .02f, .03f, .97f);
            backdrop.raycastTarget = true;

            float aspect = (float)image.width / image.height;
            float imageWidth = Mathf.Min(1180f, 612f * aspect);
            float imageHeight = imageWidth / aspect;
            var imageObject = new GameObject("Original Artwork Uncropped", typeof(RectTransform),
                typeof(RawImage));
            imageObject.transform.SetParent(artworkOverlay.transform, false);
            RectTransform imageRect = imageObject.GetComponent<RectTransform>();
            imageRect.anchorMin = imageRect.anchorMax = new Vector2(.5f, .5f);
            imageRect.anchoredPosition = new Vector2(0f, 0f);
            imageRect.sizeDelta = new Vector2(imageWidth, imageHeight);
            artworkImage = imageObject.GetComponent<RawImage>();
            artworkImage.texture = image;
            artworkImage.uvRect = new Rect(0f, 0f, 1f, 1f);
            artworkImage.raycastTarget = false;

            // A transparent UGUI raycast surface handles drag without allocating or copying
            // the original texture. Coordinates are converted into the artwork's local space.
            var panObject = new GameObject("Artwork Pan Gesture Surface", typeof(RectTransform),
                typeof(Image), typeof(EventTrigger));
            panObject.transform.SetParent(artworkOverlay.transform, false);
            RectTransform panRect = panObject.GetComponent<RectTransform>();
            panRect.anchorMin = panRect.anchorMax = new Vector2(.5f, .5f);
            panRect.anchoredPosition = Vector2.zero;
            panRect.sizeDelta = imageRect.sizeDelta;
            Image panCapture = panObject.GetComponent<Image>();
            panCapture.color = Color.clear;
            panCapture.raycastTarget = true;
            var dragEntry = new EventTrigger.Entry { eventID = EventTriggerType.Drag };
            dragEntry.callback.AddListener(eventData =>
            {
                PointerEventData drag = eventData as PointerEventData;
                if (drag == null || !IsArtworkOpen || artworkViewport.Zoom <= 1f) return;
                Camera eventCamera = drag.pressEventCamera;
                if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(imageRect,
                    drag.position, eventCamera, out Vector2 currentLocal) ||
                    !RectTransformUtility.ScreenPointToLocalPointInRectangle(imageRect,
                    drag.position - drag.delta, eventCamera, out Vector2 previousLocal) ||
                    imageRect.rect.width <= 0f || imageRect.rect.height <= 0f)
                    return;
                float extent = artworkViewport.Extent;
                TryPanArtwork((previousLocal.x - currentLocal.x) * extent / imageRect.rect.width,
                    (previousLocal.y - currentLocal.y) * extent / imageRect.rect.height);
            });
            panObject.GetComponent<EventTrigger>().triggers.Add(dragEntry);

            AddText("Artwork Focus Title", artworkOverlay.transform,
                "ORIGINAL LOCATION REFERENCE  |  VISUAL STUDY ONLY",
                new Vector2(0f, 388f), new Vector2(1350f, 48f), 24);
            AddButton("CLOSE ART", artworkOverlay.transform,
                new Vector2(500f, -384f), new Vector2(260f, 64f),
                () => SetArtworkFocus(false));
            AddButton("ART ZOOM +", artworkOverlay.transform,
                new Vector2(-190f, -384f), new Vector2(220f, 64f),
                () => ZoomArtwork(.5f));
            AddButton("ART ZOOM -", artworkOverlay.transform,
                new Vector2(80f, -384f), new Vector2(220f, 64f),
                () => ZoomArtwork(-.5f));
            AddButton("ART PAN LEFT", artworkOverlay.transform,
                new Vector2(-420f, -320f), new Vector2(190f, 48f),
                () => TryPanArtwork(-.14f, 0f));
            AddButton("ART PAN RIGHT", artworkOverlay.transform,
                new Vector2(-210f, -320f), new Vector2(190f, 48f),
                () => TryPanArtwork(.14f, 0f));
            AddButton("ART PAN UP", artworkOverlay.transform,
                new Vector2(0f, -320f), new Vector2(190f, 48f),
                () => TryPanArtwork(0f, .14f));
            AddButton("ART PAN DOWN", artworkOverlay.transform,
                new Vector2(210f, -320f), new Vector2(190f, 48f),
                () => TryPanArtwork(0f, -.14f));
            artworkOverlay.SetActive(false);
        }

        private void BuildComparisonViewer(Transform parent)
        {
            comparisonOverlay = new GameObject("Evidence Comparison Viewer",
                typeof(RectTransform), typeof(Image));
            comparisonOverlay.transform.SetParent(parent, false);
            RectTransform backdrop = comparisonOverlay.GetComponent<RectTransform>();
            backdrop.anchorMin = backdrop.anchorMax = new Vector2(.5f, .5f);
            backdrop.anchoredPosition = Vector2.zero;
            backdrop.sizeDelta = new Vector2(1600f, 900f);
            Image image = comparisonOverlay.GetComponent<Image>();
            image.color = new Color(.015f, .02f, .03f, .98f);
            image.raycastTarget = true;
            AddText("Comparison Heading", comparisonOverlay.transform,
                "EVIDENCE COMPARISON  |  INVESTIGATOR NOTES",
                new Vector2(0f, 358f), new Vector2(1370f, 76f), 31);
            comparisonEvidenceA = AddText("Evidence A Comparison", comparisonOverlay.transform,
                string.Empty, new Vector2(-380f, 18f), new Vector2(660f, 490f), 23);
            comparisonEvidenceB = AddText("Evidence B Comparison", comparisonOverlay.transform,
                string.Empty, new Vector2(380f, 18f), new Vector2(660f, 490f), 23);
            comparisonEvidenceA.alignment = TextAnchor.UpperLeft;
            comparisonEvidenceB.alignment = TextAnchor.UpperLeft;
            AddText("Comparison Disclaimer", comparisonOverlay.transform,
                "Only examined clues are shown. Comparison does not solve the case.",
                new Vector2(0f, -286f), new Vector2(1320f, 70f), 21);
            AddButton("CLOSE COMPARISON", comparisonOverlay.transform,
                new Vector2(0f, -378f), new Vector2(300f, 66f), CloseComparison);
            comparisonOverlay.SetActive(false);
        }

        public bool TryOpenComparison()
        {
            if (!isOpen || inspection == null || comparisonOverlay == null ||
                IsArtworkOpen || IsComparisonOpen || inspection.InspectedCount == 0)
                return false;
            if (IsSpiralOpen || IsChapterTwoOpen) return false;
            if (IsChapterThreeOpen || IsChapterFourOpen) return false;
            if (IsThresholdOpen) return false;
            gesture.Cancel();
            previousPinchDistance = -1f;
            RefreshComparison();
            comparisonOverlay.SetActive(true);
            RefreshInterface();
            return true;
        }

        private void CloseComparison()
        {
            if (!isOpen || comparisonOverlay == null) return;
            comparisonOverlay.SetActive(false);
            RefreshInterface();
        }

        private void RefreshComparison()
        {
            if (current == null || inspection == null ||
                comparisonEvidenceA == null || comparisonEvidenceB == null) return;
            StoryDossierCase dossier = StoryDossierCatalog.Get(current.LocationNumber);
            for (int index = 0; index < ChapterEvidenceVisualCatalog.EvidencePerLocation; index++)
            {
                ChapterEvidenceVisualSpec spec = ChapterEvidenceVisualCatalog.Get(
                    current.LocationNumber, index);
                string caption = "EVIDENCE " + (char)('A' + index) + "  |  " + spec.Label +
                    "\nVISIBLE MARKS: " + spec.MotifCount + "\n\n";
                string excerpt = inspection.HasInspected(index) ?
                    dossier.EvidenceFragments[index] : "NOT EXAMINED - NO CLUE REVEALED";
                Text target = index == 0 ? comparisonEvidenceA : comparisonEvidenceB;
                target.text = caption + excerpt;
            }
        }

        private void SetArtworkFocus(bool focused)
        {
            if (!isOpen || artworkOverlay == null || artworkImage == null ||
                (focused && (IsThresholdOpen || IsComparisonOpen || IsSpiralOpen || IsChapterTwoOpen))) return;
            if (focused && (IsChapterThreeOpen || IsChapterFourOpen)) return;
            gesture.Cancel();
            previousPinchDistance = -1f;
            artworkViewport.Reset();
            ApplyArtworkViewport();
            artworkOverlay.SetActive(focused);
            RefreshInterface();
        }

        private void ZoomArtwork(float delta)
        {
            if (!IsArtworkOpen || artworkImage == null || !artworkViewport.TryZoom(delta)) return;
            ApplyArtworkViewport();
        }

        /// <summary>
        /// Panning affects only the transient artwork UV viewport, never the image asset,
        /// inspected evidence, deduction state or durable saves.
        /// </summary>
        public bool TryPanArtwork(float deltaU, float deltaV)
        {
            if (!isOpen || !IsArtworkOpen || artworkImage == null || IsSpiralOpen ||
                !artworkViewport.TryPan(deltaU, deltaV)) return false;
            ApplyArtworkViewport();
            return true;
        }

        private void ApplyArtworkViewport()
        {
            if (artworkImage == null) return;
            float extent = artworkViewport.Extent;
            artworkImage.uvRect = new Rect(artworkViewport.X, artworkViewport.Y, extent, extent);
        }

        private void RefreshInterface()
        {
            if (inspection == null || current == null) return;
            RefreshChapterThreeWorldMark();
            RefreshChapterFourWorldMark();
            ApplyCinematicHud();
            caseTitle.text = (scenicMode ? "EXPLORE LOCATION  " : "3D INVESTIGATION  ") + current.LocationNumber.ToString("00") +
                "  |  " + current.Title.ToUpperInvariant();
            evidenceAButton.interactable = !inspection.HasInspected(0);
            evidenceBButton.interactable = !inspection.HasInspected(1);
            deductionButton.interactable = CanDeduce &&
                !IsArtworkOpen && !IsComparisonOpen && !IsThresholdOpen &&
                !IsSpiralOpen && !IsChapterTwoOpen && !IsChapterThreeOpen && !IsChapterFourOpen;
            if (chapterFourFocusButton != null)
                chapterFourFocusButton.interactable = !IsArtworkOpen && !IsComparisonOpen &&
                    !IsThresholdOpen && !IsSpiralOpen && !IsChapterFourOpen;
            if (chapterFourButton != null)
                chapterFourButton.interactable = inspection.CanDeduce &&
                    !IsArtworkOpen && !IsComparisonOpen && !IsChapterFourOpen;
            if (chapterThreeFocusButton != null)
                chapterThreeFocusButton.interactable = !IsArtworkOpen && !IsComparisonOpen &&
                    !IsThresholdOpen && !IsSpiralOpen && !IsChapterThreeOpen;
            if (chapterThreeButton != null)
                chapterThreeButton.interactable = inspection.CanDeduce &&
                    !IsArtworkOpen && !IsComparisonOpen && !IsChapterThreeOpen;
            if (chapterTwoFocusButton != null)
                chapterTwoFocusButton.interactable = !IsArtworkOpen && !IsComparisonOpen &&
                    !IsThresholdOpen && !IsSpiralOpen && !IsChapterTwoOpen;
            if (chapterTwoButton != null)
                chapterTwoButton.interactable = inspection.CanDeduce &&
                    !IsArtworkOpen && !IsComparisonOpen && !IsChapterTwoOpen;
            if (spiralButton != null)
                spiralButton.interactable = inspection.CanDeduce &&
                    !IsArtworkOpen && !IsComparisonOpen && !IsSpiralOpen;
            if (thresholdButton != null)
                thresholdButton.interactable = inspection.CanDeduce &&
                    !IsArtworkOpen && !IsComparisonOpen && !IsThresholdOpen;
            bool canTurnRelic = CanManipulateFocusedRelic();
            if (turnRelicLeftButton != null) turnRelicLeftButton.interactable = canTurnRelic;
            if (turnRelicRightButton != null) turnRelicRightButton.interactable = canTurnRelic;
            if (resetRelicButton != null) resetRelicButton.interactable = canTurnRelic;
            if (comparisonButton != null)
                comparisonButton.interactable = inspection.InspectedCount > 0 &&
                    !IsArtworkOpen && !IsComparisonOpen && !IsThresholdOpen && !IsSpiralOpen &&
                !IsChapterThreeOpen && !IsChapterFourOpen;
            string transcript = inspection.SelectedEvidenceIndex >= 0 ?
                StoryDossierCatalog.Get(current.LocationNumber).EvidenceFragments[inspection.SelectedEvidenceIndex] :
                (scenicMode ? CinematicSceneMap.GetAtmosphere(current.LocationNumber) :
                "Inspect the two illuminated relics. Rotate and zoom to study the scene.");
            string focus = chapterFourFocusActive ? "MERIDIAN CLOSE-UP" :
                chapterTwoFocusActive ? "MECHANISM CLOSE-UP" :
                chapterThreeFocusActive ? "TESTAMENT CLOSE-UP" :
                crestFocusActive ? "CREST CLOSE-UP" :
                focusedEvidenceIndex < 0 ? "OVERVIEW" :
                "FOCUS " + (char)('A' + focusedEvidenceIndex);
            string thresholdInstruction = current.LocationNumber != 1 ? string.Empty :
                (thresholdCrest.IsVerified ? "  |  CREST VERIFIED" :
                inspection.CanDeduce ? "  |  VERIFY THE CREST" : "  |  CREST LOCKED");
            string chapterTwoInstruction = current.ChapterNumber != 2 ? string.Empty :
                IsChapterTwoVerified ? "  |  MECHANISM VERIFIED" :
                inspection.CanDeduce ? "  |  RESTORE MECHANISM" : "  |  MECHANISM LOCKED";
            string chapterThreeInstruction = current.ChapterNumber != 3 ? string.Empty :
                IsChapterThreeVerified ? "  |  TESTAMENT VERIFIED" :
                inspection.CanDeduce ? "  |  RESTORE TESTAMENT" : "  |  TESTAMENT LOCKED";
            string chapterFourInstruction = current.ChapterNumber != 4 ? string.Empty :
                IsChapterFourVerified ? "  |  MERIDIAN VERIFIED" :
                inspection.CanDeduce ? "  |  ALIGN MERIDIAN" : "  |  MERIDIAN LOCKED";
            string spiralInstruction = current.LocationNumber != SpiralBalusterPuzzle.LocationNumber ?
                string.Empty : spiralPuzzle.IsVerified ? "  |  STAIR PATTERN VERIFIED" :
                inspection.CanDeduce ? "  |  RESTORE STAIR PATTERN" : "  |  STAIR PATTERN LOCKED";
            evidenceStatus.text = "WORLD EVIDENCE  " + inspection.InspectedCount + "/2" +
                (CanDeduce ? "  |  DEDUCTION READY" : "  |  INVESTIGATION IN PROGRESS") +
                thresholdInstruction + spiralInstruction + chapterTwoInstruction +
                chapterThreeInstruction + chapterFourInstruction +
                "  |  " + focus + "\n" + transcript;
        }

        private void Finish(bool toDossier)
        {
            if (!isOpen || current == null || inspection == null) return;
            if (cinematicScene != null && cinematicScene.IsEvidencePreviewOpen) return;
            // A stale atlas callback may not discard an active Chapter One or Two
            // mechanism or inspection layer. Back dismisses those layers explicitly.
            if (!toDossier && (IsArtworkOpen || IsComparisonOpen || IsThresholdOpen ||
                IsSpiralOpen || IsChapterTwoOpen)) return;
            // Chapter Three's backdrop must consume navigation before the atlas
            // receives an exit. The dedicated Back handler closes one layer at
            // a time; a stale HUD callback cannot silently discard this view.
            if (!toDossier && (IsChapterThreeLocation || IsChapterFourLocation) &&
                (IsChapterThreeOpen || IsChapterFourOpen || IsArtworkOpen || IsComparisonOpen)) return;
            if (toDossier && !inspection.CanDeduce) return;
            if (toDossier && !CanDeduce) return;
            if (toDossier && (IsChapterThreeOpen || IsChapterFourOpen)) return;
            if (toDossier && (IsArtworkOpen || IsComparisonOpen ||
                IsThresholdOpen || IsSpiralOpen || IsChapterTwoOpen || IsChapterFourOpen)) return;
            int location = current.LocationNumber;
            bool evidenceA = inspection.HasInspected(0);
            bool evidenceB = inspection.HasInspected(1);
            Action<int, bool, bool, bool> callback = finished;
            Close();
            if (callback == null) return;
            pendingDossierHandoff = toDossier ? new WorldInvestigationGrant(location) : null;
            try
            {
                callback.Invoke(location, toDossier, evidenceA, evidenceB);
            }
            finally
            {
                pendingDossierHandoff = null;
            }
        }

        private static Text AddText(string name, Transform parent, string value, Vector2 position,
            Vector2 size, int fontSize)
        {
            var gameObject = new GameObject(name, typeof(RectTransform), typeof(Text));
            gameObject.transform.SetParent(parent, false);
            RectTransform rect = gameObject.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            Text label = gameObject.GetComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.text = value;
            label.fontSize = fontSize;
            label.color = Ivory;
            label.alignment = TextAnchor.MiddleCenter;
            label.horizontalOverflow = HorizontalWrapMode.Wrap;
            label.verticalOverflow = VerticalWrapMode.Truncate;
            label.raycastTarget = false;
            return label;
        }

        private static Button AddButton(string name, Transform parent, Vector2 position, Vector2 size,
            UnityEngine.Events.UnityAction action)
        {
            var gameObject = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            gameObject.transform.SetParent(parent, false);
            RectTransform rect = gameObject.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            Image image = gameObject.GetComponent<Image>();
            image.color = Brass;
            var button = gameObject.GetComponent<Button>();
            button.onClick.AddListener(action);
            var caption = AddText("Caption", gameObject.transform, name, Vector2.zero,
                size - new Vector2(10f, 8f), 18);
            caption.color = Ink;
            return button;
        }

        private void OnApplicationFocus(bool hasFocus)
        {
            applicationFocused = hasFocus;
            if (!hasFocus)
            {
                gesture.Cancel();
                pointerResumeGate.Suspend();
                touchChordGate.Suspend();
                previousPinchDistance = -1f;
                if (cinematicScene != null) cinematicScene.SetPinchActive(false);
            }
        }

        private void OnApplicationPause(bool isPaused)
        {
            applicationPaused = isPaused;
            if (isPaused)
            {
                gesture.Cancel();
                pointerResumeGate.Suspend();
                touchChordGate.Suspend();
                previousPinchDistance = -1f;
                if (cinematicScene != null) cinematicScene.SetPinchActive(false);
            }
        }

        private void OnDisable()
        {
            Close();
        }

        private void OnDestroy()
        {
            Close();
        }
    }
}
