using System;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Device-local sound preferences. Retains the original master-audio key so
    /// existing installations keep their mute choice across upgrades.
    /// </summary>
    public static class LocalPrivacyPreferences
    {
        public const string AudioEnabledKey = "SableAndSigil.Settings.AudioEnabled.v1";
        public const string EffectsEnabledKey = "SableAndSigil.Settings.EffectsEnabled.v1";
        public const string AmbienceEnabledKey = "SableAndSigil.Settings.AmbienceEnabled.v1";
        public const string EffectsVolumeKey = "SableAndSigil.Settings.EffectsVolume.v1";
        public const string AmbienceVolumeKey = "SableAndSigil.Settings.AmbienceVolume.v1";

        public static event Action AudioSettingsChanged;

        public static bool AudioEnabled => PlayerPrefs.GetInt(AudioEnabledKey, 1) != 0;
        public static bool EffectsEnabled => PlayerPrefs.GetInt(EffectsEnabledKey, 1) != 0;
        public static bool AmbienceEnabled => PlayerPrefs.GetInt(AmbienceEnabledKey, 1) != 0;
        public static float EffectsVolume => Mathf.Clamp(PlayerPrefs.GetInt(EffectsVolumeKey, 100), 0, 100) / 100f;
        public static float AmbienceVolume => Mathf.Clamp(PlayerPrefs.GetInt(AmbienceVolumeKey, 100), 0, 100) / 100f;
        public static bool EffectsAudible => AudioEnabled && EffectsEnabled && EffectsVolume > 0f;
        public static bool AmbienceAudible => AudioEnabled && AmbienceEnabled && AmbienceVolume > 0f;

        public static bool TrySetAudioEnabled(bool enabled, out string error)
        {
            return TryWritePreference(AudioEnabledKey, enabled ? 1 : 0, out error);
        }

        public static bool TrySetEffectsEnabled(bool enabled, out string error)
        {
            return TryWritePreference(EffectsEnabledKey, enabled ? 1 : 0, out error);
        }

        public static bool TrySetAmbienceEnabled(bool enabled, out string error)
        {
            return TryWritePreference(AmbienceEnabledKey, enabled ? 1 : 0, out error);
        }

        public static bool TrySetEffectsVolume(float volume, out string error)
        {
            return TrySetVolume(EffectsVolumeKey, volume, out error);
        }

        public static bool TrySetAmbienceVolume(float volume, out string error)
        {
            return TrySetVolume(AmbienceVolumeKey, volume, out error);
        }

        private static bool TrySetVolume(string key, float volume, out string error)
        {
            if (float.IsNaN(volume) || float.IsInfinity(volume) || volume < 0f || volume > 1f)
            {
                error = "Sound volume must be a finite value between 0 and 1.";
                return false;
            }

            return TryWritePreference(key, Mathf.RoundToInt(volume * 100f), out error);
        }

        private static bool TryWritePreference(string key, int value, out string error)
        {
            error = null;
            bool hasPrevious = false;
            int previous = 0;

            try
            {
                hasPrevious = PlayerPrefs.HasKey(key);
                if (hasPrevious)
                {
                    previous = PlayerPrefs.GetInt(key);
                    if (previous == value) return true;
                }

                PlayerPrefs.SetInt(key, value);
                PlayerPrefs.Save();
            }
            catch (Exception exception)
            {
                try
                {
                    if (hasPrevious) PlayerPrefs.SetInt(key, previous);
                    else PlayerPrefs.DeleteKey(key);
                    PlayerPrefs.Save();
                }
                catch (Exception rollbackFailure)
                {
                    Debug.LogWarning("Sound preference rollback failed: " + rollbackFailure.GetType().Name);
                }

                error = "Sound preference could not be saved: " + exception.GetType().Name;
                return false;
            }

            NotifyAudioSettingsChanged();
            return true;
        }

        private static void NotifyAudioSettingsChanged()
        {
            Action handlers = AudioSettingsChanged;
            if (handlers == null) return;
            foreach (Delegate callback in handlers.GetInvocationList())
            {
                try
                {
                    ((Action)callback)();
                }
                catch (Exception exception)
                {
                    Debug.LogWarning("Sound preference observer failed: " + exception.GetType().Name);
                }
            }
        }
    }
}
