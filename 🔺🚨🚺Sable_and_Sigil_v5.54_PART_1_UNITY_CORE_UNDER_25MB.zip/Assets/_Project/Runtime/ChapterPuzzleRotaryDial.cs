using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Translates one owned pointer's angular motion into discrete quarter-turns.
    /// Hit-testing uses the stationary canvas, never the rotating dial transform.
    /// The domain controls the phase and the caller controls chapter progression.
    /// </summary>
    public sealed class ChapterPuzzleRotaryDial : MonoBehaviour,
        IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        private RectTransform canvasRoot;
        private RectTransform dial;
        private Func<bool> canRotate;
        private Func<int, bool> tryTurn;
        private int pointerId;
        private float previousAngle;
        private float angularRemainder;
        private bool dragging;
        private bool initialized;

        public void Initialize(RectTransform fixedCanvasRoot, Func<bool> canBegin,
            Func<int, bool> tryQuarterTurn)
        {
            if (initialized) throw new InvalidOperationException("Rotary dial already initialized.");
            canvasRoot = fixedCanvasRoot;
            dial = GetComponent<RectTransform>();
            Image graphic = GetComponent<Image>();
            if (canvasRoot == null || dial == null || graphic == null ||
                canBegin == null || tryQuarterTurn == null || dial.parent != canvasRoot)
                throw new ArgumentException("Invalid rotary dial configuration.");
            canRotate = canBegin;
            tryTurn = tryQuarterTurn;
            graphic.raycastTarget = true;
            initialized = true;
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (!initialized || !isActiveAndEnabled || dragging ||
                eventData == null || !canRotate() ||
                !TryReadAngle(eventData, out float angle)) return;
            pointerId = eventData.pointerId;
            previousAngle = angle;
            angularRemainder = 0f;
            dragging = true;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!dragging || eventData == null || eventData.pointerId != pointerId) return;
            if (!canRotate() || !TryReadAngle(eventData, out float nextAngle))
            {
                CancelDrag();
                return;
            }
            float delta = Mathf.DeltaAngle(previousAngle, nextAngle);
            if (float.IsNaN(delta) || float.IsInfinity(delta))
            {
                CancelDrag();
                return;
            }
            previousAngle = nextAngle;
            angularRemainder += delta;
            while (angularRemainder >= 90f || angularRemainder <= -90f)
            {
                int direction = angularRemainder > 0f ? 1 : -1;
                if (!tryTurn(direction))
                {
                    CancelDrag();
                    return;
                }
                angularRemainder -= direction * 90f;
            }
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (!dragging || eventData == null || eventData.pointerId != pointerId) return;
            dragging = false;
            if (isActiveAndEnabled && canRotate() && Mathf.Abs(angularRemainder) >= 50f)
                tryTurn(angularRemainder > 0f ? 1 : -1);
            angularRemainder = 0f;
        }

        private bool TryReadAngle(PointerEventData eventData, out float angle)
        {
            angle = 0f;
            if (!IsFinite(eventData.position) || !IsFinite(dial.position)) return false;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    canvasRoot, eventData.position, eventData.pressEventCamera,
                    out Vector2 pointer)) return false;
            Vector3 centerLocal = canvasRoot.InverseTransformPoint(dial.position);
            Vector2 radial = pointer - new Vector2(centerLocal.x, centerLocal.y);
            if (!IsFinite(radial) || radial.sqrMagnitude < 400f) return false;
            angle = Mathf.Atan2(radial.y, radial.x) * Mathf.Rad2Deg;
            return !float.IsNaN(angle) && !float.IsInfinity(angle);
        }

        private static bool IsFinite(Vector2 position)
        {
            return !float.IsNaN(position.x) && !float.IsInfinity(position.x) &&
                   !float.IsNaN(position.y) && !float.IsInfinity(position.y);
        }

        private void CancelDrag()
        {
            dragging = false;
            angularRemainder = 0f;
            pointerId = 0;
        }

        private void OnDisable() => CancelDrag();
        private void OnApplicationPause(bool paused)
        {
            if (paused) CancelDrag();
        }

        private void OnApplicationFocus(bool focused)
        {
            if (!focused) CancelDrag();
        }
    }
}
