using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
#endif

namespace TheOrderRoom.Runtime
{
    public sealed class OrderPointerInput : MonoBehaviour
    {
        public OrderGame Game;

        private enum PointerKind { None, Mouse, Touch }

        private PointerKind activePointer;
        // A gesture is owned by the game that accepted its initial press, not
        // whichever scene/controller currently happens to occupy the public field.
        private OrderGame gestureOwner;
        private bool blockUntilTouchesEnd;
        private bool blockUntilMouseReleased;
        private int lastTouchFrame = -10;
#if ENABLE_INPUT_SYSTEM
        private TouchControl activeTouch;
        private int activeTouchId;
#elif ENABLE_LEGACY_INPUT_MANAGER
        private int activeFingerId;
#endif

        private void Update()
        {
            if (activePointer != PointerKind.None &&
                (gestureOwner == null || Game != gestureOwner || !gestureOwner.isActiveAndEnabled))
                SuspendInput();
            if (Game == null || !Game.isActiveAndEnabled) return;
#if ENABLE_INPUT_SYSTEM
            UpdateInputSystem();
#elif ENABLE_LEGACY_INPUT_MANAGER
            UpdateLegacyInput();
#endif
        }

#if ENABLE_INPUT_SYSTEM
        private void UpdateInputSystem()
        {
            var screen = Touchscreen.current;
            int contactCount = 0;
            TouchControl began = null;
            bool ownerPresent = false;
            if (screen != null)
            {
                foreach (var touch in screen.touches)
                {
                    if (touch == activeTouch && touch.touchId.ReadValue() == activeTouchId) ownerPresent = true;
                    if (!touch.press.isPressed && !touch.press.wasPressedThisFrame) continue;
                    contactCount++;
                    if (touch.press.wasPressedThisFrame) began = touch;
                }
            }

            if (activePointer == PointerKind.Touch && (!ownerPresent || contactCount > 1 ||
                (began != null && began != activeTouch)))
            {
                CancelGesture();
                blockUntilTouchesEnd = contactCount != 0;
                lastTouchFrame = Time.frameCount;
                return;
            }

            if (contactCount != 0 || activePointer == PointerKind.Touch)
            {
                lastTouchFrame = Time.frameCount;
                if (activePointer == PointerKind.Mouse) CancelGesture();
                if (contactCount > 1) blockUntilTouchesEnd = true;
                if (blockUntilTouchesEnd) return;

                if (activePointer == PointerKind.Touch)
                {
                    var phase = activeTouch.phase.ReadValue();
                    var position = activeTouch.position.ReadValue();
                    if (phase == UnityEngine.InputSystem.TouchPhase.Ended) CompleteGesture(position);
                    else if (phase == UnityEngine.InputSystem.TouchPhase.Canceled || !activeTouch.press.isPressed)
                        CancelGesture();
                    else Game.UpdateWorldGesture(position);
                }
                else if (began != null)
                {
                    activeTouch = began;
                    activeTouchId = began.touchId.ReadValue();
                    BeginGesture(PointerKind.Touch, began.position.ReadValue());
                    if (began.phase.ReadValue() == UnityEngine.InputSystem.TouchPhase.Ended)
                        CompleteGesture(began.position.ReadValue());
                }
                return;
            }

            blockUntilTouchesEnd = false;
            if (Time.frameCount - lastTouchFrame <= 2) return;
            var mouse = Mouse.current;
            if (mouse == null) { CancelGesture(); return; }
            if (blockUntilMouseReleased)
            {
                if (!mouse.leftButton.isPressed) blockUntilMouseReleased = false;
                return;
            }
            var mousePosition = mouse.position.ReadValue();
            if (activePointer == PointerKind.Mouse)
            {
                if (mouse.leftButton.wasReleasedThisFrame) CompleteGesture(mousePosition);
                else if (mouse.leftButton.isPressed) Game.UpdateWorldGesture(mousePosition);
                else CancelGesture();
            }
            else if (mouse.leftButton.wasPressedThisFrame)
            {
                BeginGesture(PointerKind.Mouse, mousePosition);
                if (mouse.leftButton.wasReleasedThisFrame) CompleteGesture(mousePosition);
            }
        }
#elif ENABLE_LEGACY_INPUT_MANAGER
        private void UpdateLegacyInput()
        {
            int count = Input.touchCount;
            if (count != 0 || activePointer == PointerKind.Touch)
            {
                lastTouchFrame = Time.frameCount;
                if (activePointer == PointerKind.Mouse) CancelGesture();
                if (count != 1)
                {
                    CancelGesture();
                    blockUntilTouchesEnd = count != 0;
                    return;
                }
                if (blockUntilTouchesEnd) return;
                var touch = Input.GetTouch(0);
                if (activePointer == PointerKind.Touch)
                {
                    if (touch.fingerId != activeFingerId || touch.phase == TouchPhase.Canceled)
                    {
                        CancelGesture();
                        blockUntilTouchesEnd = true;
                    }
                    else if (touch.phase == TouchPhase.Ended) CompleteGesture(touch.position);
                    else Game.UpdateWorldGesture(touch.position);
                }
                else if (touch.phase == TouchPhase.Began)
                {
                    activeFingerId = touch.fingerId;
                    BeginGesture(PointerKind.Touch, touch.position);
                }
                return;
            }

            blockUntilTouchesEnd = false;
            if (Time.frameCount - lastTouchFrame <= 2) return;
            if (blockUntilMouseReleased)
            {
                if (!Input.GetMouseButton(0)) blockUntilMouseReleased = false;
                return;
            }
            if (activePointer == PointerKind.Mouse)
            {
                if (Input.GetMouseButtonUp(0)) CompleteGesture(Input.mousePosition);
                else if (Input.GetMouseButton(0)) Game.UpdateWorldGesture(Input.mousePosition);
                else CancelGesture();
            }
            else if (Input.GetMouseButtonDown(0)) BeginGesture(PointerKind.Mouse, Input.mousePosition);
        }
#endif

        private void BeginGesture(PointerKind kind, Vector2 position)
        {
            OrderGame owner = Game;
            if (owner == null || !owner.isActiveAndEnabled) return;
            activePointer = kind;
            gestureOwner = owner;
            owner.BeginWorldGesture(position);
        }

        private void CompleteGesture(Vector2 position)
        {
            OrderGame owner = gestureOwner;
            ClearPointer();
            if (owner == null) return;
            if (owner == Game && owner.isActiveAndEnabled) owner.EndWorldGesture(position);
            else owner.CancelWorldGesture();
        }

        private void CancelGesture()
        {
            if (activePointer == PointerKind.None) return;
            OrderGame owner = gestureOwner;
            ClearPointer();
            if (owner != null) owner.CancelWorldGesture();
        }

        private void ClearPointer()
        {
            activePointer = PointerKind.None;
            gestureOwner = null;
#if ENABLE_INPUT_SYSTEM
            activeTouch = null;
            activeTouchId = 0;
#endif
        }

        private void OnDisable() => SuspendInput();
        private void OnApplicationFocus(bool focused)
        {
            if (!focused) SuspendInput();
        }

        private void OnApplicationPause(bool paused)
        {
            if (paused) SuspendInput();
        }

        private void SuspendInput()
        {
            CancelGesture();
            // A finger held while the app loses focus must not become a new gesture
            // on resume. Resume only after all active contacts have been released.
            blockUntilTouchesEnd = true;
            blockUntilMouseReleased = true;
            lastTouchFrame = Time.frameCount;
        }
    }
}
