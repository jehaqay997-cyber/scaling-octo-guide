using TheOrderRoom.Domain;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>Allocation-free sampling and bounded frame-rate control, not a thermal sensor.</summary>
    [DisallowMultipleComponent]
    public sealed class OrderPerformanceGovernor : MonoBehaviour
    {
        private const int WindowFrames = 120;
        // Application frame pacing is global. Only one governor may own it at a time.
        private static OrderPerformanceGovernor activeOwner;
        private int previousTarget;
        private int previousVsync;
        private int target;
        private int samples;
        private int slowWindows;
        private double accumulatedMilliseconds;
        private bool ownsSettings;
        private bool mobileFrameControl;
        private bool applicationPaused;
        private bool applicationFocused = true;
        private double displayRefreshHertz;
        private double effectiveTargetFps;
        private const int UnfocusedMobileFrameRate = 15;

        private void OnEnable()
        {
            if (activeOwner != null && activeOwner != this)
            {
                Debug.LogError("Multiple performance governors detected; the duplicate is disabled.", this);
                enabled = false;
                return;
            }
            activeOwner = this;
            previousTarget = Application.targetFrameRate;
            previousVsync = QualitySettings.vSyncCount;
            mobileFrameControl = Application.isMobilePlatform;
            target = FrameBudgetPolicy.InitialTarget(mobileFrameControl);
            displayRefreshHertz = mobileFrameControl ? Screen.currentResolution.refreshRateRatio.value : 0.0;
            // Unity 2022.3: use vSync on desktop to avoid software frame-pacing jitter;
            // mobile ignores vSync and uses Application.targetFrameRate instead.
            if (mobileFrameControl)
            {
                QualitySettings.vSyncCount = 0;
                ApplyMobileFrameTarget();
            }
            else
            {
                QualitySettings.vSyncCount = 1;
                Application.targetFrameRate = -1;
            }
            samples = 0;
            slowWindows = 0;
            accumulatedMilliseconds = 0;
            ownsSettings = true;
        }

        private void Update()
        {
            // Do not profile suspended frames or reset the sample window on resume.
            if (!ownsSettings || !mobileFrameControl || applicationPaused || !applicationFocused) return;
            if (Time.unscaledDeltaTime <= 0f || Time.unscaledDeltaTime > .5f)
            {
                samples = 0;
                accumulatedMilliseconds = 0;
                slowWindows = 0;
                return;
            }
            accumulatedMilliseconds += Time.unscaledDeltaTime * 1000.0;
            samples++;
            if (samples < WindowFrames) return;
            double currentRefreshHertz = Screen.currentResolution.refreshRateRatio.value;
            if (RefreshChanged(currentRefreshHertz))
            {
                displayRefreshHertz = currentRefreshHertz;
                ApplyMobileFrameTarget();
                ResetSamples();
                return;
            }

            double mean = accumulatedMilliseconds / samples;
            if (FrameBudgetPolicy.IsFrameOverBudget(mean, effectiveTargetFps)) slowWindows++;
            else slowWindows = 0;
            bool discharging = SystemInfo.batteryStatus == BatteryStatus.Discharging;
            int next = FrameBudgetPolicy.Choose(target, mean, SystemInfo.batteryLevel,
                discharging, slowWindows, effectiveTargetFps);
            if (next != target)
            {
                target = next;
                ApplyMobileFrameTarget();
                slowWindows = 0;
            }
            samples = 0;
            accumulatedMilliseconds = 0;
        }

        private bool RefreshChanged(double observedHertz)
        {
            bool observedValid = !double.IsNaN(observedHertz) && !double.IsInfinity(observedHertz) &&
                observedHertz >= 1.0 && observedHertz <= 1000.0;
            bool previousValid = !double.IsNaN(displayRefreshHertz) && !double.IsInfinity(displayRefreshHertz) &&
                displayRefreshHertz >= 1.0 && displayRefreshHertz <= 1000.0;
            return observedValid != previousValid ||
                (observedValid && System.Math.Abs(observedHertz - displayRefreshHertz) >= 0.5);
        }

        private void ApplyMobileFrameTarget()
        {
            if (!mobileFrameControl) return;
            effectiveTargetFps = FrameBudgetPolicy.EffectiveMobileFramesPerSecond(target, displayRefreshHertz);
            int desired = applicationPaused || !applicationFocused ? UnfocusedMobileFrameRate : target;
            Application.targetFrameRate = FrameBudgetPolicy.MobileFrameRequest(desired, displayRefreshHertz);
        }

        private void ResetSamples()
        {
            samples = 0;
            accumulatedMilliseconds = 0;
            slowWindows = 0;
        }

        private void OnApplicationFocus(bool focused)
        {
            applicationFocused = focused;
            ResetSamples();
            if (ownsSettings)
            {
                if (mobileFrameControl) displayRefreshHertz = Screen.currentResolution.refreshRateRatio.value;
                ApplyMobileFrameTarget();
            }
        }

        private void OnApplicationPause(bool paused)
        {
            applicationPaused = paused;
            ResetSamples();
            if (ownsSettings)
            {
                if (mobileFrameControl) displayRefreshHertz = Screen.currentResolution.refreshRateRatio.value;
                ApplyMobileFrameTarget();
            }
        }

        private void OnDisable()
        {
            if (!ownsSettings)
            {
                if (activeOwner == this) activeOwner = null;
                return;
            }
            // Never overwrite settings owned by another instance.
            if (activeOwner != this) return;
            Application.targetFrameRate = previousTarget;
            QualitySettings.vSyncCount = previousVsync;
            ownsSettings = false;
            activeOwner = null;
        }
    }
}
