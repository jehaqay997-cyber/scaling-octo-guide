using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Pointer-owned, canvas-local drag-and-drop control. It never grants durable
    /// progress itself. The receiving mechanism validates the drop transaction.
    /// </summary>
    public sealed class ChapterPuzzleDragToken : MonoBehaviour,
        IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        private RectTransform token;
        private RectTransform dragBounds;
        private RectTransform target;
        private RectTransform[] selectableTargets;
        private Func<bool> canStart;
        private Func<bool, bool> tryCommit;
        private Func<int, bool> tryCommitSelected;
        private Image hitGraphic;
        private Vector2 home;
        private Vector2 grabOffset;
        private int pointerId;
        private bool dragging;
        private bool committed;
        private bool initialized;
        private bool hideAfterCommit;

        public bool IsCommitted => committed;

        public void Initialize(RectTransform bounds, RectTransform dropTarget,
            Func<bool> canBeginDrag, Func<bool, bool> commitDrop, bool hideWhenCommitted = false)
        {
            if (initialized) throw new InvalidOperationException("Drag token is already initialized.");
            token = GetComponent<RectTransform>();
            hitGraphic = GetComponent<Image>();
            if (token == null || hitGraphic == null || bounds == null || dropTarget == null ||
                canBeginDrag == null || commitDrop == null || token.parent != bounds)
                throw new ArgumentException("Invalid puzzle drag configuration.");
            dragBounds = bounds;
            target = dropTarget;
            canStart = canBeginDrag;
            tryCommit = commitDrop;
            home = token.anchoredPosition;
            hitGraphic.raycastTarget = true;
            hideAfterCommit = hideWhenCommitted;
            initialized = true;
        }

        /// <summary>
        /// Reuses the existing drag control for a board with several independently
        /// validated sockets. The UI does not decide which evidence is correct.
        /// </summary>
        public void Initialize(RectTransform bounds, RectTransform[] dropTargets,
            Func<bool> canBeginDrag, Func<int, bool> commitSelectedDrop)
        {
            if (initialized) throw new InvalidOperationException("Drag token is already initialized.");
            token = GetComponent<RectTransform>();
            hitGraphic = GetComponent<Image>();
            if (token == null || hitGraphic == null || bounds == null || dropTargets == null ||
                dropTargets.Length < 2 || canBeginDrag == null || commitSelectedDrop == null ||
                token.parent != bounds)
                throw new ArgumentException("Invalid multi-socket drag configuration.");
            for (int index = 0; index < dropTargets.Length; index++)
            {
                if (dropTargets[index] == null)
                    throw new ArgumentException("A drop target cannot be null.");
                for (int previous = 0; previous < index; previous++)
                    if (dropTargets[index] == dropTargets[previous])
                        throw new ArgumentException("Drop targets must be unique.");
            }
            dragBounds = bounds;
            selectableTargets = (RectTransform[])dropTargets.Clone();
            canStart = canBeginDrag;
            tryCommitSelected = commitSelectedDrop;
            home = token.anchoredPosition;
            hitGraphic.raycastTarget = true;
            initialized = true;
        }

        /// <summary>
        /// Resets only the draggable visual. It never modifies committed domain
        /// evidence or saved progress. Call when opening a different case.
        /// </summary>
        public void ResetToHome()
        {
            if (!initialized) throw new InvalidOperationException("Drag token is not initialized.");
            dragging = false;
            committed = false;
            pointerId = 0;
            token.anchoredPosition = home;
            hitGraphic.raycastTarget = true;
            if (hideAfterCommit && !gameObject.activeSelf) gameObject.SetActive(true);
        }

        /// <summary>Restores a verified placement after closing and reopening a dossier.</summary>
        public void RestoreCommittedSlot(int slotIndex)
        {
            if (!initialized) throw new InvalidOperationException("Drag token is not initialized.");
            RectTransform destination = selectableTargets == null ?
                (slotIndex == 0 ? target : null) :
                (slotIndex >= 0 && slotIndex < selectableTargets.Length ?
                    selectableTargets[slotIndex] : null);
            if (destination == null) throw new ArgumentOutOfRangeException(nameof(slotIndex));
            dragging = false;
            committed = true;
            SnapTo(destination);
            hitGraphic.raycastTarget = false;
            if (hideAfterCommit) gameObject.SetActive(false);
        }

        private void SnapTo(RectTransform destination)
        {
            Vector3 centerWorld = destination.TransformPoint(destination.rect.center);
            Vector3 localCenter = dragBounds.InverseTransformPoint(centerWorld);
            token.anchoredPosition = new Vector2(localCenter.x, localCenter.y);
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (!initialized || eventData == null || committed || dragging ||
                !isActiveAndEnabled || !IsFinite(eventData.position) || !canStart()) return;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    dragBounds, eventData.position, eventData.pressEventCamera,
                    out Vector2 local) || !IsFinite(local) ||
                !IsFinite(token.anchoredPosition)) return;
            pointerId = eventData.pointerId;
            grabOffset = local - token.anchoredPosition;
            dragging = true;
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!dragging || eventData == null || eventData.pointerId != pointerId) return;
            if (!isActiveAndEnabled || !IsFinite(eventData.position) || !canStart())
            {
                CancelDrag();
                return;
            }
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    dragBounds, eventData.position, eventData.pressEventCamera,
                    out Vector2 local)) return;
            if (!IsFinite(local))
            {
                CancelDrag();
                return;
            }
            Rect bounds = dragBounds.rect;
            Vector2 extent = token.rect.size * .5f;
            Vector2 desired = local - grabOffset;
            if (!IsFinite(desired))
            {
                CancelDrag();
                return;
            }
            token.anchoredPosition = new Vector2(
                Mathf.Clamp(desired.x, bounds.xMin + extent.x, bounds.xMax - extent.x),
                Mathf.Clamp(desired.y, bounds.yMin + extent.y, bounds.yMax - extent.y));
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (!dragging || eventData == null || eventData.pointerId != pointerId) return;
            if (!isActiveAndEnabled || !IsFinite(eventData.position))
            {
                CancelDrag();
                return;
            }
            dragging = false;
            RectTransform destination = target;
            int selectedSlot = -1;
            if (selectableTargets != null)
            {
                destination = null;
                for (int index = 0; index < selectableTargets.Length; index++)
                {
                    if (!RectTransformUtility.RectangleContainsScreenPoint(
                        selectableTargets[index], eventData.position, eventData.pressEventCamera)) continue;
                    selectedSlot = index;
                    destination = selectableTargets[index];
                    break;
                }
            }
            bool inside = destination != null && RectTransformUtility.RectangleContainsScreenPoint(
                destination, eventData.position, eventData.pressEventCamera);
            bool accepted = canStart() && (selectableTargets == null ?
                tryCommit(inside) && inside :
                inside && tryCommitSelected(selectedSlot));
            if (accepted)
            {
                committed = true;
                SnapTo(destination);
                hitGraphic.raycastTarget = false;
                if (hideAfterCommit) gameObject.SetActive(false);
                return;
            }
            token.anchoredPosition = home;
        }

        private static bool IsFinite(Vector2 value)
        {
            return !float.IsNaN(value.x) && !float.IsInfinity(value.x) &&
                   !float.IsNaN(value.y) && !float.IsInfinity(value.y);
        }

        private void CancelDrag()
        {
            dragging = false;
            pointerId = 0;
            if (initialized && !committed && token != null)
                token.anchoredPosition = home;
        }

        private void OnDisable() => CancelDrag();
        private void OnApplicationPause(bool paused)
        {
            if (paused) CancelDrag();
        }

        private void OnApplicationFocus(bool focused)
        {
            if (!focused) CancelDrag();
        }
    }
}
