using System;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Four short, original procedural cues. The scene owns its audio source and
    /// clips. Playback is voice-limited, pause-aware, and controlled by saved
    /// master/effects preferences without allocating in the playback path.
    /// </summary>
    [RequireComponent(typeof(AudioSource))]
    [DisallowMultipleComponent]
    public sealed class OrderAudioFeedback : MonoBehaviour
    {
        private const float BaseVolume = .40f;
        private const float RepeatCooldownSeconds = .08f;
        private AudioSource source;
        private AudioClip success;
        private AudioClip warning;
        private AudioClip discovery;
        private AudioClip hint;
        private float lastPlayed = -10f;
        private bool applicationPaused;
        private bool applicationFocused = true;
        private bool outputFailureReported;

        private void Awake()
        {
            source = GetComponent<AudioSource>();
            if (source == null)
            {
                Debug.LogWarning("Audio feedback is unavailable because its AudioSource is missing.", this);
                enabled = false;
                return;
            }

            source.playOnAwake = false;
            source.loop = false;
            source.spatialBlend = 0f;
            source.spatialize = false;
            source.volume = BaseVolume;
            try
            {
                success = MakeTone("OrderSuccess", 587.33f, 0.14f, 880f);
                warning = MakeTone("OrderWarning", 220f, 0.12f, 196f);
                discovery = MakeTone("OrderDiscovery", 783.99f, 0.16f, 1174.66f);
                hint = MakeTone("OrderHint", 392f, 0.14f, 523.25f);
                ApplySettings();
            }
            catch (Exception exception)
            {
                ReleaseClips();
                Debug.LogWarning("Optional audio initialization failed: " + exception.GetType().Name, this);
                enabled = false;
            }
        }

        private void OnEnable()
        {
            LocalPrivacyPreferences.AudioSettingsChanged += ApplySettings;
            ApplySettings();
        }

        private void OnDisable()
        {
            LocalPrivacyPreferences.AudioSettingsChanged -= ApplySettings;
            StopPlayback();
        }

        private static AudioClip MakeTone(string name, float hz, float durationSeconds, float harmonyHz)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(durationSeconds * sampleRate);
            var data = new float[count];
            float attack = Mathf.Max(1f, sampleRate * .008f);
            float release = Mathf.Max(1f, sampleRate * .035f);
            float mainStep = 2f * Mathf.PI * hz / sampleRate;
            float harmonyStep = 2f * Mathf.PI * harmonyHz / sampleRate;

            for (int i = 0; i < count; i++)
            {
                float fadeIn = Mathf.Clamp01(i / attack);
                float fadeOut = Mathf.Clamp01((count - 1 - i) / release);
                float envelope = Mathf.Min(fadeIn, fadeOut);
                float decay = 1f - .3f * (i / (float)count);
                data[i] = (Mathf.Sin(i * mainStep) * .70f +
                    Mathf.Sin(i * harmonyStep) * .30f) * envelope * decay * .35f;
            }

            var created = AudioClip.Create(name, count, 1, sampleRate, false);
            if (created == null)
                throw new InvalidOperationException("Failed to create audio feedback clip.");
            if (!created.SetData(data, 0))
            {
                DestroyClip(created);
                throw new InvalidOperationException("Failed to initialize audio feedback clip.");
            }
            return created;
        }

        private void ApplySettings()
        {
            if (source == null) return;
            bool audible = LocalPrivacyPreferences.EffectsAudible &&
                !applicationPaused && applicationFocused && !AudioListener.pause;
            source.volume = audible ? BaseVolume * LocalPrivacyPreferences.EffectsVolume : 0f;
            if (!audible) StopPlayback();
        }

        private void Play(AudioClip clip)
        {
            if (clip == null || source == null || !isActiveAndEnabled ||
                applicationPaused || !applicationFocused || AudioListener.pause ||
                !LocalPrivacyPreferences.EffectsAudible) return;

            float now = Time.unscaledTime;
            if (now - lastPlayed < RepeatCooldownSeconds) return;
            lastPlayed = now;
            try
            {
                source.volume = BaseVolume * LocalPrivacyPreferences.EffectsVolume;
                // Do not accumulate overlapping one-shots on a mobile audio voice.
                source.Stop();
                source.PlayOneShot(clip);
            }
            catch (Exception exception)
            {
                if (!outputFailureReported)
                {
                    outputFailureReported = true;
                    Debug.LogWarning("Optional audio playback failed: " + exception.GetType().Name, this);
                }
                enabled = false;
            }
        }

        public void PlaySuccess() => Play(success);
        public void PlayWarning() => Play(warning);
        public void PlayDiscovery() => Play(discovery);
        public void PlayHint() => Play(hint);

        public void StopPlayback()
        {
            if (source != null) source.Stop();
        }

        private void OnApplicationPause(bool paused)
        {
            applicationPaused = paused;
            ApplySettings();
        }

        private void OnApplicationFocus(bool focused)
        {
            applicationFocused = focused;
            ApplySettings();
        }

        private void OnDestroy()
        {
            LocalPrivacyPreferences.AudioSettingsChanged -= ApplySettings;
            StopPlayback();
            ReleaseClips();
        }

        private void ReleaseClips()
        {
            if (success != null) DestroyClip(success);
            if (warning != null) DestroyClip(warning);
            if (discovery != null) DestroyClip(discovery);
            if (hint != null) DestroyClip(hint);
            success = null;
            warning = null;
            discovery = null;
            hint = null;
        }

        private static void DestroyClip(AudioClip clip)
        {
            if (Application.isPlaying) UnityEngine.Object.Destroy(clip);
            else UnityEngine.Object.DestroyImmediate(clip);
        }
    }
}
