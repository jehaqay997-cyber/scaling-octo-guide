using System;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Prevents a two-or-more finger chord from turning into an accidental
    /// one-finger inspection when only one contact remains on the screen.
    /// It never owns, creates or commits game state.
    /// </summary>
    public sealed class WorldTouchChordGate
    {
        private bool awaitingAllReleased;

        public bool IsAwaitingRelease => awaitingAllReleased;

        public void Reset()
        {
            awaitingAllReleased = false;
        }

        public void Suspend()
        {
            awaitingAllReleased = true;
        }

        /// <summary>
        /// Called once per frame. A multi-contact chord suppresses all single
        /// pointer input until every finger lifts, including the release frame.
        /// </summary>
        public bool MayProcessSinglePointer(int activeContacts)
        {
            if (activeContacts < 0)
                throw new ArgumentOutOfRangeException(nameof(activeContacts));
            if (activeContacts > 1)
                awaitingAllReleased = true;
            if (!awaitingAllReleased) return true;
            if (activeContacts == 0) awaitingAllReleased = false;
            return false;
        }
    }
}
