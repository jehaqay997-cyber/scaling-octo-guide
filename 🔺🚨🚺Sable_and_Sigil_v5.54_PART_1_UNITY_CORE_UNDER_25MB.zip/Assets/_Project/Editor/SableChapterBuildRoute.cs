#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using TheOrderRoom.Domain;
using UnityEditor;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// The sole shipping scene route for Sable & Sigil. The historical Main
    /// puzzle board may remain on disk for migration and diagnostics, but is
    /// never an enabled player entry point.
    /// </summary>
    public static class SableChapterBuildRoute
    {
        private static readonly string[] RequiredScenes =
        {
            ChapterOneSceneBuilder.ScenePath,
            ChapterCaseSceneBuilder.ChapterTwoScene,
            ChapterCaseSceneBuilder.ChapterThreeScene,
            ChapterCaseSceneBuilder.ChapterFourScene
        };

        public static string[] ChapterScenes => (string[])RequiredScenes.Clone();

        /// <summary>
        /// Idempotently enables the four narrative chapters in order. Existing
        /// custom and legacy scenes are retained but disabled, never deleted.
        /// </summary>
        public static void Configure()
        {
            var configured = new List<EditorBuildSettingsScene>(RequiredScenes.Length);
            var known = new HashSet<string>(StringComparer.Ordinal);
            foreach (string path in RequiredScenes)
            {
                if (!known.Add(path))
                    throw new InvalidOperationException("Duplicated canonical chapter: " + path);
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
                    throw new InvalidOperationException(
                        "Cannot enable a missing or unimported narrative scene: " + path);
                configured.Add(new EditorBuildSettingsScene(path, true));
            }
            foreach (EditorBuildSettingsScene existing in EditorBuildSettings.scenes)
            {
                if (existing == null || string.IsNullOrWhiteSpace(existing.path))
                    continue;
                if (known.Add(existing.path))
                    configured.Add(new EditorBuildSettingsScene(existing.path, false));
            }
            EditorBuildSettings.scenes = configured.ToArray();
        }

        public static List<string> Validate()
        {
            var failures = new List<string>();
            EditorBuildSettingsScene[] all = EditorBuildSettings.scenes;
            string[] enabled = all.Where(item => item != null && item.enabled)
                .Select(item => item.path).ToArray();
            if (!enabled.SequenceEqual(RequiredScenes, StringComparer.Ordinal))
                failures.Add("Enabled build scenes must be exactly ChapterOne, ChapterTwo, ChapterThree and ChapterFour in this order.");
            foreach (string path in RequiredScenes)
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
                    failures.Add("Required narrative scene is missing or not imported: " + path);

            // Guard against a future divergence between Unity scene serialization
            // and the runtime navigation policy. Neither list may silently drift.
            if (NarrativeSceneRoute.ChapterCount != RequiredScenes.Length)
                failures.Add("Narrative runtime and editor route have different chapter counts.");
            else
                for (int chapter = 1; chapter <= RequiredScenes.Length; chapter++)
                    if (!string.Equals(RequiredScenes[chapter - 1],
                        NarrativeSceneRoute.ScenePath(chapter), StringComparison.Ordinal))
                        failures.Add("Chapter route mismatch at chapter " + chapter);

            var paths = new HashSet<string>(StringComparer.Ordinal);
            foreach (EditorBuildSettingsScene item in all)
            {
                if (item == null || string.IsNullOrWhiteSpace(item.path) || !paths.Add(item.path))
                    failures.Add("Build Settings contain an empty or duplicated scene entry.");
                if (item != null && item.enabled &&
                    !RequiredScenes.Contains(item.path, StringComparer.Ordinal))
                    failures.Add("An unauthorized scene is enabled: " + item.path);
            }
            return failures;
        }
    }
}
#endif
