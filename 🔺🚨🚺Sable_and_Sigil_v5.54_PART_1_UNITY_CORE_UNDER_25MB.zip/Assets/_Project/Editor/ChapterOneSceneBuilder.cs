#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Non-destructive first-chapter scene creation. Keeps the legacy board scene
    /// available while prioritizing the playable narrative chapter for builds.
    /// </summary>
    public static class ChapterOneSceneBuilder
    {
        public const string ScenePath = "Assets/_Project/Scenes/ChapterOne.unity";

        [MenuItem("Sable & Sigil/Create or Open Chapter One")]
        public static void OpenChapterOne()
        {
            if (Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) return;
            EnsureChapterOne(true);
        }

        [MenuItem("Sable & Sigil/Play Chapter One")]
        public static void PlayChapterOne()
        {
            if (Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) return;
            EnsureChapterOne(true);
            if (SceneManager.GetActiveScene().path != ScenePath)
                throw new InvalidOperationException("Chapter One must be the active scene before Play Mode.");
            EditorApplication.ExecuteMenuItem("Window/General/Game");
            EditorApplication.isPlaying = true;
        }

        public static void EnsureChapterOne(bool openScene)
        {
            if (!File.Exists(ScenePath)) CreateScene();
            var asset = AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath);
            if (asset == null)
                throw new InvalidOperationException("The Chapter One scene asset cannot be imported.");

            // A stale or hand-edited scene must not silently enter the shipping
            // route. Inspect it without overwriting the file or losing the
            // Editor's active scene and unsaved user changes.
            ValidateExistingChapterOne();

            var scenes = EditorBuildSettings.scenes;
            var others = scenes.Where(s => s.path != ScenePath).ToArray();
            EditorBuildSettings.scenes = (new[] { new EditorBuildSettingsScene(ScenePath, true) })
                .Concat(others).ToArray();
            // Only the complete chapter builder may certify the shipping route.
            // This method deliberately does not enable the historical Main scene.
            if (openScene && SceneManager.GetActiveScene().path != ScenePath)
            {
                if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
                EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            }
        }

        private static void ValidateExistingChapterOne()
        {
            Scene chapter = SceneManager.GetSceneByPath(ScenePath);
            bool openedHere = !chapter.IsValid() || !chapter.isLoaded;
            Scene previousActive = SceneManager.GetActiveScene();
            try
            {
                if (openedHere)
                    chapter = EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Additive);
                if (!chapter.IsValid() || !chapter.isLoaded)
                    throw new InvalidOperationException("Chapter One scene cannot be opened for inspection.");
                if (chapter.isDirty)
                    throw new InvalidOperationException(
                        "Chapter One has unsaved changes. Save or revert them before preparing the build.");

                int activeControllers = 0;
                int controllerCount = 0;
                foreach (GameObject root in chapter.GetRootGameObjects())
                {
                    foreach (ChapterOneExperience controller in
                        root.GetComponentsInChildren<ChapterOneExperience>(true))
                    {
                        controllerCount++;
                        if (controller.isActiveAndEnabled) activeControllers++;
                    }
                    foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
                    {
                        if (GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(child.gameObject) != 0)
                            throw new InvalidOperationException(
                                "Chapter One contains a missing script on " + child.gameObject.name + ".");
                    }
                }
                if (controllerCount != 1 || activeControllers != 1)
                    throw new InvalidOperationException(
                        "Chapter One must contain exactly one active ChapterOneExperience. Existing scene was not changed.");
            }
            finally
            {
                if (openedHere && chapter.IsValid() && chapter.isLoaded)
                    EditorSceneManager.CloseScene(chapter, true);
                if (previousActive.IsValid() && previousActive.isLoaded)
                    SceneManager.SetActiveScene(previousActive);
            }
        }

        private static void CreateScene()
        {
            const string parent = "Assets/_Project";
            if (!AssetDatabase.IsValidFolder(parent + "/Scenes"))
                AssetDatabase.CreateFolder(parent, "Scenes");
            var old = SceneManager.GetActiveScene();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            try
            {
                if (!SceneManager.SetActiveScene(scene))
                    throw new InvalidOperationException("Cannot activate a new chapter scene.");
                var root = new GameObject("Sable & Sigil - Chapter One");
                root.AddComponent<ChapterOneExperience>();
                if (!EditorSceneManager.SaveScene(scene, ScenePath))
                    throw new IOException("Chapter One scene could not be saved.");
                AssetDatabase.SaveAssets();
            }
            finally
            {
                if (old.IsValid() && old.isLoaded) SceneManager.SetActiveScene(old);
                if (scene.IsValid() && scene.isLoaded) EditorSceneManager.CloseScene(scene, true);
            }
        }
    }
}
#endif
