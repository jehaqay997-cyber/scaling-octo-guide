#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    /// <summary>Builds a test APK only after the separate verification pipeline has passed.</summary>
    public static class OrderAndroidBuildBatch
    {
        private const string OutputVariable = "TOR_ANDROID_APK_PATH";
        private const string SuccessMarker = "THEORDERROOM_ANDROID_APK_BUILT";

        public static void BuildVerifiedApk()
        {
            var output = Environment.GetEnvironmentVariable(OutputVariable);
            if (string.IsNullOrWhiteSpace(output))
                throw new BuildFailedException(OutputVariable + " must be provided by the verified build runner.");

            var outputPath = Path.GetFullPath(output);
            if (!string.Equals(Path.GetExtension(outputPath), ".apk", StringComparison.OrdinalIgnoreCase))
                throw new BuildFailedException("The output must have an .apk extension.");
            var projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            var normalizedProject = projectRoot.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                + Path.DirectorySeparatorChar;
            if (outputPath.StartsWith(normalizedProject, StringComparison.OrdinalIgnoreCase))
                throw new BuildFailedException("Android build output must be outside the Unity project.");
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
                throw new BuildFailedException("Android Build Support is not installed for this Unity Editor.");
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
                throw new BuildFailedException("Start the editor with -buildTarget Android.");

            ChapterOneSceneBuilder.EnsureChapterOne(false);
            ChapterCaseSceneBuilder.EnsureCaseScenes();
            var problems = SableChapterBuildRoute.Validate();
            try
            {
                SableLaunchAcceptance.RequireImportedSourceAndScenes();
            }
            catch (Exception error)
            {
                problems.Add("Imported-source and chapter-scene acceptance failed: " +
                    error.GetType().Name + ": " + error.Message);
            }
            var requiredScene = ChapterOneSceneBuilder.ScenePath;
            var enabledScenes = EditorBuildSettings.scenes.Where(scene => scene.enabled).ToArray();
            if (enabledScenes.Length != 4 || enabledScenes[0].path != requiredScene)
                problems.Add("Only the four ordered narrative chapters may be enabled in the test APK.");
            if (problems.Count != 0)
                throw new BuildFailedException("Android build validation failed:\n" + string.Join("\n", problems));
            if (File.Exists(outputPath))
                throw new BuildFailedException("Refusing to overwrite an existing APK: " + outputPath);

            var folder = Path.GetDirectoryName(outputPath);
            if (string.IsNullOrEmpty(folder))
                throw new BuildFailedException("Invalid output folder.");
            Directory.CreateDirectory(folder);
            var options = new BuildPlayerOptions
            {
                scenes = enabledScenes.Select(scene => scene.path).ToArray(),
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = BuildOptions.Development | BuildOptions.DetailedBuildReport
            };
            // A development APK must not inherit a previously enabled AAB editor preference.
            // Restore the user's setting even when the build raises an exception.
            var originalBundleMode = EditorUserBuildSettings.buildAppBundle;
            BuildReport report;
            try
            {
                EditorUserBuildSettings.buildAppBundle = false;
                report = BuildPipeline.BuildPlayer(options);
            }
            finally
            {
                EditorUserBuildSettings.buildAppBundle = originalBundleMode;
            }
            if (report == null || report.summary.result != BuildResult.Succeeded ||
                report.summary.totalErrors != 0 || !File.Exists(outputPath) ||
                new FileInfo(outputPath).Length <= 0)
                throw new BuildFailedException("Android BuildPipeline did not produce a successful nonempty APK.");
            Debug.Log(SuccessMarker + " " + outputPath);
        }
    }
}
#endif
