# Sable & Sigil — Open the v5.44 Unity Candidate

- Use Unity **2022.3.62f3**.
- Unzip the lightweight Unity package; `Assets`, `Packages`, and `ProjectSettings` must be visible at its root.
- On first import, allow Package Manager and script import to finish. Do not assume a clean compile without observing the Console.
- Run `Sable & Sigil > Prepare Chapters One to Four` to create and validate all four narrative scenes.
- Run `Sable & Sigil > Prepare and Validate Playable Chapter` to open Chapter One and run the Editor preflight.
- If an existing scene contains missing scripts or unsaved changes, save a copy and review the diagnostic. The builder now fails closed rather than overwriting it.
- When the editor is closed, `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` executes independent Unity verification and writes evidence to the sibling `SableSigilVerification` directory.

Do not publish or claim runtime readiness without passing Unity C# compilation, EditMode, PlayMode, full campaign gameplay, and Android device verification.
