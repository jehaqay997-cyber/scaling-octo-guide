#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Invoke-Main {
    $projectRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
    $versionFile = Join-Path $projectRoot 'ProjectSettings\ProjectVersion.txt'
    if (-not (Test-Path -LiteralPath $versionFile -PathType Leaf)) {
        throw 'ProjectSettings/ProjectVersion.txt is missing. Extract the full project first.'
    }
    $versionText = Get-Content -LiteralPath $versionFile -Raw
    if ($versionText -notmatch '(?m)^m_EditorVersion:\s*2022\.3\.62f3\s*$') {
        throw 'Expected Unity 2022.3.62f3. Build aborted without modifying ProjectSettings.'
    }

    $candidates = New-Object 'System.Collections.Generic.List[string]'
    if (-not [string]::IsNullOrWhiteSpace($env:UNITY_EDITOR_PATH)) {
        $candidates.Add($env:UNITY_EDITOR_PATH)
    }
    if (-not [string]::IsNullOrWhiteSpace($env:ProgramFiles)) {
        $candidates.Add((Join-Path $env:ProgramFiles 'Unity\Hub\Editor\2022.3.62f3\Editor\Unity.exe'))
    }
    if (-not [string]::IsNullOrWhiteSpace(${env:ProgramFiles(x86)})) {
        $candidates.Add((Join-Path ${env:ProgramFiles(x86)} 'Unity\Hub\Editor\2022.3.62f3\Editor\Unity.exe'))
    }
    $editor = $null
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            $editor = (Resolve-Path -LiteralPath $candidate).Path
            break
        }
    }
    if ($null -eq $editor) {
        throw 'Unity 2022.3.62f3 was not found. Install the exact editor and Android Build Support, or set UNITY_EDITOR_PATH to Unity.exe.'
    }

    $projectParent = Split-Path -Path $projectRoot -Parent
    $buildDirectory = Join-Path $projectParent 'SableAndSigil_DevelopmentBuilds'
    New-Item -Path $buildDirectory -ItemType Directory -Force | Out-Null
    $identifier = [DateTime]::UtcNow.ToString('yyyyMMdd_HHmmss_fff', [Globalization.CultureInfo]::InvariantCulture) + '_' + [Guid]::NewGuid().ToString('N').Substring(0,8)
    $apkPath = Join-Path $buildDirectory ('SableAndSigil_Development_' + $identifier + '.apk')
    $logPath = Join-Path $buildDirectory ('UnityBuild_' + $identifier + '.log')

    $env:TOR_ANDROID_APK_PATH = $apkPath
    try {
        Write-Host ('Unity editor: ' + $editor)
        Write-Host ('Project: ' + $projectRoot)
        Write-Host ('Expected APK: ' + $apkPath)
        Write-Host ('Build log: ' + $logPath)
        $arguments = '-batchmode -nographics -quit -buildTarget Android -projectPath "' + $projectRoot + '" -executeMethod TheOrderRoom.Editor.OrderAndroidBuildBatch.BuildVerifiedApk -logFile "' + $logPath + '"'
        $process = Start-Process -FilePath $editor -ArgumentList $arguments -Wait -PassThru
        if ($process.ExitCode -ne 0) {
            throw ('Unity exited with code ' + $process.ExitCode + '. Inspect: ' + $logPath)
        }
        if (-not (Test-Path -LiteralPath $apkPath -PathType Leaf)) {
            throw ('Unity did not produce the expected APK. Inspect: ' + $logPath)
        }
        $artifact = Get-Item -LiteralPath $apkPath
        if ($artifact.Length -le 0) {
            throw ('Unity produced an empty APK. Inspect: ' + $logPath)
        }
        if (-not (Test-Path -LiteralPath $logPath -PathType Leaf)) {
            throw 'Unity did not produce a log. Build cannot be verified.'
        }
        $marker = 'THEORDERROOM_ANDROID_APK_BUILT ' + $apkPath
        $logContent = Get-Content -LiteralPath $logPath -Raw
        if (-not $logContent.Contains($marker)) {
            throw ('The expected successful build marker is missing. Inspect: ' + $logPath)
        }
        $hash = (Get-FileHash -LiteralPath $apkPath -Algorithm SHA256).Hash
        Write-Host ''
        Write-Host 'DEVELOPMENT_APK_BUILT' -ForegroundColor Green
        Write-Host ('Path: ' + $apkPath)
        Write-Host ('Bytes: ' + $artifact.Length)
        Write-Host ('SHA256: ' + $hash)
    }
    finally {
        Remove-Item Env:TOR_ANDROID_APK_PATH -ErrorAction SilentlyContinue
    }
}

try {
    Invoke-Main
}
catch {
    Write-Host ('BUILD_FAILED: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
