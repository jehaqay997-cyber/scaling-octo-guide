SABLE & SIGIL — PLAYABLE EDITION AND UNITY DEVELOPMENT BUILD

BROWSER GAME
The separate Sable_and_Sigil_PLAY_NOW_OFFLINE.html download contains a complete
playable browser adaptation: ten authentic original investigation cases, original
scene artwork, interactive mechanisms, four chapters, four ending pages,
independent sound controls, and local progression saves.

Unity and the browser game are separate runtimes. The browser edition is not an
Android APK and does not claim to execute Unity C# assemblies or 3D scenes.

UNITY DEVELOPMENT APK ON WINDOWS
1. Extract this ZIP into a local folder with Assets, Packages, ProjectSettings.
2. Close any Unity Editor that already has the project open.
3. Double-click BUILD_DEVELOPMENT_APK.cmd.

The launcher looks for Unity 2022.3.62f3 and requires the editor's Android Build
Support. It writes a unique Development APK and a Unity log to the sibling
SableAndSigil_DevelopmentBuilds directory. It uses the game's existing
OrderAndroidBuildBatch.BuildVerifiedApk method and validates the success marker,
file existence, size, and SHA-256 digest. It does not change ProjectSettings,
Packages, asset GUIDs, or disable release gates.

IMPORTANT
The Unity Editor is unavailable in the creation environment. Compilation,
EditMode, PlayMode, Android SDK integration, device installation, and final
release verification must run on the target Windows PC and Android device.
The script will fail with a clear error if dependencies are absent or the source
has unresolved compilation errors; no APK is prebuilt or guaranteed.
