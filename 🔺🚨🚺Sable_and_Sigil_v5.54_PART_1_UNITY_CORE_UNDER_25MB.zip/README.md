# Sable & Sigil — v5.47 Verified Dossier Continuity Candidate

**Unity compatibility target:** 2022.3.62f3. **Status:** SOURCE REVIEWED; UNITY COMPILE, EDITMODE, PLAYMODE, APK AND DEVICE TESTS NOT EXECUTED.

## Production-relevant fixes

- The first two cases retain an authorized, case-scoped, in-memory inference board when the player leaves a verified but unfinished dossier. The atlas offers **RESUME CASE FILE** without forcing the physical world mechanism to be repeated during the same live gallery session.
- Resume authorization requires the matching live world handoff, case identity, a ready save session, and an unchanged save revision. Unvisited cases remain inaccessible, and a new game process cannot forge a durable proof. Completing the case invalidates the transient authorization.
- The existing `ChapterPuzzleDragToken` now accepts multiple drop targets. Evidence cards can be dragged into either board socket; the existing `StoryCaseInspection.TryPlaceOnBoard` validates the correct pairing, and decoy cards are rejected.
- The evidence cards reset between cases instead of remaining committed across dossier openings. Reopening the same verified case reconstructs their visual placements from the case's ephemeral inspection data.
- The existing `StoryDossierSession` remains the only owner of durable case completion. No alternate save, puzzle scene, or parallel chapter system was added. All existing runtime art bytes and `.meta` identities are unchanged.

## Unity acceptance — must be executed on the target machine

1. Extract into a local directory and open with the designated Unity editor. Check Package Manager, Console, and script compilation.
2. Run `Sable & Sigil > Prepare Chapters One to Four` once compilation is clean.
3. In Test Runner, run EditMode, then PlayMode. In particular run `VerifiedUnfinishedDossierResumesWithoutRepeatingWorldAndCannotUnlockAnotherCase` and `InferenceCardsAreReusableForCaseTwoAndRejectIncorrectSockets`.
4. Play physical case 1, drag a card to the *wrong* slot, then to the correct one; close and reopen the unsolved dossier; finish the deduction. Repeat with case 2 and verify that its drag cards are usable.
5. Verify touch input, return to atlas, scene transitions, persistence and an Android build on device.

## Limitations

The resume authorization is intentionally in-memory and is lost across a full application restart; a future persistence migration could explicitly store world proof without making it forgeable. Cases 03–10 still use the earlier deduction flow. Unity scenes are created by editor scripts, not yet built or played in this environment. No actual C# compiler, Unity Editor, or Android build pipeline was available for executable verification. `Python` source checks are *not* a substitute for Unity Test Runner.

The 15 reference and master-art files are supplied separately in `Sable_and_Sigil_v5.43_ART_REFERENCES_AND_MASTERS_BACKUP.zip`; they are outside `Assets` and do not affect project startup.
