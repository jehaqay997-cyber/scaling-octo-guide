# TheOrderRoom — Unity 2022.3.62f3 compatibility candidate

Status: SOURCE ADAPTED; UNITY COMPILATION NOT EXECUTED; NOT VERIFIED TO RUN.

Original baseline: TheOrderRoom v3.8. No original file changed.

Changes:
- ProjectVersion.txt set to 2022.3.62f3.
- com.unity.ugui 2.0.0 -> 1.0.0.
- com.unity.inputsystem 1.17.0 -> 1.7.0.
- com.unity.test-framework 1.6.0 -> 1.1.33.

These are compatibility candidate versions, NOT proof of successful package resolution. Unity Package Manager may resolve different transitive dependencies. No packages-lock.json was supplied.

Static checks: Unity 2022.3 supports FindObjectsByType with FindObjectsInactive and FindObjectsSortMode. No UnityPac or ML-Agents dependency declared. No saved .unity scenes or .prefab assets in baseline; editor bootstrap must generate scene after successful compilation.

Important: No Unity executable exists in the audit environment. Unity compilation, EditMode, PlayMode and Android IL2CPP tests remain NOT EXECUTED.

Acceptance steps: open in Unity Hub 2022.3.62f3; verify UPM; capture Console compile errors; run EditMode; run bootstrap and save Main.unity; PlayMode smoke test; Android build.

Do not merge with an older project. Extract to a separate short ASCII path. Do not delete .meta files or regenerate GUIDs.
