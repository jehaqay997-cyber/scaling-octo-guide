#!/usr/bin/env python3
"""Read-only structural preflight. Does not compile Unity C# or alter files."""
import json,re,sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
assets=root/'Assets'
files=[p for p in assets.rglob('*') if p.is_file()]
issues=[]; guids={}
for p in files:
 if p.suffix=='.meta':
  m=re.search(r'(?m)^guid: ([0-9a-f]{32})$',p.read_text(errors='replace'))
  if not m: issues.append('Invalid meta: '+str(p.relative_to(root)))
  else:
   if m.group(1) in guids: issues.append('Duplicate GUID: '+str(p))
   guids[m.group(1)]=str(p)
  if not p.with_suffix('').exists(): issues.append('Orphan meta: '+str(p))
 elif p.name!='.DS_Store' and not (p.parent/(p.name+'.meta')).exists(): issues.append('Missing meta: '+str(p))
for p in assets.rglob('*.asmdef'):
 try: json.loads(p.read_text())
 except Exception as e: issues.append('Bad asmdef: '+str(p)+' '+str(e))
try: json.loads((root/'Packages/manifest.json').read_text())
except Exception as e: issues.append('Bad manifest: '+str(e))
print(json.dumps({'file_count':len(files),'guid_count':len(guids),'scenes':[str(p.relative_to(root)) for p in assets.rglob('*.unity')],'issues':issues,'status':'STATIC_PASS' if not issues else 'STATIC_FAIL'},indent=2))
sys.exit(1 if issues else 0)
