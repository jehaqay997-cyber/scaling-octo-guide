# TheOrderRoom v4.0 — Targeted Source Remediation

Target: Unity 2022.3.62f3. Source base: v3.9 foundation candidate.

## Changes actually made
- `CollectionMilestones`: count unique validated artifact IDs rather than raw collection length.
- `LevelSolvability`: iterative bounded DFS (no recursive stack); new `Analyze` result distinguishes Solvable, Unsolvable, BudgetExceeded. Existing `TryFindSolution`/`HasSolution` retain their previous budget-exhaustion exception contract.
- `PuzzleMath`: validate non-finite input in the historical `SmoothStepAntiderivative` method, clarify that it integrates the derivative, not SmoothStep.
- Added `MathematicalHardeningTests.cs` with five EditMode tests (written, not executed).

## Complexity
- Milestones: O(N + M) expected time; O(U + M) extra space (N input IDs, U unique IDs, M milestones).
- Solvability: O(min(B^N, nodeLimit * B)) time in the worst case and O(N+B) auxiliary space, excluding the returned witness. Search remains exponential; bounded nodes do not bound wall-clock latency without measurement.

## Known unresolved release blockers
- No Unity Editor executable in audit environment; compilation, package resolution, tests and Android build not executed.
- Foundation.unity is a placeholder, not a playable scene. Main.unity requires Unity Editor bootstrap execution.
- `OrderBoard` scans locations in CanPlace, O(N) per attempt; replacing it with indexed counters requires dedicated regression tests for Restore/Reset and is deferred rather than risk changing semantics blindly.
- `OrderBoard.Revision` is int; exhaustion is guarded, but long migration requires save-schema compatibility tests.
- Save durability and power-loss atomicity, mobile performance, input correctness, IL2CPP and security posture remain unverified.
- Unity package versions are compatibility candidates, not proven installed/resolved.

## Status
SOURCE_PATCHED / ZIP_STATIC_CHECKED / UNITY_COMPILE_NOT_EXECUTED / TESTS_NOT_EXECUTED / DEVICE_NOT_EXECUTED.
