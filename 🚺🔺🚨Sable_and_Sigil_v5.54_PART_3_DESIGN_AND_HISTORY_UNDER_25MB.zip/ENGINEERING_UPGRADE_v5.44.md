# Sable & Sigil v5.44 — Editor Scene Import Guards

Target editor: Unity 2022.3.62f3. This is a **source-verified Unity acceptance candidate**, not a verified playable build.

## Corrective work

1. `ChapterOneSceneBuilder.EnsureChapterOne()` now validates the actual imported scene before modifying Build Settings. If an existing Chapter One scene is dirty, cannot load, has missing scripts, or does not contain exactly one active `ChapterOneExperience`, the builder fails with a diagnostic without overwriting it.
2. Scene validation uses additive loading and restores the previous active Editor scene. A scene opened solely for validation is closed by the validator; already loaded user scenes remain open.
3. `SableChapterBuildRoute.Configure()` refuses to enable a required chapter if its Unity `SceneAsset` has not imported. The route validator reports missing or unimported required scenes even when a Build Settings entry appears syntactically correct.
4. Added nine independent source-level regression tests in `Verification/test_v544_scene_import_guards.py`.
5. Acceptance report revision metadata updated to v5.44.

## Offline validation

- Python regression: 1,063 tests passed and 30 subtests passed after restoring the external artwork backup.
- Seven targeted source-verification scripts passed, including canonical chapter route, atlas route, scene serialization, reference graph, build integrity, final audit and project integrity.
- Each original authored asset, original artwork and `.meta` must remain byte-identical to v5.43. The package report verifies this at ZIP member level.
- The original 15 non-runtime design masters and reference photos remain in a separate, unchanged backup ZIP to keep the Unity package under 25,000,000 bytes.

## Not yet verified

- Unity source import and C# compilation, Unity generated scene serialization, NUnit EditMode or PlayMode, real graphics, Android build and device operation were **not executed**.
- The source archive intentionally contains no generated `.unity` scenes. They are created by Unity, not by offline scripts.
- The original `ProjectSettings.asset` is a minimal settings fragment; its completeness and Android platform settings require editor-side review.

## First run

1. Extract the Unity ZIP to a writable local directory, not a cloud-synced folder.
2. Open the project in Unity 2022.3.62f3. If Safe Mode appears, capture the first Console compiler error without deleting files.
3. After import and compilation succeed, run `Sable & Sigil > Prepare Chapters One to Four` and then `Sable & Sigil > Prepare and Validate Playable Chapter`.
4. Inspect all four ordered scenes in Build Settings, play the first chapter, and verify cross-chapter atlas navigation.
5. Close the editor and run `RUN_SABLE_EDITOR_ACCEPTANCE.cmd` to capture fresh EditMode and PlayMode execution evidence.

The separate artwork backup is not needed to open the Unity project. Restore it to the same directory if you need the full original authoring materials and the full offline Python suite.
