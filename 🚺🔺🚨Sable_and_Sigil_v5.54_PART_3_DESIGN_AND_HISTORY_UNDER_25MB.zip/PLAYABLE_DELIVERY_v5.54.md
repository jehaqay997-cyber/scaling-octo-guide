# Sable & Sigil v5.54 — Playable Runtime Repair

## Scope

This release updates the existing browser-playable investigation (ten authored cases, four chapters and finale), not the original Unity scenes or narrative source. The Unity source, .meta identifiers, ProjectSettings and Packages remain byte-identical to v5.53.

## Runtime repairs

- Persistent visible alert on local save failures or unavailable storage. In-memory play remains possible, but no false claim of durability is shown.
- Save failure protection for unavailable storage, quota errors and generation exhaustion; successful retry removes the warning.
- Web Audio cues can be scheduled during a suspended AudioContext after a user gesture. The first effect is not discarded solely because resume is asynchronous.
- Effect concurrency is bounded to six active voices, and ended voices disconnect from the graph.
- Independent effects bus silences in-flight cues when effects mute is enabled.
- PWA application shell requests use network-first with an offline fallback; images remain cache-first. Other origin requests are not intercepted.

## Validation

- 1,130 Python static tests passed.
- 41 + 25 + 17 = 83 Chromium DOM tests passed using an injected localStorage adapter and a controlled AudioContext mock for audio edge cases.
- Every Web asset is present and the single-file HTML embeds 14 original visual assets.
- Source ZIP/PWA ZIP were CRC checked after packaging and all original Unity files preserved.

## Unverified

This environment has no Unity 2022.3.62f3 editor, Android toolchain, Android device, iOS device or deployable public HTTPS origin. Unity compilation, Editor tests, APK/AAB builds, device playback and real Service Worker installation are NOT verified. Existing Android release requirements remain unchanged.

## How to run

Open `PLAY_GAME_NOW.html` or the standalone HTML directly in a browser that permits local HTML execution. For installable PWA behavior, host the `PlayableBrowser/Web/` folder over HTTPS with the standard web files intact. For native Android, open the entire project in the required Unity Editor and execute the existing development APK build script; do not mistake the browser HTML for an APK.
