# Sable & Sigil v5.53 — Playable Runtime Hardening

## Delivery

- `PLAY_GAME_NOW.html`: complete, single-file offline browser adaptation with the original ten cases, fourteen embedded scene/chapter images, interactive mechanisms, finale, audio, and local saves.
- `PlayableBrowser/Web/`: static hosted/PWA version. Host the directory over HTTPS to enable service-worker installation and offline caching.
- Unity project source under `Assets/`, `Packages/`, and `ProjectSettings/` is retained byte-for-byte from v5.52.
- `BUILD_DEVELOPMENT_APK.cmd` remains the Windows development-build runner for Unity 2022.3.62f3, and requires an installed Unity Editor and Android Build Support.

## Fixed defects

1. Stale-tab changes could overwrite a more recent investigation in the same alternating save slot. Saves now reconcile the latest persisted generation before writing.
2. A stale verdict could reinstate completed findings after another tab reset the game. A reset now assigns an epoch identifier, and progress writes reject a different epoch.
3. Storage-change events could reduce the active generation counter when a newer slot was removed. The event listener only adopts genuinely newer valid snapshots and handles explicit storage clearance.
4. Mechanism buttons lost keyboard focus after redrawing, which disrupted keyboard-only operation. Repeated actions now preserve focus, and navigation focuses the new screen heading.
5. A cache-first service-worker navigation could serve a stale HTML shell despite a new deployment. Navigations now prefer the network, retaining a cached offline fallback.
6. A settings change from a stale tab could display a stale finding count until another navigation. The settings screen now redraws using reconciled state.

## Persistence boundaries

- Existing v1 save data without an epoch is accepted. The epoch is added upon starting a new game.
- A two-slot FNV checksum detects accidental changes but does not authenticate or encrypt data.
- Browser localStorage is not a transactional database. Simultaneous writes at exactly the same generation cannot be guaranteed race-free without a transactional backend. Unity's native persistence is not replaced by this browser save implementation.

## Verification

- Static test suite: `python -m unittest discover -s Verification -p 'test_*.py' -q`.
- Existing browser regression tests: `python Verification/BrowserPlaywright/verify_playable_browser_v552.py`.
- New cross-tab and keyboard tests: `python Verification/BrowserPlaywright/verify_playable_browser_v553.py`.
- JavaScript syntax checked with `node --check` for `game.js`, `story.js`, and `service-worker.js`.

The browser tests ran actual Chromium DOM interactions with a controlled in-memory storage adapter. Direct file/localhost navigation was blocked by the automation environment, and no Android handset, Unity Editor, Unity compilation, Unity Test Runner, signed AAB, or device APK test was available.
