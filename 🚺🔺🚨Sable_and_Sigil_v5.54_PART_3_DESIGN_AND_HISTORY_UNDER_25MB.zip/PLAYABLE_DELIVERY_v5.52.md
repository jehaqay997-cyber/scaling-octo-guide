# Sable & Sigil v5.52 — Canonical Playable Edition

## Playable browser game

Open `PLAY_GAME_NOW.html` to play the standalone browser edition. It embeds original
artwork, ten authored investigation locations, four chapters, independent music/effects
settings, two-slot checksum-validated local saves, and four finale pages.

For Windows, `PLAY_SABLE_BROWSER.cmd` opens this file with the default browser.
Some mobile browser/file-manager combinations restrict locally opened HTML; use the
static web bundle in `PlayableBrowser/Web` on a trusted HTTPS host for mobile/PWA use.
No backend, login, advertising integration, or external game CDN is required.

The playable browser edition is an adaptation based on the project story data and is
not a Unity executable or Android APK. Browser saves are stored locally per browser
and origin; they are validated against accidental corruption but are NOT encrypted,
authenticated, or intended to store sensitive information.

## Corrections in this revision

- Replaced the root `PLAY_GAME_NOW.html` legacy TheOrderRoom board preview with the
  canonical Sable & Sigil investigation game.
- Preserved the original ten cases and the four-page finale.
- Protected existing investigation progress with an explicit New Game confirmation.
- Wrote both alternating save slots on reset to prevent progress resurrection from
  a damaged latest slot.
- Properly disclosed local-storage denial and recovery from corrupted save records.
- Resumed browser ambience after page visibility restoration when the browser allows it.
- Synchronized progress changes received from other browser tabs on a best-effort basis.
- Scoped PWA cache deletion to this app's cache prefix, avoiding unrelated caches.
- Added installable 192px and 512px PNG icons to the PWA bundle.
- Updated obsolete static gates that checked the unrelated legacy browser puzzle,
  without weakening their Unity startup, GUID, packaging, or security checks.

## Validation

The Python offline unit suite and a Chromium mobile-emulation interaction suite
are included under `Verification`. Browser checks cover the ten mechanisms, ten
verdicts, four finale pages, settings persistence, corrupted-slot recovery,
confirmation before reset, and disabled localStorage fallback. The Chromium
sandbox blocked HTTP and file navigation, so its automated browser tests injected
the actual standalone HTML into a browser document with a test-only storage adapter.
They are NOT tests of a real device, PWA installation, or the Unity Editor.

Unity Editor 2022.3.62f3, C# compilation, EditMode, PlayMode, Android build, and
physical phone verification remain NOT EXECUTED in this environment.

## Unity project

All existing Unity `Assets`, `Packages`, `ProjectSettings`, `.meta`, and asset GUID
files were preserved byte-for-byte from v5.51. `BUILD_DEVELOPMENT_APK.cmd` is the
previously supplied development-build launcher. An APK can only be produced and
verified on a machine with the compatible Unity Editor and Android build support.
