# Changelog


## v5.47 — Verified dossier continuity and reusable evidence cards

- Fixed an unfinished, physically verified dossier becoming inaccessible after returning to the atlas.
- Added case-specific, revision-checked in-memory resume authorization; no save schema changes.
- Fixed evidence cards remaining committed when starting the second case.
- Reused the existing drag component for two independent inference sockets instead of hard-wiring each card to its answer slot.
- Added two Unity PlayMode scenario tests for resume authority, cross-case isolation and two-case board lifecycle (authored, not executed).
- Preserved all gameplay artwork and Unity asset identities.


## v5.46 — Chapter One inference boards

- Replaced player-facing four-choice case conclusions for Cases 01 and 02 with the existing game's draggable evidence board and typed finding.
- Added misleading testimony cards, physical corroboration readouts, and negative-response handling without persisting transient UI state.
- Preserved `StoryDossierSession`, checkpoint schema v1, world mechanisms, chapter scene routes, all Unity resource artwork, and existing Unity GUIDs.
- Added one NUnit EditMode fixture and extended existing PlayMode fixtures. NUnit has not been run inside Unity.
- Updated authored two-case contracts, inventory hashes, and static gates while preserving legacy source verifiers.
- Offline verification must be distinguished from Unity C# compilation and runtime acceptance.

## v5.45 — Physical world input

- Crest tracing drag, baluster symbol drag and lunar rotary dial, as inherited from the v5.45 input source baseline.
