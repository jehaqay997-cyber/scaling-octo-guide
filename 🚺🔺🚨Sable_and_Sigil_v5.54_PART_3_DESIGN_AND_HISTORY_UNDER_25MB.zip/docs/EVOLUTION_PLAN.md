# Sable & Sigil — Existing-System Evolution Plan

**Baseline:** v5.47 — `Sable_and_Sigil_v5.47_VERIFIED_DOSSIER_CONTINUITY_UNDER_25MB.zip`  
**Status:** SOURCE INSPECTED; UNITY COMPILATION AND RUNTIME ACCEPTANCE NOT VERIFIED  
**Change policy:** Extend the existing game; do not introduce another chapter, deduction, or save authority.

## 1. Non-negotiable compatibility contract

- Preserve every existing assembly name, namespace, public member, serialized field, and asset GUID.
- Never change an existing `.meta` file merely to refactor code. New assets, if any, receive new unique GUIDs.
- Preserve `StoryDossierSession` as the exclusive owner of durable investigation completion.
- Add characterization tests **before** modifying production implementations.
- Apply one bounded code change per review, then run source integrity checks and Unity EditMode/PlayMode tests.
- Do not report an offline source test as a C# compile, Unity test, Play session, APK build, or device test.
- The first playable vertical slice is cases 1 and 2 in chapter 1; do not broaden the new UX until those cases pass on-device.

## 2. Findings from source inspection — existing components

| File / component | Observed responsibility | Existing coupling | Decision |
| --- | --- | --- | --- |
| `Domain/StoryDeductionProof.cs` | Computes one expected answer for each of the ten cases and checks the current four-choice catalog | Called by `StoryDossierCatalog.Validate`; covered by EditMode tests | **Reuse** as the compatibility oracle. Add new evidence-proof semantics later without removing the legacy answer verification. It is not an interactive evidence collector. |
| `Domain/LinkedPuzzleRules.cs` | `LinkedPairRule` and `DestinationKeyRule` enforce placement constraints on `OrderBoard` | Used by `CampaignPuzzles` and legacy puzzle runtime | **Do not connect directly to dossier evidence**. These rules operate on drawer/item positions, not a narrative evidence graph. Reuse their constraint-solving patterns only when an explicit adapter is justified. |
| `Domain/CollectionMilestones.cs` | Counts distinct artifact identifiers to award thresholds 1, 4, 8 and 12 | Has tests but no identified dossier runtime caller | **Leave isolated for now**. Ten completed investigations cannot satisfy the twelve-artifact milestone without a defined artifact catalog. Do not couple milestones to story progression by assumption. |
| `Domain/ChapterStoryGraph.cs` | Holds ten authored locations and their prerequisite lists; `Validate` checks metadata and basic reachability | Used in `StoryDossierSession`, chapter summaries and gallery | **Extend the existing graph data**, after characterization tests. Cases 3 and 4 currently have sequential dependencies (2 → 3 → 4); they are **not yet independently solvable**. |
| `Domain/AdventureSolvabilityVerifier.cs` | Exhaustively explores `AdventureChapter` actions and `AdventureSnapshot` states | Tests cover the older adventure transition model | **Do not misrepresent as a validator of the ten-case graph**. Add a distinct graph-focused validator to the existing Domain assembly if branching is introduced. |
| `Domain/StoryDossierPersistence.cs` | `StoryEvidenceLedger`, versioned checkpoint codec, repository and `StoryDossierSession` own canonical case progress | Runtime uses this session through `PlayerPrefsDossierStorage` | **Keep authority unchanged**. Any future durability upgrade occurs behind the existing `IStoryDossierStorage` interface with migration and recovery tests first. |
| `Infrastructure/AdventureJournalStore.cs` | Stores versioned `AdventureSnapshot` transitions | Tested separately; no direct implementation of `IStoryDossierStorage` | **Not a drop-in replacement** for dossier saves. Implement a compatible storage adapter or explicitly retain the current storage until migration is proven. |
| `Runtime/ChapterWorldExplorer.cs` | World interaction and view/controller orchestration in an oversized MonoBehaviour | Referenced by existing scene generation and play tests | **First make the MonoBehaviour partial** without moving serialized fields or changing class identity. Extract one non-serialized responsibility at a time after tests. |
| `Runtime/StoryDossierView.cs` | Existing in-game inference overlay with verified-world handoff and resume behavior | Uses `StoryDossierSession`; first two cases have typed findings | **Expand this UI in place**. Do not add a parallel deduction screen or independent progress store. |

### Critical integration cautions

1. `StoryDeductionProof` proves the old authored answer key, but it does **not** prove that a player physically collected the required clues. The current physical handoff is mediated by `StoryDossierView`; it must be tested against bypass and reload paths before changing the submission API.
2. `AdventureSolvabilityVerifier` is for a different finite state machine. Branching the ten cases requires exhaustive reachability and dead-end checks against `ChapterStoryGraph`, `StoryEvidenceLedger`, and the actual unlock policy.
3. The existing dossier checkpoint format is `v1` and uses two PlayerPrefs-backed slots. A future journal migration must preserve both valid existing saves and corruption/future-version rejection rules.
4. UI evidence placement may be ephemeral. Treat cross-process persistence of partial puzzle work as a separate decision from persisted completed-case progress.

## 3. Characterization gate (this delivery)

New EditMode file: `Assets/_Project/Tests/EditMode/ExistingSystemCompatibilityBaselineTests.cs`.

It freezes the observed behavior of existing ten-case proof keys, typed-answer aliases, current sequential prerequisites, read-only proof queries, drawer-specific linked rules, and artifact milestone thresholds. It does not modify production code or create a new assembly.

**Required Unity acceptance:** verify `TheOrderRoom.Tests.EditMode.ExistingSystemCompatibilityBaselineTests` passes inside Unity before starting any production refactor. The test file has not been compiled or run by a C# compiler in this environment.

## 4. Incremental implementation sequence

| Gate | Bounded change | Rollback trigger | Evidence required |
| --- | --- | --- | --- |
| P0 | Import current project and generate the four chapter scenes using existing editor tools | Compilation failure or Safe Mode | Editor log, successful compile, generated scenes and Build Settings screenshot |
| P0 | Execute existing and new EditMode/PlayMode tests | Failing baseline or scene load | Test Runner XML and full Console log |
| P1-A | Make cases 1 and 2 reliably playable end-to-end using existing dossier overlay and world interactions | Unverified evidence bypass, broken resume, lost save | Recorded playthrough with success, wrong-answer, close/reopen and reload cases |
| P1-B | Add an interaction-kind property to existing dossier case metadata, defaulting to legacy choice mode | Existing case outcome or serialization changes | Before/after characterization tests and deliberate migration assertions |
| P1-C | Make case 3 and case 4 prerequisites independent in existing graph metadata; keep next-chapter gate | Any reachable softlock or mismatched save restore | Exhaustive graph-state verifier and Unity behavior tests |
| P1-D | Split `ChapterWorldExplorer` using a partial class in the same assembly and namespace, preserving serialized fields | Scene/asset reference breaks | GUID diff, serialized reference audit, Unity scene load and play tests |
| P1-E | Add durable `IStoryDossierStorage` adapter backed by approved on-disk journal with old-key migration | Changed existing save or future-schema recovery | Atomic rollback, corruption, power-loss and migration tests |
| P2 | Expand clue contradictions and mechanics for cases 3–10 through existing case/presenter routing | Regression in chapter navigation or story answers | Case-by-case vertical-slice tests and player observations |
| P2 | Finish missing art, sourced audio, accessibility and Android optimization | Unknown licenses or accessibility regressions | License register, in-game accessibility audit, profiled device builds |

## 5. Quality acceptance checklist

Use **ISO/IEC 25010:2023** as the quality model for functional suitability, reliability, performance efficiency, maintainability, security, compatibility, interaction capability, flexibility and safety as applicable to the product. Apply SOLID at code boundaries without introducing abstractions that cannot be exercised by the current game.

- **Functional suitability:** every chapter-one deduction can be reached, played, abandoned, resumed and completed exactly once.
- **Reliability:** wrong evidence never commits progress; save failure does not silently advance the canonical ledger; obsolete and future-format checkpoints are handled explicitly.
- **Maintainability:** source changes are bounded, dependencies stay inside existing assemblies, serialized fields and GUIDs remain unchanged.
- **Accessibility:** verify text scaling, readable contrast, non-color-only clues, accessible drag alternatives, reduce-motion and touch-target sizing against **WCAG 2.2** principles adapted to a native Unity game.
- **Performance:** collect real frame-time, memory, GC, crash and ANR observations on Android devices; report **Android vitals** only when Play Console evidence exists.
- **Release readiness:** `COMPILE_VERIFIED`, `EDITMODE_VERIFIED`, `PLAYMODE_VERIFIED`, `APK_VERIFIED`, and `DEVICE_VERIFIED` remain false without corresponding executable evidence.

### Primary references

- ISO/IEC 25010:2023 — https://www.iso.org/standard/78176.html
- Unity Test Framework 1.1 manual — https://docs.unity.cn/Packages/com.unity.test-framework@1.1/manual/edit-mode-vs-play-mode-tests.html
- WCAG 2.2 — https://www.w3.org/TR/WCAG22/
- Android vitals — https://developer.android.com/games/optimize/vitals

## 6. Current validation status

- Source mapping for the three requested Domain files: **REVIEWED**.
- Previous code/assets/.meta files: **UNMODIFIED** in this delivery.
- New characterization tests: **AUTHORED, NOT EXECUTED IN UNITY**.
- C# compilation, EditMode/PlayMode execution, actual game session, APK and Android device build: **NOT VERIFIED**.
- Next required real-world action: run Unity's EditMode tests and capture the first compiler error, if any.
