# Sable & Sigil v5.50 — World Interaction Runtime Hardening

## Scope

Unity 2022.3.62f3 remains the source compatibility target. This change upgrades the existing playable investigation scenes and puzzle viewers; it does not replace any narrative content or evidence, alter save files, or change release-build settings.

## Changes

1. `WorldTouchChordGate` prevents a multi-finger gesture from being reinterpreted as a new one-finger evidence inspection after partial release. The gate opens only after all contacts are released. A new scene opened while a finger is held starts suspended.
2. `ChapterWorldExplorer` counts active contacts, limits pinch handling to exactly two active contacts, and cancels single-pointer gesture state during a multi-contact chord. Focus/pause transitions suspend touch processing.
3. `ChapterPuzzleDragToken` validates finite UI pointer and local-coordinate values, rejects invalid movement, and cancels transient drags on pause, focus loss, and disable, without granting persistent rewards.
4. `ChapterPuzzleRotaryDial` rejects nonfinite angles/deltas and cancels transient rotation on pause, focus loss, and disable.
5. `CinematicSceneDragSurface` prevents nonfinite screen-to-local movements from reaching camera rotation, while preserving the original local-coordinate conversion and pointer ownership checks.
6. New NUnit fixtures define EditMode contact-gate behavior and PlayMode malformed-pointer regressions. Their content hashes are registered in the existing test inventory.

## Verification boundary

- Python offline source-verification and mutation tests are executed in this environment.
- NUnit EditMode and PlayMode fixtures are authored, **not executed**.
- Unity compilation, actual Android APK/AAB build, on-device frame pacing, visual quality, and mobile touch hardware behavior are **not verified**.
- No claim is made that these changes fix every possible Unity import or console error.
- Existing Android release gate constraints remain unchanged and must be verified independently before publication.

## Priority Unity acceptance matrix

1. Editor imports the entire full-source project without Safe Mode or compiler errors.
2. EditMode: execute `WorldTouchChordGateTests`; verify NUnit XML output.
3. PlayMode: execute `WorldPuzzlePointerSafetyPlayModeTests` and existing chapter interactive-scene tests; verify NUnit XML output.
4. Chapter 1 seal drag, chapter 1 stairs, chapter 2 moon dial, chapters 3–4 viewers, scenic camera, and Android Back return to their previous scene without duplicate reward or gesture carryover.
5. Real Android device: switch foreground/background during drag and pinch; verify zero phantom taps; verify frame-rate behavior and saved progress after application restart.
6. Release prerequisites and Android target API must be checked from generated build artifacts and Unity logs, not inferred from source-only scans.
