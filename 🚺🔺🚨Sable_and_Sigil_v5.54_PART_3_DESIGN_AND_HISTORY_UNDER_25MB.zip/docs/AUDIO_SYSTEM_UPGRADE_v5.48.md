# Sable & Sigil — Audio Controls Upgrade v5.48

## Base and compatibility

- Source: `Sable_and_Sigil_v5.47_EXISTING_SYSTEM_BASELINE_UNDER_25MB.zip`.
- Target editor: Unity `2022.3.62f3`, unchanged.
- Existing namespaces, assembly definitions, Unity metadata GUIDs, gameplay interfaces, procedural synthesis, scene construction and story content remain intact.
- The existing `SableAndSigil.Settings.AudioEnabled.v1` key is retained. Existing master-mute choices are preserved.
- No `ProjectSettings`, `Packages`, `.asmdef`, scene or Android release-gate files were modified.

## Implemented features

1. Independent device-local master, effects and chapter-ambience mute flags.
2. Independent effects and ambience volume controls, persisted as integer percentages from 0 to 100.
3. Audio settings panel built into the existing gallery privacy modal, with touch-sized controls and status labels. Existing `TOGGLE SOUND` object name and its public behavior are retained.
4. Immediate settings-change notification to active sound sources, with subscription cleanup on disable/destroy.
5. Bounded chapter-ambience fades (150 ms), pause/focus suspension, and release of scene-owned procedural clips.
6. Single-voice feedback playback, reduced overlapping one-shot stacking, smooth amplitude envelope and clip cleanup.
7. Fail-safe local preference writes: input validation, save error reporting and best-effort rollback. No network, telemetry, device identifiers or new third-party dependencies.
8. Existing NUnit fixture inventory extended with four new PlayMode regression tests; legacy static contracts updated to check the new architecture without removing their adversarial mutation checks.

## User-facing audio controls

Open `PRIVACY & AUDIO` from the Chapter Gallery.

- `MUTE ALL SOUND` / `ENABLE ALL SOUND`: affects both channels.
- `MUTE EFFECTS` / `ENABLE EFFECTS`: affects the existing success, warning, discovery and hint cues.
- `MUTE AMBIENCE` / `ENABLE AMBIENCE`: affects chapter atmosphere loops.
- `EFFECTS VOLUME DOWN/UP` and `AMBIENCE VOLUME DOWN/UP`: 20-percentage-point steps from 0% to 100%.

A muted channel retains its stored volume for later restoration; master mute does not erase the channel choices. The game does not currently supply a separate music track, so the ambience channel is not mislabeled as music.

## Acceptance and verification limitations

- Python static verification and source mutation tests can be executed outside Unity and do not prove C# compilation, audible output or Android behavior.
- The new `SoundSettingsUpgradePlayModeTests.cs` tests must be executed in Unity PlayMode before labeling `TEST_VERIFIED`.
- Additional manual checks: device speaker/headphone output, silent mode, Android suspend/resume, rapidly repeated taps, screen reader and safe-area positioning, and listening quality for all four chapter soundscapes.
- The compact v5.47 source baseline omits several source-art masters. Existing art completeness checks will remain blocked until those master files are restored from the separate art backups; this does not arise from the audio changes.

## Verification categories

- Design/source contract: statically inspected; not independently compiled in Unity.
- Unity compile: NOT_EXECUTED.
- Unity EditMode: NOT_EXECUTED.
- Unity PlayMode: NOT_EXECUTED.
- Android build: NOT_EXECUTED.
- Physical-device audio test: NOT_EXECUTED.
