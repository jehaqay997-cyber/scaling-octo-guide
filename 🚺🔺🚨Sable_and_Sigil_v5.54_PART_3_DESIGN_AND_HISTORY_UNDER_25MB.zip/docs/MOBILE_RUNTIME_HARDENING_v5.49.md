# Sable & Sigil v5.49 — Mobile Session Reliability Upgrade

Compatibility target: Unity 2022.3.62f3. Source baseline: v5.48 audio-controls candidate. These changes preserve all existing public namespaces, assembly names, serializable fields, scene GUIDs, package versions, Android settings, dossier progress, chapter artwork, audio assets, and authored puzzles.

## Execution changes

1. **Refresh-aware mobile frame pacing.** The existing `FrameBudgetPolicy` retains nominal quality tiers of 60, 30, and 24 FPS. Added `EffectiveMobileFramesPerSecond` and `MobileFrameRequest` to align requested FPS with the display VBlank interval instead of relying on Unity to silently round down a non-dividing target. The governor observes the screen's actual refresh ratio and uses estimated display-paced FPS for slow-frame decisions. The 120-frame sample window is cleared on a detected refresh-rate transition.
2. **Stable mobile classification.** On a 90 Hz device, requesting 60 produces an expected 45 FPS cadence. This is not automatically classified as a performance fault after three windows. Sustained frame times above 125% of the *effective cadence* are still downgraded. The low-battery conservative tier remains unchanged, and the system does not auto-upgrade quality without evidence of headroom.
3. **Cross-scene pointer ownership.** A touch or mouse gesture is now linked to the `OrderGame` that accepted its initial press. Swapping `OrderPointerInput.Game`, disabling its owner, or losing focus cancels the original gesture rather than dispatching a release or cancellation to a different game. Gesture transfer is blocked until existing touch/mouse contacts are fully released; the release frame cannot be treated as a new press.
4. **Regression tests.** Expanded existing EditMode frame pacing tests with 60/75/90/120/144 Hz scenarios and fractional-Hz handling. Added PlayMode lifecycle tests for pointer owner swaps and disabling. Updated hash-locked NUnit fixture inventory to include both test modifications.

## Expected pacing (device-dependent, not a benchmark)

| Display | Desired quality tier | Mobile request | Estimated display-paced FPS |
| --- | ---: | ---: | ---: |
| 60 Hz | 60 | 60 | 60 |
| 60 Hz | 30 | 30 | 30 |
| 60 Hz | 24 | 20 | 20 |
| 90 Hz | 60 | 45 | 45 |
| 90 Hz | 30 | 30 | 30 |
| 90 Hz | 24 | 23 | 22.5 |
| 120 Hz | 24 | 24 | 24 |
| 144 Hz | 60 | 48 | 48 |

These are calculations based on VBlank divisibility. They are not runtime device measurements. Dynamic refresh policies, throttling, the platform compositor and power modes can alter observed FPS.

## Rollback and verification gates

- The patch is additive to the public `FrameBudgetPolicy` API and does not rename or delete any public member.
- Unity **compile, EditMode, PlayMode, APK, and physical-device** tests are not executable in the packaging environment. Do not mark them as passed.
- Open a copy in Unity 2022.3.62f3. Run `Verification/Run-UnityVerification.ps1` using Unity installation and project paths. Run both test assemblies and capture Test Runner XML. Exercise chapter-one and chapter-two scene transitions, a touch held across app pause, returning from background, a scene transition mid-gesture, sound mute, and checkpoint restore. On physical Android devices, verify 60 Hz and 90/120 Hz behavior with `Profiler` and Android frame pacing metrics.
- The full-source package restores the 15 original authoring images from the preserved v5.43 art backup, and both former compact-art test failures pass when those exact files are present. The optional compact package intentionally excludes those 15 authoring originals and therefore retains the two known source-art test failures. All Unity runtime Resources art remains in both packages.
- Do not promote v5.49 into a Play Store Release until a separately supported/security-reviewed Android build configuration passes release validation. ProjectSettings and Packages are deliberately unchanged.

## Primary Unity 2022.3 references

- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Application-targetFrameRate.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Resolution-refreshRateRatio.html
- https://docs.unity3d.com/2022.3/Documentation/ScriptReference/RefreshRate-value.html
