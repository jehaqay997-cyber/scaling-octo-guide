#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace TheOrderRoom.Editor
{
    /// <summary>Builds a test APK only after the separate verification pipeline has passed.</summary>
    public static class OrderAndroidBuildBatch
    {
        private const string OutputVariable = "TOR_ANDROID_APK_PATH";
        private const string SuccessMarker = "THEORDERROOM_ANDROID_APK_BUILT";

        public static void BuildVerifiedApk()
        {
            var output = Environment.GetEnvironmentVariable(OutputVariable);
            if (string.IsNullOrWhiteSpace(output))
                throw new BuildFailedException(OutputVariable + " must be provided by the verified build runner.");

            var outputPath = Path.GetFullPath(output);
            if (!string.Equals(Path.GetExtension(outputPath), ".apk", StringComparison.OrdinalIgnoreCase))
                throw new BuildFailedException("The output must have an .apk extension.");
            var projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            var normalizedProject = projectRoot.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                + Path.DirectorySeparatorChar;
            if (outputPath.StartsWith(normalizedProject, StringComparison.OrdinalIgnoreCase))
                throw new BuildFailedException("Android build output must be outside the Unity project.");
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
                throw new BuildFailedException("Android Build Support is not installed for this Unity Editor.");
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
                throw new BuildFailedException("Start the editor with -buildTarget Android.");

            var problems = OrderSceneValidator.ValidateProject();
            ChapterOneSceneBuilder.EnsureChapterOne(false);
            var requiredScene = ChapterOneSceneBuilder.ScenePath;
            var enabledScenes = EditorBuildSettings.scenes.Where(scene => scene.enabled).ToArray();
            if (enabledScenes.Length < 1 || enabledScenes[0].path != requiredScene)
                problems.Add("Chapter One must be the first enabled scene for the test APK.");
            if (problems.Count != 0)
                throw new BuildFailedException("Android build validation failed:\n" + string.Join("\n", problems));
            if (File.Exists(outputPath))
                throw new BuildFailedException("Refusing to overwrite an existing APK: " + outputPath);

            var folder = Path.GetDirectoryName(outputPath);
            if (string.IsNullOrEmpty(folder))
                throw new BuildFailedException("Invalid output folder.");
            Directory.CreateDirectory(folder);
            var options = new BuildPlayerOptions
            {
                scenes = new[] { requiredScene },
                locationPathName = outputPath,
                target = BuildTarget.Android,
                options = BuildOptions.Development | BuildOptions.DetailedBuildReport
            };
            var report = BuildPipeline.BuildPlayer(options);
            if (report == null || report.summary.result != BuildResult.Succeeded ||
                report.summary.totalErrors != 0 || !File.Exists(outputPath) ||
                new FileInfo(outputPath).Length <= 0)
                throw new BuildFailedException("Android BuildPipeline did not produce a successful nonempty APK.");
            Debug.Log(SuccessMarker + " " + outputPath);
        }
    }
}
#endif
