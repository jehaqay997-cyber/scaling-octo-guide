#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using TheOrderRoom.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TheOrderRoom.Editor
{
    /// <summary>
    /// Non-destructive first-chapter scene creation. Keeps the legacy board scene
    /// available while prioritizing the playable narrative chapter for builds.
    /// </summary>
    public static class ChapterOneSceneBuilder
    {
        public const string ScenePath = "Assets/_Project/Scenes/ChapterOne.unity";

        [MenuItem("Sable & Sigil/Create or Open Chapter One")]
        public static void OpenChapterOne()
        {
            if (Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) return;
            EnsureChapterOne(true);
        }

        [MenuItem("Sable & Sigil/Play Chapter One")]
        public static void PlayChapterOne()
        {
            if (Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) return;
            EnsureChapterOne(true);
            if (SceneManager.GetActiveScene().path != ScenePath)
                throw new InvalidOperationException("Chapter One must be the active scene before Play Mode.");
            EditorApplication.ExecuteMenuItem("Window/General/Game");
            EditorApplication.isPlaying = true;
        }

        public static void EnsureChapterOne(bool openScene)
        {
            if (!File.Exists(ScenePath)) CreateScene();
            var asset = AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath);
            if (asset == null)
                throw new InvalidOperationException("The Chapter One scene asset cannot be imported.");

            var scenes = EditorBuildSettings.scenes;
            var others = scenes.Where(s => s.path != ScenePath).ToArray();
            EditorBuildSettings.scenes = (new[] { new EditorBuildSettingsScene(ScenePath, true) })
                .Concat(others).ToArray();
            if (openScene && SceneManager.GetActiveScene().path != ScenePath)
            {
                if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
                EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            }
        }

        private static void CreateScene()
        {
            const string parent = "Assets/_Project";
            if (!AssetDatabase.IsValidFolder(parent + "/Scenes"))
                AssetDatabase.CreateFolder(parent, "Scenes");
            var old = SceneManager.GetActiveScene();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            try
            {
                if (!SceneManager.SetActiveScene(scene))
                    throw new InvalidOperationException("Cannot activate a new chapter scene.");
                var root = new GameObject("Sable & Sigil - Chapter One");
                root.AddComponent<ChapterOneExperience>();
                if (!EditorSceneManager.SaveScene(scene, ScenePath))
                    throw new IOException("Chapter One scene could not be saved.");
                AssetDatabase.SaveAssets();
            }
            finally
            {
                if (old.IsValid() && old.isLoaded) SceneManager.SetActiveScene(old);
                if (scene.IsValid() && scene.isLoaded) EditorSceneManager.CloseScene(scene, true);
            }
        }
    }
}
#endif
