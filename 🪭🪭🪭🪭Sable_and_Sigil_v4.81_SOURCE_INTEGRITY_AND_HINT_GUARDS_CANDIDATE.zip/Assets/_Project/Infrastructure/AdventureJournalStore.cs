using System;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using TheOrderRoom.AppCore;
using TheOrderRoom.Domain;

namespace TheOrderRoom.Infrastructure
{
    /// <summary>
    /// Immutable revision journal. Every accepted commit creates exactly one revision file.
    /// Cross-process exclusion is provided by the exclusive lock file. If the result of a
    /// write cannot be established, callers must reconcile by reading the authoritative journal.
    /// Journal hashes detect accidental damage; they are not cryptographic authentication.
    /// </summary>
    public sealed class AdventureJournalStore : IAdventureStore, IAdventureSnapshotReader
    {
        private const int Magic = 0x544F5241;
        private const int RecordLength = 4 + 4 + 8 + 4 + 4 + 32;
        private const int MaxEntries = 10000;
        private readonly string directory;
        private readonly string lockPath;
        private readonly string prefix;

        public AdventureJournalStore(string directory, string filePrefix = "adventure")
        {
            if (string.IsNullOrWhiteSpace(directory)) throw new ArgumentException("A storage directory is required.", nameof(directory));
            if (string.IsNullOrWhiteSpace(filePrefix) || filePrefix.Length > 48)
                throw new ArgumentException("Invalid journal prefix.", nameof(filePrefix));
            foreach (char c in filePrefix)
                if (!(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z') &&
                    !(c >= '0' && c <= '9') && c != '-' && c != '_')
                    throw new ArgumentException("Invalid journal prefix.", nameof(filePrefix));
            this.directory = Path.GetFullPath(directory);
            prefix = filePrefix;
            lockPath = Path.Combine(this.directory, prefix + ".lock");
        }

        /// <summary>Creates genesis only for a fresh journal. Never overwrites existing data.</summary>
        public bool TryInitialize(out AdventureSnapshot snapshot)
        {
            snapshot = null;
            try
            {
                Directory.CreateDirectory(directory);
                using (AcquireLock())
                {
                    if (!TryReadLocked(out snapshot, out bool exists)) return false;
                    if (exists) return true;
                    var genesis = AdventureChapter.NewGame();
                    WriteNewRecord(genesis);
                    return TryReadLocked(out snapshot, out exists) && exists;
                }
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        public bool TryRead(out AdventureSnapshot snapshot)
        {
            snapshot = null;
            try
            {
                using (AcquireLock())
                {
                    return TryReadLocked(out snapshot, out bool exists) && exists;
                }
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
        }

        public AdventureCommitResult Commit(long expectedRevision, AdventureSnapshot candidate)
        {
            if (candidate == null || expectedRevision < 0 || expectedRevision == long.MaxValue ||
                candidate.Revision != expectedRevision + 1)
                return AdventureCommitResult.Rejected;
            try
            {
                using (AcquireLock())
                {
                    if (!TryReadLocked(out AdventureSnapshot authoritative, out bool exists) || !exists)
                        return AdventureCommitResult.Rejected;
                    if (authoritative.Revision != expectedRevision)
                        return AdventureCommitResult.Rejected;
                    if (!IsLegalTransition(authoritative, candidate))
                        return AdventureCommitResult.Rejected;
                    WriteNewRecord(candidate);
                    return AdventureCommitResult.Committed;
                }
            }
            catch (IOException) { return AdventureCommitResult.Unknown; }
            catch (UnauthorizedAccessException) { return AdventureCommitResult.Unknown; }
        }

        private static bool IsLegalTransition(AdventureSnapshot source, AdventureSnapshot candidate)
        {
            if (source.Schema != candidate.Schema) return false;
            foreach (AdventureAction action in Enum.GetValues(typeof(AdventureAction)))
            {
                if (AdventureChapter.TryAct(source, action, source.Revision, out AdventureSnapshot next, out _) &&
                    SameState(next, candidate)) return true;
            }
            foreach (AdventureLocation location in Enum.GetValues(typeof(AdventureLocation)))
            {
                if (AdventureChapter.TryTravel(source, location, source.Revision, out AdventureSnapshot next, out _) &&
                    SameState(next, candidate)) return true;
            }
            return false;
        }

        private static bool SameState(AdventureSnapshot left, AdventureSnapshot right) =>
            left.Schema == right.Schema && left.Revision == right.Revision &&
            left.Location == right.Location && left.Facts == right.Facts;

        private FileStream AcquireLock()
        {
            // The directory is created only by TryInitialize, never by reads/commits.
            return new FileStream(lockPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        }

        private string RecordPath(long revision) => Path.Combine(directory,
            prefix + ".r" + revision.ToString("D20", CultureInfo.InvariantCulture) + ".bin");

        private bool TryReadLocked(out AdventureSnapshot snapshot, out bool exists)
        {
            snapshot = null;
            exists = false;
            if (!Directory.Exists(directory)) return true;
            // Bound enumeration before allocating an attacker-controlled directory listing.
            var entries = new System.Collections.Generic.List<string>();
            foreach (string entry in Directory.EnumerateFiles(directory, prefix + ".r*.bin", SearchOption.TopDirectoryOnly))
            {
                if (entries.Count == MaxEntries) return false;
                entries.Add(entry);
            }
            long maximum = -1;
            string path = null;
            foreach (string entry in entries)
            {
                string name = Path.GetFileName(entry);
                string begin = prefix + ".r";
                if (!name.StartsWith(begin, StringComparison.Ordinal) || !name.EndsWith(".bin", StringComparison.Ordinal)) return false;
                string number = name.Substring(begin.Length, name.Length - begin.Length - 4);
                if (number.Length != 20 || !long.TryParse(number, NumberStyles.None, CultureInfo.InvariantCulture, out long revision) ||
                    revision < 0 || !string.Equals(entry, RecordPath(revision), StringComparison.Ordinal)) return false;
                if (revision > maximum) { maximum = revision; path = entry; }
            }
            if (path == null) return true;
            exists = true;
            // Every accepted revision is represented by an immutable record. Gaps fail closed.
            if (maximum != entries.Length - 1) return false;
            for (long revision = 0; revision <= maximum; revision++)
                if (!File.Exists(RecordPath(revision))) return false;
            // Validate every recorded step, not just file names and the latest digest.
            // This detects a corrupted historical record and an invalid transition chain.
            AdventureSnapshot previous = null;
            for (long revision = 0; revision <= maximum; revision++)
            {
                if (!TryReadRecord(RecordPath(revision), revision, out AdventureSnapshot current))
                    return false;
                if (revision == 0)
                {
                    if (!SameState(current, AdventureChapter.NewGame())) return false;
                }
                else if (!IsLegalTransition(previous, current))
                    return false;
                previous = current;
            }
            snapshot = previous;
            return true;
        }

        private static bool TryReadRecord(string path, long expectedRevision, out AdventureSnapshot snapshot)
        {
            snapshot = null;
            // One handle, a fixed buffer, and an exact-length read avoid the
            // length-check/read race and prevent unbounded allocations.
            var data = new byte[RecordLength];
            using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                if (stream.Length != RecordLength) return false;
                int offset = 0;
                while (offset < data.Length)
                {
                    int read = stream.Read(data, offset, data.Length - offset);
                    if (read == 0) return false;
                    offset += read;
                }
                if (stream.ReadByte() != -1) return false;
            }
            using (var sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(data, 0, RecordLength - 32);
                int mismatch = 0;
                for (int i = 0; i < hash.Length; i++)
                    mismatch |= hash[i] ^ data[RecordLength - 32 + i];
                if (mismatch != 0) return false;
            }
            using (var memory = new MemoryStream(data, 0, RecordLength - 32, false))
            using (var reader = new BinaryReader(memory))
            {
                if (reader.ReadInt32() != Magic) return false;
                int schema = reader.ReadInt32();
                long storedRevision = reader.ReadInt64();
                int location = reader.ReadInt32();
                int facts = reader.ReadInt32();
                if (storedRevision != expectedRevision) return false;
                try
                {
                    snapshot = new AdventureSnapshot(schema, storedRevision,
                        (AdventureLocation)location, (AdventureFacts)facts);
                }
                catch (ArgumentException) { return false; }
                return true;
            }
        }

        private void WriteNewRecord(AdventureSnapshot snapshot)
        {
            string path = RecordPath(snapshot.Revision);
            byte[] payload;
            using (var memory = new MemoryStream())
            {
                using (var writer = new BinaryWriter(memory, System.Text.Encoding.UTF8, true))
                {
                    writer.Write(Magic);
                    writer.Write(snapshot.Schema);
                    writer.Write(snapshot.Revision);
                    writer.Write((int)snapshot.Location);
                    writer.Write((int)snapshot.Facts);
                }
                payload = memory.ToArray();
            }
            string temporary = Path.Combine(directory, prefix + ".pending-" + Guid.NewGuid().ToString("N") + ".tmp");
            try
            {
                using (var sha = SHA256.Create())
                {
                    byte[] hash = sha.ComputeHash(payload);
                    using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    {
                        stream.Write(payload, 0, payload.Length);
                        stream.Write(hash, 0, hash.Length);
                        stream.Flush(true);
                    }
                }
                // Same-directory rename publishes a complete record, never a partial one.
                // On power loss a .tmp may remain and must not be treated as committed state.
                File.Move(temporary, path);
            }
            finally
            {
                // Failed incomplete records are never considered authoritative.
                // Cleanup errors must not mask an unknown commit outcome.
                try { if (File.Exists(temporary)) File.Delete(temporary); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
    }
}
