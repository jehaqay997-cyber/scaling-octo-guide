using System.Collections;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterArtGalleryTests
    {
        [Test]
        public void ChapterCatalogHasCompleteOrderedUniqueLocationMappings()
        {
            Assert.That(ChapterGalleryView.ValidateContentCatalog(out string error), Is.True, error);
            Assert.That(ChapterGalleryView.ChapterCount, Is.EqualTo(4));
            Assert.That(ChapterGalleryView.LocationCount, Is.EqualTo(10));
        }

        [UnityTest]
        public IEnumerator ChapterArtworkLoadsOnDemandAndReleasesWhenClosed()
        {
            var operation = SceneManager.LoadSceneAsync("Assets/_Project/Scenes/ChapterOne.unity", LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null);
            while (!operation.isDone) yield return null;
            yield return null;
            var experience = Object.FindObjectOfType<ChapterOneExperience>();
            Assert.That(experience, Is.Not.Null);
            Assert.That(experience.IsChapterReady, Is.True);
            var gallery = experience.GetComponent<ChapterGalleryView>();
            if (gallery == null) gallery = experience.gameObject.AddComponent<ChapterGalleryView>();
            gallery.Show();
            var image = System.Array.Find(gallery.GetComponentsInChildren<RawImage>(true),
                candidate => candidate.name == "Selected Chapter Artwork");
            Assert.That(image, Is.Not.Null);
            Assert.That(image.texture, Is.Not.Null);
            Texture first = image.texture;
            Assert.That(gallery.ResidentChapterArtworkCount, Is.EqualTo(1));
            gallery.SelectChapter(2);
            Assert.That(image.texture, Is.Not.Null);
            Assert.That(image.texture, Is.Not.SameAs(first));
            Assert.That(gallery.ResidentChapterArtworkCount, Is.EqualTo(1));
            Assert.That(image.texture.width, Is.EqualTo(1280));
            Assert.That(image.texture.height, Is.EqualTo(720));
            gallery.Close();
            Assert.That(image.texture, Is.Null,
                "Closing a gallery must detach its chapter texture before unloading.");
            Assert.That(gallery.ResidentChapterArtworkCount, Is.Zero);
            gallery.Show();
            Assert.That(image.texture, Is.Not.Null,
                "The first chapter image must be reloadable after close.");
            gallery.Close();
        }

        [UnityTest]
        public IEnumerator GallerySafeAreaAndModalShieldPreserveScreenBounds()
        {
            var operation = SceneManager.LoadSceneAsync("Assets/_Project/Scenes/ChapterOne.unity", LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null);
            while (!operation.isDone) yield return null;
            yield return null;
            var experience = Object.FindObjectOfType<ChapterOneExperience>();
            Assert.That(experience, Is.Not.Null);
            Assert.That(experience.IsChapterReady, Is.True);
            var gallery = experience.GetComponent<ChapterGalleryView>();
            if (gallery == null) gallery = experience.gameObject.AddComponent<ChapterGalleryView>();
            gallery.Show();
            yield return null;
            var shield = System.Array.Find(gallery.GetComponentsInChildren<Image>(true),
                image => image.name == "Gallery Input Shield");
            Assert.That(shield, Is.Not.Null);
            Assert.That(shield.raycastTarget, Is.True);
            var shieldRect = shield.GetComponent<RectTransform>();
            Assert.That(shieldRect.anchorMin, Is.EqualTo(Vector2.zero));
            Assert.That(shieldRect.anchorMax, Is.EqualTo(Vector2.one));
            var safeRoot = System.Array.Find(gallery.GetComponentsInChildren<RectTransform>(true),
                rect => rect.name == "Gallery Safe Area");
            var layoutRoot = System.Array.Find(gallery.GetComponentsInChildren<RectTransform>(true),
                rect => rect.name == "Gallery Layout");
            Assert.That(safeRoot, Is.Not.Null);
            Assert.That(layoutRoot, Is.Not.Null);
            Assert.That(layoutRoot.localScale.x, Is.EqualTo(layoutRoot.localScale.y).Within(.0001f));
            Assert.That(layoutRoot.localScale.x, Is.EqualTo(layoutRoot.localScale.z).Within(.0001f));
            Assert.That(layoutRoot.localScale.x, Is.GreaterThan(0f).And.LessThanOrEqualTo(1f));
            Rect safe = Screen.safeArea;
            Assert.That(safeRoot.anchorMin.x, Is.EqualTo(safe.xMin / Screen.width).Within(.0001f));
            Assert.That(safeRoot.anchorMax.x, Is.EqualTo(safe.xMax / Screen.width).Within(.0001f));
            Assert.That(safeRoot.anchorMin.y, Is.EqualTo(safe.yMin / Screen.height).Within(.0001f));
            Assert.That(safeRoot.anchorMax.y, Is.EqualTo(safe.yMax / Screen.height).Within(.0001f));
            gallery.Close();
        }

        [UnityTest]
        public IEnumerator OpaqueGallerySuspendsWorldCameraAndRestoresItOnClose()
        {
            var operation = SceneManager.LoadSceneAsync("Assets/_Project/Scenes/ChapterOne.unity", LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null);
            while (!operation.isDone) yield return null;
            yield return null;
            var experience = Object.FindObjectOfType<ChapterOneExperience>();
            Assert.That(experience, Is.Not.Null);
            Assert.That(experience.IsChapterReady, Is.True);
            var worldCamera = Camera.main;
            Assert.That(worldCamera, Is.Not.Null);
            Assert.That(worldCamera.enabled, Is.True);
            var gallery = experience.GetComponent<ChapterGalleryView>();
            if (gallery == null) gallery = experience.gameObject.AddComponent<ChapterGalleryView>();
            gallery.Show();
            Assert.That(gallery.IsOpen, Is.True);
            Assert.That(worldCamera.enabled, Is.False,
                "The opaque gallery must not render the hidden 3D world each frame.");
            gallery.SelectLocation(2);
            Assert.That(worldCamera.enabled, Is.False);
            gallery.Close();
            Assert.That(gallery.IsOpen, Is.False);
            Assert.That(worldCamera.enabled, Is.True,
                "Closing the gallery must restore the exact camera it suspended.");
        }

        [Test]
        public void LocationChapterMappingRejectsInvalidInputs()
        {
            Assert.That(ChapterGalleryView.GetChapterForLocation(1), Is.EqualTo(1));
            Assert.That(ChapterGalleryView.GetChapterForLocation(4), Is.EqualTo(2));
            Assert.That(ChapterGalleryView.GetChapterForLocation(7), Is.EqualTo(3));
            Assert.That(ChapterGalleryView.GetChapterForLocation(10), Is.EqualTo(4));
            Assert.Throws<System.ArgumentOutOfRangeException>(() => ChapterGalleryView.GetChapterForLocation(0));
            Assert.Throws<System.ArgumentOutOfRangeException>(() => ChapterGalleryView.GetChapterForLocation(11));
        }

        [UnityTest]
        public IEnumerator ChapterAndLocationImagesNeverStayResidentTogether()
        {
            var operation = SceneManager.LoadSceneAsync("Assets/_Project/Scenes/ChapterOne.unity", LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null);
            while (!operation.isDone) yield return null;
            yield return null;
            var experience = Object.FindObjectOfType<ChapterOneExperience>();
            Assert.That(experience, Is.Not.Null);
            Assert.That(experience.IsChapterReady, Is.True);
            var gallery = experience.GetComponent<ChapterGalleryView>();
            if (gallery == null) gallery = experience.gameObject.AddComponent<ChapterGalleryView>();
            gallery.Show();
            Assert.That(gallery.ResidentChapterArtworkCount, Is.EqualTo(1));
            gallery.SelectLocation(7);
            Assert.That(gallery.SelectedChapter, Is.EqualTo(3));
            Assert.That(gallery.ResidentChapterArtworkCount, Is.Zero,
                "The location atlas must release the previously shown chapter artwork.");
            var art = System.Array.Find(gallery.GetComponentsInChildren<RawImage>(true),
                entry => entry.name == "Selected Chapter Artwork");
            Assert.That(art, Is.Not.Null);
            Assert.That(art.texture, Is.Not.Null);
            Assert.That(art.texture.width, Is.EqualTo(1280));
            gallery.SelectChapter(gallery.SelectedChapter);
            Assert.That(gallery.ResidentChapterArtworkCount, Is.EqualTo(1));
            Assert.That(art.texture, Is.Not.Null);
            Assert.That(art.texture.height, Is.EqualTo(720));
            gallery.Close();
            Assert.That(gallery.ResidentChapterArtworkCount, Is.Zero);
            Assert.That(art.texture, Is.Null);
        }

        [UnityTest]
        public IEnumerator ImageAspectAndNavigationStayConsistent()
        {
            var operation = SceneManager.LoadSceneAsync("Assets/_Project/Scenes/ChapterOne.unity", LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null);
            while (!operation.isDone) yield return null;
            yield return null;
            var experience = Object.FindObjectOfType<ChapterOneExperience>();
            Assert.That(experience, Is.Not.Null);
            Assert.That(experience.IsChapterReady, Is.True);
            var gallery = experience.GetComponent<ChapterGalleryView>();
            if (gallery == null) gallery = experience.gameObject.AddComponent<ChapterGalleryView>();
            gallery.Show();
            for (int chapter = 1; chapter <= ChapterGalleryView.ChapterCount; chapter++)
            {
                gallery.SelectChapter(chapter);
                var image = System.Array.Find(gallery.GetComponentsInChildren<RawImage>(true),
                    entry => entry.name == "Selected Chapter Artwork");
                Assert.That(image, Is.Not.Null);
                var rect = image.GetComponent<RectTransform>();
                Assert.That(rect.rect.width / rect.rect.height,
                    Is.EqualTo((float)image.texture.width / image.texture.height).Within(.0001f));
            }
            gallery.SelectLocation(1);
            var previous = System.Array.Find(gallery.GetComponentsInChildren<Button>(true),
                item => item.name == "PREVIOUS SCENE");
            Assert.That(previous.gameObject.activeSelf, Is.True);
            gallery.SelectChapter(1);
            Assert.That(previous.gameObject.activeSelf, Is.False);
            gallery.Close();
        }

        [UnityTest]
        public IEnumerator LocationAtlasHasTenImagesAndNoFalsePlayability()
        {
            var operation = SceneManager.LoadSceneAsync("Assets/_Project/Scenes/ChapterOne.unity", LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null);
            while (!operation.isDone) yield return null;
            yield return null;
            var experience = Object.FindObjectOfType<ChapterOneExperience>();
            Assert.That(experience, Is.Not.Null);
            Assert.That(experience.IsChapterReady, Is.True);
            var gallery = experience.GetComponent<ChapterGalleryView>();
            if (gallery == null) gallery = experience.gameObject.AddComponent<ChapterGalleryView>();
            Assert.That(ChapterGalleryView.LocationCount, Is.EqualTo(10));
            gallery.Show();
            var sceneNavigation = System.Array.Find(gallery.GetComponentsInChildren<Button>(true),
                item => item.name == "PREVIOUS SCENE");
            Assert.That(sceneNavigation, Is.Not.Null);
            Assert.That(sceneNavigation.gameObject.activeSelf, Is.False,
                "Scene navigation cannot appear while browsing chapters.");
            for (int i = 1; i <= ChapterGalleryView.LocationCount; i++)
            {
                var image = Resources.Load<Texture2D>("LocationArt/Scene_" + i.ToString("00"));
                Assert.That(image, Is.Not.Null, "Missing user reference image " + i);
                Assert.That(image.width, Is.EqualTo(1280));
                Assert.That(image.height, Is.EqualTo(720));
                gallery.SelectLocation(i);
                Assert.That(sceneNavigation.gameObject.activeSelf, Is.True,
                    "Scene navigation must be available in the location atlas.");
                var buttons = gallery.GetComponentsInChildren<Button>(true);
                var enter = System.Array.Find(buttons, b => b.name == "ENTER CHAPTER I");
                Assert.That(enter, Is.Not.Null);
                Assert.That(enter.interactable, Is.False, "Reference imagery must never unlock an unfinished location.");
                var art = System.Array.Find(gallery.GetComponentsInChildren<RawImage>(true),
                    item => item.name == "Selected Chapter Artwork");
                Assert.That(art, Is.Not.Null);
                Assert.That(art.texture, Is.SameAs(image));
                var rect = art.GetComponent<RectTransform>();
                Assert.That(rect.sizeDelta.x / rect.sizeDelta.y,
                    Is.EqualTo((float) image.width / image.height).Within(0.0001f),
                    "Image aspect ratio must be preserved.");
            }
            gallery.SelectChapter(1);
            Assert.That(sceneNavigation.gameObject.activeSelf, Is.False,
                "Leaving the location atlas must hide location-only controls.");
            gallery.Close();
        }

        [UnityTest]
        public IEnumerator AllFourChaptersHaveArtButOnlyChapterOneIsPlayable()
        {
            var operation = SceneManager.LoadSceneAsync("Assets/_Project/Scenes/ChapterOne.unity", LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null);
            while (!operation.isDone) yield return null;
            yield return null;
            var experience = Object.FindObjectOfType<ChapterOneExperience>();
            Assert.That(experience, Is.Not.Null);
            Assert.That(experience.IsChapterReady, Is.True);
            var chaptersButton = GameObject.Find("CHAPTERS");
            Assert.That(chaptersButton, Is.Not.Null);
            Assert.That(chaptersButton.GetComponent<Button>(), Is.Not.Null);
            var gallery = experience.GetComponent<ChapterGalleryView>();
            if (gallery == null) gallery = experience.gameObject.AddComponent<ChapterGalleryView>();
            Assert.That(ChapterGalleryView.ChapterCount, Is.EqualTo(4));
            gallery.Show();
            Assert.That(gallery.IsOpen, Is.True);
            for (int i = 1; i <= 4; i++)
            {
                var texture = Resources.Load<Texture2D>("ChapterArt/Chapter_" + i.ToString("00"));
                Assert.That(texture, Is.Not.Null, "Missing chapter art " + i);
                Assert.That(texture.width, Is.EqualTo(1280));
                Assert.That(texture.height, Is.EqualTo(720));
                gallery.SelectChapter(i);
                Assert.That(gallery.SelectedChapter, Is.EqualTo(i));
                var allButtons = gallery.GetComponentsInChildren<Button>(true);
                var enter = System.Array.Find(allButtons, b => b.name == "ENTER CHAPTER I");
                Assert.That(enter, Is.Not.Null);
                Assert.That(enter.interactable, Is.EqualTo(i == 1), "Future chapters cannot be playable yet.");
            }
            gallery.Close();
            Assert.That(gallery.IsOpen, Is.False);
        }
    }
}
