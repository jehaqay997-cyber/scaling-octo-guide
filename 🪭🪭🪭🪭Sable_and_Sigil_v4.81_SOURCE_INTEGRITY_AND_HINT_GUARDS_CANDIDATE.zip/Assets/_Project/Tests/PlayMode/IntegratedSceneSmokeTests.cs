using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class IntegratedSceneSmokeTests
    {
        private const string ScenePath = "Assets/_Project/Scenes/Main.unity";

        [UnityTest]
        public IEnumerator MainScene_InitializesInteractionServicesAndButtons()
        {
            var operation = SceneManager.LoadSceneAsync(ScenePath, LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null, "The generated Main scene must exist before PlayMode tests.");
            while (!operation.isDone)
                yield return null;
            yield return null;

            var scene = SceneManager.GetActiveScene();
            Assert.That(scene.path, Is.EqualTo(ScenePath));
            Assert.That(scene.isLoaded, Is.True);

            var roots = scene.GetRootGameObjects();
            var games = roots.SelectMany(root => root.GetComponentsInChildren<OrderGame>(true)).ToArray();
            Assert.That(games.Length, Is.EqualTo(1));
            Assert.That(games[0].isActiveAndEnabled, Is.True,
                "Game initialization must complete without blocking gameplay.");
            var renderedPieces = roots.SelectMany(root => root.GetComponentsInChildren<OrderClick>(true))
                .Where(piece => piece.isActiveAndEnabled && piece.GetComponent<Renderer>() != null)
                .ToArray();
            Assert.That(renderedPieces.Length, Is.GreaterThan(0),
                "The opened scene must contain visible, interactive puzzle pieces.");
            var statusTexts = roots.SelectMany(root => root.GetComponentsInChildren<Text>(true))
                .Where(text => text.name == "Status" && text.isActiveAndEnabled).ToArray();
            Assert.That(statusTexts.Length, Is.EqualTo(1));
            Assert.That(statusTexts[0].text, Is.Not.Empty,
                "The initial scene must tell the player what to do.");
            Assert.That(statusTexts[0].text, Does.Not.Contain("Session blocked"),
                "The initial scene must not open with an unusable save session.");

            var pointers = roots.SelectMany(root => root.GetComponentsInChildren<OrderPointerInput>(true)).ToArray();
            Assert.That(pointers.Length, Is.EqualTo(1));
            Assert.That(pointers[0].isActiveAndEnabled, Is.True);
            Assert.That(pointers[0].Game, Is.SameAs(games[0]));

            var eventSystems = roots.SelectMany(root => root.GetComponentsInChildren<EventSystem>(true)).ToArray();
            Assert.That(eventSystems.Length, Is.EqualTo(1));
            Assert.That(eventSystems[0].isActiveAndEnabled, Is.True);
            Assert.That(eventSystems[0].GetComponents<BaseInputModule>().Count(module => module.isActiveAndEnabled),
                Is.EqualTo(1), "UI needs exactly one active input module.");

            var cameras = roots.SelectMany(root => root.GetComponentsInChildren<Camera>(true))
                .Where(camera => camera.isActiveAndEnabled && camera.CompareTag("MainCamera")).ToArray();
            Assert.That(cameras.Length, Is.EqualTo(1));
            Assert.That(cameras[0].GetComponent<AudioListener>(), Is.Not.Null);

            var canvases = roots.SelectMany(root => root.GetComponentsInChildren<Canvas>(true))
                .Where(canvas => canvas.isActiveAndEnabled).ToArray();
            Assert.That(canvases.Length, Is.GreaterThanOrEqualTo(1));
            Assert.That(canvases.Any(canvas => canvas.GetComponent<GraphicRaycaster>() != null &&
                canvas.GetComponent<GraphicRaycaster>().isActiveAndEnabled), Is.True);

            var requiredNames = new[]
            {
                "RESET", "UNDO", "REDO", "NEXT", "RULES", "HINT", "FOCUS +",
                "FOCUS -", "INSPECT", "TURN LEFT", "TURN RIGHT", "SCAN", "CLAIM"
            };
            var buttons = roots.SelectMany(root => root.GetComponentsInChildren<Button>(true)).ToArray();
            Assert.That(buttons.Length, Is.EqualTo(requiredNames.Length));
            foreach (var name in requiredNames)
            {
                var matches = buttons.Where(button => button.name == name).ToArray();
                Assert.That(matches.Length, Is.EqualTo(1), "Missing or duplicate button: " + name);
                Assert.That(matches[0].isActiveAndEnabled && matches[0].interactable, Is.True,
                    "Button is not interactable: " + name);
                Assert.That(matches[0].targetGraphic, Is.Not.Null);
                Assert.That(matches[0].targetGraphic.raycastTarget, Is.True);
            }

            var decorationImages = roots.SelectMany(root => root.GetComponentsInChildren<Image>(true)).ToArray();
            foreach (var name in new[] { "Upper Archive Header", "Lower Control Deck" })
            {
                var matches = decorationImages.Where(image => image.name == name).ToArray();
                Assert.That(matches.Length, Is.EqualTo(1), "Missing decorative UI surface: " + name);
                Assert.That(matches[0].isActiveAndEnabled, Is.True);
                Assert.That(matches[0].raycastTarget, Is.False,
                    "Non-interactive UI must never consume pointer events: " + name);
            }
            var visualRails = roots.SelectMany(root => root.GetComponentsInChildren<MeshRenderer>(true)).ToArray();
            foreach (var name in new[] { "North Inlay", "South Inlay", "East Inlay", "West Inlay" })
            {
                var matches = visualRails.Where(renderer => renderer.name == name).ToArray();
                Assert.That(matches.Length, Is.EqualTo(1), "Missing board detail: " + name);
                Assert.That(matches[0].GetComponent<Collider>(), Is.Null,
                    "Decorative geometry must never block drag-and-drop raycasts: " + name);
            }

            Assert.That(roots.SelectMany(root => root.GetComponentsInChildren<OrderPerformanceGovernor>(true))
                .Count(governor => governor.isActiveAndEnabled), Is.EqualTo(1));
            Assert.That(roots.SelectMany(root => root.GetComponentsInChildren<OrderScreenLayout>(true))
                .Count(layout => layout.isActiveAndEnabled), Is.EqualTo(1));
        }
    }
}
