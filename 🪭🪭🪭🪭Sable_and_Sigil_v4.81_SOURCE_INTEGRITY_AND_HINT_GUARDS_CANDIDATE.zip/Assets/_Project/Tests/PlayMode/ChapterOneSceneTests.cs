using System.Collections;
using System.Linq;
using NUnit.Framework;
using TheOrderRoom.Runtime;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace TheOrderRoom.Tests.PlayMode
{
    public sealed class ChapterOneSceneTests
    {
        private const string ChapterScene = "Assets/_Project/Scenes/ChapterOne.unity";

        private static long ReadCheckpointRevision(ChapterOneExperience chapter)
        {
            var field = typeof(ChapterOneExperience).GetField("checkpointRevision",
                System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            Assert.That(field, Is.Not.Null);
            return (long)field.GetValue(chapter);
        }

        [UnityTest]
        public IEnumerator HotspotInteractionsPersistOnlyDurablePuzzleChanges()
        {
            const string slotA = "SableAndSigil.ChapterOne.v1.CheckpointA";
            const string slotB = "SableAndSigil.ChapterOne.v1.CheckpointB";
            bool hadA = PlayerPrefs.HasKey(slotA);
            bool hadB = PlayerPrefs.HasKey(slotB);
            string oldA = PlayerPrefs.GetString(slotA, "");
            string oldB = PlayerPrefs.GetString(slotB, "");
            try
            {
                var operation = SceneManager.LoadSceneAsync(ChapterScene, LoadSceneMode.Single);
                Assert.That(operation, Is.Not.Null);
                while (!operation.isDone) yield return null;
                yield return null;
                var chapter = Object.FindObjectOfType<ChapterOneExperience>();
                Assert.That(chapter, Is.Not.Null);
                Assert.That(chapter.IsChapterReady, Is.True);
                chapter.Progress.Restart();
                long initialRevision = ReadCheckpointRevision(chapter);
                chapter.Interact("desk");
                Assert.That(ReadCheckpointRevision(chapter), Is.EqualTo(initialRevision),
                    "A locked desk must not create an unchanged checkpoint.");
                chapter.Interact("shelf");
                Assert.That(chapter.Progress.HasKey, Is.True);
                Assert.That(ReadCheckpointRevision(chapter), Is.EqualTo(initialRevision + 1),
                    "Collecting a clue must create one durable checkpoint.");
                chapter.Interact("shelf");
                Assert.That(ReadCheckpointRevision(chapter), Is.EqualTo(initialRevision + 1),
                    "Revisiting a collected clue must not write another checkpoint.");
            }
            finally
            {
                if (hadA) PlayerPrefs.SetString(slotA, oldA);
                else PlayerPrefs.DeleteKey(slotA);
                if (hadB) PlayerPrefs.SetString(slotB, oldB);
                else PlayerPrefs.DeleteKey(slotB);
                PlayerPrefs.Save();
            }
        }

        [UnityTest]
        public IEnumerator LensInspection_ReleasesAndReacquiresGpuSurface()
        {
            const string slotA = "SableAndSigil.ChapterOne.v1.CheckpointA";
            const string slotB = "SableAndSigil.ChapterOne.v1.CheckpointB";
            bool hadA = PlayerPrefs.HasKey(slotA);
            bool hadB = PlayerPrefs.HasKey(slotB);
            string oldA = PlayerPrefs.GetString(slotA, "");
            string oldB = PlayerPrefs.GetString(slotB, "");
            try
            {
                var operation = SceneManager.LoadSceneAsync(ChapterScene, LoadSceneMode.Single);
                Assert.That(operation, Is.Not.Null);
                while (!operation.isDone) yield return null;
                yield return null;
                var chapter = Object.FindObjectOfType<ChapterOneExperience>();
                Assert.That(chapter, Is.Not.Null);
                Assert.That(chapter.IsChapterReady, Is.True);
                chapter.Progress.Restart();
                chapter.Interact("shelf");
                chapter.Interact("desk");
                chapter.Interact("portrait");
                var images = chapter.GetComponentsInChildren<RawImage>(true);
                var lens = System.Array.Find(images, i => i.name == "Live Lens Examination");
                Assert.That(lens, Is.Not.Null);
                var target = lens.texture as RenderTexture;
                Assert.That(target, Is.Not.Null);
                var buttons = chapter.GetComponentsInChildren<Button>(true);
                var inspect = System.Array.Find(buttons, b => b.name == "INSPECT LENS");
                var close = System.Array.Find(buttons, b => b.name == "RETURN");
                Assert.That(inspect, Is.Not.Null);
                Assert.That(close, Is.Not.Null);
                inspect.onClick.Invoke();
                yield return null;
                Assert.That(target.IsCreated(), Is.True,
                    "Opening inspection must allocate its rendering target.");
                close.onClick.Invoke();
                yield return null;
                Assert.That(target.IsCreated(), Is.False,
                    "Closing inspection must release native GPU memory.");
                inspect.onClick.Invoke();
                yield return null;
                Assert.That(target.IsCreated(), Is.True,
                    "Reopening inspection must restore the GPU target.");
                close.onClick.Invoke();
                Assert.That(target.IsCreated(), Is.False);
            }
            finally
            {
                // PlayMode checks must never overwrite the player's real progress.
                if (hadA) PlayerPrefs.SetString(slotA, oldA);
                else PlayerPrefs.DeleteKey(slotA);
                if (hadB) PlayerPrefs.SetString(slotB, oldB);
                else PlayerPrefs.DeleteKey(slotB);
                PlayerPrefs.Save();
            }
        }

        [UnityTest]
        public IEnumerator ChapterOwnedFallbackCamera_IsRemovedWhenChapterIsDestroyed()
        {
            var operation = SceneManager.LoadSceneAsync(ChapterScene, LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null);
            while (!operation.isDone) yield return null;
            yield return null;
            var chapter = Object.FindObjectOfType<ChapterOneExperience>();
            Assert.That(chapter, Is.Not.Null);
            Assert.That(chapter.IsChapterReady, Is.True);
            var main = Camera.main;
            Assert.That(main, Is.Not.Null);
            Assert.That(main.transform.IsChildOf(chapter.transform), Is.True,
                "The generated chapter camera must belong to the chapter lifecycle.");
            Object.Destroy(chapter.gameObject);
            yield return null;
            Assert.That(main == null, Is.True,
                "Destroying the chapter must not leave a camera and audio listener alive.");
        }

        [UnityTest]
        public IEnumerator ChapterOne_OpensAnInteractiveArchiveWithCluesAndNarrative()
        {
            var operation = SceneManager.LoadSceneAsync(ChapterScene, LoadSceneMode.Single);
            Assert.That(operation, Is.Not.Null, "Chapter scene must be generated by the batch bootstrap.");
            while (!operation.isDone) yield return null;
            yield return null;
            var scene = SceneManager.GetActiveScene();
            Assert.That(scene.path, Is.EqualTo(ChapterScene));
            var roots = scene.GetRootGameObjects();
            var chapters = roots.SelectMany(r => r.GetComponentsInChildren<ChapterOneExperience>(true)).ToArray();
            Assert.That(chapters.Length, Is.EqualTo(1));
            Assert.That(chapters[0].isActiveAndEnabled, Is.True,
                "Chapter must remain active and enabled after initialization.");
            Assert.That(chapters[0].IsChapterReady, Is.True, "Chapter must create its environment and UI.");
            var hotspots = roots.SelectMany(r => r.GetComponentsInChildren<ChapterOneHotspot>(true)).ToArray();
            Assert.That(hotspots.Select(h => h.HotspotId).OrderBy(id => id).ToArray(),
                Is.EquivalentTo(new[] { "desk", "passage", "portrait", "shelf" }));
            foreach (var hotspot in hotspots)
                Assert.That(hotspot.GetComponent<Collider>(), Is.Not.Null);
            Assert.That(roots.SelectMany(r => r.GetComponentsInChildren<Camera>(true)).Count(c => c.isActiveAndEnabled),
                Is.EqualTo(1));
            var buttons = roots.SelectMany(r => r.GetComponentsInChildren<Button>(true)).ToArray();
            Assert.That(buttons.Length, Is.GreaterThanOrEqualTo(15));
            Assert.That(buttons.All(b => b.targetGraphic != null), Is.True);
            var texts = roots.SelectMany(r => r.GetComponentsInChildren<Text>(true)).ToArray();
            Assert.That(texts.Any(t => t.name == "Narrative" && !string.IsNullOrWhiteSpace(t.text)), Is.True);
            Assert.That(texts.Any(t => t.name == "Evidence Journal" && t.text.Contains("EVIDENCE JOURNAL")), Is.True);
            Assert.That(texts.Any(t => t.name == "Chapter Title" && t.text.Contains("HOUSE OF THE LAST STAR")), Is.True);
            Assert.That(buttons.Any(b => b.name == "STORY HINT"), Is.True, "Players must have a contextual hint.");
            var allTransforms = roots.SelectMany(r => r.GetComponentsInChildren<Transform>(true)).ToArray();
            Assert.That(allTransforms.Count(t => t.name == "Pointed Arch Rib"), Is.GreaterThanOrEqualTo(4));
            Assert.That(allTransforms.Count(t => t.name == "Ceiling Rib"), Is.GreaterThanOrEqualTo(4));
            Assert.That(allTransforms.Any(t => t.name == "Hidden Passage Moonlight"), Is.True);
            Assert.That(allTransforms.Any(t => t.name == "Hidden Passage"), Is.True);
            var lensView = roots.SelectMany(r => r.GetComponentsInChildren<RawImage>(true))
                .SingleOrDefault(image => image.name == "Live Lens Examination");
            Assert.That(lensView, Is.Not.Null, "Lens inspection must be visible in a dedicated UI viewport.");
            Assert.That(lensView.texture, Is.Not.Null, "Lens viewport requires a RenderTexture.");
            Assert.That(lensView.raycastTarget, Is.False);
            var governor = chapters[0].GetComponent<OrderPerformanceGovernor>();
            Assert.That(governor, Is.Not.Null,
                "Chapter gameplay must use the shared mobile frame-budget policy.");
            Assert.That(governor.isActiveAndEnabled, Is.True);
            Assert.That(roots.SelectMany(r => r.GetComponentsInChildren<Camera>(true))
                .Count(camera => camera.name == "Chapter One Inspection Camera" && !camera.enabled), Is.EqualTo(1));
        }
    }
}
