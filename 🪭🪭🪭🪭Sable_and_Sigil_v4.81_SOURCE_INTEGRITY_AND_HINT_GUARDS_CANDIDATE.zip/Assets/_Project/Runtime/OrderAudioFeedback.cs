using System;
using UnityEngine;

namespace TheOrderRoom.Runtime
{
    /// <summary>Original short procedural sounds; no streamed files, per-frame allocations or mixer polling.</summary>
    [RequireComponent(typeof(AudioSource))]
    [DisallowMultipleComponent]
    public sealed class OrderAudioFeedback : MonoBehaviour
    {
        private AudioSource source;
        private AudioClip success;
        private AudioClip warning;
        private AudioClip discovery;
        private float lastPlayed = -10f;

        private void Awake()
        {
            source = GetComponent<AudioSource>();
            source.playOnAwake = false;
            source.loop = false;
            source.spatialBlend = 0f;
            source.volume = .35f;
            success = MakeTone("OrderSuccess", 587.33f, 0.10f);
            warning = MakeTone("OrderWarning", 220f, 0.10f);
            discovery = MakeTone("OrderDiscovery", 783.99f, 0.18f);
        }

        private static AudioClip MakeTone(string name, float hz, float durationSeconds)
        {
            const int sampleRate = 22050;
            int count = Mathf.CeilToInt(durationSeconds * sampleRate);
            var data = new float[count];
            for (int i = 0; i < count; i++)
            {
                float phase = i * (2f * Mathf.PI * hz / sampleRate);
                float envelope = Mathf.Sin(Mathf.PI * i / (count - 1));
                data[i] = Mathf.Sin(phase) * envelope * envelope * .25f;
            }
            var clip = AudioClip.Create(name, count, 1, sampleRate, false);
            if (!clip.SetData(data, 0))
            {
                Destroy(clip);
                throw new InvalidOperationException("Failed to initialize audio feedback clip.");
            }
            return clip;
        }

        private void Play(AudioClip clip)
        {
            if (clip == null || source == null || !isActiveAndEnabled || AudioListener.pause) return;
            if (Time.unscaledTime - lastPlayed < .075f) return;
            lastPlayed = Time.unscaledTime;
            source.PlayOneShot(clip);
        }

        public void PlaySuccess() => Play(success);
        public void PlayWarning() => Play(warning);
        public void PlayDiscovery() => Play(discovery);

        private void OnDestroy()
        {
            if (success != null) Destroy(success);
            if (warning != null) Destroy(warning);
            if (discovery != null) Destroy(discovery);
        }
    }
}
