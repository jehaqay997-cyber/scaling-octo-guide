using System;
using System.Collections.Generic;
using TheOrderRoom.Domain;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Chapter One: The Astral Archive. Self-contained room, narrative, clue interaction,
    /// inspection, mechanical cipher and persistent unlock of the next location.
    /// </summary>
    public sealed class ChapterOneExperience : MonoBehaviour
    {
        private const string SavePrefix = "SableAndSigil.ChapterOne.v1.";
        private const string CheckpointA = SavePrefix + "CheckpointA";
        private const string CheckpointB = SavePrefix + "CheckpointB";
        private long checkpointRevision;
        private bool nextCheckpointIsA = true;
        private static readonly Color Brass = new Color(.70f, .49f, .23f);
        private static readonly Color Ink = new Color(.035f, .055f, .075f);
        private static readonly Color Ivory = new Color(.93f, .86f, .70f);
        private readonly ChapterOneProgress progress = new ChapterOneProgress();
        private readonly List<Material> ownedMaterials = new List<Material>();
        private readonly Dictionary<string, Button> actionButtons = new Dictionary<string, Button>();
        private Transform worldRoot;
        private Transform inspectModel;
        private Camera viewCamera;
        private ChapterGalleryView chapterGallery;
        private Camera inspectionCamera;
        private RenderTexture inspectionTarget;
        private const int ChapterInspectionLayer = 29;
        private Text narrative;
        private Text objectives;
        private Text journal;
        private Text dialText;
        private Text locationTitle;
        private Text inspectionText;
        private GameObject inspectPanel;
        private GameObject cipherPanel;
        private GameObject travelPanel;
        private int quarterTurns;
        private int focusLevel = 1;
        private bool inspecting;
        private bool initialized;
        private Light lanternLight;
        private Transform secretDoor;
        private Vector3 sealedDoorPosition;
        private Vector3 desiredCameraPosition;
        private Vector3 desiredCameraLookAt;
        private bool cameraRigReady;
        private float sceneTime;
        private PointerEventData pointerEvent;
        private EventSystem cachedEventSystem;
        private readonly List<RaycastResult> interfaceHits = new List<RaycastResult>(12);

        public bool IsChapterReady => initialized && viewCamera != null && narrative != null && worldRoot != null;
        public ChapterOneProgress Progress => progress;

        private void Awake()
        {
            try
            {
                // Every playable chapter must own bounded mobile frame pacing.
                if (GetComponent<OrderPerformanceGovernor>() == null)
                    gameObject.AddComponent<OrderPerformanceGovernor>();
                LoadProgress();
                CreateRoom();
                CreateInterface();
                UpdatePresentation();
                if (progress.ObservatoryUnlocked)
                {
                    locationTitle.text = "SABLE & SIGIL  |  THE FORGOTTEN OBSERVATORY";
                    FocusCamera(new Vector3(2.2f, 3.4f, -6.1f), new Vector3(5.55f, 2.6f, 5.7f));
                    Say("The sealed threshold remembers you. The observatory waits beyond the veil.");
                }
                initialized = true;
            }
            catch (Exception error)
            {
                Debug.LogException(error, this);
                enabled = false;
            }
        }

        private void Update()
        {
            if (!initialized || (chapterGallery != null && chapterGallery.IsOpen)) return;
            AnimateEnvironment();
            if (inspecting) return;
            Vector2 position;
            if (!TryReadPointerDown(out position) || IsPointerOverInterface(position)) return;
            if (!viewCamera || !viewCamera.pixelRect.Contains(position)) return;
            RaycastHit hit;
            if (!Physics.Raycast(viewCamera.ScreenPointToRay(position), out hit, 100f)) return;
            var hotspot = hit.collider.GetComponentInParent<ChapterOneHotspot>();
            if (hotspot != null) Interact(hotspot.HotspotId);
        }

        private static bool TryReadPointerDown(out Vector2 position)
        {
            position = Vector2.zero;
#if ENABLE_INPUT_SYSTEM
            if (Touchscreen.current != null && Touchscreen.current.primaryTouch.press.wasPressedThisFrame)
            {
                position = Touchscreen.current.primaryTouch.position.ReadValue();
                return true;
            }
            if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
            {
                position = Mouse.current.position.ReadValue();
                return true;
            }
#else
            if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
            {
                position = Input.GetTouch(0).position;
                return true;
            }
            if (Input.GetMouseButtonDown(0))
            {
                position = Input.mousePosition;
                return true;
            }
#endif
            return false;
        }

        private bool IsPointerOverInterface(Vector2 position)
        {
            var current = EventSystem.current;
            if (current == null) return true;
            if (cachedEventSystem != current || pointerEvent == null)
            {
                cachedEventSystem = current;
                pointerEvent = new PointerEventData(current);
            }
            pointerEvent.Reset();
            pointerEvent.position = position;
            interfaceHits.Clear();
            current.RaycastAll(pointerEvent, interfaceHits);
            return interfaceHits.Count != 0;
        }

        private void FocusCamera(Vector3 cameraPosition, Vector3 lookAt)
        {
            desiredCameraPosition = cameraPosition;
            desiredCameraLookAt = lookAt;
            cameraRigReady = true;
        }

        private void AnimateEnvironment()
        {
            sceneTime += Time.deltaTime;
            if (lanternLight != null)
                lanternLight.intensity = 1.55f + .13f * Mathf.Sin(sceneTime * 1.7f) + .06f * Mathf.Sin(sceneTime * 5.8f);
            if (secretDoor != null)
            {
                Vector3 target = sealedDoorPosition + (progress.PassageOpen ? Vector3.right * 1.95f : Vector3.zero);
                secretDoor.localPosition = Vector3.MoveTowards(secretDoor.localPosition, target, Time.deltaTime * 1.35f);
            }
            if (cameraRigReady && viewCamera != null)
            {
                float blend = 1f - Mathf.Exp(-2.0f * Time.deltaTime);
                viewCamera.transform.position = Vector3.Lerp(viewCamera.transform.position, desiredCameraPosition, blend);
                Vector3 direction = desiredCameraLookAt - viewCamera.transform.position;
                if (direction.sqrMagnitude > .001f)
                    viewCamera.transform.rotation = Quaternion.Slerp(viewCamera.transform.rotation,
                        Quaternion.LookRotation(direction.normalized), blend);
            }
        }

        private void CreateRoom()
        {
            var currentCamera = Camera.main;
            if (currentCamera == null)
            {
                var cameraGo = new GameObject("Chapter One Main Camera");
                cameraGo.tag = "MainCamera";
                // Own the fallback camera so unloading or restarting this chapter
                // cannot leave a second active camera and AudioListener behind.
                cameraGo.transform.SetParent(transform, false);
                viewCamera = cameraGo.AddComponent<Camera>();
                cameraGo.AddComponent<AudioListener>();
            }
            else viewCamera = currentCamera;
            viewCamera.transform.position = new Vector3(0f, 5.8f, -12f);
            viewCamera.transform.LookAt(new Vector3(0f, 1.65f, 1.3f));
            viewCamera.fieldOfView = 52f;
            viewCamera.clearFlags = CameraClearFlags.SolidColor;
            viewCamera.backgroundColor = new Color(.028f, .040f, .062f);
            RenderSettings.ambientLight = new Color(.23f, .25f, .32f);
            RenderSettings.fog = true;
            RenderSettings.fogColor = new Color(.060f, .080f, .115f);
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogDensity = .009f;
            FocusCamera(new Vector3(0f, 5.8f, -12f), new Vector3(0f, 1.65f, 1.3f));

            worldRoot = new GameObject("Astral Archive Environment").transform;
            worldRoot.SetParent(transform, false);
            Material walnut = MaterialFor("Deep Walnut", new Color(.16f, .089f, .057f));
            Material wall = MaterialFor("Blue Slate", new Color(.095f, .14f, .19f));
            Material stone = MaterialFor("Limestone", new Color(.28f, .30f, .30f));
            Material gold = MaterialFor("Antique Brass", Brass);
            Material blue = MaterialFor("Cold Glass", new Color(.12f, .48f, .58f));
            Material paper = MaterialFor("Aged Parchment", new Color(.74f, .64f, .46f));
            Material velvet = MaterialFor("Midnight Velvet", new Color(.095f, .042f, .075f));
            Material iron = MaterialFor("Blackened Iron", new Color(.075f, .078f, .092f));
            Material moon = MaterialFor("Moonlit Glass", new Color(.23f, .31f, .42f));
            Material obsidian = MaterialFor("Obsidian Inlay", new Color(.043f, .048f, .064f));

            Block("Floor", new Vector3(0f, -.25f, 1.1f), new Vector3(14f, .5f, 12f), stone);
            Block("Rear Wall", new Vector3(0f, 3.1f, 6.3f), new Vector3(14f, 6.5f, .35f), wall);
            Block("West Wall", new Vector3(-7.0f, 3.1f, 1.1f), new Vector3(.35f, 6.5f, 10.5f), wall);
            Block("East Wall", new Vector3(7.0f, 3.1f, 1.1f), new Vector3(.35f, 6.5f, 10.5f), wall);
            Block("Rear Architrave", new Vector3(0f, 5.85f, 6.0f), new Vector3(13.7f, .24f, .22f), gold);
            for (int x = -6; x <= 6; x += 3)
            {
                Block("Wall Pilaster", new Vector3(x, 3f, 6.0f), new Vector3(.12f, 5.7f, .16f), gold);
            }
            // Procedural architectural dressing: gothic ribs, pointed tracery, and worn stone.
            // All ornamental shapes are non-colliding so the hidden-object raycast remains deterministic.
            for (int i = 0; i < 5; i++)
            {
                float x = -5.8f + i * 2.9f;
                Block("Fluted Stone Pier", new Vector3(x, 2.75f, 6.02f), new Vector3(.47f, 5.28f, .40f), stone, false);
                Block("Pier Plinth", new Vector3(x, .35f, 5.82f), new Vector3(.66f, .70f, .73f), obsidian, false);
                Block("Pier Capital", new Vector3(x, 5.30f, 5.83f), new Vector3(.68f, .28f, .72f), gold, false);
            }
            GothicWindow("West Rose Window", new Vector3(-6.77f, 3.45f, 0.0f), true, stone, iron, moon, gold);
            GothicWindow("East Rose Window", new Vector3(6.77f, 3.45f, 0.0f), true, stone, iron, moon, gold);
            for (int i = 0; i < 4; i++)
            {
                float z = -2.25f + i * 2.05f;
                Block("Ceiling Rib", new Vector3(0f, 6.05f, z), new Vector3(13.7f, .16f, .18f), stone, false);
                Block("Ceiling Fillet", new Vector3(0f, 5.9f, z), new Vector3(13.7f, .05f, .065f), gold, false);
            }
            Block("Vaulted Ceiling", new Vector3(0f, 6.35f, 1.1f), new Vector3(13.9f, .3f, 10.5f), obsidian, false);
            for (int i = 0; i < 3; i++)
            {
                Block("Floor Mosaic North", new Vector3(-2.7f + i * 2.7f, .014f, -3.45f),
                    new Vector3(.14f, .025f, .8f), gold, false);
            }
            Block("Archive Carpet", new Vector3(0f, .015f, 1.1f), new Vector3(7.6f, .04f, 6.4f), velvet, false);
            Block("Carpet Edge North", new Vector3(0f, .05f, 4.25f), new Vector3(7.6f, .02f, .07f), gold, false);
            Block("Carpet Edge South", new Vector3(0f, .05f, -2.05f), new Vector3(7.6f, .02f, .07f), gold, false);

            Block("Writing Desk", new Vector3(-3.6f, 1.0f, 1.2f), new Vector3(3.0f, .23f, 1.7f), walnut);
            for (int x = -1; x <= 1; x += 2)
                for (int z = -1; z <= 1; z += 2)
                    Block("Desk Leg", new Vector3(-3.6f + x * 1.28f, .48f, 1.2f + z * .65f), new Vector3(.2f, .96f, .2f), gold);
            Block("Locked Desk Drawer", new Vector3(-3.6f, .69f, .17f), new Vector3(2.25f, .43f, .25f), walnut);
            Block("Drawer Lock", new Vector3(-3.6f, .70f, -.02f), new Vector3(.21f, .24f, .06f), gold, false);
            Hotspot("desk", "Writing Desk Evidence", PrimitiveType.Cube, new Vector3(-3.6f, 1.25f, 1.2f), new Vector3(1.45f, .12f, .94f), paper);

            Block("Curiosity Cabinet", new Vector3(3.7f, 1.95f, 3.7f), new Vector3(2.25f, 3.8f, 1.1f), walnut);
            for (int y = 1; y <= 3; y++)
                Block("Cabinet Shelf", new Vector3(3.7f, y * .94f, 3.08f), new Vector3(2.16f, .10f, .9f), gold);
            Hotspot("shelf", "Brass Casket on Shelf", PrimitiveType.Cube, new Vector3(3.65f, 1.98f, 2.64f), new Vector3(.83f, .50f, .60f), gold);
            Block("Casket Lid", new Vector3(3.65f, 2.27f, 2.64f), new Vector3(.95f, .08f, .72f), walnut, false);

            Block("Portrait Frame", new Vector3(0f, 3.45f, 5.98f), new Vector3(2.6f, 2.8f, .2f), gold);
            Hotspot("portrait", "Astronomer's Portrait", PrimitiveType.Cube, new Vector3(0f, 3.45f, 5.80f), new Vector3(2.26f, 2.42f, .12f), velvet);
            Round("Portrait Moon", PrimitiveType.Sphere, new Vector3(.34f, 3.75f, 5.67f), new Vector3(.7f, .7f, .14f), blue, false);
            Block("Hidden Passage Moonlight", new Vector3(5.55f, 2.45f, 6.19f),
                new Vector3(1.9f, 4.45f, .10f), moon, false);
            var sealedDoor = Block("Hidden Passage", new Vector3(5.55f, 2.45f, 5.98f),
                new Vector3(2.05f, 4.55f, .25f), walnut, false);
            secretDoor = sealedDoor.transform;
            sealedDoorPosition = secretDoor.localPosition;
            Block("Door Arch Keystone", new Vector3(5.55f, 5.01f, 5.74f),
                new Vector3(.45f, .38f, .3f), gold, false);
            Block("Passage Latch", new Vector3(5.55f, 4.85f, 5.77f), new Vector3(1.8f, .13f, .16f), gold, false);
            Hotspot("passage", "Sealed Astral Door", PrimitiveType.Cylinder, new Vector3(5.55f, 2.5f, 5.76f), new Vector3(.62f, .04f, .62f), gold);
            Round("Celestial Globe", PrimitiveType.Sphere, new Vector3(0f, 1.10f, 2.4f), new Vector3(1.0f, 1.0f, 1.0f), blue, false);
            Block("Globe Stand", new Vector3(0f, .45f, 2.4f), new Vector3(.35f, .9f, .35f), walnut, false);
            Round("Globe Ring", PrimitiveType.Cylinder, new Vector3(0f, 1.09f, 2.4f), new Vector3(1.18f, .016f, 1.18f), gold, false);
            for (int i = 0; i < 5; i++)
                Block("Archive Book", new Vector3(-5.5f + i * .29f, 1.35f, 3.2f), new Vector3(.22f, .67f + (i % 3) * .11f, .36f), i % 2 == 0 ? paper : velvet, false);
            Block("Western Display Stand", new Vector3(-4.9f, .9f, 3.1f), new Vector3(2.6f, .2f, 1.5f), walnut);
            Block("Western Display Base", new Vector3(-4.9f, .43f, 3.1f), new Vector3(.9f, .87f, .7f), gold, false);

            var key = new GameObject("Key Light").AddComponent<Light>();
            key.transform.SetParent(worldRoot, false);
            key.type = LightType.Directional;
            key.color = new Color(1f, .79f, .54f);
            key.intensity = 1.15f;
            key.transform.rotation = Quaternion.Euler(48f, -38f, 0f);
            var lamp = new GameObject("Archive Lantern").AddComponent<Light>();
            lamp.transform.SetParent(worldRoot, false);
            lamp.type = LightType.Point;
            lamp.range = 10f;
            lamp.intensity = 1.55f;
            lanternLight = lamp;
            lamp.color = new Color(1f, .66f, .34f);
            lamp.transform.position = new Vector3(-3.7f, 3.4f, 2f);
            Round("Lantern Crown", PrimitiveType.Sphere, new Vector3(-3.7f, 3.5f, 2f), new Vector3(.3f, .43f, .3f), gold, false);
            Block("Lantern Chain", new Vector3(-3.7f, 4.12f, 2f), new Vector3(.045f, .88f, .045f), iron, false);
            Round("Lantern Hearth", PrimitiveType.Sphere, new Vector3(-3.7f, 3.36f, 2f),
                new Vector3(.16f, .23f, .16f), paper, false);

            var artifact = new GameObject("Inspectable Celestial Lens");
            artifact.transform.SetParent(transform, false);
            artifact.transform.position = new Vector3(0f, 1.9f, -1f);
            inspectModel = artifact.transform;
            Round("Lens Brass Rim", PrimitiveType.Cylinder, Vector3.zero, new Vector3(1.00f, .12f, 1.00f), gold, false, inspectModel);
            Round("Lens Crystal", PrimitiveType.Sphere, new Vector3(0f, .17f, 0f), new Vector3(.78f, .20f, .78f), blue, false, inspectModel);
            Block("Lens Engraving", new Vector3(0f, -.18f, .6f), new Vector3(.45f, .06f, .10f), paper, false, inspectModel);
            inspectModel.gameObject.SetActive(false);
            CreateInspectionCamera();
        }

        private void CreateInspectionCamera()
        {
            foreach (Transform child in inspectModel.GetComponentsInChildren<Transform>(true))
                child.gameObject.layer = ChapterInspectionLayer;
            viewCamera.cullingMask &= ~(1 << ChapterInspectionLayer);
            inspectionTarget = new RenderTexture(640, 480, 16, RenderTextureFormat.ARGB32)
            {
                name = "Chapter One Lens Inspection",
                antiAliasing = 1,
                filterMode = FilterMode.Bilinear
            };
            var cameraObject = new GameObject("Chapter One Inspection Camera");
            cameraObject.transform.SetParent(transform, false);
            inspectionCamera = cameraObject.AddComponent<Camera>();
            inspectionCamera.enabled = false;
            inspectionCamera.cullingMask = 1 << ChapterInspectionLayer;
            inspectionCamera.clearFlags = CameraClearFlags.SolidColor;
            inspectionCamera.backgroundColor = new Color(.035f, .045f, .064f);
            inspectionCamera.fieldOfView = 34f;
            inspectionCamera.nearClipPlane = .05f;
            inspectionCamera.farClipPlane = 20f;
            inspectionCamera.targetTexture = inspectionTarget;
            inspectionCamera.transform.position = new Vector3(0f, 3.5f, -4.7f);
            inspectionCamera.transform.LookAt(new Vector3(0f, 1.9f, -1f));
        }

        private void GothicWindow(string name, Vector3 centre, bool sideWall, Material stone,
            Material iron, Material glass, Material brass)
        {
            var frame = new GameObject(name).transform;
            frame.SetParent(worldRoot, false);
            frame.localPosition = centre;
            var axis = sideWall ? Quaternion.Euler(0f, 90f, 0f) : Quaternion.identity;
            frame.localRotation = axis;
            Block("Recessed Moon Glass", Vector3.zero, new Vector3(2.15f, 3.15f, .08f), glass, false, frame);
            Block("Left Mullion", new Vector3(-1.12f, 0f, -.13f), new Vector3(.18f, 3.3f, .22f), stone, false, frame);
            Block("Right Mullion", new Vector3(1.12f, 0f, -.13f), new Vector3(.18f, 3.3f, .22f), stone, false, frame);
            Block("Window Sill", new Vector3(0f, -1.64f, -.18f), new Vector3(2.42f, .18f, .28f), stone, false, frame);
            Block("Central Tracery", new Vector3(0f, 0f, -.14f), new Vector3(.09f, 3.25f, .14f), iron, false, frame);
            Block("Glass Transom", new Vector3(0f, -.44f, -.14f), new Vector3(2.18f, .08f, .14f), iron, false, frame);
            for (int side = -1; side <= 1; side += 2)
            {
                var wing = Block("Pointed Arch Rib", new Vector3(side * .56f, 1.72f, -.18f),
                    new Vector3(.11f, 1.57f, .20f), stone, false, frame);
                wing.transform.localRotation = Quaternion.Euler(0f, 0f, side * 43f);
            }
            Round("Rose Window Boss", PrimitiveType.Sphere, new Vector3(0f, 1.4f, -.2f),
                new Vector3(.20f, .20f, .12f), brass, false, frame);
        }

        private Material MaterialFor(string name, Color color)
        {
            Shader shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Universal Render Pipeline/Lit");
            if (shader == null) shader = Shader.Find("Sprites/Default");
            if (shader == null) throw new InvalidOperationException("No supported material shader exists.");
            var material = new Material(shader) { name = name, color = color };
            if (material.HasProperty("_Metallic"))
                material.SetFloat("_Metallic", name.Contains("Brass") || name.Contains("Iron") ? .72f : .04f);
            if (material.HasProperty("_Glossiness"))
                material.SetFloat("_Glossiness", name.Contains("Glass") ? .84f :
                    name.Contains("Brass") ? .55f : name.Contains("Velvet") ? .13f : .28f);
            ownedMaterials.Add(material);
            return material;
        }

        private GameObject Block(string name, Vector3 position, Vector3 size, Material material, bool collision = true, Transform parent = null)
            => Shape(name, PrimitiveType.Cube, position, size, material, collision, parent);

        private GameObject Round(string name, PrimitiveType primitive, Vector3 position, Vector3 size, Material material,
            bool collision = true, Transform parent = null)
            => Shape(name, primitive, position, size, material, collision, parent);

        private GameObject Shape(string name, PrimitiveType primitive, Vector3 position, Vector3 size, Material material,
            bool collision = true, Transform parent = null)
        {
            var go = GameObject.CreatePrimitive(primitive);
            go.name = name;
            go.transform.SetParent(parent == null ? worldRoot : parent, false);
            go.transform.localPosition = position;
            go.transform.localScale = size;
            go.GetComponent<Renderer>().sharedMaterial = material;
            if (!collision)
            {
                var component = go.GetComponent<Collider>();
                if (component != null) Destroy(component);
            }
            return go;
        }

        private void Hotspot(string id, string name, PrimitiveType primitive, Vector3 position, Vector3 size, Material material)
        {
            var go = Shape(name, primitive, position, size, material);
            go.AddComponent<ChapterOneHotspot>().SetId(id);
        }

        private void CreateInterface()
        {
            if (FindObjectOfType<EventSystem>() == null)
            {
                var events = new GameObject("Chapter One EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
                events.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
                events.AddComponent<StandaloneInputModule>();
#endif
                events.transform.SetParent(transform, false);
            }
            var canvasObject = new GameObject("Chapter One HUD", typeof(RectTransform), typeof(Canvas),
                typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasObject.transform.SetParent(transform, false);
            var canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 50;
            var scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1600f, 900f);
            scaler.matchWidthOrHeight = .5f;
            var root = (RectTransform)canvasObject.transform;

            Panel("Title Backdrop", root, new Vector2(.0f, .86f), new Vector2(1f, 1f), new Color(.025f, .032f, .056f, .96f));
            Panel("Footer Backdrop", root, new Vector2(0f, 0f), new Vector2(1f, .21f), new Color(.025f, .035f, .059f, .97f));
            Panel("Evidence Backdrop", root, new Vector2(.0f, .22f), new Vector2(.27f, .84f), new Color(.035f, .049f, .071f, .88f));
            Panel("Actions Backdrop", root, new Vector2(.77f, .22f), new Vector2(1f, .84f), new Color(.035f, .049f, .071f, .88f));

            locationTitle = Label("Chapter Title", root, "SABLE & SIGIL  |  THE HOUSE OF THE LAST STAR", new Vector2(0f, 392f), new Vector2(1450f, 63f), 33, Ivory);
            narrative = Label("Narrative", root, "", new Vector2(0f, -294f), new Vector2(1460f, 87f), 23, Ivory);
            objectives = Label("Objective", root, "", new Vector2(-595f, 150f), new Vector2(340f, 70f), 22, Ivory);
            journal = Label("Evidence Journal", root, "", new Vector2(-590f, -25f), new Vector2(340f, 220f), 20, Ivory);
            Label("Actions Heading", root, "EXPLORE", new Vector2(620f, 260f), new Vector2(255f, 58f), 24, Ivory);

            Action("shelf", "SEARCH CABINET", root, new Vector2(615f, 185f), () => Interact("shelf"));
            Action("desk", "OPEN DESK", root, new Vector2(615f, 98f), () => Interact("desk"));
            Action("portrait", "CHECK PORTRAIT", root, new Vector2(615f, 11f), () => Interact("portrait"));
            Action("inspect", "INSPECT LENS", root, new Vector2(615f, -76f), BeginInspection);
            Action("cipher", "EXAMINE LOCK", root, new Vector2(615f, -163f), ShowCipher);
            Action("restart", "RESTART CHAPTER", root, new Vector2(-595f, -192f), RestartChapter);
            Action("hint", "STORY HINT", root, new Vector2(-595f, 260f), ShowContextHint);
            Action("chapters", "CHAPTERS", root, new Vector2(615f, -246f), ShowChapterGallery);

            inspectPanel = Overlay("Inspection Controls", root);
            var inspectionRect = (RectTransform)inspectPanel.transform;
            inspectionRect.anchorMin = new Vector2(.20f, .12f);
            inspectionRect.anchorMax = new Vector2(.80f, .88f);
            Label("Inspection Heading", inspectPanel.transform, "CELESTIAL LENS  |  INSPECTION",
                new Vector2(0f, 265f), new Vector2(860f, 55f), 25, Ivory);
            var lensScreen = new GameObject("Live Lens Examination", typeof(RectTransform), typeof(RawImage));
            lensScreen.transform.SetParent(inspectPanel.transform, false);
            var lensRect = (RectTransform)lensScreen.transform;
            lensRect.anchorMin = lensRect.anchorMax = new Vector2(.5f, .5f);
            lensRect.anchoredPosition = new Vector2(0f, 48f);
            lensRect.sizeDelta = new Vector2(510f, 350f);
            var lensImage = lensScreen.GetComponent<RawImage>();
            lensImage.texture = inspectionTarget;
            lensImage.color = Color.white;
            lensImage.raycastTarget = false;
            inspectionText = Label("Lens Detail", inspectPanel.transform, "",
                new Vector2(0f, -157f), new Vector2(860f, 65f), 21, Ivory);
            Action("turn", "ROTATE 90°", inspectPanel.transform, new Vector2(-285f, -256f), RotateLens);
            Action("focus", "FOCUS +", inspectPanel.transform, new Vector2(0f, -256f), FocusLens);
            Action("close-inspect", "RETURN", inspectPanel.transform, new Vector2(285f, -256f), CloseInspection);

            cipherPanel = Overlay("Cipher Lock", root);
            Label("Cipher Heading", cipherPanel.transform, "THE ASTRAL LOCK  |  THREE SYMBOLS", new Vector2(0f, 130f), new Vector2(920f, 52f), 25, Ivory);
            dialText = Label("Dial Value", cipherPanel.transform, "0  0  0", new Vector2(0f, 43f), new Vector2(600f, 64f), 38, Ivory);
            Action("digit-0", "LEFT +", cipherPanel.transform, new Vector2(-310f, -64f), () => CycleDigit(0));
            Action("digit-1", "CENTRE +", cipherPanel.transform, new Vector2(-100f, -64f), () => CycleDigit(1));
            Action("digit-2", "RIGHT +", cipherPanel.transform, new Vector2(110f, -64f), () => CycleDigit(2));
            Action("unlock", "UNSEAL", cipherPanel.transform, new Vector2(330f, -64f), TryUnseal);
            Action("close-cipher", "RETURN", cipherPanel.transform, new Vector2(0f, -141f), CloseCipher);

            travelPanel = Overlay("Passage Unlocked", root);
            Label("Revelation Heading", travelPanel.transform, "THE FORGOTTEN OBSERVATORY", new Vector2(0f, 120f), new Vector2(980f, 70f), 36, Ivory);
            Label("Revelation Detail", travelPanel.transform,
                "A forbidden star chart hangs beyond the stone. One constellation has been erased by hand.",
                new Vector2(0f, 32f), new Vector2(980f, 72f), 21, Ivory);
            Action("travel", "ENTER OBSERVATORY", travelPanel.transform, new Vector2(0f, -83f), EnterObservatory);
            Action("travel-close", "RETURN TO ARCHIVE", travelPanel.transform, new Vector2(0f, -159f), CloseTravel);
            inspectPanel.SetActive(false);
            cipherPanel.SetActive(false);
            travelPanel.SetActive(false);
        }

        private static GameObject Panel(string name, RectTransform parent, Vector2 min, Vector2 max, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            var rect = (RectTransform)go.transform;
            rect.SetParent(parent, false);
            rect.anchorMin = min;
            rect.anchorMax = max;
            rect.offsetMin = rect.offsetMax = Vector2.zero;
            var image = go.GetComponent<Image>();
            image.color = color;
            image.raycastTarget = false;
            return go;
        }

        private static GameObject Overlay(string name, RectTransform canvas)
        {
            var go = Panel(name, canvas, new Vector2(.15f, .28f), new Vector2(.85f, .78f),
                new Color(.035f, .055f, .086f, .99f));
            var image = go.GetComponent<Image>();
            image.raycastTarget = true;
            return go;
        }

        private static Text Label(string name, Transform parent, string value, Vector2 position, Vector2 size, int fontSize, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Text));
            go.transform.SetParent(parent, false);
            var rect = (RectTransform)go.transform;
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            var label = go.GetComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.text = value;
            label.fontSize = fontSize;
            label.color = color;
            label.alignment = TextAnchor.MiddleCenter;
            label.horizontalOverflow = HorizontalWrapMode.Wrap;
            label.verticalOverflow = VerticalWrapMode.Truncate;
            label.raycastTarget = false;
            return label;
        }

        private void Action(string id, string caption, Transform parent, Vector2 position, UnityEngine.Events.UnityAction callback)
        {
            var go = new GameObject(caption, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            var rect = (RectTransform)go.transform;
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.sizeDelta = new Vector2(205f, 57f);
            rect.anchoredPosition = position;
            go.GetComponent<Image>().color = Brass;
            var button = go.GetComponent<Button>();
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, .94f, .77f);
            colors.pressedColor = new Color(.69f, .65f, .57f);
            button.colors = colors;
            button.onClick.AddListener(callback);
            actionButtons[id] = button;
            Label("Caption", go.transform, caption, Vector2.zero, new Vector2(198f, 54f), 17, Ink);
        }

        public void Interact(string id)
        {
            if (!initialized || inspecting || inspectPanel.activeSelf || cipherPanel.activeSelf || travelPanel.activeSelf ||
                (chapterGallery != null && chapterGallery.IsOpen))
                return;
            int previousFlags = progress.Flags;
            int previousDial = progress.DialValue;
            switch (id)
            {
                case "shelf":
                    if (progress.SearchShelf()) Say("A blackened key rests in a velvet casket. Its crest matches the astronomer's vanished house.");
                    else Say("The cabinet is empty. The brass key is in your journal.");
                    break;
                case "desk":
                    if (!progress.HasKey) Say("The writing desk is locked. Search the cabinet for its key.");
                    else if (progress.UnlockWritingDesk()) Say("Lady Vey's last letter: 'The portrait is a lie. Turn the lens twice, bring its underside into focus.'");
                    else Say("The desk contains only the letter you already recovered.");
                    break;
                case "portrait":
                    if (!progress.HasLetter) Say("A peculiar portrait. You need a clue before disturbing it.");
                    else if (progress.SearchPortrait()) Say("The portrait swings free. Behind the painted stars: a cold lens, and a date scratched into plaster.");
                    else Say("The portrait's secret compartment is empty.");
                    break;
                case "passage":
                    if (progress.PassageOpen) ShowTravel();
                    else ShowCipher();
                    break;
                default: return;
            }
            // Revisiting a completed clue or tapping a locked hotspot must not
            // trigger a PlayerPrefs write. Only durable puzzle transitions persist.
            if (progress.Flags != previousFlags || progress.DialValue != previousDial)
                SaveProgress();
            UpdatePresentation();
        }

        private void ShowChapterGallery()
        {
            if (inspecting || inspectPanel.activeSelf || cipherPanel.activeSelf || travelPanel.activeSelf)
                return;
            if (chapterGallery == null) chapterGallery = GetComponent<ChapterGalleryView>();
            if (chapterGallery == null) chapterGallery = gameObject.AddComponent<ChapterGalleryView>();
            var gallery = chapterGallery;
            gallery.Show();
        }

        private void ShowContextHint()
        {
            if (progress.ObservatoryUnlocked) Say("The passage is open. Your journey continues beyond the observatory.");
            else if (progress.PassageOpen) Say("The threshold is open. Enter to read the missing constellation.");
            else if (progress.KnowsCipher) Say("The lens revealed three digits. Look for the lock on the sealed door.");
            else if (progress.HasLens) Say("Turn the lens 180 degrees and focus until the engraving becomes legible.");
            else if (progress.HasLetter) Say("The letter warns that the portrait conceals more than a likeness.");
            else if (progress.HasKey) Say("Lady Vey hid her letter in the writing desk.");
            else Say("The brass cabinet contains something that belongs to the locked desk.");
        }

        private void BeginInspection()
        {
            if (!progress.HasLens) { Say("Find the celestial lens behind the portrait first."); return; }
            HideOverlays();
            inspecting = true;
            if (inspectionTarget == null || (!inspectionTarget.IsCreated() && !inspectionTarget.Create()))
            {
                inspecting = false;
                Say("The inspection viewer is unavailable. Close other applications and try again.");
                return;
            }
            inspectPanel.SetActive(true);
            inspectModel.gameObject.SetActive(true);
            if (inspectionCamera != null)
                inspectionCamera.enabled = true;
            UpdateInspection();
        }

        private void RotateLens()
        {
            if (!inspecting) return;
            quarterTurns = (quarterTurns + 1) % 4;
            inspectModel.rotation = Quaternion.Euler(30f, 90f * quarterTurns, 35f);
            RevealEngravingIfReady();
            UpdateInspection();
        }

        private void FocusLens()
        {
            if (!inspecting) return;
            focusLevel = focusLevel >= 3 ? 1 : focusLevel + 1;
            inspectModel.localScale = Vector3.one * (1f + (focusLevel - 1) * .25f);
            RevealEngravingIfReady();
            UpdateInspection();
        }

        private void RevealEngravingIfReady()
        {
            if (progress.DecodeLens(quarterTurns, focusLevel))
            {
                Say("Under the glass, three numbers emerge: 3 - 1 - 4. Beneath them: 'What was hidden above waits below.'");
                SaveProgress();
            }
            UpdatePresentation();
        }

        private void UpdateInspection()
        {
            inspectionText.text = progress.KnowsCipher
                ? "The inscription is clear: 3 - 1 - 4."
                : "Rotate the lens 180 degrees and focus to at least level 2.  Rotation: " +
                  (Math.Abs(quarterTurns) % 4) * 90 + "°  |  Focus: " + focusLevel;
        }

        private void CloseInspection()
        {
            inspecting = false;
            inspectPanel.SetActive(false);
            inspectModel.gameObject.SetActive(false);
            if (inspectionCamera != null) inspectionCamera.enabled = false;
            if (inspectionTarget != null && inspectionTarget.IsCreated()) inspectionTarget.Release();
            UpdatePresentation();
        }

        private void ShowCipher()
        {
            if (!progress.KnowsCipher)
            {
                Say("The astronomical lock needs a sequence. Examine the lens to find it.");
                return;
            }
            if (progress.PassageOpen) { ShowTravel(); return; }
            HideOverlays();
            cipherPanel.SetActive(true);
            UpdateDial();
        }

        private void CycleDigit(int index)
        {
            int place = index == 0 ? 100 : index == 1 ? 10 : 1;
            int current = progress.DialValue / place % 10;
            if (progress.SetDigit(index, (current + 1) % 10))
                SaveProgress();
            UpdateDial();
        }

        private void UpdateDial()
        {
            int value = progress.DialValue;
            dialText.text = (value / 100) + "   " + (value / 10 % 10) + "   " + (value % 10);
        }

        private void TryUnseal()
        {
            if (progress.OpenSecretPanel())
            {
                SaveProgress();
                Say("The lock releases. The false wall withdraws, revealing a moonlit stair and a star chart with one constellation erased.");
                ShowTravel();
            }
            else Say("The lock refuses the combination. Examine the engraved lens again.");
            UpdatePresentation();
        }

        private void CloseCipher() => cipherPanel.SetActive(false);
        private void ShowTravel()
        {
            HideOverlays();
            travelPanel.SetActive(true);
        }
        private void CloseTravel() => travelPanel.SetActive(false);

        private void EnterObservatory()
        {
            if (!progress.PassageOpen) return;
            if (progress.EnterObservatory())
                SaveProgress();
            HideOverlays();
            locationTitle.text = "SABLE & SIGIL  |  THE FORGOTTEN OBSERVATORY";
            FocusCamera(new Vector3(2.2f, 3.4f, -6.1f), new Vector3(5.55f, 2.6f, 5.7f));
            Say("The Observatory is open. A missing star marks the first page of a far greater mystery.");
            UpdatePresentation();
        }

        private void HideOverlays()
        {
            inspecting = false;
            inspectPanel.SetActive(false);
            cipherPanel.SetActive(false);
            travelPanel.SetActive(false);
            inspectModel.gameObject.SetActive(false);
            if (inspectionCamera != null) inspectionCamera.enabled = false;
            if (inspectionTarget != null && inspectionTarget.IsCreated()) inspectionTarget.Release();
        }

        private void RestartChapter()
        {
            progress.Restart();
            quarterTurns = 0;
            focusLevel = 1;
            inspectModel.localScale = Vector3.one;
            inspectModel.rotation = Quaternion.identity;
            FocusCamera(new Vector3(0f, 5.8f, -12f), new Vector3(0f, 1.65f, 1.3f));
            locationTitle.text = "SABLE & SIGIL  |  THE HOUSE OF THE LAST STAR";
            HideOverlays();
            SaveProgress();
            Say("Rain grips the abandoned estate. The astronomer's last letter points to a sealed room beneath the observatory.");
            UpdatePresentation();
        }

        private void Say(string message)
        {
            if (narrative != null) narrative.text = message;
        }

        private void UpdatePresentation()
        {
            if (narrative == null) return;
            if (string.IsNullOrEmpty(narrative.text))
                Say("The night the stars disappeared, Lady Vey sealed her observatory. Her final message begins: 'Do not trust the sky.'");
            objectives.text = progress.ObservatoryUnlocked ? "CHAPTER COMPLETE" :
                progress.PassageOpen ? "ENTER THE PASSAGE" :
                progress.KnowsCipher ? "UNSEAL THE DOOR" :
                progress.HasLens ? "INSPECT THE LENS" :
                progress.HasLetter ? "SEARCH THE PORTRAIT" :
                progress.HasKey ? "UNLOCK THE DESK" : "FIND THE BRASS KEY";
            journal.text = "EVIDENCE JOURNAL\n\n" +
                (progress.HasKey ? "[FOUND] Brass Key\n" : "[  ?  ] Brass Key\n") +
                (progress.HasLetter ? "[FOUND] Torn Letter\n" : "[  ?  ] Torn Letter\n") +
                (progress.HasLens ? "[FOUND] Celestial Lens\n" : "[  ?  ] Celestial Lens\n") +
                (progress.KnowsCipher ? "[DECODED] Astral Cipher\n" : "[  ?  ] Astral Cipher\n") +
                (progress.PassageOpen ? "[OPEN] Hidden Passage" : "[SEALED] Hidden Passage");
            actionButtons["inspect"].interactable = progress.HasLens;
            actionButtons["cipher"].interactable = progress.KnowsCipher && !progress.PassageOpen;
            actionButtons["desk"].interactable = !progress.HasLetter;
            actionButtons["portrait"].interactable = !progress.HasLens;
            actionButtons["shelf"].interactable = !progress.HasKey;
        }

        private void SaveProgress()
        {
            // Rotate independent snapshots. The previously committed slot remains intact
            // until the new slot is completely written and persisted.
            if (checkpointRevision == long.MaxValue)
            {
                Debug.LogError("Chapter checkpoint revision exhausted; refusing to overwrite saved progress.");
                return;
            }
            string snapshot = ChapterCheckpointCodec.Encode(checkpointRevision + 1,
                progress.Flags, progress.DialValue);
            string destination = nextCheckpointIsA ? CheckpointA : CheckpointB;
            try
            {
                PlayerPrefs.SetString(destination, snapshot);
                PlayerPrefs.Save();
                checkpointRevision++;
                nextCheckpointIsA = !nextCheckpointIsA;
            }
            catch (Exception error)
            {
                Debug.LogException(error, this);
                // Do not advance local revision if the persistence operation failed.
            }
        }

        private void LoadProgress()
        {
            long revisionA;
            long revisionB;
            int flagsA;
            int flagsB;
            int dialA;
            int dialB;
            bool validA = ChapterCheckpointCodec.TryDecode(PlayerPrefs.GetString(CheckpointA, ""),
                out revisionA, out flagsA, out dialA);
            bool validB = ChapterCheckpointCodec.TryDecode(PlayerPrefs.GetString(CheckpointB, ""),
                out revisionB, out flagsB, out dialB);
            if (validA || validB)
            {
                bool useA = validA && (!validB || revisionA >= revisionB);
                checkpointRevision = useA ? revisionA : revisionB;
                nextCheckpointIsA = !useA;
                if (!progress.Restore(useA ? flagsA : flagsB, useA ? dialA : dialB))
                    throw new InvalidOperationException("Validated checkpoint unexpectedly failed to restore.");
                if (!validA || !validB)
                    Debug.LogWarning("One chapter checkpoint was unavailable or damaged; restored the valid snapshot.");
                return;
            }
            // Only migrate the legacy three-key format if no new-format checkpoint has
            // ever been stored. Corruption must not silently resurrect obsolete state.
            if (PlayerPrefs.HasKey(CheckpointA) || PlayerPrefs.HasKey(CheckpointB))
            {
                Debug.LogWarning("Both chapter checkpoints are invalid; starting with a safe empty state.");
                progress.Restart();
                return;
            }
            int flags = PlayerPrefs.GetInt(SavePrefix + "Flags", 0);
            int dial = PlayerPrefs.GetInt(SavePrefix + "Dial", 0);
            int check = PlayerPrefs.GetInt(SavePrefix + "Check", 541);
            if (check != unchecked(flags * 7919 + dial * 1297 + 541) || !progress.Restore(flags, dial))
            {
                Debug.LogWarning("Legacy chapter save validation failed; starting safely from the beginning.");
                progress.Restart();
            }
        }

        private void OnApplicationPause(bool paused)
        {
            if (!initialized || inspectionCamera == null || inspectionTarget == null) return;
            if (paused)
            {
                inspectionCamera.enabled = false;
                if (inspectionTarget.IsCreated()) inspectionTarget.Release();
            }
            else if (inspecting && inspectPanel != null && inspectPanel.activeSelf)
            {
                if (inspectionTarget.IsCreated() || inspectionTarget.Create())
                    inspectionCamera.enabled = true;
                else
                    CloseInspection();
            }
        }

        private void OnDestroy()
        {
            foreach (var material in ownedMaterials)
                if (material != null) Destroy(material);
            ownedMaterials.Clear();
            pointerEvent = null;
            cachedEventSystem = null;
            interfaceHits.Clear();
            if (inspectionCamera != null) inspectionCamera.targetTexture = null;
            if (inspectionTarget != null)
            {
                inspectionTarget.Release();
                Destroy(inspectionTarget);
                inspectionTarget = null;
            }
        }
    }
}
