using System;
using UnityEngine;
using UnityEngine.UI;

namespace TheOrderRoom.Runtime
{
    /// <summary>
    /// Read-only chapter art gallery. Only the implemented first chapter is playable;
    /// concept previews never mutate progress or claim to unlock playable scenes.
    /// </summary>
    public sealed class ChapterGalleryView : MonoBehaviour
    {
        private static readonly string[] ChapterNames =
        {
            "The House of the Last Star", "The Veiled Conservatory",
            "The Ashen Gallery", "The Hollow Meridian"
        };
        private static readonly string[] ChapterDescriptions =
        {
            "Find Lady Vey's last letter, examine the celestial lens, and unseal the forgotten observatory.",
            "Beyond the estate, the glass gardens keep a botanical star map beneath living vines.",
            "An ash-filled portrait hall preserves faces that should never have been painted.",
            "Across the cloud sea, the last meridian is aligned with a constellation no one remembers."
        };
        private static readonly string[] LocationNames =
        {
            "The Threshold of Vey", "The Spiral of Testimony", "The Lantern Ascent",
            "The Rose Pavilion", "The Fountain of Echoes", "The Silent Crossing",
            "The Glass Testament", "The Hall of False Light", "The Weeping Witness",
            "The Meridian Rotunda"
        };
        private static readonly string[] LocationDescriptions =
        {
            "A sealed arch bears the lost-star crest. Compare the seal with Lady Vey's last letter.",
            "One section of the ceremonial staircase has been replaced. Follow its repeating pattern.",
            "A lantern along the garden approach remains lit at the wrong hour.",
            "An overgrown pavilion surrounds a basin engraved with a forgotten flower sequence.",
            "Four fountain spouts once sounded the notes of the gardener's lunar calendar.",
            "A boat and three statues conceal the direction to a hidden shore.",
            "Colored windowpanes form a sequence visible only from the correct angle.",
            "The vaulted gallery contradicts a family memorial hidden behind the light.",
            "A damaged epitaph beneath the stone witness conceals one erased word.",
            "The circular archive holds a sphere aligned with a star absent from every chart."
        };
        private static readonly int[] LocationChapters = { 1, 1, 2, 2, 2, 2, 3, 3, 3, 4 };
        public const int LocationCount = 10;
        private static readonly Color Parchment = new Color(.91f, .84f, .69f);
        private static readonly Color AntiqueBrass = new Color(.62f, .43f, .23f);
        private GameObject galleryCanvas;
        private RawImage artwork;
        private Text heading;
        private Text description;
        private Text availability;
        private Button enterButton;
        private Button previousSceneButton;
        private Button nextSceneButton;
        private Button sceneAtlasButton;
        private Text enterCaption;
        private readonly Texture2D[] chapterTextures = new Texture2D[4];
        private int activeChapterTextureIndex = -1;
        private Texture2D activeLocationTexture;
        private int activeLocationTextureIndex = -1;
        private RectTransform artworkRect;
        private RectTransform safeAreaRoot;
        private RectTransform layoutRoot;
        private CanvasScaler galleryScaler;
        private int lastScreenWidth = -1;
        private int lastScreenHeight = -1;
        private Rect lastSafeArea;
        private bool locationMode;
        private int locationIndex;
        private int selectedIndex;
        private Camera hiddenWorldCamera;
        private bool worldCameraWasEnabled;

        public bool IsOpen => galleryCanvas != null && galleryCanvas.activeSelf;
        public int SelectedChapter => selectedIndex + 1;
        public int ResidentChapterArtworkCount
        {
            get
            {
                int count = 0;
                for (int index = 0; index < chapterTextures.Length; index++)
                    if (chapterTextures[index] != null) count++;
                return count;
            }
        }
        public const int ChapterCount = 4;

        public static int GetChapterForLocation(int locationNumber)
        {
            if (locationNumber < 1 || locationNumber > LocationCount)
                throw new ArgumentOutOfRangeException(nameof(locationNumber));
            return LocationChapters[locationNumber - 1];
        }

        public static bool ValidateContentCatalog(out string error)
        {
            error = null;
            if (ChapterNames.Length != ChapterCount || ChapterDescriptions.Length != ChapterCount ||
                LocationNames.Length != LocationCount || LocationDescriptions.Length != LocationCount ||
                LocationChapters.Length != LocationCount)
            {
                error = "Chapter and location catalog lengths do not agree.";
                return false;
            }
            var chaptersWithLocations = new bool[ChapterCount];
            var uniqueChapterNames = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            var uniqueLocationNames = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
            int previousChapter = 1;
            for (int chapter = 0; chapter < ChapterCount; chapter++)
            {
                if (string.IsNullOrWhiteSpace(ChapterNames[chapter]) ||
                    string.IsNullOrWhiteSpace(ChapterDescriptions[chapter]) ||
                    !uniqueChapterNames.Add(ChapterNames[chapter]))
                {
                    error = "Missing or duplicate chapter content at index " + chapter;
                    return false;
                }
            }
            for (int location = 0; location < LocationCount; location++)
            {
                int chapterNumber = LocationChapters[location];
                if (chapterNumber < 1 || chapterNumber > ChapterCount || chapterNumber < previousChapter ||
                    string.IsNullOrWhiteSpace(LocationNames[location]) ||
                    string.IsNullOrWhiteSpace(LocationDescriptions[location]) ||
                    !uniqueLocationNames.Add(LocationNames[location]))
                {
                    error = "Invalid location mapping or content at index " + location;
                    return false;
                }
                previousChapter = chapterNumber;
                chaptersWithLocations[chapterNumber - 1] = true;
            }
            for (int chapter = 0; chapter < chaptersWithLocations.Length; chapter++)
            {
                if (chaptersWithLocations[chapter]) continue;
                error = "Chapter " + (chapter + 1) + " has no mapped locations.";
                return false;
            }
            return true;
        }

        public void Show()
        {
            if (galleryCanvas == null) Build();
            selectedIndex = 0;
            locationMode = false;
            Refresh();
            galleryCanvas.SetActive(true);
            UpdateSafeAreaLayout();
            SuspendWorldCamera();
        }

        public void Close()
        {
            if (galleryCanvas != null) galleryCanvas.SetActive(false);
            RestoreWorldCamera();
            ReleaseLocationTexture();
            ReleaseChapterTexture();
        }

        private void SuspendWorldCamera()
        {
            if (hiddenWorldCamera != null) return;
            // Only the opaque ScreenSpaceOverlay gallery is visible at this point.
            // Preserve the previous camera state; never enable a previously disabled camera.
            var camera = Camera.main;
            if (camera == null) return;
            hiddenWorldCamera = camera;
            worldCameraWasEnabled = camera.enabled;
            if (worldCameraWasEnabled) camera.enabled = false;
        }

        private void RestoreWorldCamera()
        {
            if (hiddenWorldCamera != null)
            {
                if (worldCameraWasEnabled) hiddenWorldCamera.enabled = true;
                hiddenWorldCamera = null;
            }
            worldCameraWasEnabled = false;
        }

        private void OnDisable()
        {
            if (galleryCanvas != null) galleryCanvas.SetActive(false);
            RestoreWorldCamera();
            ReleaseLocationTexture();
            ReleaseChapterTexture();
        }

        private void LateUpdate()
        {
            if (galleryCanvas != null && galleryCanvas.activeSelf)
                UpdateSafeAreaLayout();
        }

        private void UpdateSafeAreaLayout()
        {
            if (safeAreaRoot == null || layoutRoot == null || galleryScaler == null) return;
            int width = Screen.width;
            int height = Screen.height;
            if (width <= 0 || height <= 0) return;
            Rect safe = Screen.safeArea;
            safe.xMin = Mathf.Clamp(safe.xMin, 0f, width);
            safe.xMax = Mathf.Clamp(safe.xMax, 0f, width);
            safe.yMin = Mathf.Clamp(safe.yMin, 0f, height);
            safe.yMax = Mathf.Clamp(safe.yMax, 0f, height);
            if (safe.width <= 0f || safe.height <= 0f) safe = new Rect(0f, 0f, width, height);
            if (width == lastScreenWidth && height == lastScreenHeight && safe == lastSafeArea) return;
            lastScreenWidth = width;
            lastScreenHeight = height;
            lastSafeArea = safe;
            safeAreaRoot.anchorMin = new Vector2(safe.xMin / width, safe.yMin / height);
            safeAreaRoot.anchorMax = new Vector2(safe.xMax / width, safe.yMax / height);
            safeAreaRoot.offsetMin = Vector2.zero;
            safeAreaRoot.offsetMax = Vector2.zero;
            // Expand never crops the virtual canvas; uniformly shrink the fixed layout
            // only if safe-area insets leave less than the 1600x900 design bounds.
            float virtualScale = Mathf.Min(width / 1600f, height / 900f);
            float safeLogicalWidth = safe.width / Mathf.Max(virtualScale, .0001f);
            float safeLogicalHeight = safe.height / Mathf.Max(virtualScale, .0001f);
            float fit = Mathf.Min(1f, safeLogicalWidth / 1600f, safeLogicalHeight / 900f);
            layoutRoot.localScale = Vector3.one * Mathf.Max(.01f, fit);
        }

        private void ReleaseLocationTexture()
        {
            if (activeLocationTexture == null) return;
            if (artwork != null && artwork.texture == activeLocationTexture)
                artwork.texture = null;
            Resources.UnloadAsset(activeLocationTexture);
            activeLocationTexture = null;
            activeLocationTextureIndex = -1;
        }

        private void ReleaseChapterTexture()
        {
            if (activeChapterTextureIndex < 0) return;
            Texture2D previous = chapterTextures[activeChapterTextureIndex];
            if (artwork != null && artwork.texture == previous) artwork.texture = null;
            chapterTextures[activeChapterTextureIndex] = null;
            activeChapterTextureIndex = -1;
            if (previous != null) Resources.UnloadAsset(previous);
        }

        private Texture2D GetChapterTexture(int index)
        {
            if (index < 0 || index >= ChapterCount)
                throw new ArgumentOutOfRangeException(nameof(index));
            if (activeChapterTextureIndex == index && chapterTextures[index] != null)
                return chapterTextures[index];
            // Acquire before releasing the old image: a failed load must not leave
            // a stale native texture referenced by RawImage.
            Texture2D next = Resources.Load<Texture2D>("ChapterArt/Chapter_" + (index + 1).ToString("00"));
            if (next == null)
                throw new InvalidOperationException("Missing required chapter artwork: " + (index + 1));
            ReleaseChapterTexture();
            chapterTextures[index] = next;
            activeChapterTextureIndex = index;
            return next;
        }

        public void SelectChapter(int number)
        {
            if (number < 1 || number > ChapterCount)
                throw new ArgumentOutOfRangeException(nameof(number));
            if (galleryCanvas == null) Build();
            selectedIndex = number - 1;
            locationMode = false;
            Refresh();
        }

        private void Build()
        {
            if (!ValidateContentCatalog(out string catalogError))
                throw new InvalidOperationException(catalogError);
            galleryCanvas = new GameObject("Chapter Gallery", typeof(RectTransform), typeof(Canvas),
                typeof(CanvasScaler), typeof(GraphicRaycaster));
            galleryCanvas.transform.SetParent(transform, false);
            var canvas = galleryCanvas.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 120;
            var scaler = galleryCanvas.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1600f, 900f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
            galleryScaler = scaler;
            RectTransform canvasRoot = galleryCanvas.GetComponent<RectTransform>();
            // Modal shield must cover the entire physical screen, including unsafe edges.
            // Otherwise taps outside the safe layout could reach the 3D puzzle behind it.
            var shield = new GameObject("Gallery Input Shield", typeof(RectTransform), typeof(Image));
            var shieldRect = shield.GetComponent<RectTransform>();
            shieldRect.SetParent(canvasRoot, false);
            shieldRect.anchorMin = Vector2.zero;
            shieldRect.anchorMax = Vector2.one;
            shieldRect.offsetMin = shieldRect.offsetMax = Vector2.zero;
            var shieldImage = shield.GetComponent<Image>();
            shieldImage.color = new Color(.018f, .025f, .041f, 1f);
            shieldImage.raycastTarget = true;
            var safeAreaObject = new GameObject("Gallery Safe Area", typeof(RectTransform));
            safeAreaRoot = safeAreaObject.GetComponent<RectTransform>();
            safeAreaRoot.SetParent(canvasRoot, false);
            safeAreaRoot.anchorMin = Vector2.zero;
            safeAreaRoot.anchorMax = Vector2.one;
            safeAreaRoot.offsetMin = safeAreaRoot.offsetMax = Vector2.zero;
            var layoutObject = new GameObject("Gallery Layout", typeof(RectTransform));
            layoutRoot = layoutObject.GetComponent<RectTransform>();
            layoutRoot.SetParent(safeAreaRoot, false);
            layoutRoot.anchorMin = layoutRoot.anchorMax = new Vector2(.5f, .5f);
            layoutRoot.anchoredPosition = Vector2.zero;
            layoutRoot.sizeDelta = new Vector2(1600f, 900f);
            RectTransform root = layoutRoot;
            lastScreenWidth = -1;
            UpdateSafeAreaLayout();

            var backdrop = new GameObject("Gallery Backdrop", typeof(RectTransform), typeof(Image));
            var rect = backdrop.GetComponent<RectTransform>();
            rect.SetParent(root, false);
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = rect.offsetMax = Vector2.zero;
            backdrop.GetComponent<Image>().color = new Color(.018f, .025f, .041f, .99f);

            TextLabel("Gallery Header", root, "SABLE & SIGIL  |  CHAPTERS", new Vector2(0f, 367f),
                new Vector2(1350f, 75f), 34);

            var artObject = new GameObject("Selected Chapter Artwork", typeof(RectTransform), typeof(RawImage));
            artObject.transform.SetParent(root, false);
            var artRect = artObject.GetComponent<RectTransform>();
            artworkRect = artRect;
            artRect.anchorMin = artRect.anchorMax = new Vector2(.5f, .5f);
            artRect.anchoredPosition = new Vector2(-215f, 31f);
            artRect.sizeDelta = new Vector2(880f, 495f);
            artwork = artObject.GetComponent<RawImage>();
            artwork.color = Color.white;
            artwork.raycastTarget = false;

            heading = TextLabel("Selected Chapter Heading", root, "", new Vector2(530f, 206f),
                new Vector2(420f, 124f), 27);
            description = TextLabel("Selected Chapter Description", root, "", new Vector2(530f, 41f),
                new Vector2(415f, 194f), 21);
            availability = TextLabel("Selected Chapter Availability", root, "", new Vector2(530f, -124f),
                new Vector2(430f, 82f), 19);

            for (int i = 0; i < ChapterCount; i++)
            {
                int chapterNumber = i + 1;
                MakeButton(root, "Chapter " + chapterNumber, new Vector2(-568f + i * 275f, -304f),
                    () => SelectChapter(chapterNumber));
            }
            enterButton = MakeButton(root, "ENTER CHAPTER I", new Vector2(552f, -245f), Close);
            enterCaption = enterButton.GetComponentInChildren<Text>();
            sceneAtlasButton = MakeButton(root, "SCENE ATLAS", new Vector2(552f, 316f), () =>
            {
                locationMode = !locationMode;
                Refresh();
            });
            previousSceneButton = MakeButton(root, "PREVIOUS SCENE", new Vector2(-575f, -221f),
                () => NavigateLocation(-1));
            nextSceneButton = MakeButton(root, "NEXT SCENE", new Vector2(145f, -221f),
                () => NavigateLocation(1));
            MakeButton(root, "BACK TO GAME", new Vector2(552f, -332f), Close);
            galleryCanvas.SetActive(false);
        }

        private void NavigateLocation(int delta)
        {
            locationMode = true;
            locationIndex = (locationIndex + delta + LocationCount) % LocationCount;
            selectedIndex = GetChapterForLocation(locationIndex + 1) - 1;
            Refresh();
        }

        public void SelectLocation(int number)
        {
            if (number < 1 || number > LocationCount)
                throw new ArgumentOutOfRangeException(nameof(number));
            if (galleryCanvas == null) Build();
            locationMode = true;
            locationIndex = number - 1;
            selectedIndex = GetChapterForLocation(number) - 1;
            Refresh();
        }

        private void FitArtwork(Texture2D texture)
        {
            if (texture == null || artworkRect == null) return;
            const float viewportWidth = 880f;
            const float viewportHeight = 495f;
            float scale = Mathf.Min(viewportWidth / texture.width, viewportHeight / texture.height);
            artworkRect.sizeDelta = new Vector2(texture.width * scale, texture.height * scale);
        }

        private void Refresh()
        {
            // Scene navigation must never leak into the chapter-selection workflow.
            if (previousSceneButton != null) previousSceneButton.gameObject.SetActive(locationMode);
            if (nextSceneButton != null) nextSceneButton.gameObject.SetActive(locationMode);
            if (sceneAtlasButton != null)
            {
                var caption = sceneAtlasButton.GetComponentInChildren<Text>();
                if (caption != null) caption.text = locationMode ? "CHAPTERS" : "SCENE ATLAS";
            }
            if (locationMode)
            {
                if (activeLocationTexture == null || activeLocationTextureIndex != locationIndex)
                {
                    Texture2D next = Resources.Load<Texture2D>("LocationArt/Scene_" +
                        (locationIndex + 1).ToString("00"));
                    if (next == null)
                        throw new InvalidOperationException("Missing required location reference: " + (locationIndex + 1));
                    Texture2D previous = activeLocationTexture;
                    activeLocationTexture = next;
                    activeLocationTextureIndex = locationIndex;
                    // Detach the outgoing texture before unloading native image memory.
                    if (previous != null && previous != next)
                    {
                        if (artwork != null && artwork.texture == previous) artwork.texture = null;
                        Resources.UnloadAsset(previous);
                    }
                }
                Texture2D scene = activeLocationTexture;
                artwork.texture = scene;
                // The atlas and chapter selector are mutually exclusive views.
                // Do not retain a hidden chapter image while browsing locations.
                ReleaseChapterTexture();
                FitArtwork(scene);
                heading.text = "LOCATION " + (locationIndex + 1).ToString("00") + " / " + LocationCount +
                    "\n" + LocationNames[locationIndex];
                description.text = LocationDescriptions[locationIndex];
                enterButton.interactable = false;
                enterCaption.text = "REFERENCE ONLY";
                availability.text = "CHAPTER " + LocationChapters[locationIndex] +
                    "  |  ART & PUZZLE DESIGN\nNo playable location is implemented yet.";
                return;
            }
            Texture2D selectedChapterTexture = GetChapterTexture(selectedIndex);
            artwork.texture = selectedChapterTexture;
            ReleaseLocationTexture();
            FitArtwork(selectedChapterTexture);
            heading.text = "CHAPTER " + (selectedIndex + 1).ToString("00") + "\n" + ChapterNames[selectedIndex];
            description.text = ChapterDescriptions[selectedIndex];
            bool playable = selectedIndex == 0;
            enterButton.interactable = playable;
            enterCaption.text = playable ? "ENTER CHAPTER I" : "NOT YET PLAYABLE";
            availability.text = playable ? "PLAYABLE  |  START OR CONTINUE" :
                "ART CONCEPT  |  FUTURE CHAPTER\nNo playable scene is implemented yet.";
        }

        private static Text TextLabel(string name, Transform parent, string value, Vector2 position,
            Vector2 size, int fontSize)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Text));
            obj.transform.SetParent(parent, false);
            var rect = obj.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            var text = obj.GetComponent<Text>();
            text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            text.text = value;
            text.fontSize = fontSize;
            text.color = Parchment;
            text.alignment = TextAnchor.MiddleCenter;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            text.raycastTarget = false;
            return text;
        }

        private static Button MakeButton(Transform parent, string label, Vector2 position,
            UnityEngine.Events.UnityAction action)
        {
            var obj = new GameObject(label, typeof(RectTransform), typeof(Image), typeof(Button));
            obj.transform.SetParent(parent, false);
            var rect = obj.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f, .5f);
            rect.anchoredPosition = position;
            rect.sizeDelta = new Vector2(245f, 62f);
            obj.GetComponent<Image>().color = AntiqueBrass;
            var button = obj.GetComponent<Button>();
            button.onClick.AddListener(action);
            var text = TextLabel("Button Caption", obj.transform, label, Vector2.zero,
                new Vector2(235f, 58f), 19);
            text.color = new Color(.038f, .046f, .06f);
            return button;
        }

        private void OnDestroy()
        {
            RestoreWorldCamera();
            ReleaseLocationTexture();
            ReleaseChapterTexture();
            // Only the displayed image is retained while the gallery is open.
            if (galleryCanvas != null) Destroy(galleryCanvas);
        }
    }
}
