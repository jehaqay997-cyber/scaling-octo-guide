#!/usr/bin/env python3
import importlib.util
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('restore_guard', HERE / 'restore_integrity_gate_v433.py')
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class RestoreGuardMutationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = MODULE.SOURCE.read_text()
        cls.tests = MODULE.TESTS.read_text()

    def test_current_code_satisfies_guard(self):
        self.assertEqual([], MODULE.validate(self.source, self.tests))

    def test_removed_copy_is_detected(self):
        mutated = self.source.replace('candidate.Add(pair.Key, pair.Value);', '', 1)
        self.assertNotEqual([], MODULE.validate(mutated, self.tests))

    def test_premature_publication_is_detected(self):
        mutated = self.source.replace('locations = candidate; occupancy = counts;',
                                      'locations = candidate; occupancy = counts;', 1)
        start = mutated.index('private bool RestoreCore(')
        boundary = mutated.index('private bool ValidateSnapshot(', start)
        region = mutated[start:boundary]
        region = region.replace('locations = candidate; occupancy = counts;', '', 1)
        region = region.replace('candidate.Add(pair.Key, pair.Value);',
                                'candidate.Add(pair.Key, pair.Value);\n                    locations = candidate; occupancy = counts;', 1)
        mutated = mutated[:start] + region + mutated[boundary:]
        self.assertNotEqual([], MODULE.validate(mutated, self.tests))

    def test_missing_test_is_detected(self):
        altered = self.tests.replace('ValidSnapshotRestoresEveryItemAtomically', 'RenamedTest')
        self.assertNotEqual([], MODULE.validate(self.source, altered))


if __name__ == '__main__':
    unittest.main()
