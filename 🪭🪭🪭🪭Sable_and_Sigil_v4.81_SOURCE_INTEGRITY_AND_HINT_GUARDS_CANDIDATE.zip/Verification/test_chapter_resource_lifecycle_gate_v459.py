"""Mutation tests enforce the offline lifecycle gate's defensive contracts."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import chapter_resource_lifecycle_gate_v459 as gate


class ChapterResourceLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.chapter = (gate.ROOT / gate.CHAPTER).read_text()
        cls.gallery = (gate.ROOT / gate.GALLERY).read_text()
        cls.governor = (gate.ROOT / gate.GOVERNOR).read_text()
        cls.playmode = (gate.ROOT / gate.PLAYMODE).read_text()

    def valid(self, chapter=None, gallery=None, governor=None, playmode=None):
        return gate.validate(chapter if chapter is not None else self.chapter,
                             gallery if gallery is not None else self.gallery,
                             governor if governor is not None else self.governor,
                             playmode if playmode is not None else self.playmode)

    def test_current_contract(self):
        self.assertEqual([], self.valid())

    def test_missing_frame_governor_is_rejected(self):
        changed = self.chapter.replace('gameObject.AddComponent<OrderPerformanceGovernor>()',
                                       'gameObject.AddComponent<AudioListener>()')
        self.assertTrue(self.valid(chapter=changed))

    def test_missing_render_allocation_guard_is_rejected(self):
        changed = self.chapter.replace('!inspectionTarget.IsCreated() && !inspectionTarget.Create()', 'false')
        self.assertTrue(self.valid(chapter=changed))

    def test_missing_surface_release_is_rejected(self):
        changed = self.chapter.replace('if (inspectionTarget != null && inspectionTarget.IsCreated()) inspectionTarget.Release();', '')
        self.assertTrue(self.valid(chapter=changed))

    def test_missing_pause_handler_is_rejected(self):
        changed = self.chapter.replace('private void OnApplicationPause(bool paused)', 'private void OnApplicationPauseRemoved(bool paused)')
        self.assertTrue(self.valid(chapter=changed))

    def test_dangling_gallery_image_is_rejected(self):
        changed = self.gallery.replace('if (artwork != null && artwork.texture == previous) artwork.texture = null;', '')
        self.assertTrue(self.valid(gallery=changed))

    def test_missing_world_camera_restoration_is_rejected(self):
        changed = self.gallery.replace('if (worldCameraWasEnabled) hiddenWorldCamera.enabled = true;', '')
        self.assertTrue(self.valid(gallery=changed))

    def test_missing_playmode_acceptance_is_rejected(self):
        changed = self.playmode.replace('Assert.That(governor.isActiveAndEnabled, Is.True);', '')
        self.assertTrue(self.valid(playmode=changed))


if __name__ == '__main__':
    unittest.main()
