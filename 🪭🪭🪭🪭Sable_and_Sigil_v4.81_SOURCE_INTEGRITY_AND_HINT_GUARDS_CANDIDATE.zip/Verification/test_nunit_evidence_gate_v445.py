"""Mutation tests for the mandatory NUnit evidence acceptance contract."""
from __future__ import annotations

import unittest
from pathlib import Path

from nunit_evidence_gate_v445 import RUNNER, validate


class NunitEvidenceGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = RUNNER.read_text(encoding='utf-8-sig')

    def test_unmodified_runner_passes(self):
        self.assertEqual(validate(self.source), [])

    def test_missing_inconclusive_guard_is_detected(self):
        broken = self.source.replace("$values['inconclusive'] -ne 0", '$false')
        self.assertTrue(validate(broken))

    def test_missing_required_domain_fixture_is_detected(self):
        broken = self.source.replace("        'OrderBoardTests',\n", '')
        self.assertTrue(validate(broken))

    def test_missing_playmode_fixture_is_detected(self):
        broken = self.source.replace("@('IntegratedSceneSmokeTests')", '@()')
        self.assertTrue(validate(broken))

    def test_missing_case_count_check_is_detected(self):
        broken = self.source.replace("$cases.Count -ne $values['total']", '$false')
        self.assertTrue(validate(broken))

    def test_disabling_test_case_verification_is_detected(self):
        broken = self.source.replace("$testCase.GetAttribute('result') -ne 'Passed'", '$false')
        self.assertTrue(validate(broken))

    def test_missing_editmode_call_is_detected(self):
        broken = self.source.replace("Assert-NUnitEvidence $xml 'EditMode'", '# disabled')
        self.assertTrue(validate(broken))

    def test_missing_playmode_call_is_detected(self):
        broken = self.source.replace("Assert-NUnitEvidence $playXml 'PlayMode'", '# disabled')
        self.assertTrue(validate(broken))


if __name__ == '__main__':
    unittest.main()
