"""Mutation tests for redundant checkpoint prevention."""
import unittest
from pathlib import Path
from chapter_interaction_persistence_gate_v463 import evaluate

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = (ROOT / 'Assets/_Project/Runtime/ChapterOneExperience.cs').read_text(encoding='utf-8')
TESTS = (ROOT / 'Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs').read_text(encoding='utf-8')


class ChapterInteractionPersistenceGateTests(unittest.TestCase):
    def test_baseline(self):
        self.assertEqual([], evaluate(RUNTIME, TESTS))

    def test_unguarded_save_rejected(self):
        altered = RUNTIME.replace('if (progress.Flags != previousFlags || progress.DialValue != previousDial)\n                SaveProgress();', 'SaveProgress();')
        self.assertTrue(evaluate(altered, TESTS))

    def test_flags_only_check_rejected(self):
        altered = RUNTIME.replace('progress.Flags != previousFlags || progress.DialValue != previousDial', 'progress.Flags != previousFlags')
        self.assertTrue(evaluate(altered, TESTS))

    def test_duplicate_save_rejected(self):
        altered = RUNTIME.replace('if (progress.Flags != previousFlags || progress.DialValue != previousDial)\n                SaveProgress();', 'if (progress.Flags != previousFlags || progress.DialValue != previousDial)\n                SaveProgress();\n            SaveProgress();')
        self.assertTrue(evaluate(altered, TESTS))

    def test_missing_playmode_rejected(self):
        altered = TESTS.replace('HotspotInteractionsPersistOnlyDurablePuzzleChanges', 'TestDisabled')
        self.assertTrue(evaluate(RUNTIME, altered))


if __name__ == '__main__':
    unittest.main()
