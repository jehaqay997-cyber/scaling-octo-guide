"""Mutation regression coverage of Chapter One checkpoint contracts."""
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from chapter_checkpoint_gate_v457 import CONTRACTS, ROOT, check

class ChapterCheckpointGateTests(unittest.TestCase):
    def test_original_source(self):
        self.assertEqual(check(ROOT), [])

    def test_all_contracts_are_required(self):
        for changed, fragments in CONTRACTS.items():
            for fragment in fragments:
                with self.subTest(path=str(changed), contract=fragment), TemporaryDirectory() as dirname:
                    local = Path(dirname)
                    for item in CONTRACTS:
                        target = local / item
                        target.parent.mkdir(parents=True, exist_ok=True)
                        source = (ROOT / item).read_text(encoding='utf-8')
                        if item == changed:
                            source = source.replace(fragment, 'REMOVED_CHECKPOINT_CONTRACT')
                        target.write_text(source, encoding='utf-8')
                    self.assertTrue(check(local))

    def test_missing_source_fails_closed(self):
        with TemporaryDirectory() as dirname:
            self.assertTrue(check(Path(dirname)))

    def test_no_live_source_writes_legacy_multi_key_format(self):
        runtime = (ROOT / 'Assets/_Project/Runtime/ChapterOneExperience.cs').read_text()
        self.assertNotIn('PlayerPrefs.SetInt(SavePrefix + "Flags"', runtime)
        self.assertNotIn('PlayerPrefs.SetInt(SavePrefix + "Dial"', runtime)
        self.assertNotIn('PlayerPrefs.SetInt(SavePrefix + "Check"', runtime)

if __name__ == '__main__':
    unittest.main()
