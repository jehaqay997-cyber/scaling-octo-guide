#!/usr/bin/env python3
"""Mutation checks for source contracts, not execution of Unity gameplay."""
import unittest
from pathlib import Path
from fail_closed_session_gate_v438 import check

ROOT = Path(__file__).resolve().parents[1]
BOARD = (ROOT / "Assets/_Project/Domain/OrderBoard.cs").read_text(encoding="utf-8")
GAME = (ROOT / "Assets/_Project/Runtime/OrderGame.cs").read_text(encoding="utf-8")
TEST = (ROOT / "Assets/_Project/Tests/EditMode/BoardExternalDictionarySafetyTests.cs").read_text(encoding="utf-8")

class FailClosedSessionContractTests(unittest.TestCase):
    def test_unmodified_source_passes(self):
        self.assertEqual([], check(BOARD, GAME, TEST))

    def test_missing_dictionary_exception_handler_fails(self):
        corrupted = BOARD.replace("catch (NotSupportedException) { return false; }", "", 1)
        self.assertTrue(check(corrupted, GAME, TEST))

    def test_fail_open_saved_session_fails(self):
        corrupted = GAME.replace("saveSessionBlocked = true;\n                    selected = null;", "selected = null;", 1)
        self.assertTrue(check(BOARD, corrupted, TEST))

    def test_runtime_reset_after_rejection_fails(self):
        corrupted = GAME.replace("board = null;\n                    Debug.LogError", "board = null; LoadLevel(0);\n                    Debug.LogError", 1)
        self.assertTrue(check(BOARD, corrupted, TEST))

    def test_missing_regression_fails(self):
        self.assertTrue(check(BOARD, GAME, ""))

if __name__ == "__main__":
    unittest.main()
