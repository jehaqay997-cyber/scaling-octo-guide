#!/usr/bin/env python3
"""Mutation tests for the standalone content graph verifier."""
import copy
import importlib.util
import json
import pathlib
import unittest
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("content_graph", HERE / "verify_content_graph_v466.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class ContentGraphTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import sys
        with zipfile.ZipFile(sys.argv[-1]) as archive:
            cls.data = json.loads(archive.read(module.CATALOG))
            cls.images = {item["art"]: archive.read(item["art"]) for item in cls.data["puzzles"]}

    def check_invalid(self, mutate):
        data = copy.deepcopy(self.data)
        mutate(data)
        with self.assertRaises(ValueError):
            module.validate_catalog(data, self.images.__getitem__)

    def test_valid(self):
        self.assertEqual(module.validate_catalog(self.data, self.images.__getitem__)["puzzle_count"], 10)

    def test_duplicate_id(self):
        self.check_invalid(lambda d: d["puzzles"][1].update(id=d["puzzles"][0]["id"]))

    def test_duplicate_evidence(self):
        self.check_invalid(lambda d: d["puzzles"][1].update(evidence_id=d["puzzles"][0]["evidence_id"]))

    def test_missing_evidence(self):
        self.check_invalid(lambda d: d["puzzles"][1].update(prerequisites=["missing"]))

    def test_cycle(self):
        self.check_invalid(lambda d: d["puzzles"][0].update(prerequisites=[d["puzzles"][1]["evidence_id"]]))

    def test_self_dependency(self):
        self.check_invalid(lambda d: d["puzzles"][0].update(prerequisites=[d["puzzles"][0]["evidence_id"]]))

    def test_duplicate_dependency(self):
        self.check_invalid(lambda d: d["puzzles"][1].update(prerequisites=[d["puzzles"][0]["evidence_id"]] * 2))

    def test_art_integrity(self):
        self.check_invalid(lambda d: d["puzzles"][0].update(art_sha256="0" * 64))

    def test_unverified_runtime_claim(self):
        self.check_invalid(lambda d: d["puzzles"][0].update(runtime_binding="VERIFIED"))

    def test_bad_hint_count(self):
        self.check_invalid(lambda d: d["puzzles"][0].update(hint_tiers=[]))

    def test_future_chapter_dependency(self):
        def mutate(d):
            d["puzzles"][0]["prerequisites"] = [d["puzzles"][2]["evidence_id"]]
        self.check_invalid(mutate)

    def test_bad_chapter_count(self):
        self.check_invalid(lambda d: d.update(chapter_count=5))

if __name__ == "__main__":
    unittest.main(argv=["tests"], verbosity=2)
