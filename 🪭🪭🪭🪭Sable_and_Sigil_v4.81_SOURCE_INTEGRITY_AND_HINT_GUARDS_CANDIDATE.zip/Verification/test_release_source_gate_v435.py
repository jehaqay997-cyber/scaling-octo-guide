#!/usr/bin/env python3
"""Independent regression and mutation tests for release source governance."""
from __future__ import annotations

import copy
import importlib.util
import json
import shutil
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("release_gate", HERE / "release_source_gate_v435.py")
release_gate = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(release_gate)


class ReleaseSourceGateTests(unittest.TestCase):
    def setUp(self):
        self.source = HERE.parents[0]

    def test_current_source_passes_static_governance(self):
        report = release_gate.audit(self.source)
        self.assertEqual([], report["issues"])
        self.assertEqual("STATIC_PASS_ONLY", report["status"])
        self.assertFalse(report["unity_compilation_verified"])

    def test_assembly_dependency_drift_is_detected(self):
        defs = {}
        for path in (self.source / "Assets" / "_Project").rglob("*.asmdef"):
            data = json.loads(path.read_text(encoding="utf-8"))
            defs[data["name"]] = data
        altered = copy.deepcopy(defs)
        altered["TheOrderRoom.Domain"]["references"] = ["TheOrderRoom.Runtime"]
        problems = release_gate.check_assembly_graph(altered)
        self.assertTrue(any("Assembly dependency drift" in item for item in problems))
        self.assertTrue(any("cycle" in item for item in problems))

    def test_duplicate_reference_is_detected(self):
        defs = {}
        for path in (self.source / "Assets" / "_Project").rglob("*.asmdef"):
            data = json.loads(path.read_text(encoding="utf-8"))
            defs[data["name"]] = data
        altered = copy.deepcopy(defs)
        altered["TheOrderRoom.AppCore"]["references"].append("TheOrderRoom.Domain")
        self.assertTrue(any("dependency drift" in item for item in release_gate.check_assembly_graph(altered)))

    def test_external_package_or_floating_version_is_detected(self):
        self.assertTrue(release_gate.check_manifest({"dependencies": {"com.example.package": "file:../plugin"}}))
        self.assertTrue(release_gate.check_manifest({"dependencies": {"com.example.package": "latest"}}))
        self.assertEqual([], release_gate.check_manifest({"dependencies": {"com.example.package": "1.2.3"}}))

    def test_api_updater_mutation_is_detected(self):
        script = (self.source / "Verification" / "Run-UnityVerification.ps1").read_text(encoding="utf-8")
        self.assertEqual([], release_gate.check_runner(script))
        self.assertTrue(any("rewrite" in issue for issue in release_gate.check_runner(script + "\n-accept-apiupdate\n")))

    def test_missing_scene_lifecycle_validation_is_detected(self):
        source = (self.source / "Assets" / "_Project" / "Editor" / "OrderSceneValidator.cs").read_text(encoding="utf-8")
        self.assertEqual([], release_gate.check_scene_lifecycle(source))
        changed = source.replace('The pointer source must be active and enabled.', 'Pointer check removed')
        self.assertTrue(any("pointer source" in issue for issue in release_gate.check_scene_lifecycle(changed)))

    def test_duplicate_guids_and_missing_meta_are_detected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            shutil.copytree(self.source / "Assets", root / "Assets")
            shutil.copytree(self.source / "Packages", root / "Packages")
            shutil.copytree(self.source / "ProjectSettings", root / "ProjectSettings")
            (root / "Verification").mkdir()
            shutil.copy2(self.source / "Verification" / "Run-UnityVerification.ps1", root / "Verification")
            meta_files = sorted((root / "Assets").rglob("*.meta"))
            first = meta_files[0].read_text(encoding="utf-8")
            second = meta_files[1]
            second.write_text(first, encoding="utf-8")
            report = release_gate.audit(root)
            self.assertTrue(any("Duplicate Unity GUID" in issue for issue in report["issues"]))
            third = meta_files[2]
            third.unlink()
            report = release_gate.audit(root)
            self.assertTrue(any("Missing Unity meta" in issue for issue in report["issues"]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
