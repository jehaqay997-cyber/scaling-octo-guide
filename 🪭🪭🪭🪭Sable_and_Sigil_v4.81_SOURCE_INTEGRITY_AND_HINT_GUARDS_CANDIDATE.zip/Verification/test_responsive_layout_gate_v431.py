import unittest
from pathlib import Path
from responsive_layout_gate_v431 import verify, SOURCE


class ResponsiveLayoutGateTests(unittest.TestCase):
    def test_original_source_passes(self):
        self.assertEqual('STATIC_PASS_ONLY', verify()['status'])

    def test_slot_width_limits_are_enforced(self):
        source = SOURCE.read_text(encoding='utf-8')
        self.assertIn('availableLayoutWidth / slots * .86f', source)
        self.assertIn('PlaceInSlots(actions[i]', source)
        self.assertIn('PlaceInSlots(inspection[i]', source)

    def test_canvas_scaler_restoration_is_complete(self):
        source = SOURCE.read_text(encoding='utf-8')
        for statement in ('scaler.uiScaleMode = originalScaleMode;',
                          'scaler.matchWidthOrHeight = originalMatchWidthOrHeight;',
                          'scaler.referenceResolution = originalReferenceResolution;'):
            self.assertIn(statement, source)

    def test_landscape_lanes_have_no_overlap(self):
        rows = [(0.055, 44), (0.125, 44), (0.192, 36), (0.26, 45)]
        bounds = [(y * 720 - height / 2, y * 720 + height / 2) for y, height in rows]
        for left, right in zip(bounds, bounds[1:]):
            self.assertLessEqual(left[1], right[0])
        self.assertLessEqual(bounds[-1][1], 720 * .30)


if __name__ == '__main__':
    unittest.main()
