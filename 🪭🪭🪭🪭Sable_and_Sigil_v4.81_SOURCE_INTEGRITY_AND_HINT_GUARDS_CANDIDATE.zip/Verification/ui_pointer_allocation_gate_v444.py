#!/usr/bin/env python3
"""Static regression contract for non-allocating world-vs-UI raycasts.

This gate checks source structure only; it does not measure Unity GC allocations.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'Assets/_Project/Runtime/OrderGame.cs'


def check_source(contents: str) -> list[str]:
    errors: list[str] = []
    start = contents.find('private static bool IsScreenPointOverUi(Vector2 screenPoint)')
    end = contents.find('private bool CanUseWorld(', start)
    if start < 0 or end < 0:
        return ['UI raycast method is missing']
    method = contents[start:end]
    required = {
        'cached event reference': 'private static EventSystem cachedUiEventSystem;',
        'cached pointer reference': 'private static PointerEventData cachedUiPointerEvent;',
        'safe missing router': 'if (eventSystem == null || !eventSystem.isActiveAndEnabled) return true;',
        'recreate on router replacement': '!ReferenceEquals(cachedUiEventSystem, eventSystem)',
        'clear reusable data': 'cachedUiPointerEvent.Reset();',
        'set current pointer position': 'cachedUiPointerEvent.position = screenPoint;',
        'raycast using reused object': 'eventSystem.RaycastAll(cachedUiPointerEvent, UiRaycastHits);',
        'clear raycast results': 'finally { UiRaycastHits.Clear(); }',
        'release reference on destruction': 'cachedUiPointerEvent = null;',
    }
    for label, needle in required.items():
        scope = contents if label in (
            'cached event reference', 'cached pointer reference',
            'release reference on destruction'
        ) else method
        if needle not in scope:
            errors.append('Missing ' + label)
    if re.search(r'new\s+PointerEventData\s*\(', method) and not re.search(
        r'if\s*\(!ReferenceEquals\(cachedUiEventSystem,\s*eventSystem\)', method
    ):
        errors.append('Pointer event allocation is unconditional')
    if 'var data = new PointerEventData(eventSystem)' in method:
        errors.append('Legacy per-call allocation returned')
    return errors


def main() -> int:
    errors = check_source(SOURCE.read_text(encoding='utf-8'))
    for error in errors:
        print('FAIL: ' + error)
    if not errors:
        print('STATIC_PASS_ONLY: reusable UI pointer event contract')
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
