"""Mutation tests for launch readiness, independent from the Unity runtime."""
import importlib.util
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('chapter_runtime_readiness_gate_v458',
                                              HERE / 'chapter_runtime_readiness_gate_v458.py')
GATE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GATE)
EDITOR = (HERE.parent / 'Assets/_Project/Editor/OrderFirstImportSetup.cs').read_text(encoding='utf-8')
RUNTIME = (HERE.parent / 'Assets/_Project/Runtime/ChapterOneExperience.cs').read_text(encoding='utf-8')
PLAYMODE = (HERE.parent / 'Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs').read_text(encoding='utf-8')


class ChapterRuntimeReadinessTests(unittest.TestCase):
    def test_actual_contract_is_present(self):
        self.assertEqual([], GATE.validate(EDITOR, RUNTIME, PLAYMODE))

    def test_existence_only_check_is_rejected(self):
        broken = EDITOR.replace('chapter != null && chapter.isActiveAndEnabled && chapter.IsChapterReady',
                                'chapter != null')
        self.assertNotEqual(broken, EDITOR)
        self.assertTrue(GATE.validate(broken, RUNTIME, PLAYMODE))

    def test_disabled_component_is_rejected(self):
        broken = EDITOR.replace('chapter.isActiveAndEnabled && ', '')
        self.assertNotEqual(broken, EDITOR)
        self.assertTrue(GATE.validate(broken, RUNTIME, PLAYMODE))

    def test_failed_runtime_initialization_is_rejected(self):
        broken = RUNTIME.replace('initialized = true;', 'initialized = false;')
        self.assertNotEqual(broken, RUNTIME)
        self.assertTrue(GATE.validate(EDITOR, broken, PLAYMODE))

    def test_missing_playmode_verification_is_rejected(self):
        broken = PLAYMODE.replace('Assert.That(chapters[0].IsChapterReady, Is.True',
                                  'Assert.That(chapters[0].IsChapterReady, Is.False')
        self.assertNotEqual(broken, PLAYMODE)
        self.assertTrue(GATE.validate(EDITOR, RUNTIME, broken))

    def test_gate_is_in_unified_audit(self):
        audit = (HERE / 'run_full_static_audit_v443.py').read_text(encoding='utf-8')
        self.assertEqual(audit.count('"chapter_runtime_readiness_gate_v458.py",'), 1)


if __name__ == '__main__':
    unittest.main()
