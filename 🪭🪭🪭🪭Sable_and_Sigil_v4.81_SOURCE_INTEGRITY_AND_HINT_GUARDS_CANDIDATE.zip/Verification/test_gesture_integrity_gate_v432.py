#!/usr/bin/env python3
"""Mutation-based tests for the static gesture contract auditor."""
import unittest
from pathlib import Path
from gesture_integrity_gate_v432 import GAME_PATH, inspect


class GestureIntegrityGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = GAME_PATH.read_text(encoding='utf-8-sig')

    def test_source_passes(self):
        self.assertEqual(inspect(self.source), [])

    def test_wrong_release_target_fails(self):
        broken = self.source.replace('HandleWorldTap(tapPosition)', 'HandleWorldTap(point)', 1)
        self.assertIn('tap_anchored_to_press', inspect(broken))

    def test_ui_release_filter_missing_fails(self):
        broken = self.source.replace('bool overUi = IsScreenPointOverUi(point);',
                                     'bool overUi = dragged && IsScreenPointOverUi(point);', 1)
        self.assertIn('ui_release_rejected', inspect(broken))

    def test_failed_selection_must_not_place(self):
        broken = self.source.replace('if (!TrySelectItem(itemId)) return;', 'TrySelectItem(itemId);', 1)
        self.assertIn('selection_failure_blocks_place', inspect(broken))

    def test_drag_requires_captured_item(self):
        broken = self.source.replace('if (gestureItem == null) return;', 'if (false) return;', 1)
        self.assertIn('drag_requires_item', inspect(broken))


if __name__ == '__main__':
    unittest.main()
