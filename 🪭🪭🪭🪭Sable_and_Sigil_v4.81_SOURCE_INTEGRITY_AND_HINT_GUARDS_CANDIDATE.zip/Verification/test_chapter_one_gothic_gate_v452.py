"""Mutation-style regression tests for the Chapter One source acceptance gate."""
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from chapter_one_gothic_gate_v452 import inspect


class GothicChapterGateTests(unittest.TestCase):
    def test_real_source_passes(self):
        self.assertEqual(inspect(), [])

    def test_missing_runtime_fails(self):
        with TemporaryDirectory() as directory:
            failures = inspect(Path(directory))
            self.assertTrue(any("Missing or empty" in failure for failure in failures))

    def test_missing_narrative_hint_fails(self):
        root = Path(__file__).resolve().parents[1]
        code = (root / "Assets/_Project/Runtime/ChapterOneExperience.cs").read_text()
        self.assertIn("ShowContextHint", code)
        self.assertIn('Action("hint", "STORY HINT"', code)

    def test_camera_and_light_have_frame_updates(self):
        root = Path(__file__).resolve().parents[1]
        code = (root / "Assets/_Project/Runtime/ChapterOneExperience.cs").read_text()
        self.assertIn("AnimateEnvironment();", code)
        self.assertIn("Time.deltaTime", code)
        self.assertIn("lanternLight.intensity", code)

    def test_chapter_is_the_build_entry_point(self):
        root = Path(__file__).resolve().parents[1]
        builder = (root / "Assets/_Project/Editor/ChapterOneSceneBuilder.cs").read_text()
        self.assertIn("new EditorBuildSettingsScene(ScenePath, true)", builder)


if __name__ == "__main__":
    unittest.main()
