#!/usr/bin/env python3
"""Repeatable source integrity and independent state-space verification.
No C# compile/Unity/NUnit claims are made by this tool.
"""
import hashlib
import json
import pathlib
import re
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parents[1]
project = root / 'Assets' / '_Project'
failures = []
ids = {}
for meta in project.rglob('*.meta'):
    data = meta.read_text(encoding='utf-8-sig')
    match = re.search(r'^guid: ([0-9a-f]{32})$', data, re.M)
    if not match:
        failures.append('Missing GUID: ' + str(meta.relative_to(root)))
    elif match.group(1) in ids:
        failures.append('Duplicate GUID: '+str(meta.relative_to(root))+' and '+ids[match.group(1)])
    else:
        ids[match.group(1)] = str(meta.relative_to(root))
for code in project.rglob('*.cs'):
    if not pathlib.Path(str(code) + '.meta').is_file():
        failures.append('Missing source .meta: ' + str(code.relative_to(root)))
assemblies = {}
for asmdef in project.rglob('*.asmdef'):
    try:
        a = json.loads(asmdef.read_text())
        name = a['name']
        if name in assemblies:
            failures.append('Duplicate asmdef name: ' + name)
        assemblies[name] = a
    except (KeyError, ValueError) as error:
        failures.append('Invalid asmdef: '+str(asmdef)+' '+str(error))
for name, asm in assemblies.items():
    for dependency in asm.get('references', []):
        if dependency.startswith('TheOrderRoom.') and dependency not in assemblies:
            failures.append('Missing assembly dependency: '+name+' -> '+dependency)
for name in ('TheOrderRoom.Domain','TheOrderRoom.AppCore','TheOrderRoom.Infrastructure'):
    if not assemblies.get(name,{}).get('noEngineReferences'):
        failures.append('Unity engine dependency not forbidden: '+name)
for cs in (project/'Domain').glob('*.cs'):
    if re.search(r'^\s*using\s+Unity(?:Engine|Editor)',cs.read_text(), re.M):
        failures.append('Unity dependency in Domain: '+cs.name)
model = subprocess.run([sys.executable, str(root/'Verification/independent_adventure_oracle.py')],
                       capture_output=True, text=True, check=False)
try:
    oracle = json.loads(model.stdout)
except json.JSONDecodeError:
    oracle = None
    failures.append('Python oracle did not produce valid JSON: '+model.stderr)
if model.returncode or not oracle:
    failures.append('Python oracle execution failed')
elif oracle.get('softlocked_states') != 0 or oracle.get('reachable_states') != 20 or oracle.get('transitions') != 34:
    failures.append('Unexpected oracle state-space results')
files = sorted(f for f in root.rglob('*') if f.is_file() and not f.name.startswith('.'))
result = {
    'verification_version': 'v4.20',
    'status': 'STATIC_PASS' if not failures else 'STATIC_FAIL',
    'file_count': len(files),
    'csharp_file_count': sum(f.suffix == '.cs' for f in files),
    'asmdef_count': len(assemblies),
    'independent_oracle': oracle,
    'failures': failures,
    'unity_compiled': False,
    'nunit_executed': False,
    'device_verified': False,
    'limitations': ['Independent Python model does not execute production C#.',
                    'Journal store requires C# compilation and fault-injection on the target platform.',
                    'Local SHA-256 journal integrity is not authentication against tampering.']
}
print(json.dumps(result, indent=2))
sys.exit(1 if failures else 0)
