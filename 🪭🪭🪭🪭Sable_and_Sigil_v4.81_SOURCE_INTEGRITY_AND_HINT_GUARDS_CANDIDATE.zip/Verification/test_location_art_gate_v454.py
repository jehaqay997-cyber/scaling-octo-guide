import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import location_art_gate_v454 as gate


class LocationArtGateTests(unittest.TestCase):
    def test_real_source_passes(self):
        self.assertEqual(gate.verify(gate.ROOT), [])

    def test_missing_image_fails(self):
        normal = Path.is_file
        with patch.object(Path, 'is_file', autospec=True) as check:
            check.side_effect = lambda p: False if p.name == 'Scene_01.jpg' else normal(p)
            self.assertTrue(gate.verify(gate.ROOT))

    def test_images_are_not_marked_playable(self):
        self.assertIn('VISUAL_REFERENCE_ONLY', (gate.ROOT / 'Design/LOCATION_ART_AND_PUZZLE_MAP_v4.54.json').read_text())

    def test_scene_gallery_enforces_aspect_ratio(self):
        source = (gate.ROOT / 'Assets/_Project/Runtime/ChapterGalleryView.cs').read_text()
        self.assertIn('Mathf.Min(viewportWidth / texture.width, viewportHeight / texture.height)', source)


if __name__ == '__main__':
    unittest.main()
