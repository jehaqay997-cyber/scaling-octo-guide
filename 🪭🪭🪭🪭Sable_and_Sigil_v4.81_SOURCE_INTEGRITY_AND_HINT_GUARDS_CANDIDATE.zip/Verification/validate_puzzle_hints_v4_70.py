#!/usr/bin/env python3
"""Validate authored puzzle hints against their source contract and asset hashes."""
import hashlib
import json
import pathlib
import sys


def validate(root):
    root = pathlib.Path(root)
    contract = json.loads((root / "Design/SCENE_PUZZLE_CONTRACT_v4.65.json").read_text(encoding="utf-8"))
    authored = json.loads((root / "Design/PUZZLE_HINT_AUTHORING_v4.70.json").read_text(encoding="utf-8"))
    puzzles = contract["puzzles"]
    entries = authored["entries"]
    if len(puzzles) != 10 or len(entries) != len(puzzles):
        raise ValueError("Unexpected puzzle or hint count")
    if len({entry["id"] for entry in entries}) != len(entries):
        raise ValueError("Duplicate puzzle IDs")
    by_id = {entry["id"]: entry for entry in entries}
    evidence = set()
    for puzzle in puzzles:
        entry = by_id.get(puzzle["id"])
        if entry is None:
            raise ValueError("Missing puzzle hints")
        for field in ("chapter", "art", "art_sha256", "prerequisites", "evidence_id"):
            if entry[field] != puzzle[field]:
                raise ValueError("Contract mismatch: " + puzzle["id"] + ":" + field)
        tiers = entry["hint_tiers"]
        if len(tiers) != 3 or any(not isinstance(t, str) or not t.strip() for t in tiers):
            raise ValueError("Invalid hint tiers")
        if len(set(tiers)) != 3:
            raise ValueError("Duplicate hint tiers")
        if not set(entry["prerequisites"]).issubset(evidence):
            raise ValueError("Unresolved prerequisite")
        art = root / entry["art"]
        if not art.is_file() or hashlib.sha256(art.read_bytes()).hexdigest() != entry["art_sha256"]:
            raise ValueError("Artwork missing or hash mismatch: " + str(art))
        evidence.add(entry["evidence_id"])
    return len(entries)


if __name__ == "__main__":
    try:
        print("Validated puzzle hints:", validate(sys.argv[1] if len(sys.argv) > 1 else "."))
    except (ValueError, KeyError, OSError, json.JSONDecodeError) as error:
        print("VALIDATION_FAILED:", error, file=sys.stderr)
        sys.exit(1)
