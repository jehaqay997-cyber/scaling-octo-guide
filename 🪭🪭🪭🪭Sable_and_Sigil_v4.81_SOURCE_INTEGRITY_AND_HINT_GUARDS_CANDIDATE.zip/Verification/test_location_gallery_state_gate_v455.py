import shutil
import tempfile
import unittest
from pathlib import Path
from location_gallery_state_gate_v455 import check, SOURCE, PLAYMODE

ROOT = Path(__file__).resolve().parents[1]


class LocationGalleryStateContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        for relative in (SOURCE, PLAYMODE):
            dest = self.root / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / relative, dest)

    def tearDown(self):
        self.tmp.cleanup()

    def test_real_project_contract(self):
        self.assertEqual(check(ROOT), [])

    def test_missing_navigation_visibility_contract_is_rejected(self):
        target = self.root / SOURCE
        target.write_text(target.read_text().replace(
            'nextSceneButton.gameObject.SetActive(locationMode)',
            'nextSceneButton.gameObject.SetActive(true)'))
        self.assertTrue(check(self.root))

    def test_missing_playmode_evidence_is_rejected(self):
        target = self.root / PLAYMODE
        target.write_text(target.read_text().replace(
            'sceneNavigation.gameObject.activeSelf, Is.False',
            'sceneNavigation.gameObject.activeSelf, Is.Null'))
        self.assertTrue(check(self.root))


if __name__ == '__main__':
    unittest.main()
