"""Coverage contract for the current consolidated source audit."""
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / "Verification" / "run_full_static_audit_v443.py"
SPEC = importlib.util.spec_from_file_location("audit443", PATH)
AUDIT = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(AUDIT)


class FullAuditContractTests(unittest.TestCase):
    def test_all_gate_sources_are_present(self):
        for gate in AUDIT.GATES:
            self.assertTrue((ROOT / "Verification" / gate).is_file(), gate)

    def test_last_release_guards_are_included(self):
        for required in ("release_source_gate_v435.py", "final_integrity_gate_v436.py",
                         "fail_closed_session_gate_v438.py", "ui_event_delivery_gate_v439.py",
                         "playmode_release_gate_v440.py", "unity_first_run_gate_v447.py"):
            self.assertIn(required, AUDIT.GATES)

    def test_pytest_suite_always_runs_last(self):
        commands = AUDIT.commands()
        self.assertEqual(len(commands), len(AUDIT.GATES) + 1)
        self.assertEqual(commands[-1][1:4], ("-m", "unittest", "discover"))


if __name__ == "__main__":
    unittest.main()
