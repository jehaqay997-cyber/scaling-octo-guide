#!/usr/bin/env python3
"""Check all approved user location images and prevent false scene activation (static only)."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]


def verify(root: Path) -> list[str]:
    issues = []
    catalog_path = root / "Design/LOCATION_ART_AND_PUZZLE_MAP_v4.54.json"
    try:
        document = json.loads(catalog_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return ["Location catalog unavailable: " + str(exc)]
    scenes = document.get("scenes", [])
    if len(scenes) != 10 or [x.get("scene") for x in scenes] != list(range(1, 11)):
        issues.append("Scene order/count mismatch")
    if document.get("image_policy") != "FULL_SUBJECT_CONTAIN_16_9_NO_STRETCH":
        issues.append("Image policy mismatch")
    unique_hashes = set()
    for item in scenes:
        index = item.get("scene")
        if not isinstance(index, int) or not 1 <= index <= 10:
            issues.append("Invalid scene number")
            continue
        expected = f"Assets/_Project/Resources/LocationArt/Scene_{index:02d}.jpg"
        if item.get("asset") != expected:
            issues.append(f"Scene {index} path mismatch")
        file = root / expected
        meta = root / (expected + ".meta")
        original = root / "Design/LocationSourceReferences" / item.get("source", "missing")
        if not file.is_file() or file.stat().st_size < 10_000:
            issues.append(f"Scene {index} image missing or empty")
            continue
        if not original.is_file() or original.stat().st_size < 10_000:
            issues.append(f"Scene {index} original missing")
        if not meta.is_file() or not re.search(r"(?m)^guid: [0-9a-f]{32}$", meta.read_text()):
            issues.append(f"Scene {index} meta missing")
        with Image.open(file) as im:
            if im.size != (1280,720):
                issues.append(f"Scene {index} wrong aspect ratio")
            im.verify()
        digest = hashlib.sha256(file.read_bytes()).hexdigest()
        if digest != item.get("sha256") or digest in unique_hashes:
            issues.append(f"Scene {index} hash issue")
        unique_hashes.add(digest)
        if item.get("implementation") != "VISUAL_REFERENCE_ONLY":
            issues.append(f"Scene {index} falsely marked playable")
        if not isinstance(item.get("story"), str) or not item["story"].strip():
            issues.append(f"Scene {index} missing story")
        if not isinstance(item.get("proposed_puzzle"), str) or not item["proposed_puzzle"].strip():
            issues.append(f"Scene {index} missing puzzle concept")
    gallery = (root / "Assets/_Project/Runtime/ChapterGalleryView.cs").read_text()
    tests = (root / "Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs").read_text()
    for token in ('LocationCount = 10', 'Resources.Load<Texture2D>("LocationArt/Scene_"',
                  'FitArtwork(Texture2D texture)', 'Mathf.Min(viewportWidth / texture.width, viewportHeight / texture.height)',
                  'enterButton.interactable = false;', 'No playable location is implemented yet.'):
        if token not in gallery:
            issues.append("Gallery missing contract: " + token)
    for token in ('LocationAtlasHasTenImagesAndNoFalsePlayability',
                  'gallery.SelectLocation(i)', 'Is.EqualTo(1280)', 'Is.False', 'rect.sizeDelta.x / rect.sizeDelta.y'):
        if token not in tests:
            issues.append("PlayMode contract missing: " + token)
    return issues


if __name__ == "__main__":
    problems = verify(ROOT)
    print(json.dumps({"status": "STATIC_PASS_ONLY" if not problems else "FAIL",
                      "user_reference_scenes": 10, "unity_executed": False,
                      "problems": problems}, indent=2))
    raise SystemExit(bool(problems))
