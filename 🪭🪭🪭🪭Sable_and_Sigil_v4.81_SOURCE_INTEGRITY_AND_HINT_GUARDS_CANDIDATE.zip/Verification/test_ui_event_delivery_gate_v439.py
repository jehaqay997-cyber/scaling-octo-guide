"""Mutation tests: verify the gate rejects disabled UI dispatch paths."""
import unittest
from pathlib import Path

from ui_event_delivery_gate_v439 import inspect

SOURCE = (Path(__file__).resolve().parent.parent / "Assets/_Project/Editor/OrderSceneValidator.cs").read_text(encoding="utf-8")


class UIEventDeliveryGateTests(unittest.TestCase):
    def test_original_contract(self):
        self.assertEqual([], inspect(SOURCE))

    def test_disabled_input_module_check_removed(self):
        damaged = SOURCE.replace("!module.isActiveAndEnabled", "module == null")
        self.assertIn("input_module_enabled", inspect(damaged))

    def test_missing_raycaster_check_removed(self):
        damaged = SOURCE.replace("canvas.TryGetComponent<GraphicRaycaster>(out var raycaster)", "canvas.gameObject.activeSelf")
        self.assertIn("canvas_raycaster", inspect(damaged))

    def test_missing_button_raycast_check_removed(self):
        damaged = SOURCE.replace("!button.targetGraphic.raycastTarget", "false")
        self.assertIn("button_target_graphic", inspect(damaged))

    def test_missing_button_parent_canvas_check_removed(self):
        damaged = SOURCE.replace("button.GetComponentInParent<Canvas>()", "button.GetComponent<Canvas>()")
        self.assertIn("button_canvas_raycaster", inspect(damaged))

    def test_duplicate_ui_modules_check_removed(self):
        damaged = SOURCE.replace("GetComponents<BaseInputModule>().Count(x => x.isActiveAndEnabled) != 1", "false")
        self.assertIn("single_active_module", inspect(damaged))


if __name__ == "__main__":
    unittest.main()
