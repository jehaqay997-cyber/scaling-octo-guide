import shutil
import tempfile
import unittest
from pathlib import Path
from chapter_art_linkage_gate_v453 import ROOT, jpeg_size, verify


class ChapterArtLinkageTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.root = Path(self.folder.name)
        for rel in ["Design/CHAPTER_VISUAL_CATALOG_v4.53.json",
                    "Assets/_Project/Runtime/ChapterGalleryView.cs",
                    "Assets/_Project/Runtime/ChapterOneExperience.cs",
                    "Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs"]:
            target = self.root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / rel, target)
        for i in range(1, 5):
            rel = f"Assets/_Project/Resources/ChapterArt/Chapter_{i:02d}.jpg"
            target = self.root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / rel, target)
            shutil.copyfile(ROOT / (rel + ".meta"), Path(str(target)+".meta"))

    def tearDown(self):
        self.folder.cleanup()

    def test_original_passes(self):
        self.assertEqual(verify(self.root), [])

    def test_missing_art_fails(self):
        (self.root / "Assets/_Project/Resources/ChapterArt/Chapter_02.jpg").unlink()
        self.assertTrue(verify(self.root))

    def test_mutated_image_fails_checksum(self):
        path = self.root / "Assets/_Project/Resources/ChapterArt/Chapter_03.jpg"
        path.write_bytes(path.read_bytes() + b"altered")
        self.assertTrue(any("SHA256" in e for e in verify(self.root)))

    def test_unlocked_future_button_fails(self):
        path = self.root / "Assets/_Project/Runtime/ChapterGalleryView.cs"
        path.write_text(path.read_text().replace("enterButton.interactable = playable", "enterButton.interactable = true"))
        self.assertTrue(any("Gallery interaction contract" in e for e in verify(self.root)))

    def test_unlinked_button_fails(self):
        path = self.root / "Assets/_Project/Runtime/ChapterOneExperience.cs"
        path.write_text(path.read_text().replace('Action("chapters", "CHAPTERS"','Action("chapters", "MAP"'))
        self.assertTrue(any("scene integration" in e for e in verify(self.root)))


if __name__ == "__main__":
    unittest.main()
