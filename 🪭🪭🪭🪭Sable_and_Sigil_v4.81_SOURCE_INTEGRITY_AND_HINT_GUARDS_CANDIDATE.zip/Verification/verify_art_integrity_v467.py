#!/usr/bin/env python3
"""Validate chapter art decode, geometry, evidence hashes and metadata. Static only."""
import hashlib
import io
import json
import sys
import zipfile
from PIL import Image, UnidentifiedImageError

CATALOG = "Design/SCENE_PUZZLE_CONTRACT_v4.65.json"

def inspect(archive):
    records = json.loads(archive.read(CATALOG))["puzzles"]
    seen = set()
    result = []
    for record in records:
        path = record["art"]
        if path in seen:
            raise ValueError("Duplicate art path")
        seen.add(path)
        if not path.startswith("Assets/_Project/Resources/LocationArt/") or ".." in path.split("/"):
            raise ValueError("Invalid art path")
        raw = archive.read(path)
        if hashlib.sha256(raw).hexdigest() != record["art_sha256"]:
            raise ValueError("Artwork digest mismatch")
        try:
            with Image.open(io.BytesIO(raw)) as image:
                image.verify()
            with Image.open(io.BytesIO(raw)) as image:
                width, height, fmt = image.width, image.height, image.format
        except (OSError, UnidentifiedImageError) as exc:
            raise ValueError("Corrupt artwork") from exc
        if fmt not in ("JPEG", "PNG") or width < 1280 or height < 720:
            raise ValueError("Unsupported or undersized artwork")
        result.append({"id": record["id"], "width": width, "height": height, "format": fmt})
    return result

def validate(path):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError("Archive CRC failure")
        return inspect(archive)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python verify_art_integrity_v467.py <archive.zip>")
    print(json.dumps(validate(sys.argv[1]), indent=2))
