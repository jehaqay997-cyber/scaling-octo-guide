import collections
import random
import shutil
import tempfile
import unittest
from pathlib import Path
import interaction_energy_gate_v437 as gate


class EnergyContractTests(unittest.TestCase):
    def test_baseline(self):
        self.assertEqual([], gate.inspect())

    def test_detects_shifting_history(self):
        self._mutation('Assets/_Project/Domain/EnergyPuzzle.cs',
                       'history.Push((int[])ports.Clone());',
                       'history.Add((int[])ports.Clone());')

    def test_detects_missing_selection_invalidation(self):
        self._mutation('Assets/_Project/Runtime/OrderGame.cs',
                       '            selected = null;\n            if (!isActiveAndEnabled',
                       '            if (!isActiveAndEnabled')

    def test_detects_missing_reset(self):
        self._mutation('Assets/_Project/Domain/EnergyPuzzle.cs',
                       'Array.Copy(initial, ports, 9); history.Clear(); Revision++; return true;',
                       'Array.Copy(initial, ports, 9); Revision++; return true;')

    def _mutation(self, relative, original, changed):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for rel in ('Assets/_Project/Domain/EnergyPuzzle.cs',
                        'Assets/_Project/Runtime/OrderGame.cs',
                        'Assets/_Project/Domain/BoundedHistory.cs'):
                dest = root / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(gate.ROOT / rel, dest)
            file = root / relative
            text = file.read_text()
            self.assertIn(original, text)
            file.write_text(text.replace(original, changed, 1))
            self.assertTrue(gate.inspect(root))

    def test_bounded_history_differential_model(self):
        rng = random.Random(437)
        for capacity in (1, 2, 3, 8, 64, 128):
            ring = [None] * capacity
            oldest = 0
            count = 0
            reference = collections.deque(maxlen=capacity)
            for iteration in range(20000):
                action = rng.randrange(4)
                if action in (0, 1):
                    value = rng.randint(-1000000, 1000000)
                    if count < capacity:
                        ring[(oldest + count) % capacity] = value
                        count += 1
                    else:
                        ring[oldest] = value
                        oldest = (oldest + 1) % capacity
                    reference.append(value)
                elif action == 2 and reference:
                    slot = (oldest + count - 1) % capacity
                    self.assertEqual(reference.pop(), ring[slot])
                    ring[slot] = None
                    count -= 1
                    if count == 0:
                        oldest = 0
                else:
                    ring = [None] * capacity
                    oldest = count = 0
                    reference.clear()
                self.assertEqual(len(reference), count)
                if count:
                    self.assertEqual(reference[-1], ring[(oldest + count - 1) % capacity])


if __name__ == '__main__':
    unittest.main()
