#!/usr/bin/env python3
"""Static contract for reliable Windows launch and a visible Unity board.

Does not execute PowerShell, Unity, or an Android build.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def validate(launcher: str, batch: str, smoke_test: str) -> list[str]:
    requirements = {
        "launcher validates project structure": 'Assert-ProjectRoot $root' in launcher,
        "launcher reads required editor version": 'Get-RequiredVersion $root' in launcher,
        "launcher checks executable version": 'Assert-UnityEditorVersion $UnityEditorPath $requiredVersion' in launcher,
        "launcher refuses editor version mismatch": 'throw "Editor version mismatch.' in launcher,
        "launcher compares exact editor version": '$versions[0] -cne $RequiredVersion' in launcher,
        "launcher rejects failed version query": '$exitCode -ne 0' in launcher,
        "launcher opens the actual extracted project": 'Start-Process -FilePath $UnityEditorPath' in launcher
        and "'-projectPath'" in launcher,
        "batch launcher delegates to guarded launcher": 'OPEN_GAME.ps1' in batch
        and '-ExecutionPolicy Bypass' in batch,
        "PlayMode test checks visible pieces": 'renderedPieces.Length, Is.GreaterThan(0)' in smoke_test,
        "PlayMode test checks usable session": 'Does.Not.Contain("Session blocked")' in smoke_test,
        "PlayMode test checks status": 'statusTexts[0].text, Is.Not.Empty' in smoke_test,
    }
    return [f"Missing Unity first-run contract: {name}" for name, present in requirements.items() if not present]


def main() -> int:
    paths = [ROOT / 'OPEN_GAME.ps1', ROOT / 'OPEN_GAME.cmd',
             ROOT / 'Assets/_Project/Tests/PlayMode/IntegratedSceneSmokeTests.cs']
    missing = [str(p.relative_to(ROOT)) for p in paths if not p.is_file()]
    if missing:
        for file in missing:
            print('FAIL: Missing file:', file)
        return 1
    errors = validate(*(p.read_text(encoding='utf-8') for p in paths))
    for error in errors:
        print('FAIL:', error)
    if not errors:
        print('STATIC_PASS_ONLY: Windows version gate and live-scene readiness contract')
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
