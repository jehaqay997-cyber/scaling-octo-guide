"""Regression checks for the Windows Unity launcher and PlayMode readiness gate."""
import importlib.util
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('unity_first_run_gate_v447', HERE / 'unity_first_run_gate_v447.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
ROOT = HERE.parent
LAUNCHER = (ROOT / 'OPEN_GAME.ps1').read_text(encoding='utf-8')
BATCH = (ROOT / 'OPEN_GAME.cmd').read_text(encoding='utf-8')
SMOKE = (ROOT / 'Assets/_Project/Tests/PlayMode/IntegratedSceneSmokeTests.cs').read_text(encoding='utf-8')


class UnityFirstRunGateTests(unittest.TestCase):
    def test_baseline_passes(self):
        self.assertEqual([], module.validate(LAUNCHER, BATCH, SMOKE))

    def test_missing_version_check_is_rejected(self):
        changed = LAUNCHER.replace('Assert-UnityEditorVersion $UnityEditorPath $requiredVersion', '')
        self.assertTrue(module.validate(changed, BATCH, SMOKE))

    def test_missing_project_validation_is_rejected(self):
        changed = LAUNCHER.replace('Assert-ProjectRoot $root', '')
        self.assertTrue(module.validate(changed, BATCH, SMOKE))

    def test_missing_visible_pieces_assertion_is_rejected(self):
        changed = SMOKE.replace('renderedPieces.Length, Is.GreaterThan(0)', '')
        self.assertTrue(module.validate(LAUNCHER, BATCH, changed))

    def test_missing_blocked_session_assertion_is_rejected(self):
        changed = SMOKE.replace('Does.Not.Contain("Session blocked")', '')
        self.assertTrue(module.validate(LAUNCHER, BATCH, changed))

    def test_batch_bypass_is_rejected(self):
        changed = BATCH.replace('-ExecutionPolicy Bypass', '')
        self.assertTrue(module.validate(LAUNCHER, changed, SMOKE))

    def test_first_run_gate_is_in_full_audit(self):
        import importlib.util
        audit_path = HERE / 'run_full_static_audit_v443.py'
        audit_spec = importlib.util.spec_from_file_location('all_release_gates', audit_path)
        audit_module = importlib.util.module_from_spec(audit_spec)
        audit_spec.loader.exec_module(audit_module)
        self.assertEqual(audit_module.GATES.count('unity_first_run_gate_v447.py'), 1)
        self.assertEqual(len(audit_module.GATES), len(set(audit_module.GATES)))
        self.assertEqual(audit_module.commands()[-1][1:4], ('-m', 'unittest', 'discover'))

    def test_launcher_version_comparison_is_mandatory(self):
        mutated = LAUNCHER.replace('$versions[0] -cne $RequiredVersion', '$false')
        self.assertNotEqual(mutated, LAUNCHER)
        self.assertTrue(module.validate(mutated, BATCH, SMOKE))

    def test_launcher_uses_fail_closed_version_query(self):
        mutated = LAUNCHER.replace('$exitCode -ne 0', '$false')
        self.assertNotEqual(mutated, LAUNCHER)
        self.assertTrue(module.validate(mutated, BATCH, SMOKE))


if __name__ == '__main__':
    unittest.main()
