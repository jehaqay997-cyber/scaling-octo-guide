"""Mutation-oriented tests for the PlayMode release contract."""
import json
import unittest
from pathlib import Path
from playmode_release_gate_v440 import inspect, ROOT

SCRIPT = (ROOT / 'Verification/Run-UnityVerification.ps1').read_text(encoding='utf-8')
SMOKE = (ROOT / 'Assets/_Project/Tests/PlayMode/IntegratedSceneSmokeTests.cs').read_text(encoding='utf-8')
ASMDEF = json.loads((ROOT / 'Assets/_Project/Tests/PlayMode/TheOrderRoom.Tests.PlayMode.asmdef').read_text(encoding='utf-8'))


class PlayModeReleaseGateTests(unittest.TestCase):
    def test_original_contract(self):
        self.assertEqual([], inspect(SCRIPT, SMOKE, ASMDEF))

    def test_missing_playmode_stage(self):
        broken = SCRIPT.replace('"-testPlatform", "PlayMode"', '"-testPlatform", "EditMode"')
        self.assertIn('script:playmode_process', inspect(broken, SMOKE, ASMDEF))

    def test_missing_playmode_failed_count_check(self):
        broken = SCRIPT.replace('$report.playmode_failed -ne 0', '$false')
        self.assertIn('script:playmode_failed_tests', inspect(broken, SMOKE, ASMDEF))

    def test_missing_playmode_exit_check(self):
        broken = SCRIPT.replace('$playExitCode -ne 0', '$false')
        self.assertIn('script:playmode_nonzero_exit', inspect(broken, SMOKE, ASMDEF))

    def test_missing_smoke_input_module(self):
        broken = SMOKE.replace('GetComponents<BaseInputModule>()', 'GetComponents<EventSystem>()')
        self.assertIn('smoke:ui_input_module', inspect(SCRIPT, broken, ASMDEF))

    def test_missing_smoke_raycaster(self):
        broken = SMOKE.replace('GetComponent<GraphicRaycaster>()', 'GetComponent<Canvas>()')
        self.assertIn('smoke:raycaster', inspect(SCRIPT, broken, ASMDEF))

    def test_missing_asmdef_runtime_reference(self):
        broken = dict(ASMDEF, references=['UnityEngine.UI'])
        self.assertIn('assembly:runtime', inspect(SCRIPT, SMOKE, broken))


if __name__ == '__main__':
    unittest.main()
