"""Fault-injection regressions for chapter catalog and checkpoint contracts."""
import unittest
from pathlib import Path
from chapter_catalog_integrity_gate_v461 import evaluate

ROOT = Path(__file__).resolve().parents[1]
PATHS = (
    'Assets/_Project/Runtime/ChapterGalleryView.cs',
    'Assets/_Project/Domain/ChapterOneProgress.cs',
    'Assets/_Project/Runtime/ChapterOneExperience.cs',
    'Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs',
    'Assets/_Project/Tests/EditMode/ChapterOneProgressTests.cs',
)
SOURCES = tuple((ROOT / p).read_text(encoding='utf-8') for p in PATHS)


class ChapterCatalogIntegrityGateTests(unittest.TestCase):
    def test_baseline(self):
        self.assertEqual([], evaluate(*SOURCES))

    def test_disordered_location_mapping(self):
        changed = SOURCES[0].replace('1, 1, 2, 2, 2, 2, 3, 3, 3, 4',
                                     '1, 1, 3, 2, 2, 2, 3, 3, 3, 4')
        self.assertTrue(evaluate(changed, *SOURCES[1:]))

    def test_chapter_catalog_validation_removed(self):
        changed = SOURCES[0].replace('if (!ValidateContentCatalog(out string catalogError))',
                                     'if (false)')
        self.assertTrue(evaluate(changed, *SOURCES[1:]))

    def test_noop_digit_write_restored(self):
        changed = SOURCES[1].replace('if (currentDigit == digit) return false;', '')
        self.assertTrue(evaluate(SOURCES[0], changed, *SOURCES[2:]))

    def test_ui_saves_redundantly(self):
        changed = SOURCES[2].replace('if (progress.SetDigit(index, (current + 1) % 10))\n                SaveProgress();',
                                     'progress.SetDigit(index, (current + 1) % 10);\n            SaveProgress();')
        self.assertTrue(evaluate(SOURCES[0], SOURCES[1], changed, *SOURCES[3:]))

    def test_unity_test_removed(self):
        changed = SOURCES[3].replace('ChapterCatalogHasCompleteOrderedUniqueLocationMappings', 'NoCheck')
        self.assertTrue(evaluate(*SOURCES[:3], changed, SOURCES[4]))


if __name__ == '__main__':
    unittest.main()
