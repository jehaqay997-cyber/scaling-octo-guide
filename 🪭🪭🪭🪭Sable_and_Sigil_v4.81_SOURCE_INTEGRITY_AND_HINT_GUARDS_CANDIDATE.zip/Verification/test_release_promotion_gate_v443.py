"""Static/mutation regression for Android artifact publication ordering.

Does not claim to execute PowerShell, Unity, or a device. Production acceptance
requires the full Run-UnityVerification.ps1 pipeline on the pinned Unity Editor.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "Verification" / "Run-UnityVerification.ps1"


def audit(source: str) -> list[str]:
    required = {
        "candidate output": '$stagedApkPath = Join-Path',
        "stage build": '[Environment]::SetEnvironmentVariable("TOR_ANDROID_APK_PATH", $stagedApkPath)',
        "stage existence": 'Assert-File $stagedApkPath "Staged Android APK"',
        "stage unzip": '[System.IO.Compression.ZipFile]::OpenRead($stagedApkPath)',
        "stage manifest": "$stagedEntries -ccontains 'AndroidManifest.xml'",
        "stage dex": "'^classes(\\d+)?\\.dex$'",
        "build success marker": 'Android build success marker missing',
        "source checksum": 'Assert-SourceUnchanged $sourceBaseline (Get-SourceFingerprint $ProjectPath)',
        "generated checksum": 'Assert-SourceUnchanged $generatedBaseline (Get-GeneratedFingerprint $ProjectPath)',
        "atomic publish": '[System.IO.File]::Move($stagedApkPath, $apkPath)',
        "published ownership": '$apkPublishedThisRun = $true',
        "final artifact check": 'Assert-File $apkPath "Android APK"',
        "final hash": '(Get-FileHash -LiteralPath $apkPath -Algorithm SHA256).Hash',
        "android pass": '$report.android = "PASS"',
        "cleanup candidate": 'Remove-Item -LiteralPath $stagedApkPath -Force -ErrorAction SilentlyContinue',
        "cleanup published on failure": 'Remove-Item -LiteralPath $apkPath -Force -ErrorAction SilentlyContinue',
    }
    errors = [f"Missing {name}" for name, fragment in required.items() if fragment not in source]
    if errors:
        return errors
    # Multiple source checks exist, so enforce the final pair immediately before publication.
    start = source.index('    $report.playmode = "PASS"')
    end = source.index('    $report.android = "PASS"', start)
    stage = source[start:end]
    required_stage = ("stage build", "stage existence", "stage unzip", "build success marker",
                      "source checksum", "generated checksum", "atomic publish",
                      "published ownership", "final artifact check", "final hash")
    if any(required[name] not in stage for name in required_stage):
        return ["One or more release stages were removed or moved outside the authorized sequence"]
    ordering = [
        stage.index(required["stage build"]),
        stage.index(required["stage existence"]),
        stage.index(required["stage unzip"]),
        stage.index(required["build success marker"]),
        stage.index(required["source checksum"]),
        stage.index(required["generated checksum"]),
        stage.index(required["atomic publish"]),
        stage.index(required["published ownership"]),
        stage.index(required["final artifact check"]),
        stage.index(required["final hash"]),
    ]
    if ordering != sorted(ordering) or len(set(ordering)) != len(ordering):
        errors.append("Invalid staged-build, checksum, publish or evidence ordering")
    return errors


class ReleasePromotionGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = RUNNER.read_text(encoding="utf-8-sig")

    def test_current_contract(self):
        self.assertEqual(audit(self.source), [])

    def test_detect_direct_release_build(self):
        altered = self.source.replace('SetEnvironmentVariable("TOR_ANDROID_APK_PATH", $stagedApkPath)',
                                      'SetEnvironmentVariable("TOR_ANDROID_APK_PATH", $apkPath)')
        self.assertTrue(audit(altered))

    def test_detect_missing_checksum(self):
        altered = self.source.replace('    Assert-SourceUnchanged $generatedBaseline (Get-GeneratedFingerprint $ProjectPath)',
                                      '    Write-Host "checksum intentionally removed"', 1)
        self.assertTrue(audit(altered))

    def test_detect_early_publication(self):
        marker = '        # Keep the checked candidate unpublished until BOTH source fingerprints pass.'
        altered = self.source.replace(marker, '        [System.IO.File]::Move($stagedApkPath, $apkPath)')
        self.assertTrue(audit(altered))

    def test_detect_missing_candidate_cleanup(self):
        altered = self.source.replace('Remove-Item -LiteralPath $stagedApkPath -Force -ErrorAction SilentlyContinue',
                                      'Write-Host "candidate cleanup disabled"')
        self.assertTrue(audit(altered))

    def test_detect_missing_final_hash(self):
        altered = self.source.replace('(Get-FileHash -LiteralPath $apkPath -Algorithm SHA256).Hash', '"unchecked"')
        self.assertTrue(audit(altered))

    def test_detect_missing_release_marker(self):
        altered = self.source.replace('Android build success marker missing', 'marker validation disabled')
        self.assertTrue(audit(altered))


if __name__ == '__main__':
    unittest.main()
