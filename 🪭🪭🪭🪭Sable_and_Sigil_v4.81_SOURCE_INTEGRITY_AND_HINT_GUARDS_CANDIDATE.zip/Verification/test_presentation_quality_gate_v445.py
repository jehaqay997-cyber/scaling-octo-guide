import unittest
from pathlib import Path
from presentation_quality_gate_v445 import BOOTSTRAP, VALIDATOR, PLAYMODE, validate


class PresentationQualityGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bootstrap = BOOTSTRAP.read_text(encoding='utf-8')
        cls.validator = VALIDATOR.read_text(encoding='utf-8')
        cls.playmode = PLAYMODE.read_text(encoding='utf-8')

    def test_current_scene_presentation_contract(self):
        self.assertEqual(validate(self.bootstrap, self.validator, self.playmode), [])

    def test_removing_hit_test_protection_is_rejected(self):
        changed = self.bootstrap.replace('image.raycastTarget = false;', 'image.raycastTarget = true;')
        self.assertNotEqual(validate(changed, self.validator, self.playmode), [])

    def test_removing_collider_cleanup_is_rejected(self):
        changed = self.bootstrap.replace('UnityEngine.Object.DestroyImmediate(collider);', 'UnityEngine.Object.Destroy(collider);')
        self.assertNotEqual(validate(changed, self.validator, self.playmode), [])

    def test_missing_visual_contract_is_rejected(self):
        changed = self.bootstrap.replace('"West Inlay"', '"Invalid Inlay"')
        self.assertNotEqual(validate(changed, self.validator, self.playmode), [])

    def test_missing_playmode_guard_is_rejected(self):
        changed = self.playmode.replace('Assert.That(matches[0].raycastTarget, Is.False', 'Assert.That(matches[0].raycastTarget, Is.True')
        self.assertNotEqual(validate(self.bootstrap, self.validator, changed), [])


if __name__ == '__main__':
    unittest.main()
