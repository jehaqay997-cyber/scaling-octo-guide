#!/usr/bin/env python3
"""Static contract for mandatory Unity PlayMode smoke test and release verification.

This is a source check; it does not execute Unity, NUnit, or device tests.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]


def inspect(script: str, smoke_test: str, definition: dict) -> list[str]:
    errors = []
    required_script = {
        'playmode_process': '"-testPlatform", "PlayMode"',
        'playmode_xml_path': 'playmode-results.xml',
        'playmode_xml_validation': '$playRoot.LocalName -ne "test-run"',
        'playmode_results_must_exist': 'Assert-File $playResultsXml',
        'playmode_nonzero_exit': '$playExitCode -ne 0',
        'playmode_nonempty': '$report.playmode_total -le 0',
        'playmode_failed_tests': '$report.playmode_failed -ne 0',
        'playmode_status': '$report.playmode = "PASS"',
        'release_requires_pass': '$report.status = "PASS"',
        'source_immutable': 'Assert-SourceUnchanged $sourceBaseline (Get-SourceFingerprint $ProjectPath)',
        'generated_immutable': 'Assert-SourceUnchanged $generatedBaseline (Get-GeneratedFingerprint $ProjectPath)',
    }
    required_tests = {
        'scene_load': 'SceneManager.LoadSceneAsync(ScenePath, LoadSceneMode.Single)',
        'unity_test': '[UnityTest]',
        'game_binding': 'GetComponentsInChildren<OrderGame>(true)',
        'pointer_binding': 'GetComponentsInChildren<OrderPointerInput>(true)',
        'ui_event_system': 'GetComponentsInChildren<EventSystem>(true)',
        'ui_input_module': 'GetComponents<BaseInputModule>()',
        'camera': 'GetComponentsInChildren<Camera>(true)',
        'canvas': 'GetComponentsInChildren<Canvas>(true)',
        'raycaster': 'GetComponent<GraphicRaycaster>()',
        'button': 'GetComponentsInChildren<Button>(true)',
        'governor': 'GetComponentsInChildren<OrderPerformanceGovernor>(true)',
        'screen_layout': 'GetComponentsInChildren<OrderScreenLayout>(true)',
    }
    errors.extend('script:' + key for key, token in required_script.items() if token not in script)
    errors.extend('smoke:' + key for key, token in required_tests.items() if token not in smoke_test)
    if definition.get('name') != 'TheOrderRoom.Tests.PlayMode':
        errors.append('assembly:name')
    if 'UNITY_INCLUDE_TESTS' not in definition.get('defineConstraints', []):
        errors.append('assembly:test_define')
    if 'nunit.framework.dll' not in definition.get('precompiledReferences', []):
        errors.append('assembly:nunit')
    if 'TheOrderRoom.Runtime' not in definition.get('references', []):
        errors.append('assembly:runtime')
    return errors


def main() -> int:
    script = (ROOT / 'Verification/Run-UnityVerification.ps1').read_text(encoding='utf-8')
    test = (ROOT / 'Assets/_Project/Tests/PlayMode/IntegratedSceneSmokeTests.cs').read_text(encoding='utf-8')
    definition = json.loads((ROOT / 'Assets/_Project/Tests/PlayMode/TheOrderRoom.Tests.PlayMode.asmdef').read_text(encoding='utf-8'))
    errors = inspect(script, test, definition)
    result = {'gate': 'playmode_release_gate_v440', 'status': 'STATIC_PASS_ONLY' if not errors else 'FAIL',
              'errors': errors, 'unity_compiled': False, 'editmode_executed': False,
              'playmode_executed': False, 'android_verified': False}
    print(json.dumps(result, indent=2))
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
