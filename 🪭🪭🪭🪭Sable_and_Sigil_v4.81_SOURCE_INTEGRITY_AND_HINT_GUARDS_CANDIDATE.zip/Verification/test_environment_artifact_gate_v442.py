"""Fail-closed static regression tests for the editor and APK artifact gates.

These tests do not execute PowerShell, Unity, or Android. They verify the
contractual ordering of safety checks so accidental changes are detected.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'Verification' / 'Run-UnityVerification.ps1'


def validate_gate(code: str) -> list[str]:
    issues = []
    required = {
        'version_query': '& $UnityEditorPath -version',
        'version_exit': '$editorVersionExit -ne 0',
        'exact_comparison': '$installedVersions[0] -cne $requiredVersion',
        'manifest_entry': "-ccontains 'AndroidManifest.xml'",
        'dex_entry': "'^classes(\\d+)?\\.dex$'",
        'apk_archive': '[System.IO.Compression.ZipFile]::OpenRead($stagedApkPath)',
        'zip_dispose': '$apkArchive.Dispose()',
        'final_report': '$report.status = "PASS"',
    }
    for label, fragment in required.items():
        if fragment not in code:
            issues.append('Missing ' + label)
    if all(required[k] in code for k in ('version_query', 'exact_comparison')):
        if code.index(required['version_query']) >= code.index('$sourceBaseline = Get-SourceFingerprint'):
            issues.append('Editor version must be checked before project verification')
    if all(required[k] in code for k in ('apk_archive', 'manifest_entry', 'dex_entry')):
        if not (code.index('Assert-File $stagedApkPath') < code.index(required['apk_archive']) <
                code.index(required['manifest_entry']) < code.index(required['dex_entry']) <
                code.index('[System.IO.File]::Move($stagedApkPath, $apkPath)') <
                code.index('$report.android = "PASS"')):
            issues.append('APK inspection must precede Android acceptance')
    return issues


class EnvironmentArtifactGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = SCRIPT.read_text(encoding='utf-8')

    def test_valid_contract(self):
        self.assertEqual(validate_gate(self.source), [])

    def test_detect_removed_editor_check(self):
        modified = self.source.replace('$installedVersions[0] -cne $requiredVersion',
                                       '$installedVersions[0] -cne "arbitrary"')
        self.assertTrue(validate_gate(modified))

    def test_detect_removed_manifest_check(self):
        modified = self.source.replace("-ccontains 'AndroidManifest.xml'", "-ccontains 'any.file'")
        self.assertTrue(validate_gate(modified))

    def test_detect_removed_dex_check(self):
        modified = self.source.replace("'^classes(\\d+)?\\.dex$'", "'^any$'")
        self.assertTrue(validate_gate(modified))

    def test_detect_order_regression(self):
        modified = self.source.replace('& $UnityEditorPath -version 2>&1',
                                       '# version query intentionally displaced', 1)
        modified = modified.replace('$sourceBaseline = Get-SourceFingerprint $ProjectPath',
                                    '$sourceBaseline = Get-SourceFingerprint $ProjectPath\n& $UnityEditorPath -version 2>&1', 1)
        self.assertIn('Editor version must be checked before project verification', validate_gate(modified))


if __name__ == '__main__':
    unittest.main()
