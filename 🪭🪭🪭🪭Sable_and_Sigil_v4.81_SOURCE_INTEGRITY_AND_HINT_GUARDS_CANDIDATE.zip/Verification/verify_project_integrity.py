#!/usr/bin/env python3
"""Static Unity package integrity preflight; does not compile or run Unity."""
import collections
import json
import pathlib
import re
import sys
import zipfile


def validate(path):
    errors = []
    warnings = []
    with zipfile.ZipFile(path) as archive:
        names = [n for n in archive.namelist() if not n.endswith('/')]
        contents = {n: archive.read(n) for n in names}
        if archive.testzip() is not None:
            errors.append('ZIP_CRC_FAILURE')
        duplicates = [n for n, count in collections.Counter(names).items() if count > 1]
        if duplicates:
            errors.append('DUPLICATE_ARCHIVE_PATH: ' + ', '.join(duplicates))
        for name in names:
            parts = pathlib.PurePosixPath(name).parts
            if name.startswith('/') or '..' in parts or '\\' in name:
                errors.append('UNSAFE_ARCHIVE_PATH: ' + name)
            if not contents[name]:
                errors.append('EMPTY_FILE: ' + name)
        assemblies = {}
        for name in names:
            if name.endswith('.asmdef'):
                try:
                    value = json.loads(contents[name])
                    assembly = value['name']
                    if assembly in assemblies:
                        errors.append('DUPLICATE_ASSEMBLY: ' + assembly)
                    assemblies[assembly] = (name, value)
                except (ValueError, KeyError, UnicodeDecodeError) as exc:
                    errors.append('INVALID_ASMDEF: ' + name + ': ' + str(exc))
            elif name.endswith('.json'):
                try:
                    json.loads(contents[name])
                except (ValueError, UnicodeDecodeError) as exc:
                    errors.append('INVALID_JSON: ' + name + ': ' + str(exc))
        known_external = {'UnityEngine.UI', 'Unity.InputSystem', 'UnityEngine.TestRunner', 'UnityEditor.TestRunner'}
        for assembly, (name, value) in assemblies.items():
            for dependency in value.get('references', []):
                if dependency not in assemblies and dependency not in known_external and not dependency.startswith('GUID:'):
                    errors.append('UNRESOLVED_ASSEMBLY_REFERENCE: ' + name + ' -> ' + dependency)
            if value.get('noEngineReferences'):
                prefix = name.rsplit('/', 1)[0] + '/'
                for source in names:
                    if source.startswith(prefix) and source.endswith('.cs'):
                        code = contents[source].decode('utf-8-sig', errors='replace')
                        if re.search(r'^\s*using\s+(UnityEngine|UnityEditor)(\.|\s*;)', code, re.M):
                            errors.append('UNITY_REFERENCE_IN_PURE_ASSEMBLY: ' + source)
        for name in names:
            if name.startswith('Assets/') and not name.endswith('.meta') and not name.endswith('.DS_Store'):
                if name + '.meta' not in contents:
                    errors.append('MISSING_META: ' + name)
        guids = collections.defaultdict(list)
        for name in names:
            if name.endswith('.meta'):
                match = re.search(rb'(?m)^guid:\s*([a-fA-F0-9]{32})\s*$', contents[name])
                if not match:
                    errors.append('INVALID_META_GUID: ' + name)
                else:
                    guids[match.group(1).lower()].append(name)
        for guid, paths in guids.items():
            if len(paths) > 1:
                errors.append('DUPLICATE_META_GUID: ' + ', '.join(paths))
        version = contents.get('ProjectSettings/ProjectVersion.txt', b'').decode(errors='replace').strip()
        if '6000.3.28f1' not in version:
            warnings.append('UNITY_TARGET_NOT_VERIFIED: ' + version)
        if 'Packages/packages-lock.json' not in contents:
            warnings.append('PACKAGE_LOCK_MISSING: regenerate through Unity Package Manager')
        if not any(n.endswith('.unity') for n in names):
            warnings.append('NO_SAVED_SCENE: generate with ChapterOneSceneBuilder after compile')
        if not any(n.endswith('AuthoredPuzzleHintController.cs') for n in names):
            errors.append('HINT_CONTROLLER_MISSING')
        return {'status': 'PASS_STATIC_ONLY' if not errors else 'FAIL_STATIC',
                'file_count': len(names), 'assembly_count': len(assemblies),
                'errors': errors, 'warnings': warnings,
                'compile_verified': False, 'editmode_verified': False, 'android_verified': False}


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python verify_project_integrity.py PROJECT.zip')
    result = validate(sys.argv[1])
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if not result['errors'] else 1)
