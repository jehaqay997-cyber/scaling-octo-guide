"""Mutation checks for the UI pointer event allocation contract."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ui_pointer_allocation_gate_v444 import SOURCE, check_source


class UiPointerAllocationGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = SOURCE.read_text(encoding='utf-8')

    def test_correct_source_passes(self):
        self.assertEqual(check_source(self.source), [])

    def test_reset_is_required(self):
        altered = self.source.replace('cachedUiPointerEvent.Reset();', '/* Reset removed */')
        self.assertNotEqual(check_source(altered), [])

    def test_raycast_must_use_cached_pointer(self):
        altered = self.source.replace('eventSystem.RaycastAll(cachedUiPointerEvent, UiRaycastHits);',
                                      'eventSystem.RaycastAll(new PointerEventData(eventSystem), UiRaycastHits);')
        self.assertNotEqual(check_source(altered), [])

    def test_event_system_switch_must_be_detected(self):
        altered = self.source.replace('!ReferenceEquals(cachedUiEventSystem, eventSystem)', 'false')
        self.assertNotEqual(check_source(altered), [])

    def test_ui_router_missing_must_block_world(self):
        altered = self.source.replace(
            'if (eventSystem == null || !eventSystem.isActiveAndEnabled) return true;',
            'if (eventSystem == null || !eventSystem.isActiveAndEnabled) return false;')
        self.assertNotEqual(check_source(altered), [])


if __name__ == '__main__':
    unittest.main()
