#!/usr/bin/env python3
"""Validate design-only puzzle and image linkage without importing Unity."""
import hashlib
import json
import sys
import zipfile

CATALOG = "Design/SCENE_PUZZLE_CONTRACT_v4.65.json"


def validate(archive_path):
    with zipfile.ZipFile(archive_path) as archive:
        data = json.loads(archive.read(CATALOG))
        puzzles = data["puzzles"]
        assert data["schema_version"] == 1
        assert data["status"] == "DESIGN_ONLY_NOT_RUNTIME_VERIFIED"
        assert len(puzzles) == data["location_count"] == 10
        assert data["chapter_count"] == 4
        ids = [entry["id"] for entry in puzzles]
        assert len(ids) == len(set(ids))
        evidence_ids = [entry["evidence_id"] for entry in puzzles]
        assert len(evidence_ids) == len(set(evidence_ids))
        completed = set()
        previous_chapter = 1
        seen_chapters = set()
        for entry in puzzles:
            assert entry["chapter"] >= previous_chapter
            assert 1 <= entry["chapter"] <= 4
            previous_chapter = entry["chapter"]
            seen_chapters.add(entry["chapter"])
            assert entry["prerequisites"] == list(dict.fromkeys(entry["prerequisites"]))
            assert all(dep in completed for dep in entry["prerequisites"])
            assert entry["runtime_binding"] == "NOT_IMPLEMENTED"
            assert entry["solvability"] == "DESIGN_ONLY_UNPROVEN"
            assert len(entry["hint_tiers"]) == 3
            assert all(isinstance(h, str) and h.strip() for h in entry["hint_tiers"])
            assert hashlib.sha256(archive.read(entry["art"])).hexdigest() == entry["art_sha256"]
            completed.add(entry["evidence_id"])
        assert seen_chapters == {1, 2, 3, 4}
        assert archive.testzip() is None
    return True


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python verify_scene_puzzle_contract_v465.py <archive.zip>")
    validate(sys.argv[1])
    print("PASS: design catalog, prerequisite order, artwork hashes and ZIP CRC")
