"""Mutation regression tests for the chapter atlas contract."""
import unittest
from pathlib import Path
from chapter_atlas_coherence_gate_v462 import validate

ROOT = Path(__file__).resolve().parents[1]
GALLERY = (ROOT / 'Assets/_Project/Runtime/ChapterGalleryView.cs').read_text(encoding='utf-8')
TESTS = (ROOT / 'Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs').read_text(encoding='utf-8')


class ChapterAtlasCoherenceGateTests(unittest.TestCase):
    def test_current_contract_passes(self):
        self.assertEqual([], validate(GALLERY, TESTS))

    def test_missing_texture_release_is_rejected(self):
        source = GALLERY.replace('                ReleaseChapterTexture();\n                FitArtwork(scene);',
                                 '                FitArtwork(scene);')
        self.assertTrue(validate(source, TESTS))

    def test_cross_chapter_navigation_is_rejected(self):
        source = GALLERY.replace('selectedIndex = GetChapterForLocation(locationIndex + 1) - 1;',
                                 'selectedIndex = 0;')
        self.assertTrue(validate(source, TESTS))

    def test_unchecked_location_mapping_is_rejected(self):
        source = GALLERY.replace('locationNumber < 1 || locationNumber > LocationCount',
                                 'locationNumber < 0')
        self.assertTrue(validate(source, TESTS))

    def test_missing_playmode_coverage_is_rejected(self):
        self.assertTrue(validate(GALLERY, TESTS.replace(
            'ChapterAndLocationImagesNeverStayResidentTogether', 'RemovedCoverage')))


if __name__ == '__main__':
    unittest.main()
