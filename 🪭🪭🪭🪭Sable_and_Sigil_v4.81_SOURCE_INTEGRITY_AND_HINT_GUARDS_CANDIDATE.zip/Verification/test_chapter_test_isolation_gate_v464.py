"""Fault-injection checks that ensure the v4.64 regression gate fails closed."""
import unittest
from pathlib import Path
from chapter_test_isolation_gate_v464 import validate

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = (ROOT / 'Assets/_Project/Runtime/ChapterOneExperience.cs').read_text(encoding='utf-8')
TESTS = (ROOT / 'Assets/_Project/Tests/PlayMode/ChapterOneSceneTests.cs').read_text(encoding='utf-8')


class ChapterTestIsolationGateTests(unittest.TestCase):
    def test_baseline_passes(self):
        self.assertEqual([], validate(RUNTIME, TESTS))

    def test_orphan_camera_is_rejected(self):
        bad = RUNTIME.replace('cameraGo.transform.SetParent(transform, false);', '')
        self.assertTrue(validate(bad, TESTS))

    def test_missing_finally_is_rejected(self):
        bad = TESTS.replace('            finally\n            {\n                // PlayMode checks must never overwrite the player\'s real progress.',
                            '            catch (System.Exception)\n            {\n                // PlayMode checks must never overwrite the player\'s real progress.')
        self.assertTrue(validate(RUNTIME, bad))

    def test_missing_checkpoint_recovery_is_rejected(self):
        bad = TESTS.replace('if (hadB) PlayerPrefs.SetString(slotB, oldB);', 'if (hadB) PlayerPrefs.DeleteKey(slotB);')
        self.assertTrue(validate(RUNTIME, bad))

    def test_missing_camera_destructor_test_is_rejected(self):
        bad = TESTS.replace('ChapterOwnedFallbackCamera_IsRemovedWhenChapterIsDestroyed', 'DisabledCameraTest')
        self.assertTrue(validate(RUNTIME, bad))


if __name__ == '__main__':
    unittest.main()
