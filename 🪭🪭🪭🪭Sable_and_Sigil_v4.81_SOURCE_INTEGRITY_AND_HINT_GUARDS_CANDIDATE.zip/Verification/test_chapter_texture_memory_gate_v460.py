"""Mutation-oriented regression checks for the gallery memory gate."""
import unittest
from pathlib import Path

from chapter_texture_memory_gate_v460 import validate

ROOT = Path(__file__).resolve().parents[1]
GALLERY = (ROOT / 'Assets/_Project/Runtime/ChapterGalleryView.cs').read_text(encoding='utf-8')
TESTS = (ROOT / 'Assets/_Project/Tests/PlayMode/ChapterArtGalleryTests.cs').read_text(encoding='utf-8')
CHAPTER = (ROOT / 'Assets/_Project/Runtime/ChapterOneExperience.cs').read_text(encoding='utf-8')


class ChapterTextureMemoryGateTests(unittest.TestCase):
    def test_baseline_passes(self):
        self.assertEqual([], validate(GALLERY, TESTS, CHAPTER))

    def test_detects_texture_not_detached(self):
        modified = GALLERY.replace('artwork.texture = null;', 'artwork.color = Color.white;')
        self.assertTrue(validate(modified, TESTS, CHAPTER))

    def test_detects_missing_close_release(self):
        modified = GALLERY.replace('''            ReleaseLocationTexture();
            ReleaseChapterTexture();
        }''', '''            ReleaseLocationTexture();
        }''', 1)
        self.assertTrue(validate(modified, TESTS, CHAPTER))

    def test_detects_preload_in_build(self):
        modified = GALLERY.replace('''        private void Build()
        {
''', '''        private void Build()
        {
            Resources.Load<Texture2D>("ChapterArt/Chapter_01");
''', 1)
        self.assertTrue(validate(modified, TESTS, CHAPTER))

    def test_detects_missing_reopen_test(self):
        modified = TESTS.replace('ChapterArtworkLoadsOnDemandAndReleasesWhenClosed',
                                 'ChapterArtworkMemoryContractNotCovered')
        self.assertTrue(validate(GALLERY, modified, CHAPTER))

    def test_detects_world_update_while_gallery_opaque(self):
        modified = CHAPTER.replace(
            'if (!initialized || (chapterGallery != null && chapterGallery.IsOpen)) return;',
            'if (!initialized) return;')
        self.assertTrue(validate(GALLERY, TESTS, modified))

    def test_detects_unbounded_resident_chapter_count(self):
        modified = TESTS.replace(
            'Assert.That(gallery.ResidentChapterArtworkCount, Is.Zero);',
            'Assert.That(gallery.IsOpen, Is.False);')
        self.assertTrue(validate(GALLERY, modified, CHAPTER))


if __name__ == '__main__':
    unittest.main()
