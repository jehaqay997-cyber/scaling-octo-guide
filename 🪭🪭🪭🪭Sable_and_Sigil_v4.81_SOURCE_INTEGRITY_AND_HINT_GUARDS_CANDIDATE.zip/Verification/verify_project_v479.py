#!/usr/bin/env python3
"""Independent, read-only project archive integrity gate."""
import json
import pathlib
import sys
import zipfile
from collections import Counter


def audit(path):
    errors = []
    with zipfile.ZipFile(path) as archive:
        names = [i.filename for i in archive.infolist() if not i.is_dir()]
        name_set = set(names)
        for name, count in Counter(names).items():
            if count > 1:
                errors.append('Duplicate path: ' + name)
        for name in names:
            p = pathlib.PurePosixPath(name)
            if p.is_absolute() or '..' in p.parts or '\\' in name:
                errors.append('Unsafe path: ' + name)
            if archive.getinfo(name).file_size == 0:
                errors.append('Empty file: ' + name)
        bad = archive.testzip()
        if bad:
            errors.append('CRC failure: ' + bad)
        assemblies = {}
        for name in names:
            if name.endswith(('.json', '.asmdef')):
                try:
                    obj = json.loads(archive.read(name))
                    if name.endswith('.asmdef'):
                        assembly = obj['name']
                        if assembly in assemblies:
                            errors.append('Duplicate assembly: ' + assembly)
                        assemblies[assembly] = (name, obj)
                except (ValueError, KeyError) as exc:
                    errors.append('Invalid JSON/asmdef: ' + name + ': ' + str(exc))
        builtins = {'UnityEngine.UI', 'Unity.InputSystem', 'UnityEngine.TestRunner', 'UnityEditor.TestRunner'}
        for assembly, (name, obj) in assemblies.items():
            for reference in obj.get('references', []):
                if reference not in assemblies and reference not in builtins and not reference.startswith('GUID:'):
                    errors.append('Unresolved assembly reference: ' + name + ' -> ' + reference)
        for name in names:
            if name.startswith('Assets/') and not name.endswith('.meta') and name + '.meta' not in name_set:
                errors.append('Missing meta: ' + name)
        return {'archive': str(path), 'entries': len(names), 'assemblies': len(assemblies), 'errors': errors,
                'unity_compile_verified': False, 'android_verified': False}


if __name__ == '__main__':
    result = audit(pathlib.Path(sys.argv[1]))
    print(json.dumps(result, indent=2))
    sys.exit(1 if result['errors'] else 0)
