"""Regression checks for auto-launch startup contracts; not executable Unity tests."""
from pathlib import Path
import unittest
from first_open_game_gate_v446 import validate

ROOT = Path(__file__).resolve().parents[1]
FIRST = (ROOT / 'Assets/_Project/Editor/OrderFirstImportSetup.cs').read_text(encoding='utf-8')
BOOTSTRAP = (ROOT / 'Assets/_Project/Editor/OrderProjectBootstrap.cs').read_text(encoding='utf-8')
PREVIEW = (ROOT / 'PLAY_GAME_NOW.html').read_text(encoding='utf-8')


class FirstOpenGameContractTests(unittest.TestCase):
    def test_clean_contract(self):
        self.assertEqual(validate(FIRST, BOOTSTRAP, PREVIEW), [])

    def test_missing_autoplay_is_rejected(self):
        self.assertTrue(validate(FIRST.replace('EditorApplication.isPlaying = true;', ''), BOOTSTRAP, PREVIEW))

    def test_missing_safety_prompt_is_rejected(self):
        self.assertTrue(validate(FIRST, BOOTSTRAP.replace('SaveCurrentModifiedScenesIfUserWantsTo()', 'true'), PREVIEW))

    def test_missing_scene_generation_is_rejected(self):
        self.assertTrue(validate(FIRST, BOOTSTRAP.replace('if (!File.Exists(ScenePath)) CreateMainScene();', ''), PREVIEW))

    def test_missing_local_progress_is_rejected(self):
        self.assertTrue(validate(FIRST, BOOTSTRAP, PREVIEW.replace('localStorage.setItem', 'disabledPersistence')))

    def test_external_javascript_is_rejected(self):
        self.assertTrue(validate(FIRST, BOOTSTRAP, PREVIEW + '<script src="https://example.org/foreign.js"></script>'))


if __name__ == '__main__':
    unittest.main()
