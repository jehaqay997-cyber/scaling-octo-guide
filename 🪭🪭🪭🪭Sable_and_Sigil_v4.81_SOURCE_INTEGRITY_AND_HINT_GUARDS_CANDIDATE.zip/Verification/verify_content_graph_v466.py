#!/usr/bin/env python3
"""Deterministic content graph validation; does not assert Unity runtime readiness."""
import hashlib
import json
import sys
import zipfile

CATALOG = "Design/SCENE_PUZZLE_CONTRACT_v4.65.json"


def validate_catalog(data, read_art):
    if not isinstance(data, dict) or data.get("schema_version") != 1:
        raise ValueError("Unsupported content schema")
    puzzles = data.get("puzzles")
    if not isinstance(puzzles, list) or not puzzles:
        raise ValueError("Empty or invalid puzzle catalog")
    if len(puzzles) != data.get("location_count"):
        raise ValueError("Location count mismatch")
    if data.get("status") != "DESIGN_ONLY_NOT_RUNTIME_VERIFIED":
        raise ValueError("Unexpected verification status")
    ids, evidence, art_paths = set(), set(), set()
    for item in puzzles:
        if not isinstance(item, dict):
            raise ValueError("Invalid puzzle record")
        for field in ("id", "evidence_id", "art", "title", "puzzle_type", "clue_source"):
            if not isinstance(item.get(field), str) or not item[field].strip():
                raise ValueError("Missing field: " + field)
        if item["id"] in ids or item["evidence_id"] in evidence or item["art"] in art_paths:
            raise ValueError("Duplicate puzzle, evidence or artwork")
        ids.add(item["id"])
        evidence.add(item["evidence_id"])
        art_paths.add(item["art"])
        if item.get("runtime_binding") != "NOT_IMPLEMENTED" or item.get("solvability") != "DESIGN_ONLY_UNPROVEN":
            raise ValueError("Unsubstantiated runtime or solvability status")
        hints = item.get("hint_tiers")
        if not isinstance(hints, list) or len(hints) != 3 or any(not isinstance(h, str) or not h.strip() for h in hints):
            raise ValueError("Invalid hint tiers")
        if not isinstance(item.get("chapter"), int) or isinstance(item["chapter"], bool) or item["chapter"] < 1:
            raise ValueError("Invalid chapter")
        digest = item.get("art_sha256")
        if not isinstance(digest, str) or len(digest) != 64:
            raise ValueError("Invalid art digest")
        try:
            bytes.fromhex(digest)
        except ValueError as exc:
            raise ValueError("Invalid art digest") from exc
        if hashlib.sha256(read_art(item["art"])).hexdigest() != digest:
            raise ValueError("Artwork digest mismatch: " + item["id"])
    if len({p["chapter"] for p in puzzles}) != data.get("chapter_count"):
        raise ValueError("Chapter count mismatch")
    graph = {}
    evidence_to_id = {p["evidence_id"]: p["id"] for p in puzzles}
    for item in puzzles:
        deps = item.get("prerequisites")
        if not isinstance(deps, list) or len(deps) != len(set(deps)):
            raise ValueError("Invalid or repeated prerequisites")
        if any(dep not in evidence_to_id for dep in deps):
            raise ValueError("Missing evidence prerequisite")
        if item["evidence_id"] in deps:
            raise ValueError("Self dependency")
        graph[item["id"]] = [evidence_to_id[d] for d in deps]
    state = {}
    ordered = []
    def visit(node):
        if state.get(node) == 1:
            raise ValueError("Cyclic evidence dependency")
        if state.get(node) == 2:
            return
        state[node] = 1
        for dependency in graph[node]:
            visit(dependency)
        state[node] = 2
        ordered.append(node)
    for node in graph:
        visit(node)
    by_id = {p["id"]: p for p in puzzles}
    if any(by_id[dep]["chapter"] > by_id[node]["chapter"] for node in graph for dep in graph[node]):
        raise ValueError("Prerequisite points to a later chapter")
    if any(p["chapter"] != q["chapter"] and p["chapter"] > q["chapter"] for p, q in zip(puzzles, puzzles[1:])):
        raise ValueError("Chapters out of sequence")
    reachable = set()
    for node in ordered:
        if all(dep in reachable for dep in graph[node]):
            reachable.add(node)
    if len(reachable) != len(puzzles):
        raise ValueError("Unreachable puzzle")
    return {"puzzle_count": len(puzzles), "chapter_count": data["chapter_count"], "topological_order": ordered, "verification": "STATIC_CONTENT_GRAPH_ONLY"}


def validate_archive(path):
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC failure")
        data = json.loads(archive.read(CATALOG))
        return validate_catalog(data, archive.read)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python verify_content_graph_v466.py <archive.zip>")
    print(json.dumps(validate_archive(sys.argv[1]), indent=2))
