#!/usr/bin/env python3
"""Independent, read-only archive integrity check; not a Unity compilation test."""
import argparse
import io
import json
import pathlib
import re
import sys
import zipfile
from collections import Counter

MAX_UNCOMPRESSED_BYTES = 200_000_000

def check_archive(path):
    errors = []
    warnings = []
    with zipfile.ZipFile(path) as archive:
        entries = [i for i in archive.infolist() if not i.is_dir()]
        names = [i.filename for i in entries]
        for name, count in Counter(names).items():
            if count > 1: errors.append('Duplicate archive entry: ' + name)
        for info in entries:
            p = pathlib.PurePosixPath(info.filename)
            if info.filename.startswith('/') or '..' in p.parts or chr(92) in info.filename:
                errors.append('Unsafe path: ' + info.filename)
            if info.file_size == 0: errors.append('Empty file: ' + info.filename)
            if info.file_size > MAX_UNCOMPRESSED_BYTES:
                errors.append('Oversized entry: ' + info.filename)
        bad = archive.testzip()
        if bad: errors.append('CRC mismatch: ' + bad)
        paths = set(names)
        assemblies = {}
        for name in names:
            if name.endswith(('.json','.asmdef')):
                try: obj = json.loads(archive.read(name))
                except (ValueError, UnicodeError) as e:
                    errors.append('Invalid JSON: ' + name + ': ' + str(e)); continue
                if name.endswith('.asmdef'):
                    assembly_name = obj.get('name')
                    if not isinstance(assembly_name,str) or not assembly_name:
                        errors.append('Missing assembly name: '+name)
                    elif assembly_name in assemblies:
                        errors.append('Duplicate assembly name: '+assembly_name)
                    else: assemblies[assembly_name]=(name,obj)
        for asm,(asm_path,obj) in assemblies.items():
            for ref in obj.get('references',[]):
                if ref.startswith('GUID:'): continue
                if ref not in assemblies and not ref.startswith(('Unity.', 'UnityEngine.', 'UnityEditor.')):
                    errors.append('Unresolved assembly reference: '+asm+' -> '+ref)
            if obj.get('noEngineReferences'):
                folder=asm_path.rsplit('/',1)[0]+'/'
                for file in names:
                    if file.startswith(folder) and file.endswith('.cs'):
                        source=archive.read(file).decode('utf-8-sig',errors='replace')
                        if re.search(r'\b(?:using\s+(?:static\s+)?Unity(?:Engine|Editor)\b|UnityEngine\.|UnityEditor\.)',source):
                            errors.append('Unity API in no-engine assembly: '+file)
        guids={}
        for name in names:
            if name.endswith('.meta'):
                data=archive.read(name).decode('utf-8-sig',errors='replace')
                match=re.search(r'(?m)^guid:\s*([0-9a-fA-F]{32})\s*$',data)
                if not match: errors.append('Missing or invalid GUID: '+name)
                elif match.group(1).lower() in guids:
                    errors.append('Duplicate GUID: '+name+' and '+guids[match.group(1).lower()])
                else: guids[match.group(1).lower()]=name
        version=archive.read('ProjectSettings/ProjectVersion.txt').decode(errors='replace') if 'ProjectSettings/ProjectVersion.txt' in paths else ''
        if '6000.3.28f1' not in version:
            warnings.append('Unity 6.3.28f1 compatibility is unverified; ProjectVersion.txt differs.')
        if 'Packages/packages-lock.json' not in paths:
            warnings.append('packages-lock.json absent; package resolution not reproducibly verified.')
        if not any(n.endswith('.unity') for n in names):
            warnings.append('No saved .unity scene packaged; editor generation may be required.')
    return {'archive':str(path),'entries':len(entries),'assemblies':len(assemblies),'errors':errors,'warnings':warnings,'status':'STATIC_PASS' if not errors else 'STATIC_FAIL', 'unity_compile':'NOT_EXECUTED','editmode':'NOT_EXECUTED','android':'NOT_EXECUTED'}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('archive',type=pathlib.Path)
    args=parser.parse_args()
    result=check_archive(args.archive)
    print(json.dumps(result,indent=2))
    return 0 if not result['errors'] else 1

if __name__=='__main__': sys.exit(main())
