#!/usr/bin/env python3
"""Static regression contract for uGUI pointer delivery; not a Unity runtime test."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def inspect(source: str) -> list[str]:
    contracts = {
        "input_module_enabled": "!module.isActiveAndEnabled" in source,
        "single_active_module": "GetComponents<BaseInputModule>().Count(x => x.isActiveAndEnabled) != 1" in source,
        "canvas_raycaster": "canvas.TryGetComponent<GraphicRaycaster>(out var raycaster)" in source
        and "!raycaster.isActiveAndEnabled" in source,
        "button_target_graphic": "button.targetGraphic == null" in source
        and "!button.targetGraphic.isActiveAndEnabled" in source
        and "!button.targetGraphic.raycastTarget" in source,
        "button_canvas_raycaster": "button.GetComponentInParent<Canvas>()" in source
        and "buttonRaycaster.isActiveAndEnabled" in source,
        "exact_button_callbacks": "button.onClick.GetPersistentMethodName(0) != expectedMethod" in source,
    }
    return [name for name, supported in contracts.items() if not supported]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    source = args.project / "Assets/_Project/Editor/OrderSceneValidator.cs"
    if not source.is_file():
        problems = ["missing_scene_validator"]
    else:
        problems = inspect(source.read_text(encoding="utf-8"))
    result = {
        "gate": "ui_event_delivery_v439",
        "status": "STATIC_PASS_ONLY" if not problems else "FAIL",
        "issues": problems,
        "runtime_verified": False,
        "unity_compiled": False,
    }
    if args.report is not None:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return int(bool(problems))


if __name__ == "__main__":
    raise SystemExit(main())
