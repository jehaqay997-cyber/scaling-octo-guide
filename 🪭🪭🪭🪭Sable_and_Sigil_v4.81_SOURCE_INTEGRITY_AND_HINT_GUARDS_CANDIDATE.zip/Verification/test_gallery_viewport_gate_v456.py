"""Mutation-style regression checks for the safe-area and screen-ray contract."""
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from gallery_viewport_gate_v456 import check, CONTRACTS, ROOT


class GalleryViewportGateTests(unittest.TestCase):
    def test_original_sources_pass(self):
        self.assertEqual(check(ROOT), [])

    def test_each_contract_is_mandatory(self):
        for filename, contracts in CONTRACTS.items():
            contents = (ROOT / filename).read_text(encoding='utf-8')
            for fragment in contracts:
                with self.subTest(file=str(filename), fragment=fragment), TemporaryDirectory() as temporary:
                    root = Path(temporary)
                    for other in CONTRACTS:
                        target = root / other
                        target.parent.mkdir(parents=True, exist_ok=True)
                        text = (ROOT / other).read_text(encoding='utf-8')
                        if other == filename:
                            text = text.replace(fragment, 'MUTATED_CONTRACT')
                        target.write_text(text, encoding='utf-8')
                    self.assertTrue(check(root))

    def test_missing_required_source_fails(self):
        with TemporaryDirectory() as temporary:
            self.assertTrue(check(Path(temporary)))


if __name__ == '__main__':
    unittest.main()
